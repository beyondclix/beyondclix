import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword.dart';
import '../common_functions.dart';

class KeywordsPage extends StatelessWidget {
  KeywordsPage(this.keywords);
  final List<Keyword> keywords;

  @override
  Widget build(BuildContext context) {
    return /*Scaffold(
        appBar: AppBar(
          title: Text("Keywords"),
          actions: <Widget>[
            Padding(
                padding: EdgeInsets.only(right: 20.0),
                child: GestureDetector(
                  onTap: () {
                    // Navigator.push(context, new MaterialPageRoute(builder: (context) => Search()));
                  },
                  child: Icon(Icons.search),
                )),
          ],
        ),
        // floatingActionButton: FloatingActionButton(
        //   onPressed: ()=>{},
        //   tooltip: 'Increment',
        //   child: Icon(Icons.add),
        // ),
        body: */
        Center(
            child: ListView.builder(
                itemCount: keywords.length,
                itemBuilder: (context, index) {
                  return KeywordWidget(keywords[index], index);
                }));
    // );
  }
}

class KeywordWidget extends StatefulWidget {
  KeywordWidget(this.keyword, this.index);
  final Keyword keyword;
  final int index;

  @override
  _KeywordWidgetState createState() =>
      _KeywordWidgetState(this.keyword, this.index);
}

class _KeywordWidgetState extends State<KeywordWidget> {
  _KeywordWidgetState(this.keyword, this.index);
  final Keyword keyword;
  final int index;
  TextEditingController _keywordController;
  FocusNode keywordTitleFocusNode;

  @override
  void initState() {
    super.initState();
    _keywordController = TextEditingController.fromValue(TextEditingValue(
      text: this.keyword.text,
    ));
    _keywordController.addListener(_keywordTextUpdated);
  }

  @override
  void dispose() {
    _keywordController.dispose();
    super.dispose();
  }

  _keywordTextUpdated() {
    print('Keyword Text updated: ${_keywordController.text}');
  }

  Widget _titleEditor() {
    return TextField(
        focusNode: keywordTitleFocusNode,
        onSubmitted: (value) {
          print('Submit pressed');
        }, // When 'Done' is pressed in iOS
        controller: _keywordController,
        autocorrect: false,
        autofocus: false,
        maxLines: null,
        // initialValue: this.keyword.text,
        decoration: InputDecoration(
          border: InputBorder.none,
          // hintText: this.keyword.text,
          labelText: "", //this.keyword.text,
          // suffix: Text("Save"),
          labelStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: Color.fromRGBO(25, 25, 25, .95),
            // decoration: TextDecoration.underline,
            // decorationStyle: TextDecorationStyle.dashed,
          ),
          // border: new UnderlineInputBorder(
          //   borderSide: new BorderSide(
          //     color: Colors.blue
          //   )
          // )
        ),
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 18,
          color: Color.fromRGBO(25, 25, 25, .95),
          decoration: TextDecoration.underline,
          decorationStyle: TextDecorationStyle.dashed,
        ));
    // Text(this.keywords[index].text,
    //   textAlign: TextAlign.left,
    //   style: TextStyle(
    //     fontWeight: FontWeight.bold,
    //     fontSize: 18,
    //     color: Color.fromRGBO(25,25,25,.95),
    //     decoration: TextDecoration.underline,
    //     decorationStyle: TextDecorationStyle.dashed,
    //   ),
    // ),
  }

  Widget _matchTypeContainer(context, text, keywordMatchType) {
    bool isMatching = keywordMatchType.toUpperCase() == text;
    return Container(
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        margin: EdgeInsets.fromLTRB(0, 15, 5, 5),
        // width: 75,//MediaQuery.of(context).size.width*0.42,
        decoration: BoxDecoration(
          color: isMatching == true ? Colors.blue : Colors.white,
          border: Border.all(
            color: Color.fromRGBO(0, 0, 0, .2),
            width: 2.0,
          ),
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isMatching == true
                ? Colors.white
                : Color.fromRGBO(25, 25, 25, .95),
            fontSize: 12,
          ),
        ));
  }

  Widget _matchTypes(context, keywordMatchType) {
    List<String> matchTypes = ["BROAD", "BMM", "PHRASE", "EXACT"];

    return Row(children: <Widget>[
      for (var item in matchTypes)
        _matchTypeContainer(context, item, keywordMatchType)
    ]);
  }

  Widget _setWhereContainer(text) {
    return Container(
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        margin: EdgeInsets.fromLTRB(0, 5, 5, 5),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Color.fromRGBO(0, 0, 0, .2),
            width: 2.0,
          ),
          borderRadius: BorderRadius.all(Radius.circular(5)),
        ),
        child: Text(
          text,
          textAlign: TextAlign.left,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color.fromRGBO(25, 25, 25, .95),
            fontSize: 10,
          ),
        ));
  }

  Widget _setWhere() {
    List<String> setWheres = ["Final URL", "Max CPC", "Adgroup to add this to"];
    return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 10.0),
            child: Text("Click below to set the:",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 11,
                )),
          ),
          Row(children: <Widget>[
            for (var item in setWheres) _setWhereContainer(item)
          ])
        ]);
  }

  Widget _additionalActionContainer(
      String text, IconData icon, Color backgroundColor) {
    return Container(
      margin: EdgeInsets.fromLTRB(0, 10, 10, 0),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          // color: backgroundColor,
          margin: EdgeInsets.only(bottom: 5),
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: backgroundColor,
            // border: Border.all(
            //   color: Color.fromRGBO(0, 0, 0, .2),
            //   width: 2.0,
            // ),
            borderRadius: BorderRadius.all(Radius.circular(100)),
          ),
          child: Icon(
            icon,
            size: 20,
            color: Colors.white,
          ),
        ),
        Container(
            // constraints: BoxConstraints(maxWidth: 50),
            child: Text(text.toUpperCase(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10,
                ))),
      ]),
    );
  }

  Widget _additionalActions() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      _additionalActionContainer(
          "Duplicate\nthis row", Icons.copy, Color.fromRGBO(20, 255, 20, 1)),
      Row(children: [
        _additionalActionContainer(
            "Copy\nup", Icons.keyboard_arrow_up, Color.fromRGBO(50, 50, 50, 1)),
        _additionalActionContainer("Copy\ndown", Icons.keyboard_arrow_down,
            Color.fromRGBO(50, 50, 50, 1)),
        _additionalActionContainer(
            "Copy\nto all", Icons.unfold_more, Color.fromRGBO(50, 50, 50, 1)),
      ])
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.fromLTRB(10, 10, 10, 5),
      decoration: BoxDecoration(
          border: Border(
        bottom: BorderSide(color: Color.fromRGBO(0, 0, 0, .2), width: 2.0),
        left: BorderSide(
          color: getColorFromIndex(index),
          width: 4.0,
        ),
      )),
      child: Container(
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        width: MediaQuery.of(context).size.width * 0.75,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _titleEditor(),
          _matchTypes(context, this.keyword.matchType),
          _setWhere(),
          _additionalActions(),
        ]),
      ),
    );
  }
}
