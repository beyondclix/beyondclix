// Select customers to work with
// List the available customers
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/pages/customer_client_list_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/date_range_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/search_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/logo_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/search_result.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/auth.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/widgets/customer_loader.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class CustomersList extends StatelessWidget {
  bool showBackButton;
  Store<AppState> _store;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  CustomersList(this._store, [bool showBackButton]) {
    if (showBackButton == null) {
      this.showBackButton = true;
    } else {
      this.showBackButton = showBackButton;
    }

    ANALYTICS_logScreenEnteredEvent(this._store, 'Accounts List');
  }

  Future<int> _loadSearchTermSaveActionsForCustomer(String customerId) async {
    return (await SearchTermSaveAction.fromMaps('customerId', customerId))
        .length;
  }

  void _onRefresh(/*Store<AppState> store*/) async {
    // print("Refreshing");
    this._store.dispatch(
        (x) => loadCustomersAndCustomerClients(this._store, forceAPI: true));
    // await Future.delayed(Duration(milliseconds: 1500));
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    // monitor network fetch
    // await Future.delayed(Duration(milliseconds: 1000));
    // // if failed,use loadFailed(),if no data return,use LoadNodata()
    // print("Loading");
    _refreshController.loadComplete();
  }

  void _onCustomerSelected(BuildContext context, Store<AppState> store,
      Customer customer, SearchResult searchResult) async {
    print("Selected customer: ${customer.descriptiveName}");

    List<CustomerClient> customerClients =
        await CustomerClient.fromMaps(store, initialId: customer.id);
    print("Found customerClients: ${customerClients.length}");
    customerClients =
        customerClients.where((cc) => cc.id != customer.id).toList();

    if (store.state.searchTerms.length > 0) {
      store.dispatch(ClearSearchTermsAction());
    }
    store.dispatch(ModifyCurrentCustomerAction(
        store, store.state, customer, customerClients));
    // print("customerClients: ${customerClients.length}");
    if (customerClients.length > 0) {
      SearchResult customerClientSearchResult = await Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => CustomerClientListPage(store,
                  initialSetup: !this.showBackButton,
                  searchResult: searchResult)));
      if (customerClientSearchResult != null &&
          customerClientSearchResult.customer != null) {
        // Navigate to the child customer.
        // print("customerClientSearchResult.customerClient: ${customerClientSearchResult.customer}, ${customerClientSearchResult.customerClient}");
        // store.dispatch(ModifyCurrentCustomerAction(store, store.state, searchResult.customer, [searchResult.customerClient]));
        // print("customerClientSearchResult.customer: ${customerClientSearchResult.customer.descriptiveName}");

        // Recursively call Customer Client List Page
        _onCustomerSelected(context, store, customerClientSearchResult.customer,
            customerClientSearchResult);
      }
    } else {
      store.dispatch(
          (x) => updateVisibleCustomerClientsAction(store, customerClients));
      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) =>
                  DateRangePage(store.state.currentManager.timeZone)));
    }
  }

  Widget _accountsList() {
    return //SingleChildScrollView(
        /*child: */ StoreConnector<AppState, AppState>(
      converter: (store) => store.state,
      builder: (context, state) => state.loading && false //TODO
          ? Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 300,
              child: Center(child: CircularProgressIndicator()))
          : Container(
              alignment: Alignment.topCenter,
              child: SmartRefresher(
                enablePullDown: true,
                enablePullUp: false,
                // Get parameters from:
                // https://github.com/peng8350/flutter_pulltorefresh/blob/master/lib/src/indicator/classic_indicator.dart
                header: ClassicHeader(
                  idleText: "Pull to reload all accounts",
                  releaseText: "Release to reload all accounts",
                  refreshingText: "",
                ),
                // footer: CustomFooter(
                //   builder: (BuildContext context,LoadStatus mode){
                //     Widget body ;
                //     if(mode==LoadStatus.idle){
                //       body =  Text("pull up load");
                //     }
                //     else if(mode==LoadStatus.loading){
                //       body =  CircularProgressIndicator();
                //     }
                //     else if(mode == LoadStatus.failed){
                //       body = Text("Load Failed!Click retry!");
                //     }
                //     else if(mode == LoadStatus.canLoading){
                //         body = Text("release to load more");
                //     }
                //     else{
                //       body = Text("No more Data");
                //     }
                //     return Container(
                //       height: 55.0,
                //       child: Center(child:body),
                //     );
                //   },
                // ),
                controller: _refreshController,
                onRefresh: _onRefresh,
                child: ListView.builder(
                    // physics: const NeverScrollableScrollPhysics(),
                    physics: AlwaysScrollableScrollPhysics(
                      parent: BouncingScrollPhysics(),
                    ),
                    itemCount: state.customers.length +
                        1, // Add one for initial index.
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      if (state.customers.length == 0) {
                        return SizedBox.shrink();
                      }

                      // Pull down to refresh display.
                      if (index == state.customers.length) {
                        return Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 15),
                          child: Text("Pull down from top to reload accounts",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color.fromRGBO(55, 55, 55, .45),
                                fontSize: 11,
                                fontWeight: FontWeight.w400,
                              )),
                        );
                      }

                      Customer customer = state.customers[index];

                      return Container(
                        height: customer.clicks != null ? 75.0 : 72.0,
                        margin: EdgeInsets.fromLTRB(10, 5, 10, 0),
                        decoration: BoxDecoration(
                            border: Border(
                          bottom: BorderSide(
                              color: Color.fromRGBO(0, 0, 0, .2), width: 2.0),
                          left: BorderSide(
                            color: getColorFromIndex(index),
                            width: 4.0,
                          ),
                        )),
                        child: StoreConnector<AppState, Store<AppState>>(
                          converter: (store) => store,
                          builder: (context, store) => new ListTile(
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Flexible(
                                    fit: FlexFit.loose,
                                    child: Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.75,
                                      child: Text(
                                        customer.descriptiveName.toString(),
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: false,
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Icon(
                                  //   Icons.arrow_forward_ios,
                                  //   color: Colors.black54,
                                  //   size: 16.0,
                                  // )
                                ],
                              ),
                              trailing: FutureBuilder(
                                future: _loadSearchTermSaveActionsForCustomer(
                                    customer.id),
                                builder: (BuildContext context,
                                    AsyncSnapshot<int> snapshot) {
                                  if (snapshot.hasData && snapshot.data > 0) {
                                    return Container(
                                      height: 37.5,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.blue,
                                        // borderRadius: BorderRadius.circular(6),
                                      ),
                                      padding: EdgeInsets.fromLTRB(5, 0, 5, 0),
                                      child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text("${snapshot.data}",
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                )),
                                            Text(
                                              "Unsaved",
                                              style: TextStyle(
                                                fontSize: 9,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ]),
                                    );
                                  } else {
                                    return SizedBox.shrink();
                                  }
                                },
                              ),
                              subtitle: customer.clicks == null
                                  ? _managerDisplay(customer)
                                  : _nonManagerDisplay(customer),
                              // Column(
                              //   children: [
                              //     Row(
                              //       children: [
                              //         Text(
                              //           customer.isManager ? "Manager" : "",
                              //           style: TextStyle(
                              //             fontWeight: FontWeight.bold,
                              //             fontSize: 12,
                              //           ),
                              //         ),
                              //         Container(
                              //           padding:
                              //               EdgeInsets.fromLTRB(10, 0, 0, 0),
                              //           child: Text(
                              //               customer.id
                              //                   .toString()
                              //                   .replaceFirstMapped(
                              //                       RegExp(r".{3}"),
                              //                       (match) =>
                              //                           "${match.group(0)}-")
                              //                   .replaceFirstMapped(
                              //                       RegExp(r".{7}"),
                              //                       (match) =>
                              //                           "${match.group(0)}-"),
                              //               style: TextStyle(
                              //                 fontWeight: FontWeight.w300,
                              //                 fontSize: 12,
                              //               )),
                              //         )
                              //       ],
                              //     ),
                              //   ],
                              // ),
                              onTap: () {
                                ANALYTICS_logEvent(store, 'Account selected');

                                _onCustomerSelected(
                                    context, store, customer, null);

                                // CustomerPage(
                                //     customerId: int.parse(
                                //         customer.id))));
                              }),
                        ),
                      );
                    }),
              ),
            ),
      //),
    );
  }

  Widget _managerDisplay(Customer customer) {
    return Row(
      children: [
        Text(
          customer.isManager ? "Manager" : "",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
          child: Text(
              customer.id
                  .toString()
                  .replaceFirstMapped(
                      RegExp(r".{3}"), (match) => "${match.group(0)}-")
                  .replaceFirstMapped(
                      RegExp(r".{7}"), (match) => "${match.group(0)}-"),
              style: TextStyle(
                fontWeight: FontWeight.w300,
                fontSize: 12,
              )),
        )
      ],
    );
  }

  Widget _nonManagerDisplay(Customer customer) {
    return /*Column(
      children: [*/
        // Text("${customer.timeZone} ${customer.timeZone.length}"),
        Row(
      children: [
        Text(
          customer.isManager ? "Manager" : "",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
        Container(
          // padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
          child: Text(
              customer.id
                  .toString()
                  .replaceFirstMapped(
                      RegExp(r".{3}"), (match) => "${match.group(0)}-")
                  .replaceFirstMapped(
                      RegExp(r".{7}"), (match) => "${match.group(0)}-"),
              style: TextStyle(
                fontWeight: FontWeight.w300,
                fontSize: 12,
              )),
        )
      ],
      // ),
      // Column(
      //   children: [
      //     Row(
      //       children: [
      //         _customerStat('Clicks', customer.clicks.toString(), 0),
      //         _customerStat(
      //             'Cost', (customer.costMicros / 1000000).toStringAsFixed(2)),
      //         _customerStat('Impr.', customer.impressions.toString()),
      //       ],
      //     ),
      //     Row(
      //       children: [
      //         _customerStat('Conv.', customer.conversions.toString(), 0),
      //         _customerStat('All Conv.', customer.allConversions.toString()),
      //       ],
      //     )
      //   ],
      // ),
      // ],
    );
  }

  Widget _customerStat(String fieldName, String fieldValue,
      [double leftMargin = 25]) {
    return Container(
      width: 75,
      margin: EdgeInsets.only(top: 3, left: leftMargin),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
              padding: EdgeInsets.fromLTRB(0, 0, 5, 0),
              // margin: EdgeInsets.only(top: 2.5),
              child: Text(fieldName,
                  style:
                      TextStyle(fontSize: 10.5, fontWeight: FontWeight.w400))),
          Container(
              // margin: EdgeInsets.only(top: 2.5),
              child: Text(fieldValue,
                  style:
                      TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600)))
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // print("store.state.totalCustomers: ${_store.state.totalCustomers}");
    // print("GLOBAL_customerNotEnabled: ${GLOBAL_customerNotEnabled}");
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: this.showBackButton,
        title: Text("Accounts"),
        actions: <Widget>[
          StoreConnector<AppState, Store<AppState>>(
            converter: (store) => store,
            builder: (context, store) =>
                store.state.isLoadingCustomers < store.state.totalCustomers
                    ? SizedBox.shrink()
                    : Padding(
                        padding: EdgeInsets.only(right: 20.0),
                        child: GestureDetector(
                          onTap: () async {
                            ANALYTICS_logEvent(
                                store, 'Searching For Customer Account');
                            final SearchResult searchResult =
                                await Navigator.of(context).push(
                                    new MaterialPageRoute(builder: (context) {
                              return SearchPage(store);
                            }));

                            // Go to customer if it is not null.
                            if (searchResult != null &&
                                searchResult.customer != null) {
                              _onCustomerSelected(context, store,
                                  searchResult.customer, searchResult);
                            }
                          },
                          child: Icon(
                            Icons.search,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),
                      ),
          ),
          !this.showBackButton
              ? StoreConnector<AppState, Store<AppState>>(
                  converter: (store) => (store),
                  builder: (context, store) => Padding(
                    padding: EdgeInsets.only(right: 20.0),
                    child: GestureDetector(
                      onTap: () {
                        ANALYTICS_logEvent(
                            store, 'Sign Out Pressed from Customer account');
                        signOut(store);
                      },
                      child: Icon(Icons.person),
                    ),
                  ),
                )
              : Container(),
        ],
      ),
      body: Stack(
        children: <Widget>[_accountsList(), CustomerLoader()],
      ),
    );
  }
}

// children: [
//     for(customer customer in customers) Text(customer.descriptiveName.toString()),
//   ]
