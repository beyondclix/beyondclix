import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/models/search_result.dart';
import 'package:searchTermAnalyzerFlutter/pages/search_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_list.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import '../common_functions.dart';
import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/pages/date_range_page.dart';
import 'package:searchTermAnalyzerFlutter/auth.dart';

class CustomerClientListPage extends StatefulWidget {
  bool initialSetup;
  final Store<AppState> store;
  final SearchResult searchResult;

  CustomerClientListPage(this.store, {this.initialSetup, this.searchResult}) {
    if (this.initialSetup == null) {
      this.initialSetup = false;
    } else {
      this.initialSetup = initialSetup;
    }
  }

  @override
  _CustomerClientListPageState createState() => _CustomerClientListPageState();
}

class _CustomerClientListPageState extends State<CustomerClientListPage> {
  bool _isFirstLoad = false;

  _CustomerClientListPageState();

  @override
  void initState() {
    super.initState();

    ANALYTICS_logScreenEnteredEvent(widget.store, "Customer Client List");

    // print("widget.searchResult: ${widget.searchResult}");
    if (widget.searchResult != null &&
        widget.searchResult.customerClient != null) {
      // print("searchResult.customerClient: ${widget.searchResult.customerClient}");
      this.setState(() {
        _isFirstLoad = true;
      });
    }
    // If searchResult.customerClient exists, it means that this was searched, and navigate to it immediately.
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _onCustomerClientSelected(BuildContext context, Store<AppState> store,
      CustomerClient customerClient) {
    widget.store.dispatch(ModifyCurrentCustomerClientAction(
        widget.store, widget.store.state, customerClient));
    if (widget.store.state.currentDateRange != null &&
        widget.store.state.currentDateRange.getName() != "") {
      widget.store.dispatch((x) => updateVisibleSearchTermsAction(store,
          noAPI: false, customerClientId: customerClient.id));
    }
    // Navigator.pop(context);
    if (widget.initialSetup) {
      // Using initial Setup, navigate to date range page.
      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) =>
                  DateRangePage(widget.store.state.currentManager.timeZone)));
    } else {
      // https://stackoverflow.com/questions/55618717/error-thrown-on-navigator-pop-until-debuglocked-is-not-true
      Future.delayed(Duration.zero, () {
        Navigator.of(context).popUntil((route) => route.isFirst);
      });
    }
  }

  Widget _managerDisplay(CustomerClient customer) {
    return Row(
      children: [
        Text(
          customer.isManager ? "Manager" : "",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(customer.isManager ? 10 : 0, 0, 0, 0),
          child: Text(
              customer.id
                  .toString()
                  .replaceFirstMapped(
                      RegExp(r".{3}"), (match) => "${match.group(0)}-")
                  .replaceFirstMapped(
                      RegExp(r".{7}"), (match) => "${match.group(0)}-"),
              style: TextStyle(
                fontWeight: FontWeight.w300,
                fontSize: 12,
              )),
        )
      ],
    );
  }

  Widget _nonManagerDisplay(CustomerClient customer) {
    return /*Column(
      children: [*/
        Row(
      children: [
        Text(
          customer.isManager ? "Manager" : "",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
        Container(
          // padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
          child: Text(
              customer.id
                  .toString()
                  .replaceFirstMapped(
                      RegExp(r".{3}"), (match) => "${match.group(0)}-")
                  .replaceFirstMapped(
                      RegExp(r".{7}"), (match) => "${match.group(0)}-"),
              style: TextStyle(
                fontWeight: FontWeight.w300,
                fontSize: 12,
              )),
        ),
        Text(
          " (" + customer.timeZone + ")",
          style: TextStyle(
            fontWeight: FontWeight.w300,
            fontSize: 12,
          ),
        ),
      ],
      // ),
      // Column(
      //   children: [
      //     Row(
      //       children: [
      //         _customerStat('Clicks', customer.clicks.toString(), 0),
      //         _customerStat(
      //             'Cost', (customer.costMicros / 1000000).toStringAsFixed(2)),
      //         _customerStat('Impr.', customer.impressions.toString()),
      //       ],
      //     ),
      //     Row(
      //       children: [
      //         _customerStat('Conv.', customer.conversions.toString(), 0),
      //         _customerStat('All Conv.', customer.allConversions.toString()),
      //       ],
      //     )
      //   ],
      // ),
      // ],
    );
  }

  Widget _customerStat(String fieldName, String fieldValue,
      [double leftMargin = 15]) {
    return Container(
      width: 75,
      margin: EdgeInsets.only(top: 3, left: leftMargin),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
              padding: EdgeInsets.fromLTRB(0, 0, 5, 0),
              // margin: EdgeInsets.only(top: 2.5),
              child: Text(fieldName,
                  style:
                      TextStyle(fontSize: 10.5, fontWeight: FontWeight.w400))),
          Container(
              // margin: EdgeInsets.only(top: 2.5),
              child: Text(fieldValue,
                  style:
                      TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600)))
        ],
      ),
    );
  }

  Future<int> _loadSearchTermSaveActionsForCustomer(
      String customerClientId) async {
    return (await SearchTermSaveAction.fromMaps('managerId', customerClientId))
        .length;
  }

  @override
  Widget build(BuildContext context) {
    // For when a searchResult was found on Customer page, then immediately navigate to the customerClient if they also were selected by the user.
    if (widget.searchResult != null &&
        widget.searchResult.customerClient != null &&
        _isFirstLoad) {
      _onCustomerClientSelected(
          context, widget.store, widget.searchResult.customerClient);
      this.setState(() {
        _isFirstLoad = false;
      });
    }
    return Scaffold(
        appBar: AppBar(
          title: Text("Client Accounts"),
          actions: <Widget>[
            StoreConnector<AppState, Store<AppState>>(
              converter: (store) => store,
              builder: (context, store) => Padding(
                  padding: EdgeInsets.only(right: 20.0),
                  child: GestureDetector(
                    onTap: () async {
                      ANALYTICS_logEvent(
                          store, 'Searching for Customer Client Account');
                      final SearchResult searchResult =
                          await Navigator.of(context)
                              .push(new MaterialPageRoute(builder: (context) {
                        return SearchPage(store, customerClientsOnly: true);
                      }));
                      // print("searchResult.customer: ${searchResult.customer.id}");
                      // print("searchResult.customerClient: ${searchResult.customerClient}");
                      // print("store.state.currentCustomer.descriptiveName: ${store.state.currentCustomer.id}");

                      // Go to customer if it is not null.
                      // DEPRECATED, because it encourages buggy code.
                      // if (searchResult.customer != null && searchResult.customer.id != store.state.currentCustomer.id) {
                      // Customer was changed, so navigate back to customer
                      // Navigator.of(context).pop(searchResult);

                      // store.dispatch(ModifyCurrentCustomerAction(store, store.state, searchResult.customer, [searchResult.customerClient]));
                      // }
                      if (searchResult.customerClient != null) {
                        _onCustomerClientSelected(
                            context, store, searchResult.customerClient);
                      }
                    },
                    child: Icon(
                      Icons.search,
                      color: Colors.white,
                      size: 28,
                    ),
                  )),
            ),
            widget.initialSetup
                ? StoreConnector<AppState, Store<AppState>>(
                    converter: (store) => (store),
                    builder: (context, store) => Padding(
                      padding: EdgeInsets.only(right: 20.0),
                      child: GestureDetector(
                        onTap: () {
                          ANALYTICS_logEvent(
                              store, 'Initial Setup Sign Out Pressed');
                          signOut(store);
                        },
                        child: Icon(Icons.person),
                      ),
                    ),
                  )
                : Container(),
          ],
        ),
        body: Center(
            child: StoreConnector<AppState, Store<AppState>>(
                converter: (store) => store,
                builder: (context, store) => store.state.loading
                    ? Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height - 300,
                        child: Center(
                            child: CircularProgressIndicator(
                          semanticsLabel: "Loading client information...",
                        )))
                    : Container(
                        alignment: Alignment.topCenter,
                        child: ListView.builder(
                            physics: AlwaysScrollableScrollPhysics(
                              parent: BouncingScrollPhysics(),
                            ),
                            // physics: const NeverScrollableScrollPhysics(),
                            itemCount: store.state.customerClients.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              CustomerClient customerClient =
                                  store.state.customerClients[index];

                              return Container(
                                  height: 72.0,
                                  margin: EdgeInsets.fromLTRB(10, 5, 10, 0),
                                  decoration: BoxDecoration(
                                      border: Border(
                                    bottom: BorderSide(
                                        color: Color.fromRGBO(0, 0, 0, .2),
                                        width: 2.0),
                                    left: BorderSide(
                                      color: getColorFromIndex(index),
                                      width: 4.0,
                                    ),
                                  )),
                                  child: StoreConnector<AppState,
                                          Store<AppState>>(
                                      //Function(CustomerClient c)>(
                                      converter: (store) => store,
                                      // converter: (store) {
                                      //   return (c) {
                                      //     store.dispatch(
                                      //       ModifyCurrentCustomerClientAction(
                                      //           store, store.state, c));
                                      //     store.dispatch((x) => updateVisibleSearchTermsAction(store, noAPI: true));

                                      //   };
                                      // },
                                      builder: (context, store) => ListTile(
                                          title: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Expanded(
                                                child: Container(
                                                  // width: MediaQuery.of(context)
                                                  //         .size
                                                  //         .width *
                                                  //     0.5,
                                                  child: Text(
                                                    customerClient.name,
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 15,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          trailing: FutureBuilder(
                                            future:
                                                _loadSearchTermSaveActionsForCustomer(
                                                    customerClient.id),
                                            builder: (BuildContext context,
                                                AsyncSnapshot<int> snapshot) {
                                              if (snapshot.hasData &&
                                                  snapshot.data > 0) {
                                                return Container(
                                                  height: 37.5,
                                                  width: 50,
                                                  decoration: BoxDecoration(
                                                    color: Colors.blue,
                                                    // borderRadius: BorderRadius.circular(6),
                                                  ),
                                                  padding: EdgeInsets.fromLTRB(
                                                      5, 0, 5, 0),
                                                  child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text("${snapshot.data}",
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: TextStyle(
                                                              fontSize: 20,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                        Text(
                                                          "Unsaved",
                                                          style: TextStyle(
                                                            fontSize: 9,
                                                            color: Colors.white,
                                                          ),
                                                        ),
                                                      ]),
                                                );
                                              } else {
                                                return Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: Colors.black54,
                                                  size: 16.0,
                                                );
                                              }
                                            },
                                          ),
                                          subtitle: customerClient.clicks !=
                                                  null
                                              ? _nonManagerDisplay(
                                                  customerClient)
                                              : _managerDisplay(customerClient),
                                          onTap: () {
                                            ANALYTICS_logEvent(store,
                                                'Customer Client Account Selected');
                                            // callback(customerClient);
                                            _onCustomerClientSelected(
                                                context, store, customerClient);

                                            // Navigator.push(
                                            //     context,
                                            //     new MaterialPageRoute(
                                            //         builder: (context) =>
                                            //             CampaignsListPage()));
                                          })));
                            })))));
  }
}

// Row(
//                                             children: [
//                                               Text(
//                                                 customerClient.isManager
//                                                     ? "Manager"
//                                                     : "",
//                                                 style: TextStyle(
//                                                   fontWeight: FontWeight.bold,
//                                                   fontSize: 12,
//                                                 ),
//                                               ),
//                                               Container(
//                                                 padding: EdgeInsets.fromLTRB(
//                                                     customerClient.isManager
//                                                         ? 10
//                                                         : 0,
//                                                     0,
//                                                     0,
//                                                     0),
//                                                 child: Text(
//                                                     customerClient.id
//                                                         .replaceFirstMapped(
//                                                             RegExp(r".{3}"),
//                                                             (match) =>
//                                                                 "${match.group(0)}-")
//                                                         .replaceFirstMapped(
//                                                             RegExp(r".{7}"),
//                                                             (match) =>
//                                                                 "${match.group(0)}-"),
//                                                     style: TextStyle(
//                                                       fontWeight:
//                                                           FontWeight.w300,
//                                                       fontSize: 12,
//                                                     )),
//                                               ),
//                                             ],
//                                           ),

// child: FutureBuilder(
//     future: getCustomerClients(this.customerId),
// builder:
// (context, AsyncSnapshot<List<CustomerClient>> snapshot) {
// if (snapshot.hasError) {
// return Text("ERROR: ${snapshot.error}");
// } else if (snapshot.hasData) {
// && snapshot.connectionState == ConnectionState.done
// List<CustomerClient> clientCustomers = snapshot.data ?? [];
// return Container(
