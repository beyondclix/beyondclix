import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/string_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_group.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_filter_item.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_order_item.dart';
import 'package:searchTermAnalyzerFlutter/widgets/on_off_switch.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:redux/redux.dart';

class OrderFiltersPage extends StatefulWidget {
  final Store<AppState> _store;

  OrderFiltersPage(this._store);

  @override
  _OrderFiltersPageState createState() => _OrderFiltersPageState(this._store);
}

class _OrderFiltersPageState extends State<OrderFiltersPage> {
  final Store<AppState> _store;
  List<FilterGroup> _filterGroups = [];

  _OrderFiltersPageState(this._store);

  @override
  void initState() {
    super.initState();
    this._filterGroups = createFilterGroups(_store, 'ORDER');
    ANALYTICS_logScreenEnteredEvent(_store, "Search Term Display Order");
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Ordering")),
      body: Scrollbar(
        isAlwaysShown: true,
        child: ListView.builder(
            padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
            itemCount: this._filterGroups.length,
            itemBuilder: (context, index) {
              return ExpandableOrderItem(this._filterGroups[index].title,
                  this._filterGroups[index].filterValues, this._store);
            }),
      ),
    );
  }
}
