// The changes to be saved.

import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/add_searchterm_to_keyword.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/copy_action_confirmation.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/single_save_paywall_dialog.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword_response.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list_to_save.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';

class SaveButton extends StatefulWidget {
  final Function callback;
  final Store<AppState> store;
  final PastPurchase unusedConsumable;
  SaveButton(this.callback, this.store, this.unusedConsumable);

  @override
  State<StatefulWidget> createState() => _SaveButtonState(this.callback);
}

class _SaveButtonState extends State<SaveButton> {
  final Function callback;
  bool _isLoading = false;

  _SaveButtonState(this.callback);

  @override
  void initState() {
    super.initState();

    if (widget.store.state.iapProducts.length == 0) {
      widget.store.dispatch((x) => loadIapProductsAction(widget.store));
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        
        // Paywall
        // Check for pro or lifetime membership here.
        // And no consumable was purchased earlier that can be used now to save.
        if (widget.store.state.membershipType == null &&
            widget.unusedConsumable == null) {
          
          widget.store.dispatch(SetChangesPageBuildContextAction(context));
          
          // Show popup to purchase save.
          
          ANALYTICS_logEvent(widget.store, 'Paywall displayed');

          showDialog(
              context: context,
              builder: (BuildContext context) {
                return SingleSavePaywallDialog(widget.store);
              }).then((saveDialogResult) {
            if (saveDialogResult == null) {
              // Cancel transaction.
              return;
            }
          });
          // Cancel, this is handled by the payments listener.
          return;
        }
        // else if (widget.store.state.membershipType.skuId ==
        //         SKU_MONTHLY_SUBSCRIPTION ||
        //     widget.store.state.membershipType.skuId == SKU_LIFETIME_PURCHASE) {
        //   // Proceed
        // }
        this.setState(() {
          this._isLoading = true;
        });
        await callback(
            context,
            widget.store,
            widget.store.state,
            new List<ChangeAction>.from(widget.store.state.positiveKeywords)
              ..addAll(widget.store.state.negativeKeywords));
        this.setState(() {
          this._isLoading = false;
        });
        return;
      },
      child: Container(
        margin: EdgeInsets.only(left: 10, top: 5, bottom: 5, right: 5),
        child: Stack(children: [
          AnimatedOpacity(
            opacity: this._isLoading || widget.store.state.isPurchasing ? 0 : 1,
            curve: Curves.easeInOut,
            duration: Duration(milliseconds: 200),
            child: Text(
              "Save & Update Google Ads",
              style: TextStyle(fontSize: 16, color: Colors.white),
            ),
          ),
          Positioned.fill(
            child: AnimatedOpacity(
              opacity:
                  this._isLoading || widget.store.state.isPurchasing ? 1 : 0,
              duration: Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              child: Align(
                alignment: Alignment.center,
                child: Center(
                  child: SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 3,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ]),
        padding: EdgeInsets.fromLTRB(10, 8, 10, 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          color: Colors.blue,
        ),
      ),
    );
  }
}

class ChangesPage extends StatefulWidget {
  final Store<AppState> store;
  ChangesPage(this.store);

  @override
  _ChangesPageState createState() => _ChangesPageState();
}

class _ChangesPageState extends State<ChangesPage>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  TabController _tabController;
  String _negativeKeywordListName = "";

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _selectedIndex = _tabController.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, Store<AppState>>(
        converter: (store) => store,
        builder: (context, store) {
          PastPurchase unusedConsumable =
              getLastUnusedConsumable(widget.store.state.pastConsumables);
          return Scaffold(
            persistentFooterButtons: [
              Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                // Only display this text if a save is available, and user is not a member.
                unusedConsumable != null && store.state.membershipType == null
                    ? Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                          color: Color.fromRGBO(75, 205, 75, 1),
                        ),
                        padding:
                            EdgeInsets.symmetric(vertical: 2.5, horizontal: 10),
                        child: Row(
                          children: [
                            Text(
                              // "you have an unused save",
                              "Save available",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                                // decoration: TextDecoration.underline,
                              ),
                            ),
                            SizedBox(width: 1.5),
                            Icon(
                              Icons.check_box,
                              color: Colors
                                  .white, //Color.fromRGBO(75, 205, 75, 1),
                              size: 16,
                            ),
                          ],
                        ),
                      )
                    : SizedBox.shrink(),
                SizedBox(width: 7.5),
                SaveButton(saveAll, store, unusedConsumable),
              ])
            ],
            appBar: AppBar(
                title: Text(
                    "${getCombinedChangesCount(store) == 0 ? 'No' : getCombinedChangesCount(store).toString()} Change${getCombinedChangesCount(store) == 1 ? '' : 's'} To Save")),
            body: Column(children: [
              TabBar(
                controller: _tabController,
                tabs: [
                  Tab(
                    child: StoreConnector<AppState, int>(
                      converter: (store) =>
                          getKeywordErrorsCount(store.state.positiveKeywords),
                      builder: (context, positiveErrorCount) => RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Keywords ",
                              style: TextStyle(
                                color: positiveErrorCount > 0
                                    ? Colors.red
                                    : _selectedIndex == 0
                                        ? Colors.lightBlue
                                        : Colors.black54,
                                fontWeight: _selectedIndex == 0
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                            ),
                            TextSpan(
                              text: positiveErrorCount == 0
                                  ? "(${store.state.positiveKeywords.length}) "
                                  : "",
                              style: TextStyle(
                                color: _selectedIndex == 0
                                    ? Colors.lightBlue
                                    : Colors.black54,
                                fontWeight: _selectedIndex == 0
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                            ),
                            TextSpan(
                              text: positiveErrorCount > 0
                                  ? "(${positiveErrorCount} Issue${positiveErrorCount > 1 ? 's' : ''})"
                                  : "",
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: _selectedIndex == 0
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Tab(
                    child: StoreConnector<AppState, int>(
                      converter: (store) =>
                          getKeywordErrorsCount(store.state.negativeKeywords),
                      builder: (context, negativeErrorCount) => RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Negative Keywords ",
                              style: TextStyle(
                                color: negativeErrorCount > 0
                                    ? Colors.red
                                    : _selectedIndex == 1
                                        ? Colors.lightBlue
                                        : Colors.black54,
                                fontWeight: _selectedIndex == 1
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                            ),
                            TextSpan(
                              text: negativeErrorCount == 0
                                  ? "(${store.state.negativeKeywords.length}) "
                                  : "",
                              style: TextStyle(
                                color: _selectedIndex == 1
                                    ? Colors.lightBlue
                                    : Colors.black54,
                                fontWeight: _selectedIndex == 1
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                            ),
                            TextSpan(
                              text: negativeErrorCount > 0
                                  ? "(${negativeErrorCount} Issue${negativeErrorCount > 1 ? 's' : ''})"
                                  : "",
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: _selectedIndex == 1
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
              Expanded(
                child: TabBarView(controller: _tabController, children: [
                  Container(
                    child: store.state.positiveKeywords.length == 0
                        ? Center(
                            child: Text("No keywords to save",
                                style: TextStyle(
                                  color: Colors.grey.withOpacity(.95),
                                )))
                        : ListView.builder(
                            itemCount: store.state.positiveKeywords.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              if (store.state.positiveKeywords[index]
                                      .changeType ==
                                  'SearchTerm') {
                                return _searchTermSaveObjectChangeItem(
                                    index,
                                    context,
                                    store,
                                    store.state,
                                    store.state.positiveKeywords[index],
                                    store.state.positiveKeywords[index]
                                        .changeObject as SearchTermSaveAction);
                              }
                              return null;
                            }),
                  ),
                  Container(
                    child: store.state.negativeKeywords.length == 0
                        ? Center(
                            child: Text("No negative keywords to save",
                                style: TextStyle(
                                  color: Colors.grey.withOpacity(.95),
                                )))
                        : ListView.builder(
                            itemCount: store.state.negativeKeywords.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              if (store.state.negativeKeywords[index]
                                      .changeType ==
                                  'SearchTerm') {
                                return _searchTermSaveObjectChangeItem(
                                    index,
                                    context,
                                    store,
                                    store.state,
                                    store.state.negativeKeywords[index],
                                    store.state.negativeKeywords[index]
                                        .changeObject as SearchTermSaveAction);
                              }
                              return null;
                            }),
                  ),
                ]),
              ),
            ]),
          );
        });
  }

  Widget _label(String text) {
    return Container(
        margin: EdgeInsets.only(top: 8),
        child: Text(text.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              color: Colors.blue,
            )));
  }

  Widget _field(String key, String value) {
    return Container(
      margin: EdgeInsets.only(right: 25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(key),
          Container(
            padding: new EdgeInsets.only(right: 13.0),
            child: Text(
              value,
              overflow: TextOverflow.ellipsis, //.fade,
              maxLines: 1,
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400),
            ),
          ),
        ],
      ),
    );
  }

  void _duplicate(ChangeAction changeAction, Store<AppState> store,
      SearchTermSaveAction searchTermSaveAction, int index) {
    
    String newId = generateId();

    // Ensure pass by value by creating deep clones.
    ChangeAction _changeAction = ChangeAction.clone(changeAction);
    SearchTermSaveAction _searchTermSaveAction =
        SearchTermSaveAction.fromMap(searchTermSaveAction.toMap());
    _changeAction.changeId = newId;
    _searchTermSaveAction.id = newId;
    _changeAction.changeObject = _searchTermSaveAction;
    print("DUPLICATING: " +
        _searchTermSaveAction.toString() +
        " : " +
        index.toString() +
        ", newId: " +
        newId);
    store.dispatch(AddChangeAction(
        store,
        store.state,
        _changeAction,
        _searchTermSaveAction.isNegative,
        null, /* Do not add a new negative keyword list in */
        index + 1));
  }

  void _copyUp(ChangeAction changeAction, Store<AppState> store,
      SearchTermSaveAction searchTermSaveAction, int index) {
    int low = 0;
    int high = index + 1;
    // if (searchTermSaveAction.isNegative) {
    //   out = store.state.negativeKeywords.sublist(0, index + 1); // Last index is exclusive.
    // }
    _showConfirmationDialog(
        searchTermSaveAction, searchTermSaveAction.isNegative, low, high);
  }

  void _copyDown(ChangeAction changeAction, Store<AppState> store,
      SearchTermSaveAction searchTermSaveAction, int index) {
    int low = index;
    int high = -1;
    if (searchTermSaveAction.isNegative) {
      high = store.state.negativeKeywords.length;
    } else {
      high = store.state.positiveKeywords.length;
    }

    _showConfirmationDialog(
        searchTermSaveAction, searchTermSaveAction.isNegative, low, high);
  }

  void _copyAll(ChangeAction changeAction, Store<AppState> store,
      SearchTermSaveAction searchTermSaveAction, int index) {
    int low = 0;
    int high = -1;
    if (searchTermSaveAction.isNegative) {
      high = store.state.negativeKeywords.length;
    } else {
      high = store.state.positiveKeywords.length;
    }

    _showConfirmationDialog(
        searchTermSaveAction, searchTermSaveAction.isNegative, low, high);
  }

  void _showConfirmationDialog(SearchTermSaveAction searchTermSaveAction,
      bool isNegative, int low, int high) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return CopyActionConfirmation(
              searchTermSaveAction, isNegative, low, high);
        });
  }

  Widget _copyActions(ChangeAction changeAction,
      SearchTermSaveAction searchTermSaveAction, int index) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      _copyActionContainer(
          "Duplicate\nthis row",
          Icons.copy,
          Color.fromRGBO(75, 205, 75, 1),
          _duplicate,
          changeAction,
          searchTermSaveAction,
          index),
      Row(children: [
        _copyActionContainer(
            "Copy\nup",
            Icons.keyboard_arrow_up,
            Color.fromRGBO(50, 50, 50, 1),
            _copyUp,
            changeAction,
            searchTermSaveAction,
            index),
        _copyActionContainer(
            "Copy\ndown",
            Icons.keyboard_arrow_down,
            Color.fromRGBO(50, 50, 50, 1),
            _copyDown,
            changeAction,
            searchTermSaveAction,
            index),
        _copyActionContainer(
            "Copy\nto all",
            Icons.unfold_more,
            Color.fromRGBO(50, 50, 50, 1),
            _copyAll,
            changeAction,
            searchTermSaveAction,
            index),
      ])
    ]);
  }

  Widget _copyActionContainer(
      String text,
      IconData icon,
      Color backgroundColor,
      Function callback,
      ChangeAction changeAction,
      SearchTermSaveAction searchTermSaveAction,
      int index) {
    return StoreConnector<AppState, Store<AppState>>(
      converter: (store) => store,
      builder: (context, store) => GestureDetector(
          onTap: () {
            callback(changeAction, store, searchTermSaveAction, index);
          },
          child: Container(
            margin: EdgeInsets.fromLTRB(0, 10, 10, 0),
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                // color: backgroundColor,
                margin: EdgeInsets.only(bottom: 5),
                padding: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: backgroundColor,
                  // border: Border.all(
                  //   color: Color.fromRGBO(0, 0, 0, .2),
                  //   width: 2.0,
                  // ),
                  borderRadius: BorderRadius.all(Radius.circular(100)),
                ),
                child: Icon(
                  icon,
                  size: 20,
                  color: Colors.white,
                ),
              ),
              Container(
                  // constraints: BoxConstraints(maxWidth: 50),
                  child: Text(text.toUpperCase(),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 10,
                      ))),
            ]),
          )),
    );
  }

  Widget _errorsDisplay(SearchTermSaveAction searchTermSaveAction) {
    if (searchTermSaveAction.keywordErrors == null ||
        searchTermSaveAction.keywordErrors.length == 0) {
      return SizedBox.shrink();
    }
    return Container(
        color: Colors.red,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            for (KeywordError ke in searchTermSaveAction.keywordErrors)
              _errorDisplay(ke)
          ],
        ));
  }

  Widget _errorDisplay(KeywordError ke) {
    return Flexible(
      fit: FlexFit.loose,
      child: Container(
          width: double.infinity,
          padding: EdgeInsets.all(5),
          margin: EdgeInsets.symmetric(vertical: 5),
          child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Text("${ke.name}",
                //     style: TextStyle(
                //       color: Colors.white,
                //       fontSize: 12,
                //     )),
                Text(
                  ke.description,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
              ])),
    );
  }

  Widget _searchTermSaveObjectChangeItem(
      int index,
      BuildContext context,
      Store<AppState> store,
      AppState state,
      ChangeAction changeAction,
      SearchTermSaveAction searchTermSaveAction) {
    // print("EDITING searchTermSaveAction.id: " +
    //     searchTermSaveAction.id.toString());
    // print("changeAction.id: " + changeAction.changeId);
    return GestureDetector(
        onTap: () {
          ANALYTICS_logEvent(store, 'Editing Search Term To Save');
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return AddSearchTermToKeywordDialog(
                  store,
                  searchTermSaveAction.id,
                  searchTermSaveAction.searchTermText,
                  searchTermSaveAction.searchTermResourceName,
                  "Edit keyword",
                  "Update",
                  searchTermSaveAction.campaignName,
                  searchTermSaveAction.campaignResourceName,
                  searchTermSaveAction.adGroupName,
                  searchTermSaveAction.adGroupResourceId,
                  matchType: searchTermSaveAction.matchType,
                  finalUrls: searchTermSaveAction.finalUrls,
                  maxCpc: searchTermSaveAction.maxCpc,
                  isNegative: searchTermSaveAction.isNegative,
                  adGroupId: searchTermSaveAction.adGroupId,
                  dontShowCancel: false,
                  negativeKeywordSaveType:
                      searchTermSaveAction.negativeKeywordSaveType,
                  negativeKeywordListName:
                      searchTermSaveAction.negativeKeywordListName,
                  negativeKeywordListResourceName:
                      searchTermSaveAction.negativeKeywordListResourceName,
                );
              });
        },
        child: Container(
            // margin: EdgeInsets.fromLTRB(5, 3, 5, 4),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.35),
                  spreadRadius: 1,
                  blurRadius: 2,
                  offset: Offset(0, 0), // changes position of shadow
                ),
              ],
            ),
            padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _errorsDisplay(searchTermSaveAction),
                        _label("Search Term"),
                        Text(searchTermSaveAction.searchTermText,
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w600)),
                        // _label("Match type"),
                        // Text(searchTermSaveAction.matchType,
                        //     style: TextStyle(
                        //         fontSize: 15, fontWeight: FontWeight.w400)),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          // _label("Keyword type"),
                          // _field(
                          //     "Keyword type",
                          //     searchTermSaveAction.isNegative
                          //         ? "Negative"
                          //         : "Positive"),
                          // _label("Adgroup"),
                          // Text(searchTermSaveAction.adGroupName),
                          Flexible(
                              fit: FlexFit.loose,
                              child: /*searchTermSaveAction.isNegative
                                ? */
                                  _field("Campaign",
                                      searchTermSaveAction.campaignName)
                              //: Container(),
                              ),
                          Flexible(
                            fit: FlexFit.loose, //.tight
                            child: _field(
                                "Adgroup", searchTermSaveAction.adGroupName),
                          ),
                        ]),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            _field("Added to",
                                searchTermSaveAction.negativeKeywordSaveType),
                            searchTermSaveAction.negativeKeywordSaveType ==
                                    "Negative keyword list"
                                ? Expanded(
                                    child: _field(
                                        "Negative keyword list",
                                        searchTermSaveAction
                                            .negativeKeywordListName),
                                  )
                                : Container(),
                            _field(
                                "Match type", searchTermSaveAction.matchType),
                          ],
                        ),
                        _copyActions(changeAction, searchTermSaveAction, index),
                        SizedBox(height: 15),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.start,
                        //   children: [
                        //     GestureDetector(
                        //       onTap: () {
                        //         Navigator.of(context).pop();
                        //       },
                        //       child: Container(
                        //           child: Text("Remove",
                        //               style: TextStyle(
                        //                 fontSize: 14,
                        //               )),
                        //           padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
                        //           decoration: BoxDecoration(
                        //               borderRadius: BorderRadius.circular(2),
                        //               color: Color.fromRGBO(155, 155, 155, .25))),
                        //     ),
                        //     GestureDetector(
                        //       onTap: () {

                        //         this._editChangeAction(
                        //             store, changeAction, searchTermSaveAction);
                        //       },
                        //       child: Container(
                        //         margin: EdgeInsets.only(left: 20),
                        //         child: Text("Edit",
                        //             style: TextStyle(
                        //                 fontSize: 14, color: Colors.white)),
                        //         padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
                        //         decoration: BoxDecoration(
                        //           borderRadius: BorderRadius.circular(2),
                        //           color: Colors.blue,
                        //         ),
                        //       ),
                        //     )
                        //   ],
                        // ),
                      ]),
                ])));
  }

  // _editChangeAction(Store<AppState> store, ChangeAction changeAction,
  //     SearchTermSaveAction searchTermSaveAction) {
  //   store.dispatch(
  //       ModifyChangeAction(store.state, changeAction.changeId, changeAction));
  // }
}
