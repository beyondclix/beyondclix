// Initial page displaying the logo & brief intro.
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/pages/initial_screen.dart';

class LogoPage extends StatelessWidget {
  final Store<AppState> store;
  final GlobalKey<NavigatorState> navigatorKey;

  LogoPage(this.navigatorKey, this.store) {
    ANALYTICS_logScreenEnteredEvent(this.store, "First Logo page");
  }

  @override
  Widget build(BuildContext context) {
    return (SafeArea(
        bottom: true,
        child: Container(
          color: Colors.white,
          padding: EdgeInsets.only(left: 35, right: 35, top: 30),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.symmetric(horizontal: 1),
                        child: ClipRRect(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(8.0),
                            topRight: Radius.circular(8.0),
                          ),
                          child: Image.asset(
                            'lib/assets/icon.png',
                            height: 150,
                            width: 150,
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      Flexible(
                          child: Text(
                              "Manage your Google Ads search terms from your phone. Update, analyze and process your search terms on the go.",
                              style: TextStyle(
                                color: Color.fromRGBO(75, 95, 135, .7),
                              )))
                    ]),
              ),
              // Container(
              //   height: 90,
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.end,
              //     children: [
              //       GestureDetector(
              //         onTap: () {
              //           print("tapped: ${store.state.isShowingInitialScreen}");
              //           ANALYTICS_logEvent(
              //               this.store, "Pressed NEXT at First Logo Screen");

              //           // Navigator.pushReplacement(
              //           //   context,
              //           //   new MaterialPageRoute(builder: (context) {
              //           //     return MaterialApp(
              //           //       home: DefaultTextStyle(
              //           //         textAlign: TextAlign.left,
              //           //         style: new TextStyle(
              //           //           inherit: true,
              //           //           fontSize: 15.0,
              //           //           color: Colors.black,
              //           //           fontWeight: FontWeight.w400,
              //           //           // decoration: TextDecoration.underline,
              //           //           decorationColor: Colors.black,
              //           //           decorationStyle: TextDecorationStyle.wavy,
              //           //         ),
              //           //         child: InitialScreen(store),
              //           //       ),
              //           //       // return InitialScreen(store);
              //           //     );
              //           //   }),
              //           // );
              //           this.navigatorKey.currentState.pushNamed('/2');

              //           // this.store.dispatch(UpdateIsShowingWelcomeScreenAction(2));
              //         },
              //         child: Container(
              //           // padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
              //           padding:
              //               EdgeInsets.symmetric(vertical: 15, horizontal: 25),
              //           // margin: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
              //           margin: EdgeInsets.only(top: 15, bottom: 15),
              //           decoration: BoxDecoration(
              //             // color: Colors.blue,
              //             border: Border.all(color: Colors.blue),
              //             // borderRadius: BorderRadius.all(Radius.circular(2)),
              //           ),
              //           child: Text(
              //             "Next",
              //             style: TextStyle(
              //               color: Colors.blue,
              //               // fontSize: 16,
              //             ),
              //           ),
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
            ],
          ),
        ),
      )
    );
  }
}
