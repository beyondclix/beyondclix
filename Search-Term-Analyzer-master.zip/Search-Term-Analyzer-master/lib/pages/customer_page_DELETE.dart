// import 'package:searchTermAnalyzerFlutter/pages/customer_client_list_page.dart';

// import '../api.dart';
// import 'date_range_page.dart';
// import 'package:flutter/material.dart';
// import '../models/customer_info.dart';

// class CustomerPage extends StatefulWidget {
//   CustomerPage({Key key, this.customerId}) : super(key: key);
//   final int customerId;

//   @override
//   _CustomerPageState createState() => _CustomerPageState(this.customerId);
// }

// class _CustomerPageState extends State<CustomerPage> {
//   _CustomerPageState(this.customerId);
//   final int customerId;
//   Map<String, String> currentDateRange;

//   updateDate(Map<String, String> rangeType) {
//     setState(() {
//       currentDateRange = rangeType;
//     });
//   }

//   Widget _displayContainer(int number, String label) {
//     return Container(
//         padding: EdgeInsets.all(10),
//         margin: EdgeInsets.fromLTRB(10, 20, 10, 10),
//         width: MediaQuery.of(context).size.width * 0.42,
//         decoration: BoxDecoration(
//             // color: Colors.orange,
//             border: Border.all(
//               color: Color.fromRGBO(0, 0, 0, .2),
//               width: 2.0,
//             ),
//             borderRadius: BorderRadius.all(Radius.circular(20))),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Container(
//                 padding: EdgeInsets.all(20),
//                 margin: EdgeInsets.only(bottom: 10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   border: Border.all(
//                     color: Color.fromRGBO(0, 0, 0, .2),
//                     width: 2.0,
//                   ),
//                 ),
//                 child: Text(number.toString(),
//                     style: TextStyle(
//                       color: Colors.blue,
//                       fontSize: 30,
//                       fontWeight: FontWeight.w800,
//                     ))),
//             Text(label),
//           ],
//         ));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Customer Overview"),
//         actions: <Widget>[
//           Padding(
//               padding: EdgeInsets.only(right: 20.0),
//               child: GestureDetector(
//                 onTap: () {
//                   Navigator.push(
//                       context,
//                       new MaterialPageRoute(
//                           builder: (context) => DateRangePage(
//                               /*updateParentDate: updateDate,
//                               currentDateOption: currentDateRange*/
//                               )));
//                 },
//                 child: Icon(Icons.date_range),
//               )),
//         ],
//       ),
//       body: Center(
//         child: FutureBuilder(
//             future: getCustomerInfo(this.customerId),
//             builder: (context, snapshot) {
//               // print("SNAPSHOT RECEIVED: " + snapshot.data.campaigns.toString());
//               if (snapshot.hasData || snapshot.data != null) {
//                 // List<AccountInfo> accountInfos = snapshot.data ?? [];
//                 CustomerInfo customer = snapshot.data;
//                 // Text('Account data here: ' + snapshot.data.toString());
//                 return Column(
//                   children: [
//                     Center(
//                         child: GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             new MaterialPageRoute(
//                                 builder: (context) =>
//                                     CustomerClientListPage()));
//                       },
//                       child: Container(
//                         padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
//                         // margin: EdgeInsets.fromLTRB(10, 20, 10, 10),
//                         width: MediaQuery.of(context).size.width,
//                         decoration: BoxDecoration(
//                           color: Color.fromRGBO(0, 0, 0, .1),
//                           border: Border(
//                             bottom: BorderSide(
//                               color: Colors.blue, //Color.fromRGBO(0, 0, 0, .2),
//                               width: 2.0,
//                             ),
//                           ),
//                         ),
//                         child: Text(
//                           "View Client Accounts",
//                           textAlign: TextAlign.center,
//                           style: TextStyle(
//                             fontWeight: FontWeight.bold,
//                             fontSize: 15,
//                             color: Colors.blue,
//                           ),
//                         ),
//                       ),
//                     )),
//                     Center(
//                         child: GestureDetector(
//                       onTap: () {
//                         // Navigator.push(context, new MaterialPageRoute(builder: (context) => Campaigns(this.customerId)));
//                       },
//                       // child: _displayContainer(account.campaigns.getCount(), "Campaigns"),
//                       child: _displayContainer(0, "Campaigns"),
//                     )),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       children: [
//                         GestureDetector(
//                           onTap: () {
//                             // Navigator.push(context, new MaterialPageRoute(builder: (context) => AdGroupsPage(this.customerId)));
//                           },
//                           // child: _displayContainer(account.adGroups.getCount(), "Ad Groups"),
//                           child: _displayContainer(0, "Ad Groups"),
//                         ),
//                         GestureDetector(
//                           onTap: () {
//                             // Navigator.push(context, new MaterialPageRoute(builder: (context) => KeywordsPage(this.customerId, context)));
//                           },
//                           // child: _displayContainer(account.keywords.getCount(), "Search Terms"),
//                           child: _displayContainer(0, "Search Terms"),
//                         ),
//                       ],
//                     ),
//                   ],
//                 );
//               } else if (snapshot.hasError) {
//                 return Text("${snapshot.error}");
//               }
//               return CircularProgressIndicator();
//             }),
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () => {},
//         tooltip: 'Increment',
//         child: Icon(Icons.add),
//       ),
//     );
//   }
// }
