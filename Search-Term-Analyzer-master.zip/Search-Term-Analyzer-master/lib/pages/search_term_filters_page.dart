import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/string_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_group.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_filter_item.dart';
import 'package:searchTermAnalyzerFlutter/widgets/on_off_switch.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:redux/redux.dart';

class SearchTermFiltersPage extends StatefulWidget {
  final Store<AppState> _store;

  SearchTermFiltersPage(this._store);

  @override
  _SearchTermFiltersPageState createState() =>
      _SearchTermFiltersPageState(this._store);
}

class _SearchTermFiltersPageState extends State<SearchTermFiltersPage> {
  final Store<AppState> _store;
  // List<FilterValue> _filterOptions = [];
  List<FilterValue> _filterValues = [];
  List<FilterGroup> _filterGroups = [];

  _SearchTermFiltersPageState(this._store);

  @override
  void initState() {
    super.initState();

    ANALYTICS_logScreenEnteredEvent(_store, "Searchterm Filters");

    // List<FilterValue> fo = metrics.map((m) {
    //   return FilterValue(m.name, "", "");
    // }).toList();

    // fo.insert(0, FilterValue("Search Term", "", "", "string"));
    // Use expandable groups here instead.
    // this._filterOptions = fo;
    this._filterValues = _store.state.filterValues;

    this._filterGroups = createFilterGroups(_store);

    // this._filterGroups.add(FilterGroup("Attribution", []));
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Filters")),
      body: Scrollbar(
        isAlwaysShown: true,
        child:
            // Column(
            //   children: [
            // GestureDetector(
            //   onTap: () {
            //     showDialog(
            //       context: context,
            //       builder: (BuildContext context) {
            //         return StringFilterDialog("Search Term", "", "");
            //       },
            //     ).then(
            //       (newFilterValue) => this.setState(() {
            //         if (newFilterValue != null) {
            //           this._filterValues.add(newFilterValue);
            //           _store.dispatch(AddFilterAction(newFilterValue));
            //           _store.dispatch(
            //               (x) => updateVisibleSearchTermsAction(_store));
            //         }
            //       }),
            //     );
            //   },
            //   child: Column(
            //     children: [
            //       ListTile(
            //         contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
            //         tileColor: Colors.transparent,
            //         title: Row(
            //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //           crossAxisAlignment: CrossAxisAlignment.center,
            //           children: [
            //             Container(
            //               padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
            //               width: MediaQuery.of(context).size.width * 0.75,
            //               child: Text(
            //                 "Search Term",
            //                 style: TextStyle(
            //                     fontWeight: FontWeight.bold,
            //                     fontSize: 16,
            //                     color: Colors.black87),
            //               ),
            //             ),
            //             Icon(
            //               Icons.arrow_forward_ios,
            //               color: Colors.black54,
            //               size: 16.0,
            //             ),
            //           ],
            //         ),
            //       ),
            //       Divider(
            //         height: 1,
            //       ),
            //     ],
            //   ),
            // ),
            //   Expanded(
            // child:
            ListView.builder(
                padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
                itemCount: this._filterGroups.length,
                itemBuilder: (context, index) {
                  return ExpandableFilterItem(this._filterGroups[index].title,
                      this._filterGroups[index].filterValues, this._store);
                  // return Column(children: [
                  //   ListTile(
                  //     contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                  //     tileColor: Colors.transparent,
                  //     title: GestureDetector(
                  //       onTap: () {
                  //         // Open popup
                  //         showDialog(
                  //           context: context,
                  //           builder: (BuildContext context) {
                  //             if (this._filterOptions[index].valueType == "string"){
                  //               return StringFilterDialog(this._filterOptions[index].name, "", "");
                  //             } else {
                  //               return MetricFilterDialog(
                  //                   this._filterOptions[index].name, "", "");
                  //             }
                  //           },
                  //         ).then(
                  //           (newFilterValue) => this.setState(() {
                  //             if (newFilterValue != null) {
                  //               // This updates the redux store, which is a bad design pattern.
                  //               // this._filterValues.add(newFilterValue);
                  //               _store.dispatch(StartSearchTermsLoadingAction());
                  //               _store.dispatch(
                  //                   AddFilterAction(newFilterValue));
                  //               _store.dispatch((x) =>
                  //                   updateVisibleSearchTermsAction(_store));
                  //             }
                  //           }),
                  //         );
                  //       },
                  //       child: Row(
                  //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //         crossAxisAlignment: CrossAxisAlignment.center,
                  //         children: [
                  //           Container(
                  //             padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                  //             width: MediaQuery.of(context).size.width * 0.75,
                  //             child: Text(
                  //               convertToDisplayName(
                  //                   this._filterOptions[index].name),
                  //               style: TextStyle(
                  //                   fontWeight: FontWeight.bold,
                  //                   fontSize: 16,
                  //                   color: Colors.black87),
                  //             ),
                  //           ),
                  //           Icon(
                  //             Icons.arrow_forward_ios,
                  //             color: Colors.black54,
                  //             size: 16.0,
                  //           ),
                  //         ],
                  //       ),
                  //     ),
                  //   ),
                  //   Divider(
                  //     height: 1,
                  //   ),
                  // ]);
                }),
        // ),
        //   ],
        // ),
      ),
    );
  }
}
