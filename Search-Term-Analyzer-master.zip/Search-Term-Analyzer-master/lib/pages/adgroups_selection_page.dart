import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
// import 'package:indexed_list_view/indexed_list_view.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_selection_page.dart';
import '../common_functions.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';

class AdGroupsSelectionPage extends StatefulWidget {
  final Store<AppState> store;
  AdGroupsSelectionPage(this.store);

  _AdGroupsSelectionPageState createState() => _AdGroupsSelectionPageState();
}

class _AdGroupsSelectionPageState extends State<AdGroupsSelectionPage> {
  int offset = 0;

  _AdGroupsSelectionPageState();

  @override
  void initState() {
    String campaignId;

    ANALYTICS_logScreenEnteredEvent(widget.store, "AdGroups List");

    if (widget.store.state.currentCampaign != null) {
      campaignId = widget.store.state.currentCampaign.id;
    }

    widget.store
        .dispatch((x) => updateVisibleAdGroupsAction(widget.store, campaignId));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Filter by Adgroup"),
      ),
      body: Center(
        // child: StoreConnector<AppState, ItemScrollController>(
        //   converter: (store) => store.state.adgroupsScrollController,
        //   builder: (context, scrollController) => Scrollbar(
        //     interactive: true,
        //     isAlwaysShown: true,
        //     controller: scrollController.scrollController,
        child: //ListView.builder(
            Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current campaign.
            StoreConnector<AppState, Store<AppState>>(
              converter: (store) => store,
              builder: (context, store) => store.state.currentCampaign !=
                          null &&
                      store.state.currentCampaign.id != null &&
                      store.state.currentCampaign.name.length > 0
                  ? GestureDetector(
                      child: Container(
                        height: 100,
                        padding: EdgeInsets.all(25),
                        color: Colors.blue,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                margin: EdgeInsets.only(bottom: 5),
                                child: Text("FILTERING BY CAMPAIGN",
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.white.withOpacity(.75),
                                    ))),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  fit: FlexFit.loose,
                                  child: Text(
                                    store.state.currentCampaign.name,
                                    overflow: TextOverflow.ellipsis,
                                    softWrap: false,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 17,
                                    ),
                                  ),
                                ),
                                Icon(
                                  Icons.arrow_forward_ios_sharp,
                                  size: 20,
                                  color: Colors.white,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      onTap: () {
                        ANALYTICS_logEvent(
                            store, 'Selecting campaign from adgroups page');
                        Navigator.of(context).push(
                          new MaterialPageRoute(builder: (context) {
                            return CampaignsSelectionPage(true, store);
                          }),
                        );
                      })
                  : StoreConnector<AppState, Store<AppState>>(
                      converter: (store) => store,
                      builder: (context, store) => GestureDetector(
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(25),
                            color: Colors.blue,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Select a campaign",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                Icon(
                                  Icons.arrow_forward_ios_sharp,
                                  size: 20,
                                  color: Colors.white,
                                ),
                              ],
                            ),
                          ),
                          onTap: () {
                            ANALYTICS_logEvent(
                                store, 'Selecting campaign from adgroups page');
                            Navigator.of(context).push(
                              new MaterialPageRoute(builder: (context) {
                                return CampaignsSelectionPage(true, store);
                              }),
                            );
                          }),
                    ),
            ),
            StoreConnector<AppState, Store<AppState>>(
              converter: (store) => store,
              builder: (context, store) =>
                  NotificationListener<ScrollNotification>(
                onNotification: (ScrollNotification scrollInfo) {
                  if (!store.state.isLoadingAdGroups &&
                      store.state.adGroups.length >=
                          offset * PAGINATION_LIMIT &&
                      scrollInfo.metrics.pixels >=
                          scrollInfo.metrics.maxScrollExtent - 500) {
                    print(
                        "LOADING MORE ADGROUPS ${store.state.isLoadingAdGroups}");
                    store.dispatch(StartAdGroupsLoadingAction());
                    store.dispatch((x) => loadMoreAdGroupsPaginatedAction(
                        store, this.offset + 1));
                    this.setState(() {
                      offset += 1;
                    });
                  } else {
                    // NO ACTION
                  }
                  return;
                },
                child:
                    // Column(
                    // children: [
                    Expanded(
                  child: StoreConnector<AppState, int>(
                    converter: (store) => store.state.adGroupsListKey,
                    builder: (context, key) => Scrollbar(
                      child: ListView.builder(
                        key: Key(key.toString()),
                        // physics: const AlwaysScrollableScrollPhysics(),
                        // ScrollablePositionedList.builder(
                        // itemScrollController: scrollController,
                        // controller: scrollController, //_scrollController,
                        padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
                        itemCount: store.state.adGroups.length,
                        // shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return _AdGroupItem(
                              store.state.adGroups[index], index);
                        },
                      ),
                    ),
                  ),
                ),
                // store.state.isLoadingAdGroups || true
                //   ? Container(
                //       child: Center(
                //         child: CircularProgressIndicator(
                //           color: Colors.blue,
                //         ),
                //       ),
                //     )
                //   : SizedBox.shrink(),
                // ]
                // ),
              ),
            ),
          ],
        ),
      ),
      //   ),
      // ),
    );
  }
}

class _AdGroupItem extends StatefulWidget {
  final int index;
  final AdGroup adGroup;

  _AdGroupItem(this.adGroup, this.index);

  @override
  _AdGroupItemState createState() =>
      _AdGroupItemState(this.adGroup, this.index);
}

class _AdGroupItemState extends State<_AdGroupItem> {
  final int index;
  AdGroup adGroup;
  _AdGroupItemState(this.adGroup, this.index);

  List<Widget> _statsColumns(List<List<Metric>> splitMetrics) {
    List<Widget> out = [];
    for (List<Metric> metrics in splitMetrics) {
      out.add(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: new List<Widget>.generate(
          metrics.length,
          (int index) => _statContainer(
              metrics[index].name,
              getMetricDisplayValue(adGroup.metrics, metrics[index].name,
                  metrics[index].valueType, null)),
        ),
      ));
    }
    return out;
  }

  Widget _statsContainer() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      height: 65,
      child: StoreConnector<AppState, List<List<Metric>>>(
          converter: (store) => splitArray(
              store.state.adGroupMetrics.where((f) => f.isOn == true).toList()),
          builder: (context, metrics) => Scrollbar(
              child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _statsColumns(metrics),
                  )))),
    );
  }

  Widget _statContainer(String key, String value) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 50, 5),
      width: MediaQuery.of(context).size.width * 0.5,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            fit: FlexFit.loose,
            child: Container(
              child: Text(
                convertToDisplayName(key),
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 10,
                ),
              ),
            ),
          ),
          Text(value,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ))
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(
              color: getColorFromIndex(index),
              width: 2.0,
            ),
          ),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.35),
              spreadRadius: 1,
              blurRadius: 2,
              offset: Offset(0, 0), // changes position of shadow
            ),
          ],
        ),
        width: MediaQuery.of(context).size.width * 0.75,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Campaign name
            StoreConnector<AppState, Campaign>(
                converter: (store) => store.state.currentCampaign,
                builder: (context, campaign) =>
                    campaign == null || campaign.name == ""
                        ? Container(
                            padding: EdgeInsets.fromLTRB(0, 10, 10, 0),
                            width: MediaQuery.of(context).size.width * 0.8,
                            child: Text(
                              adGroup.campaignName.toUpperCase(),
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                decoration: TextDecoration.none,
                                color: Colors.blue,
                              ),
                            ),
                          )
                        : SizedBox.shrink()),
            // Ad Group name
            Container(
              padding: EdgeInsets.fromLTRB(0, 10, 10, 10),
              width: MediaQuery.of(context).size.width * 0.8,
              child: Text(adGroup.name,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.none,
                    color: Colors.black,
                  )),
            ),
            // _statsContainer(),
            StoreConnector<AppState, AdGroup>(converter: (store) {
              return store.state.currentAdGroup;
            }, builder: (context, currentAdGroup) {
              bool _selected = currentAdGroup == null
                  ? false
                  : currentAdGroup.id == adGroup.id;
              return Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      StoreConnector<AppState, Function(AdGroup c)>(
                        converter: (store) {
                          return (a) {
                            ANALYTICS_logEvent(store, 'Selected adgroup');
                            store.dispatch(ModifyCurrentAdGroupAction(
                                store, store.state, a));
                            store.dispatch(AddFilterAction(FilterValue(
                                "AdGroup", "equals", a.id,
                                displayName: a.name,
                                valueType: "adGroup",
                                stringFilterType: "adGroupId")));
                            store.dispatch((x) =>
                                updateVisibleSearchTermsAction(store,
                                    adGroupId: a.id));

                            Navigator.of(context)
                                .popUntil((route) => route.isFirst);
                          };
                        },
                        builder: (context, callback) => GestureDetector(
                          onTap: () {
                            if (_selected) {
                              callback(null);
                            } else {
                              callback(adGroup);
                            }
                          },
                          child: Container(
                            padding: EdgeInsets.fromLTRB(5, 5, 10, 5),
                            margin: EdgeInsets.fromLTRB(0, 0, 5, 5),
                            decoration: BoxDecoration(
                              color: _selected ? Colors.blue : Colors.white,
                              border: Border.all(
                                color: _selected
                                    ? Colors.white
                                    : Colors.blue.shade100,
                                width: 2.0,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                            ),
                            child: RichText(
                                text: TextSpan(children: [
                              WidgetSpan(
                                  alignment: PlaceholderAlignment.middle,
                                  child: Icon(
                                      _selected ? Icons.remove : Icons.add,
                                      color: _selected
                                          ? Colors.white
                                          : Colors.blue)),
                              TextSpan(
                                  text: _selected
                                      ? "Filtering by AdGroup"
                                      : "Filter by AdGroup",
                                  style: TextStyle(
                                    color:
                                        _selected ? Colors.white : Colors.blue,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    decoration: TextDecoration.none,
                                    letterSpacing: -.5,
                                  )),
                            ])),
                          ),
                        ),
                      ),
                    ],
                  ));
            })
          ],
        ));
  }
}
