import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import '../common_functions.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';

class CampaignsSelectionPage extends StatefulWidget {
  final bool fromAdGroup;
  final Store<AppState> store;
  CampaignsSelectionPage(this.fromAdGroup, this.store);

  _CampaignsSelectionPageState createState() => _CampaignsSelectionPageState();
}

class _CampaignsSelectionPageState extends State<CampaignsSelectionPage> {
  int offset = 0;

  _CampaignsSelectionPageState();

  @override
  void initState() {
    ANALYTICS_logScreenEnteredEvent(widget.store, "Campaigns List");

    if (widget.store.state.campaigns.length == 0) {
      widget.store.dispatch((x) => updateVisibleCampaignsAction(widget.store));
    }
    // print("store.state.campaigns.length: ${widget.store.state.campaigns.length}");
  }

  // final ScrollController _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    // print("Campaigns: ${this.campaigns}");
    return Scaffold(
      appBar: AppBar(
        title: Text("Filter by campaign"),
      ),
      body: Center(
        child: StoreConnector<AppState, ItemScrollController>(
            converter: (store) => store.state.campaignsScrollController,
            builder: (context, scrollController) {
              return Scrollbar(
                interactive: true,
                isAlwaysShown: true,
                controller: scrollController.scrollController,
                child: StoreConnector<AppState, Store<AppState>>(
                  converter: (store) => store,
                  builder: (context, store) =>
                      NotificationListener<ScrollNotification>(
                    onNotification: (ScrollNotification scrollInfo) {
                      if (!store.state.isLoadingCampaigns &&
                          store.state.campaigns.length >=
                              offset * PAGINATION_LIMIT &&
                          scrollInfo.metrics.pixels >=
                              scrollInfo.metrics.maxScrollExtent - 500) {
                        print("LOADING MORE CAMPAIGNS");
                        // store.dispatch(StartCampaignsLoadingAction()); // Triggers reset state & list.
                        store.dispatch((x) => loadMoreCampaignsPaginatedAction(
                            store, this.offset + 1));
                        this.setState(() {
                          offset += 1;
                        });
                      } else {
                        // NO ACTION
                      }
                      return;
                    },
                    child: store.state
                            .isLoadingCampaigns // && store.state.campaigns.length == 0
                        ? Container(
                            child: Center(
                              child: CircularProgressIndicator(
                                color: Colors.blue,
                              ),
                            ),
                          )
                        : StoreConnector<AppState, int>(
                            converter: (store) => store.state.campaignsListKey,
                            builder: (context, key) => Scrollbar(
                              child: ListView.builder(
                                  //ScrollablePositionedList.builder(
                                  key: Key(key.toString()),
                                  // itemScrollController: scrollController,
                                  //ListView.builder(
                                  //controller: scrollController,
                                  padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
                                  itemCount: store.state.campaigns.length,
                                  itemBuilder: (context, index) {
                                    // return AutoScrollTag(
                                    //   key: ValueKey(index),
                                    //   controller: scrollController,
                                    //   index: index,
                                    //   child: _CampaignItem(campaigns[index], index),
                                    // );
                                    return _CampaignItem(
                                        store.state.campaigns[index],
                                        index,
                                        widget.fromAdGroup);
                                  }),
                            ),
                          ),
                  ),
                ),
              );
            }),
      ),
    );
  }
}

class _CampaignItem extends StatefulWidget {
  final int index;
  final Campaign campaign;
  final bool fromAdGroup;

  _CampaignItem(this.campaign, this.index, this.fromAdGroup);

  @override
  _CampaignItemState createState() =>
      _CampaignItemState(this.campaign, this.index);
}

class _CampaignItemState extends State<_CampaignItem> {
  final int index;

  _CampaignItemState(this.campaign, this.index);

  Campaign campaign;

  List<Widget> _statsColumns(List<List<Metric>> splitMetrics) {
    List<Widget> out = [];
    for (List<Metric> metrics in splitMetrics) {
      out.add(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: new List<Widget>.generate(
          metrics.length,
          (int index) => _statContainer(
              metrics[index].name,
              getMetricDisplayValue(campaign.metrics, metrics[index].name,
                  metrics[index].valueType, null)),
        ),
      ));
    }
    return out;
  }

  Widget _statsContainer() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      height: 65,
      child: StoreConnector<AppState, List<List<Metric>>>(
          converter: (store) => splitArray(store.state.campaignMetrics
              .where((f) => f.isOn == true)
              .toList()),
          builder: (context, metrics) => Scrollbar(
              child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _statsColumns(metrics),
                  )))),
    );
  }

  Widget _statContainer(String key, String value) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 35, 5),
      width: MediaQuery.of(context).size.width * 0.425,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            fit: FlexFit.loose,
            child: Container(
              height: 15,
              child: Text(
                convertToDisplayName(key),
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 10,
                ),
              ),
            ),
          ),
          Text(value,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ))
        ],
      ),
      // ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(
              color: getColorFromIndex(index),
              width: 2.0,
            ),
          ),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.35),
              spreadRadius: 1,
              blurRadius: 2,
              offset: Offset(0, 0), // changes position of shadow
            ),
          ],
        ),
        width: MediaQuery.of(context).size.width * 0.75,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(0, 10, 10, 10),
              width: MediaQuery.of(context).size.width * 0.8,
              child: Text(campaign.name,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.none,
                    color: Colors.black,
                  )),
            ),
            Container(
              child: Text(
                campaign.status,
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.blue,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            // _statsContainer(),
            StoreConnector<AppState, Campaign>(converter: (store) {
              return store.state.currentCampaign;
            }, builder: (context, currentCampaign) {
              bool _selected = currentCampaign == null
                  ? false
                  : currentCampaign.id == campaign.id;
              return Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      StoreConnector<AppState, Function(Campaign c)>(
                        converter: (store) {
                          return (c) {
                            ANALYTICS_logEvent(store, 'Selected campaign');
                            store.dispatch(ModifyCurrentCampaignAction(
                                store, store.state, c));
                            // Remove any existing adGroup filters.
                            store.dispatch(
                                RemoveCampaignAdGroupFiltersAction(store));

                            store.dispatch(AddFilterAction(FilterValue(
                                "Campaign", "equals", c.id,
                                displayName: c.name,
                                valueType: "campaign",
                                stringFilterType: "campaignId")));
                            store
                                .dispatch((x) => updateVisibleSearchTermsAction(
                                      store,
                                      noAPI: false,
                                      campaignId: c.id,
                                    ));
                            if (widget.fromAdGroup) {
                              // Came from adgroups selection page, so only pop this and display it again.
                              Navigator.of(context).pop();
                            } else {
                              Navigator.of(context).pop();
                              Navigator.of(context)
                                  .popUntil((route) => route.isFirst);
                            }
                          };
                        },
                        builder: (context, callback) => GestureDetector(
                          onTap: () {
                            if (_selected) {
                              callback(null);
                            } else {
                              callback(campaign);
                            }
                          },
                          child: Container(
                            padding: EdgeInsets.fromLTRB(5, 5, 10, 5),
                            margin: EdgeInsets.fromLTRB(0, 10, 5, 5),
                            decoration: BoxDecoration(
                              color: _selected ? Colors.blue : Colors.white,
                              border: Border.all(
                                color: _selected
                                    ? Colors.white
                                    : Colors.blue.shade100,
                                width: 2.0,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                            ),
                            child: RichText(
                                text: TextSpan(children: [
                              WidgetSpan(
                                  alignment: PlaceholderAlignment.middle,
                                  child: Icon(
                                      _selected ? Icons.remove : Icons.add,
                                      color: _selected
                                          ? Colors.white
                                          : Colors.blue,
                                      size: 20)),
                              TextSpan(
                                  text: _selected
                                      ? "Filtering by campaign"
                                      : "Filter by campaign",
                                  style: TextStyle(
                                    color:
                                        _selected ? Colors.white : Colors.blue,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    decoration: TextDecoration.none,
                                    letterSpacing: -.5,
                                  )),
                            ])),
                          ),
                        ),
                      ),
                    ],
                  ));
            })
          ],
        ));
  }
}
