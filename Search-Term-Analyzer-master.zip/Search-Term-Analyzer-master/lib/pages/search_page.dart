// Search through all objects at once, not restricted to campaigns, adgroups, etc.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/models/search_result.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';

class SearchPage extends StatefulWidget {
  final Store<AppState> _store;
  final bool customerClientsOnly;

  const SearchPage(this._store, {this.customerClientsOnly = false});

  @override
  _SearchPageState createState() => _SearchPageState(this._store);
}

class _SearchPageState extends State<SearchPage> {
  Store<AppState> _store;
  // List<SearchResult> _formattedCampaigns;
  // List<AdGroup> _formattedAdgroups;
  // List<SearchTerm> _formattedSearchTerms;
  List<SearchResult> _allData;
  List<SearchResult> _searchResults = [];
  String _query = "";

  _SearchPageState(this._store);

  TextEditingController _controller = TextEditingController();
  // ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    ANALYTICS_logScreenEnteredEvent(_store, "Search Page");

    List<SearchResult> allData = [];
    List<String> customerIds = [];
    if (widget.customerClientsOnly == false) {
      this._store.state.customers.asMap().forEach((int index, Customer c) {
        allData.add(SearchResult(c.descriptiveName, c, null, "ACCOUNT", index));
        customerIds.add(c.id);
      });
    }
    this
        ._store
        .state
        .customerClients
        .asMap()
        .forEach((int index, CustomerClient cc) {
      // Make sure client customer is not a duplicate of customer.
      if (!customerIds.contains(cc.id)) {
        // Get customer
        Customer customer = _store.state.customers
            .firstWhere((e) => e.id == cc.parentId, orElse: () => null);
        if (customer != null) {
          allData.add(
              SearchResult(cc.name, customer, cc, "CLIENT ACCOUNT", index));
        } else {
          print("SearchPage Customer was empty!!!");
        }
      }
    });
    // this._store.state.campaigns.asMap().forEach((int index, Campaign c) =>
    //     allData.add(SearchResult(c.name, "CAMPAIGN", index)));

    // this._store.state.adGroups.asMap().forEach((int index, AdGroup a) =>
    //     allData.add(SearchResult(a.name, "ADGROUP", index)));

    // this._store.state.searchTerms.asMap().forEach((int index, SearchTerm s) =>
    //     allData.add(SearchResult(s.id, "SEARCHTERM", index)));

    this.setState(() {
      _allData = allData;
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  void filterSearchResults(String query) async {
    this.setState(() {
      this._searchResults.clear();
    });
    if (query.isNotEmpty) {
      // DB search
      // var futures = await Future.wait([
      //     getLikeText('SEARCHTERMS', query, 'id'),
      //     getLikeText('ADGROUPS', query, 'name'),
      //     getLikeText('CAMPAIGNS', query, 'name')
      //   ]);

      this.setState(() {
        this._query = query;

        // Local search
        this._searchResults.addAll(this
            ._allData
            .where((f) => f.name.toLowerCase().contains(query.toLowerCase())));
      });
    }
  }

  List<TextSpan> highlightOccurrences(String source, String query) {
    if (query == null ||
        query.isEmpty ||
        !source.toLowerCase().contains(query.toLowerCase())) {
      return [TextSpan(text: source)];
    }
    final matches = query.toLowerCase().allMatches(source.toLowerCase());

    int lastMatchEnd = 0;

    final List<TextSpan> children = [];
    for (var i = 0; i < matches.length; i++) {
      final match = matches.elementAt(i);

      if (match.start != lastMatchEnd) {
        children.add(TextSpan(
          text: source.substring(lastMatchEnd, match.start),
        ));
      }

      children.add(TextSpan(
        text: source.substring(match.start, match.end),
        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
      ));

      if (i == matches.length - 1 && match.end != source.length) {
        children.add(TextSpan(
          text: source.substring(match.end, source.length),
        ));
      }

      lastMatchEnd = match.end;
    }
    return children;
  }

  Future<int> _loadSearchTermSaveActionsForCustomer(
      String columnName, String columnValue) async {
    return (await SearchTermSaveAction.fromMaps(columnName, columnValue))
        .length;
  }

  Widget _resultList(BuildContext context) {
    return Scrollbar(
      // isAlwaysShown: true,
      // controller: _scrollController,
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: this._searchResults.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                String t = _searchResults[index].resultType;
                int resultIndex = _searchResults[index].index;

                ANALYTICS_logEvent(this._store, 'Search result selected');

                // if 'ACCOUNT', modify Customer
                // if 'CLIENT ACCOUNT', modify Customer and CustomerClient.
                // if (t == "ACCOUNT") {
                //   List<CustomerClient> customerClients = await CustomerClient.fromMaps(store, customer.id);
                //   customerClients = customerClients
                //     .where((cc) => cc.id != customer.id)
                //     .toList();
                //   store.dispatch(ModifyCurrentCustomerAction(store, store.state, customer, customerClients));
                // } else if (t == "CLIENT ACCOUNT") {
                //   List<CustomerClient> customerClients = await CustomerClient.fromMaps(store, customer.id);
                //   customerClients = customerClients
                //     .where((cc) => cc.id != customer.id)
                //     .toList();
                //   store.dispatch(ModifyCurrentCustomerAction(store, store.state, customer, customerClients));

                //   store.dispatch(ModifyCurrentCustomerClientAction(store, store.state, c));
                //   store.dispatch((x) => updateVisibleSearchTermsAction(store, noAPI: true));
                // }
                Navigator.of(context).pop(_searchResults[index]);
              },
              child: ListTile(
                // title: Text("${this._searchResults[index].name}"),
                title: Text(
                  this._searchResults[index].resultType == "ACCOUNT"
                      ? "${this._searchResults[index].resultType}"
                      : "${this._searchResults[index].customer.descriptiveName}",
                  style: TextStyle(
                      //color: Color.fromRGBO(150,150,150,1),
                      color: Colors.blue,
                      fontSize: 12,
                      fontWeight: FontWeight.w600),
                ),
                subtitle: RichText(
                  text: TextSpan(
                    children: highlightOccurrences(
                        "${this._searchResults[index].name}", this._query),
                    //style: TextStyle(color: Colors.grey),
                    style: TextStyle(
                      color: Color.fromRGBO(150, 150, 150, 1),
                    ),
                  ),
                ),
                trailing: FutureBuilder(
                  future: _loadSearchTermSaveActionsForCustomer(
                      this._searchResults[index].resultType == "ACCOUNT"
                          ? 'customerId'
                          : 'managerId',
                      this._searchResults[index].resultType == "ACCOUNT"
                          ? this._searchResults[index].customer.id
                          : this._searchResults[index].customerClient.id),
                  builder: (BuildContext context, AsyncSnapshot<int> snapshot) {
                    if (snapshot.hasData && snapshot.data > 0) {
                      return Container(
                        height: 37.5,
                        width: 50,
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          // borderRadius: BorderRadius.circular(6),
                        ),
                        padding: EdgeInsets.fromLTRB(5, 0, 5, 0),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("${snapshot.data}",
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white,
                                  )),
                              Text(
                                "Unsaved",
                                style: TextStyle(
                                  fontSize: 9,
                                  color: Colors.white,
                                ),
                              ),
                            ]),
                      );
                    } else {
                      return Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.black54,
                        size: 16.0,
                      );
                    }
                  },
                ),
              ),
            );
          }),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(color: Colors.blue),
        backgroundColor: Color.fromRGBO(245, 245, 245, 1),
        title: TextField(
          autofocus: true,
          controller: _controller,
          onChanged: (value) {
            filterSearchResults(value);
          },
          decoration: InputDecoration(
            labelText: widget.customerClientsOnly
                ? "Search in Client Accounts"
                : "Search in Accounts", //"Search in Campaigns, Adgroups, SearchTerms",
            hintText: "Search",
            prefixIcon: Icon(Icons.search),
            // border: OutlineInputBorder(
            //   borderRadius: BorderRadius.all(Radius.circular(25.0)),
            // ),
          ),
        ),
      ),
      body: _resultList(context),
    );
  }
}

/*
if (t == 'CAMPAIGN') {
  // double listItemHeight = 198.00;
  // this._store.state.campaignsScrollController.jumpToIndex(10);
  this._store.state.bottomController.jumpToPage(0);
  this._store.dispatch(UpdateCurrentPageIndexAction(0));
  setSharedPreferenceValue<int>(
      SHARED_PREFERENCE_KEYS.CURRENT_BOTTOM_NAVIGATION_TAB, 0);
  // int i = this
  //     ._store
  //     .state
  //     .campaigns
  //     .indexWhere((w) => w.name == _searchResults[index].name);
  Future.delayed(const Duration(milliseconds: 50), () {
    this
        ._store
        .state
        .campaignsScrollController
        .jumpTo(index: resultIndex);
  });
  //.jumpTo((i * listItemHeight).toDouble());
  // this._store.state.campaignsScrollController.scrollToIndex(i,
  //     preferPosition: AutoScrollPosition.begin);
  } else if (t == "ADGROUP") {
  // double listItemHeight = 198.00;
  // this._store.state.adgroupsScrollController.jumpToIndex(10);
  this._store.state.bottomController.jumpToPage(1);
  this._store.dispatch(UpdateCurrentPageIndexAction(1));
  setSharedPreferenceValue<int>(
      SHARED_PREFERENCE_KEYS.CURRENT_BOTTOM_NAVIGATION_TAB, 1);

  // int i = this
  //     ._store
  //     .state
  //     .adGroups
  //     .indexWhere((w) => w.name == _searchResults[index].name);
  Future.delayed(const Duration(milliseconds: 50), () {
    this._store.state.adgroupsScrollController.jumpTo(
        index: resultIndex); //(i * listItemHeight).toDouble());
  });
  // this._store.state.adgroupsScrollController.scrollToIndex(i,
  //     preferPosition: AutoScrollPosition.begin);
  } else {
  // double listItemHeight = 228.00;
  this._store.state.bottomController.jumpToPage(2);
  this._store.dispatch(UpdateCurrentPageIndexAction(2));
  setSharedPreferenceValue<int>(
      SHARED_PREFERENCE_KEYS.CURRENT_BOTTOM_NAVIGATION_TAB, 2);
  // this._store.state.searchTermsScrollController.jumpToIndex(10);
  // int i = this._store.state.searchTerms.indexWhere((w) =>
  //   w.id == _searchResults[index].name
  // );
  // print("FOUND INDEX: $i");
  // this._store.state.searchTermsScrollController.highlight(i,
  // highlightDuration: Duration.zero
  // );
  // this._store.state.searchTermsScrollController.jumpTo((i * listItemHeight).toDouble());
  // this
  //     ._store
  //     .state
  //     .searchTermsScrollController
  //     .jumpTo(index: resultIndex);
  // this._store.state.searchTermsScrollController.scrollToIndex(
  //     i,
  //     preferPosition: AutoScrollPosition.begin,
  //     // duration: Duration(milliseconds:1)
  //     );
  Future.delayed(const Duration(milliseconds: 50), () {
    this
        ._store
        .state
        .searchTermsScrollController
        .jumpTo(index: resultIndex);
  });
  }
  Future.delayed(const Duration(milliseconds: 100), () {
  Navigator.of(context).pop();
  });
*/