import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/string_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_group.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_filter_item.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_order_item.dart';
import 'package:searchTermAnalyzerFlutter/widgets/gradient_icon.dart';
import 'package:searchTermAnalyzerFlutter/widgets/on_off_switch.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:redux/redux.dart';
import 'package:new_gradient_app_bar/new_gradient_app_bar.dart';

class PurchaseableProductsPage extends StatefulWidget {
  final Store<AppState> _store;

  PurchaseableProductsPage(this._store);

  @override
  _PurchaseableProductsPageState createState() =>
      _PurchaseableProductsPageState(this._store);
}

class _PurchaseableProductsPageState extends State<PurchaseableProductsPage> {
  final Store<AppState> _store;

  _PurchaseableProductsPageState(this._store);

  @override
  void initState() {
    super.initState();
    if (this._store.state.iapProducts.length == 0) {
      _store.dispatch((x) => loadIapProductsAction(this._store));
    }
    ANALYTICS_logScreenEnteredEvent(_store, "Purchaseable Products");
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget _product(
      BuildContext context, ProductDetails pd, List<PastPurchase> purchases) {
    bool isPurchased = false;

    Widget _iconWidget;
    // Create icon
    if (pd.id == SKU_SINGLE_SAVE) {
      _iconWidget = Icon(Icons.arrow_forward_rounded, size: 40);
    } else if (pd.id == SKU_MONTHLY_SUBSCRIPTION) {
      _iconWidget = Icon(Icons.arrow_forward_ios_sharp, size: 40);
    } else if (pd.id == SKU_LIFETIME_PURCHASE) {
      _iconWidget = Row(children: [
        Icon(Icons.arrow_forward_ios_sharp, size: 40),
        Container(
          transform: Matrix4.translationValues(-15.0, 0.0, 0.0),
          child: Icon(Icons.arrow_forward_ios_sharp, size: 40),
        ),
      ]);
    }

    return GestureDetector(
      onTap: () async {
        ANALYTICS_logEvent(this._store, 'Purchase product pressed', {
          "productName": pd.title,
        });
        ANALYTICS_logPurchase(this._store, pd);
        // print("PURCHASING: ${pd.id}");
        await purchaseProduct(pd);
        Navigator.of(context).pop();
      },
      child: Container(
        padding: EdgeInsets.all(25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // GradientIcon(Icons.local_fire_department,
            //   50.0,
            //   LinearGradient(
            //     begin: Alignment.bottomCenter,
            //     end: Alignment.topCenter,
            //     colors: [Colors.red, Colors.orange],
            //   ),
            // ),
            Container(
              margin: EdgeInsets.only(
                bottom: 10,
              ),
              child: _iconWidget,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(
                  pd.title
                      .replaceAll(
                          " (webbi.ads.searchtermanalyzer (unreviewed))", "")
                      .replaceAll("(Search Terms Manager)", ""),
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w600,
                  )),
              // Text(pd.id),
              Text(pd.price.toString(),
                  style: TextStyle(
                    fontSize: 30,
                    // color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ))
            ]),
            Container(
              margin: EdgeInsets.only(top: 10),
              child: Text(pd.description,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 16,
                  )),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: NewGradientAppBar(
        title: Text("Unlimited uploads"),
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Colors.yellow, Color.fromRGBO(52, 168, 83, 1)],
        ),
      ),
      //AppBar(title: Text("Premium features"),
      backgroundColor: Colors.white,
      body: Scrollbar(
        isAlwaysShown: true,
        child: StoreConnector<AppState, Store<AppState>>(
          converter: (store) => store,
          builder: (context, store) => Stack(
            children: [
              ListView.builder(
                padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
                itemCount: store.state.iapProducts
                    .length, //.where((f) => f.id != SKU_SINGLE_SAVE).toList().length,
                itemBuilder: (context, index) =>
                    store.state.iapProducts[index].id != SKU_SINGLE_SAVE
                        ? _product(
                            context,
                            store.state.iapProducts[index],
                            store.state.pastPurchases,
                          )
                        : SizedBox.shrink(),
              ),
              !store.state.isIAPAvailable
                  ? Center(
                      child: Text("In-app purchases are not available"),
                    )
                  : SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }
}
