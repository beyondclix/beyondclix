// Visible on first three loads.
// Loads are stored/loaded from SharedPreferences

import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';

final Uri _feedbackUrl = Uri.parse('mailto:' + FEEDBACK_URL);

@immutable
class InitialScreen extends StatelessWidget {
  final Store<AppState> store;
  final GlobalKey<NavigatorState> navigatorKey;

  InitialScreen(this.navigatorKey, this.store) {
    ANALYTICS_logScreenEnteredEvent(this.store, "Samar Intro page");
  }

  void _launchUrl(Uri url, {Uri fallbackUrl}) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.externalApplication,
    )) {
      // mode: LaunchMode.inAppWebView)) {
      ANALYTICS_logEvent(this.store,
          "Error launching $url, using fallback https URL: $fallbackUrl");

      // TODO use fallback https URL.
      if (fallbackUrl != null) {
        if (await launchUrl(
          fallbackUrl,
          // mode: LaunchMode.inAppWebView,
          mode: LaunchMode.externalApplication 
        )) {
          ANALYTICS_logEvent(this.store, "Successfully Launched fallback Url");
        } else {
          ANALYTICS_logEvent(
              this.store, "Error launching fallback URL: $fallbackUrl");
        }
      }

      // throw 'Could not launch $_feedbackUrl';
    } else {
      ANALYTICS_logEvent(this.store, "Successfully Launched feedback Url");
    }
  }

  // void _launchLinkedInUrl() async {
  //   if (!await launchUrl(
  //     Uri.parse(LINKEDIN_URL),
  //     mode: LaunchMode.inAppWebView,
  //   )) {
  //     ANALYTICS_logEvent(this.store,
  //         "Error launching $LINKEDIN_URL, using fallback https URL");

  //     // TODO use fallback https URL.

  //     throw 'Could not launch $LINKEDIN_URL';
  //   } else {
  //     ANALYTICS_logEvent(this.store, "Launched feedback Url");
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: true,
      child: IgnorePointer(
        ignoring: false,
        child: Container(
          color: Colors.white,
          padding: EdgeInsets.only(left: 25, right: 25, top: 30),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: MediaQuery.of(context).size.height - 175,
                margin: EdgeInsets.only(top: 5),
                child: Scrollbar(
                  child: SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(
                      parent: BouncingScrollPhysics(),
                    ),
                    scrollDirection: Axis.vertical,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Hi 👋",
                            style: TextStyle(
                              fontSize: 24,
                            )),
                        SizedBox(height: 10),
                        // Text("Thanks for trying Search Terms Manager, we're brand new!",
                        // Text("Thanks for trying the 'Search Terms Manager' mobile app, we're brand new!",
                        // style: TextStyle(
                        //     fontSize: 15,
                        // )),
                        RichText(
                          text: TextSpan(
                              style: TextStyle(
                                fontSize: 15,
                              ),
                              children: [
                                TextSpan(
                                    text:
                                        "Thanks for trying Search Terms Manager",
                                    style: TextStyle(
                                      color: Colors.black,
                                    )),
                                // WidgetSpan(
                                //   child: Container(
                                //     margin: EdgeInsets.symmetric(horizontal: 1),
                                //     child: ClipRRect(
                                //       borderRadius: BorderRadius.only(
                                //         topLeft: Radius.circular(8.0),
                                //         topRight: Radius.circular(8.0),
                                //       ),
                                //       child: Image.asset(
                                //         'lib/assets/icon.png',
                                //         height: 20,
                                //         width: 20,
                                //       ),
                                //     ),
                                //   ),
                                // ),
                                TextSpan(
                                  text: ", we're brand new!",
                                  style: TextStyle(
                                    color: Colors.black,
                                  ),
                                ),
                              ]),
                        ),
                        // SizedBox(height: 5),
                        // Text("The app is just launched, it's brand new!"),
                        SizedBox(height: 5),
                        // Text("You may have questions and comments. We are very keen to know what they are."),
                        Text(
                          "You may have questions and comments, we are keen to hear them and will offer free lifetime access for any feedback that makes it into the next version!",
                          // SizedBox(height: 5),
                          // Text("will offer free lifetime access for any feedback that makes it into the next version!",
                          // Text("Here is an incentive. We can give you free life-time access to the app in return for any feedback you give that becomes a part of the next version!",
                          style: TextStyle(
                              // fontStyle: FontStyle.italic,
                              ),
                        ),
                        SizedBox(height: 5),
                        Text("We are waiting to hear from you."),
                        // Text("Looking forward to hearing from you."),
                        SizedBox(height: 5),
                        Text("Thanks!"),
                        SizedBox(height: 5),
                        Text("Sam!"),
                        // SizedBox(height: 5),
                        // Text("(Samar Jit)"),
                        SizedBox(height: 5),
                        Wrap(
                          children: [
                            // Row
                            Container(
                              margin: EdgeInsets.only(right: 15),
                              child: Image.asset(
                                'lib/assets/samar_profile.png',
                                height: 125,
                                width: 125,
                                fit: BoxFit.fill,
                              ),
                            ),
                            Container(
                                margin: EdgeInsets.only(top: 15),
                                child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Samar JIT",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 21,
                                        ),
                                      ),
                                      Text(
                                        "Director, BeyondClix Limited",
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        "Mobile/WhatsApp: +64-22-026-0126",
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        "Skype: ppcspecialists",
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        "Location: Auckland, New Zealand",
                                        style: TextStyle(
                                          fontSize: 14,
                                        ),
                                      ),
                                      GestureDetector(
                                          child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 15, vertical: 5),
                                            margin: EdgeInsets.only(top: 10),
                                            decoration: BoxDecoration(
                                              color: Colors.blue,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(50)),
                                            ),
                                            child: Text(
                                              "LINKEDIN",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 12,
                                                letterSpacing: .5,
                                              ),
                                            ),
                                          ),
                                          onTap: () {
                                            _launchUrl(Uri.parse(LINKEDIN_URL));
                                          }),
                                      // SizedBox(height: 25),
                                      // GestureDetector(
                                      //   onTap: () {
                                      //     ANALYTICS_logEvent(
                                      //         this.store, "Pressed GIVE FEEDBACK");
                                      //     _launchUrl(Uri.parse(FEEDBACK_FALLBACK_URL),
                                      //         fallbackUrl: _feedbackUrl);
                                      //   },
                                      //   child: Container(
                                      //     color: Colors.blue,
                                      //     padding:
                                      //         EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                                      //     margin: EdgeInsets.only(top: 15, bottom: 15),
                                      //     child: Text(
                                      //       "GIVE FEEDBACK",
                                      //       style: TextStyle(
                                      //         color: Colors.white,
                                      //         fontWeight: FontWeight.w600,
                                      //       ),
                                      //     ),
                                      //   ),
                                      // ),
                                    ]))
                          ],
                        ),
                        // SizedBox(height: 5),
                      ],
                    ),
                  ),
                ),
              ),
              // Container(
              //   height: 90,
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //     children: [
                    // GestureDetector(
                    //     onTap: () {
                    //       ANALYTICS_logEvent(this.store, "Pressed GIVE FEEDBACK");
                    //       _launchUrl(_feedbackUrl,
                    //           fallbackUrl: Uri.parse(FEEDBACK_FALLBACK_URL));
                    //     },
                    //     child: Container(
                    //       color: Colors.blue,
                    //       padding:
                    //           EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                    //       margin: EdgeInsets.only(top: 15, bottom: 15),
                    //       child: Text(
                    //         "GIVE FEEDBACK",
                    //         style: TextStyle(
                    //           color: Colors.white,
                    //           fontWeight: FontWeight.w600,
                    //         ),
                    //       ),
                    //     )),
                    // GestureDetector(
                    //     onTap: () {
                    //       print(
                    //           "initial screen: ${store.state.isShowingInitialScreen}");
                    //       ANALYTICS_logEvent(
                    //           this.store, "Pressed NEXT at Initial Screen");

                    //       this.store.dispatch(
                    //           UpdateIsShowingWelcomeScreenAction(false));

                    //       // Navigator.of(context).pop();
                    //       // Navigator.of(context).popUntil((route) => route.isFirst);
                    //       // this.navigatorKey.currentState.popUntil((route) => route.isFirst) ('/2');
                    //     },
                    //     child: Container(
                    //       // padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                    //       padding:
                    //           EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                    //       // margin: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                    //       margin: EdgeInsets.only(top: 15, bottom: 15),
                    //       decoration: BoxDecoration(
                    //         // color: Colors.blue,
                    //         border: Border.all(color: Colors.blue),
                    //         // borderRadius: BorderRadius.all(Radius.circular(2)),
                    //       ),
                    //       child: Text(
                    //         "Next",
                    //         style: TextStyle(
                    //           color: Colors.blue,
                    //           // fontSize: 16,
                    //         ),
                    //       ),
                    //     )),
                //   ],
                // ),
              // )
            ],
          ),
        ),
      ),
    );
  }
}
