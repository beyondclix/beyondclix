// Select the date range to work with.abstract

import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import '../redux/actions.dart';
import '../redux/models.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';

class DateRangePage extends StatefulWidget {
  // This is no longer passed from parent, but is updated and used from the store
  // final Function(DateRange) updateParentDate;
  // final DateRange currentDateOption;
  DateRangePage(
    this.timeZone, {
    Key key,
    // /*@required */ this.updateParentDate,
    // /*@required*/ this.currentDateOption
  }) : super(key: key);

  final String timeZone;

  @override
  _DateRangePageState createState() =>
      _DateRangePageState(/*this.currentDateOption*/);
}

// class OnSaveCallback {
//   DateRange dateRange;

//   OnSaveCallback(this.dateRange);
// }

class _DateRangePageState extends State<DateRangePage> {
  // DateRange currentDateOption;

  _DateRangePageState(/*this.currentDateOption*/);

  @override
  void initState() {
    super.initState();
  }

  Widget _listItem(DateRange rangeType) => StoreConnector<AppState,
          Function(DateRange dateRange, BuildContext context)>(
        //VoidCallback /*OnSaveCallback*/
        // converter: (store) => store.state,
        converter: (store) {
          // Use Flutter Redux global state management.
          return (dateRange, context) async {
            // Can also use an enum to call the action
            await resetAdGroupsToLoad(store.state.currentManager.id);

            // Search terms are no reloaded, they remain in DB.
            // But the blanks need to be removed so that data in their fields is read.

            DB_RemoveBlank("SEARCHTERMS", 'customerId',
                store.state.currentManager.id, 'text');
            store
                .dispatch(ModifyDateRangeAction(store, store.state, dateRange));

            Navigator.of(context).popUntil((route) => route.isFirst);
          };
        },
        builder: (context, callback) => StoreConnector<AppState,
                Store<AppState>>(
            converter: (store) => store,
            builder: (context, store) => GestureDetector(
                  onTap: () async {
                    ANALYTICS_logEvent(store, 'Date range selected', {
                      "dateRange": rangeType.getName(),
                    });

                    DateRange dr = DateRange(
                        rangeType.getName(),
                        rangeType.getKeyName(),
                        null,
                        null,
                        store.state.currentManager.timeZone);
                    rangeType =
                        dr; // Do this to set lowerEpochDate & upperEpochDate on first load.
                    // print("dr: ${dr.lowerEpochDate}, ${dr.upperEpochDate}, ${dr.getName()}, ${dr.getKeyName()}");

                    // If selected date is no different, no action.
                    if (rangeType.getName() ==
                            store.state.currentDateRange.getName() &&
                        rangeType.getName() != 'Custom') {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else if (rangeType.getName() == 'Custom') {
                      // Show custom date picker.
                      DateTimeRange pickedDateTimeRange =
                          await showDateRangePicker(
                              context: context,
                              firstDate: DateTime.utc(2000, 01, 01),
                              lastDate: new DateTime.now());

                      print("pickedDateTimeRange: $pickedDateTimeRange");
                      if (pickedDateTimeRange != null) {
                        print(
                            "Selected date range: ${date2String(pickedDateTimeRange.start)} AND ${date2String(pickedDateTimeRange.end)}");

                        // Set the value used to query the API.
                        rangeType.setKeyName(
                            "BETWEEN '${date2String(pickedDateTimeRange.start)}' AND '${date2String(pickedDateTimeRange.end)}'");
                        // rangeType.setAdditionalName(" (${date2String(pickedDateTimeRange.start)} to ${date2String(pickedDateTimeRange.end)})");

                        // Set the display name.
                        rangeType.setAdditionalName(
                            "${date2String(pickedDateTimeRange.start)} to ${date2String(pickedDateTimeRange.end)}");
                        rangeType.lowerEpochDate =
                            date2EpochTime(pickedDateTimeRange.start);
                        rangeType.upperEpochDate =
                            date2EpochTime(pickedDateTimeRange.end);
                        setSharedPreferenceValue<String>(
                            SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_START,
                            date2EpochTime(pickedDateTimeRange.start)
                                .toString());
                        setSharedPreferenceValue<String>(
                            SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_END,
                            date2EpochTime(pickedDateTimeRange.end).toString());
                        callback(rangeType, context);

                        // Navigator.pop(context);
                        // Navigator.of(context).popUntil((route) => route.isFirst);

                      }
                    } else {
                      setSharedPreferenceValue<String>(
                          SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_START, "");
                      setSharedPreferenceValue<String>(
                          SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_END, "");

                      callback(rangeType, context);
                      // Navigator.pop(context);
                      // Navigator.of(context).popUntil((route) => route.isFirst);

                    }
                  },
                  child: StoreConnector<AppState, DateRange>(
                    converter: (store) => store.state.currentDateRange,
                    builder: (context, currentDateRange) => Column(children: [
                      ListTile(
                        contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                        tileColor:
                            rangeType.getName() == currentDateRange.getName()
                                ? Colors.lightBlue
                                : Colors.transparent,
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                              // decoration: BoxDecoration(
                              //     border: Border(
                              //         bottom: BorderSide(
                              //             width: 1.0, color: Colors.black12))),
                              width: MediaQuery.of(context).size.width * 0.75,
                              child: Text(
                                rangeType
                                    .getName(), // + (rangeType.getName() == 'Custom' ? ' ' + rangeType.getAdditionalName() : ''),
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: rangeType.getName() ==
                                            currentDateRange.getName()
                                        ? Colors.white
                                        : Colors.black87),
                              ),
                            ),
                            // Only show icon if date is selected
                            // Can use trailing: for ListTile instead.
                            rangeType.getName() == currentDateRange.getName()
                                ? Icon(
                                    Icons.check,
                                    color: Colors.white,
                                    size: 28.0,
                                  )
                                : Text("")
                          ],
                        ),
                      ),
                      Divider(
                        height: 1,
                      ),
                    ]),
                  ),
                )),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Date Range"),
          // actions: <Widget>[
          //   Padding(
          //       padding: EdgeInsets.only(right: 20.0),
          //       child: GestureDetector(
          //         onTap: () {
          //           print('!!!Download pressed!!!');
          //         },
          //         child: Icon(Icons.download_sharp),
          //       )),
          // ],
        ),
        body: SingleChildScrollView(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var item in DateRange.dateOptions(widget.timeZone))
              _listItem(item)
          ],
        )));
  }
}
