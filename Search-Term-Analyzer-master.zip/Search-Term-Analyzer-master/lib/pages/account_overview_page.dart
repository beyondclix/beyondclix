import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/pages/adgroups_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_list.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/keywords_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/search_terms_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';

class AccountOverviewPage extends StatefulWidget {
  AccountOverviewPage();

  @override
  _AccountOverviewPageState createState() => _AccountOverviewPageState();
}

class _AccountOverviewPageState extends State<AccountOverviewPage>
    with SingleTickerProviderStateMixin {
  _AccountOverviewPageState();
  int _selectedIndex = 0;

  TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _selectedIndex = _tabController.index;
      });
    });
  }

  // List<Keywords> _keywords = () async => await getKeywords(this.clientCustomerId.toString(), this.customerId.toString());

  Widget _displayContainer(int number, String label) {
    return Container(
        padding: EdgeInsets.all(10),
        margin: EdgeInsets.fromLTRB(10, 20, 10, 10),
        // width: MediaQuery.of(context).size.width * 0.42,
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(
              color: Color.fromRGBO(0, 0, 0, .2),
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.35),
                spreadRadius: 1,
                blurRadius: 2,
                offset: Offset(0, 0), // changes position of shadow
              ),
            ],
            borderRadius: BorderRadius.all(Radius.circular(4))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
                padding: EdgeInsets.all(20),
                margin: EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Color.fromRGBO(0, 0, 0, .2),
                    width: 1.0,
                  ),
                ),
                child: Text(number.toString(),
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ))),
            Text(label),
          ],
        ));
  }

  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, Store<AppState>>(
        converter: (store) => store,
        builder: (context, store) => Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => CampaignsOverviewPage(
                                    store.state.campaigns)));
                      },
                      child: _displayContainer(
                          store.state.campaigns.length, "Campaigns"),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => AdGroupsOverviewPage(
                                    store.state.adGroups)));
                      },
                      child: _displayContainer(
                          store.state.adGroups.length, "AdGroups"),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => SearchTermsPage(
                                      store,
                                      store.state,
                                      //state.searchTerms,
                                      /*state.currentCustomer.id,
                                    state.currentManager.id*/
                                    )));
                      },
                      child: _displayContainer(
                          store.state.searchTerms.length, "Search Terms"),
                    )
                  ]),
            ));
  }
}
// return Scaffold(
//   appBar: AppBar(
//     title: Text("Account Overview"),
//     actions: <Widget>[
//       Padding(
//           padding: EdgeInsets.only(right: 20.0),
//           child: GestureDetector(
//             onTap: () {
//               Navigator.push(
//                   context,
//                   new MaterialPageRoute(
//                       builder: (context) => DateRangePage()));
//             },
//             child: Icon(Icons.date_range),
//           )),
//     ],
//   ),
//   body: Center(
//     child: Column(
//       children: [
//         Row(
//           children: [
//             FutureBuilder(
//                 future: getCampaigns(this.clientCustomerId.toString(),
//                     this.customerId.toString()),
//                 builder: (context, snapshot) {
//                   // print("CAMPAIGN RECEIVED: " + snapshot.data.toString());
//                   if (snapshot.hasData || snapshot.data != null) {
//                     // Campaign campaign = snapshot.data;
//                     return Column(
//                       children: [
//                         Center(
//                             child: GestureDetector(
//                           onTap: () {
//                             // Navigator.push(context, new MaterialPageRoute(builder: (context) => Campaigns(this.customerId)));
//                           },
//                           // child: _displayContainer(account.campaigns.getCount(), "Campaigns"),
//                           child: _displayContainer(
//                               snapshot.data.length, "Campaigns"),
//                         )),
//                       ],
//                     );
//                   } else if (snapshot.hasError) {
//                     return Text("${snapshot.error}");
//                   }
//                   return CircularProgressIndicator();
//                 }),
//             FutureBuilder(
//                 future: getAdGroups(this.clientCustomerId.toString(),
//                     this.customerId.toString()),
//                 builder: (context, snapshot) {
//                   // print("ADGROUP RECEIVED: " + snapshot.data.length.toString());
//                   if (snapshot.hasData) {
//                     // || snapshot.data.length > 0 || snapshot.data != null
//                     return GestureDetector(
//                       onTap: () {
//                         // Navigator.push(context, new MaterialPageRoute(builder: (context) => AdGroups(this.customerId)));
//                       },
//                       // child: _displayContainer(account.adGroups.getCount(), "Ad Groups"),
//                       child: _displayContainer(
//                           snapshot.data.length, "Ad Groups"),
//                     );
//                   }
//                   return CircularProgressIndicator();
//                 }),
//           ],
//         ),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             FutureBuilder(
//                 // future: getKeywords(this.clientCustomerId.toString(),
//                 //     this.customerId.toString(), ),
//                 // builder: (context, snapshot) {
//                 //   // print("KEYWORDS RECEIVED: " + (snapshot.data.length > 0).toString());
//                 //   if (snapshot.hasData) {
//                     // || snapshot.data != null
//                     return GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             new MaterialPageRoute(
//                                 builder: (context) => KeywordsPage(
//                                     this.customerId,
//                                     this.clientCustomerId,
//                                     snapshot.data)));
//                       },
//                       // child: _displayContainer(account.keywords.getCount(), "Search Terms"),
//                       child: _displayContainer(
//                           snapshot.data.length, "Keywords"),
//                     );
//                   }
//                   return CircularProgressIndicator();
//                 }),
//             FutureBuilder(
//                 future: getSearchTerms(this.clientCustomerId.toString(),
//                     this.customerId.toString()),
//                 builder: (context, snapshot) {
//                   // print("Search Terms RECEIVED: " + (snapshot.data).toString());
//                   if (snapshot.hasData) {
//                     // || snapshot.data != null
//                     return GestureDetector(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             new MaterialPageRoute(
//                                 builder: (context) => SearchTermsPage(
//                                     snapshot.data,
//                                     this.clientCustomerId.toString(),
//                                     this.customerId.toString())));
//                       },
//                       // child: _displayContainer(account.keywords.getCount(), "Search Terms"),
//                       child: _displayContainer(
//                           snapshot.data.length, "Search Terms"),
//                     );
//                   }
//                   return CircularProgressIndicator();
//                 }),
//             // Column(
//             //   children: this._keywords,
//             // )
//           ],
//         ),
//       ],
//     ),
//   ),
//   floatingActionButton: FloatingActionButton(
//     onPressed: () => {},
//     tooltip: 'Increment',
//     child: Icon(Icons.add),
//   ),
// );

// @override
//   Widget build(BuildContext context) {
//     return Column(children: [
//       TabBar(
//         controller: _tabController,
//         // Scaffold(
//         //     appBar: AppBar(
//         //         // title: Text("Account Overview"),
//         //         // actions: <Widget>[],
//         //         bottom: TabBar(
//         tabs: [
//           Tab(
//             child: Text("Search Terms",
//                 style: TextStyle(
//                     color: _selectedIndex == 0
//                         ? Colors.lightBlue
//                         : Colors.black54)),
//           ),
//           Tab(
//             child: Text("Keywords",
//                 style: TextStyle(
//                     color: _selectedIndex == 1
//                         ? Colors.lightBlue
//                         : Colors.black54)),
//           )
//         ],
//       ),
//       Expanded(
//           child: StoreConnector<AppState, AppState>(
//               converter: (store) => store.state,
//               builder: (context, state) =>
//                   TabBarView(controller: _tabController, children: [
//                     SearchTermsPage(state.searchTerms, state.currentCustomer.id,
//                         state.currentManager.id),
//                     KeywordsPage(state.keywords)
//                   ])))
//     ]);
//)
//);

// DefaultTabController(
//         length: 2,
//         child: Builder(
//             builder: (BuildContext context) =>
