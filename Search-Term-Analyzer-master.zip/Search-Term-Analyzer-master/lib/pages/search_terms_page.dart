// View search terms
//
// Use dummy data for now to view all of the search terms.
//
import 'dart:ui';
import 'package:enum_to_string/enum_to_string.dart';
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
// import 'package:indexed_list_view/indexed_list_view.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/add_searchterm_to_keyword.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import '../common_functions.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class SearchTermsPage extends StatefulWidget {
  final AppState state;
  final Store<AppState> store;

  SearchTermsPage(this.store, this.state);

  _SearchTermsPageState createState() => _SearchTermsPageState();
}

class _SearchTermsPageState extends State<SearchTermsPage> {
  // final List<SearchTerm> searchTerms;
  int offset = 0;
  bool isLoadingPaginated = false;
  // bool isLoading = false;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  _SearchTermsPageState();

  // final ItemScrollController _scrollController = ItemScrollController();
  final ScrollController _scrollController =
      ScrollController(initialScrollOffset: 0.0);

  void _onRefresh() async {
    // widget.store.dispatch((x) => updateVisibleSearchTermsAction(widget.store, noAPI: true));

    widget.store.dispatch(StartLoadingToastAction());

    // Clear search terms that are currently displayed.
    widget.store.dispatch(ClearVisibleSearchTermsAction());

    await resetAdGroupsToLoad(widget.store.state.currentManager.id);

    // Search terms are not reloaded, they remain in DB.
    // but the blanks need to be removed so that data in their fields is read.
    DB_RemoveBlank("SEARCHTERMS", 'customerId',
        widget.store.state.currentManager.id, 'text');

    GLOBAL_searchTermsAPILoading = true;

    print("Refreshing search terms page");

    SearchTerm.fromAPIPaginated(
      widget.store,
      widget.store.state.currentCustomer.id,
      widget.store.state.currentManager.id,
      widget.store.state.currentDateRange,
      null, // store.state.currentCampaign.id,
      null, // store.state.currentAdGroup.id,
      adGroupToLoads: null,
      forceAPI: true,
    );

    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    _refreshController.loadComplete();
  }

  void afterBuild() {
    // Executes after build is complete.
    // print("BUILD COMPLETE!!!");
    // int lastIndex =
    //     widget.state.searchTerms.length - LIMIT; // Jump back one page.
    // print("Jumping to index: $lastIndex");

    // // move list to new location.
    // widget.state.searchTermsScrollController.jumpTo(index: lastIndex);
  }

  // Future<void> executeAfterBuild() async {
  //   print("BUILD COMPLETE ASYNC!!!");

  // int lastIndex =
  //     widget.state.searchTerms.length - LIMIT; // Jump back one page.
  // print("Jumping to index: $lastIndex");
  // if (lastIndex > 0/* && widget.state.searchTermsScrollController != null*/) {
  //   // move list to new location.
  //   Future.delayed(const Duration(milliseconds: 100), () {
  //     widget.state.searchTermsScrollController.jumpTo(index: lastIndex);
  //   });
  // }
  // }

  _displayNoSearchTermsText(int searchTermsCount) {
    return searchTermsCount == 0 &&
        GLOBAL_searchTermsAPILoading == false
        // && GLOBAL_searchTermsLoading == false
        // && GLOBAL_searchTermsAPILoading == false
        &&
        GLOBAL_searchTermsDBLoading == false;
    // && GLOBAL_adGroupsToLoadFinished == GLOBAL_adGroupsToLoadTotal;
  }

  @override
  Widget build(BuildContext context) {
    // Trigger build complete callback.
    // https://stackoverflow.com/questions/51216448/is-there-any-callback-to-tell-me-when-build-function-is-done-in-flutter
    // WidgetsBinding.instance.addPostFrameCallback((_) => afterBuild);
    // executeAfterBuild();
    // print("GLOBAL_searchTermsLoading: ${GLOBAL_searchTermsLoading}");
    // print("GLOBAL_searchTermsAPILoading: $GLOBAL_searchTermsAPILoading");
    // print("store.state.searchTerms.length: ${widget.store.state.searchTerms.length}");
    // print("store.state.showLoadingToast: ${widget.store.state.showLoadingToast}");
    // print("store.state.isLoadingSearchTerms: ${widget.store.state.isLoadingSearchTerms}");
    // print("GLOBAL_adGroupsToLoadFinished: $GLOBAL_adGroupsToLoadFinished");
    // print("GLOBAL_adGroupsToLoadTotal: $GLOBAL_adGroupsToLoadTotal");
    return Scaffold(
      body: StoreConnector<AppState, bool>(
        converter: (store) => store.state.isInitialSearchTermsLoading,
        builder: (context, isInitialSearchTermsLoading) =>
            isInitialSearchTermsLoading
                ? Center(
                    child: Container(
                      width: 50.0,
                      height: 50.0,
                      padding: const EdgeInsets.all(10.0),
                      child: CircularProgressIndicator(
                        color: Colors.blue,
                      ),
                    ),
                  )
                : SafeArea(
                    top: false,
                    bottom: true,
                    child: Center(
                      child: StoreConnector<AppState, ItemScrollController>(
                        converter: (store) =>
                            store.state.searchTermsScrollController,
                        builder: (context, scrollController) => Scrollbar(
                          interactive: true,
                          // isAlwaysShown: true,
                          controller:
                              _scrollController, //scrollController.scrollController, // Causes a display issue.
                          child:
                              // ListView.builder(
                              //     controller: scrollController, //_scrollController,
                              //     padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
                              //     itemCount: searchTerms.length,
                              //     itemBuilder: (context, index) {
                              //       // return AutoScrollTag(
                              //       //   key: ValueKey(index),
                              //       //   index: index,
                              //       //   controller: scrollController,
                              //         // child:
                              //         return SearchTermItem(searchTerms[index], index);
                              //       // );
                              //     }),
                              StoreConnector<AppState, Store<AppState>>(
                            converter: (store) {
                              // List<SearchTerm> searchTerms = store.state.searchTerms;
                              // for (FilterValue fv in store.state.filterValues) {
                              //   searchTerms = filterSearchTerms(fv, searchTerms);
                              // }
                              // for(var st in searchTerms) {
                              //   print("metric out: ${st.text} ${st.metrics['clicks'].value}");
                              // }
                              // print(isLoadingSearchTerms
                              //     "AFTER FILTER searchTerms.length: ${store.state.searchTerms.length}");
                              // return searchTerms;
                              return store;
                            },
                            builder: (context, store) =>
                                NotificationListener<ScrollNotification>(
                              onNotification: (ScrollNotification scrollInfo) {
                                // print("scrollInfo.metrics.pixels >= scrollInfo.metrics.maxScrollExtent: ${scrollInfo.metrics.pixels}, ${scrollInfo.metrics.maxScrollExtent}");
                                if (!store.state
                                        .isLoadingSearchTerms && //!isLoading &&
                                    scrollInfo.metrics.pixels >=
                                        scrollInfo.metrics.maxScrollExtent -
                                            1000) {
                                  // Start loading data.
                                  // print(
                                  //     "LOADING MORE ${store.state.isLoadingSearchTerms}");
                                  // store.dispatch(StartSearchTermsLoadingAction());

                                  // Don't load repeated calls.
                                  if (!isLoadingPaginated) {
                                    isLoadingPaginated = true;
                                    Future.delayed(
                                        const Duration(milliseconds: 500), () {
                                      isLoadingPaginated = false;
                                    });
                                    store.dispatch((x) =>
                                        loadMoreSearchTermsPaginatedAction(
                                            store, this.offset + 1));
                                    ANALYTICS_logEvent(
                                        store,
                                        'Loading more search terms to display',
                                        {
                                          "numberOfSearchTermsDisplayed":
                                              this.offset * 10
                                        });
                                    this.setState(() {
                                      // isLoading = true;
                                      offset += 1;
                                    });
                                  }
                                } else {
                                  // NO ACTION
                                }
                                return;
                              },
                              child: Stack(
                                children: [
                                  // Only display 'No search terms' if there are no search terms,
                                  // And more are currently not being loaded in.
                                  // true ||
                                  Container(
                                    margin: EdgeInsets.only(
                                        top: store.state
                                            .updateSearchTermFiltersDisplayTopOffset),
                                    child: StoreConnector<AppState, int>(
                                      converter: (store) =>
                                          store.state.searchTermsListKey,
                                      builder: (context, key) => SmartRefresher(
                                        enablePullDown: true,
                                        enablePullUp: false,
                                        header: ClassicHeader(
                                          idleText:
                                              "Pull to reload search terms",
                                          releaseText:
                                              "Release to reload search terms",
                                          refreshingText: "",
                                        ),
                                        controller: _refreshController,
                                        onRefresh: _onRefresh,
                                        child: ListView
                                            . /*ScrollablePositionedList.*/ builder(
                                          key: Key(key.toString()),
                                          // key: UniqueKey(), // Have to add this to force rerender.
                                          controller: _scrollController,
                                          // itemScrollController: scrollController,
                                          itemCount: store
                                                  .state.searchTerms.length +
                                              (_displayNoSearchTermsText(store
                                                      .state.searchTerms.length)
                                                  ? 1
                                                  : 1),
                                          itemBuilder: (context, index) {
                                            // print("searchTerms[index].text: ${searchTerms[index].text}");
                                            // https://github.com/flutter/flutter/issues/63946
                                            if (_displayNoSearchTermsText(store
                                                .state.searchTerms.length)) {
                                              return Container(
                                                height: MediaQuery.of(context)
                                                        .size
                                                        .height -
                                                    300,
                                                child: Center(
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Text(
                                                        "No search terms",
                                                        style: TextStyle(
                                                          color: Colors.grey,
                                                        ),
                                                      ),
                                                      // store.state.mostRecentDataDate !=
                                                      //         null
                                                      //     ? Container(
                                                      //         margin:
                                                      //             EdgeInsets.only(
                                                      //                 top: 5),
                                                      //         padding: EdgeInsets
                                                      //             .symmetric(
                                                      //                 vertical: 5,
                                                      //                 horizontal:
                                                      //                     10),
                                                      //         child: Text(
                                                      //           "Latest loaded date ${epochTime2DateString(store.state.mostRecentDataDate)}",
                                                      //           style: TextStyle(
                                                      //             fontSize: 11,
                                                      //             color:
                                                      //                 Colors.grey,
                                                      //           ),
                                                      //         ),
                                                      //       )
                                                      //     : SizedBox.shrink()
                                                    ],
                                                  ),
                                                ),
                                              );
                                            } else if (index == 0) {
                                              // If index is 0, show the latest date loaded.
                                              return SizedBox.shrink();
                                              // if (store.state
                                              //             .mostRecentDataDate ==
                                              //         null ||
                                              //     GLOBAL_searchTermsAPILoading ==
                                              //         true ||
                                              //     GLOBAL_adGroupsToLoadFinished !=
                                              //         GLOBAL_adGroupsToLoadTotal) {
                                              //   return SizedBox.shrink();
                                              // }
                                              // return Container(
                                              //   padding: EdgeInsets.symmetric(
                                              //       vertical: 5, horizontal: 10),
                                              //   child: Text(
                                              //     "Latest loaded date ${epochTime2DateString(store.state.mostRecentDataDate)}",
                                              //     style: TextStyle(
                                              //       fontSize: 11,
                                              //       color: Colors.black
                                              //           .withOpacity(.5),
                                              //     ),
                                              //   ),
                                              // );
                                            }
                                            // if (store.state.isLoadingSearchTerms && index == store.state.searchTerms.length) {
                                            //   if (!store.state.isLoadingSearchTerms) {
                                            //     return SizedBox.shrink();
                                            //   }
                                            // The Loading indicator when scrolling the endless list.
                                            // return Center(
                                            //   child: Container(
                                            //     width: 50.0,
                                            //     height: 50.0,
                                            //     padding: const EdgeInsets.all(10.0),
                                            //     margin: EdgeInsets.fromLTRB(0, 15, 0, 50),
                                            //     child: CircularProgressIndicator(
                                            //       color: Color.fromRGBO(55, 55, 55, 0.35),
                                            //     ),
                                            //   ),
                                            // );
                                            // }
                                            return SearchTermItem(
                                                // store.state.searchTerms[index].text,
                                                store,
                                                store.state
                                                    .searchTerms[index - 1],
                                                store.state.currentManager
                                                    .currencyCode,
                                                index);
                                          },
                                          physics:
                                              AlwaysScrollableScrollPhysics(
                                            parent: BouncingScrollPhysics(),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  store.state.isLoadingSearchTerms ||
                                          store.state.searchTerms.length == 0
                                              // || (GLOBAL_adGroupsToLoadTotal != GLOBAL_adGroupsToLoadFinished
                                              &&
                                              GLOBAL_adGroupsToLoadTotal > 0
                                      // || GLOBAL_searchTermsAPILoading == true
                                      ? AnimatedOpacity(
                                          opacity:
                                              store.state.isLoadingSearchTerms
                                                  ? 1.0
                                                  : 1.0,
                                          duration:
                                              const Duration(milliseconds: 125),
                                          child: IgnorePointer(
                                            ignoring: true,
                                            child: Container(
                                              color:
                                                  Colors.white, //transparent,
                                              child: Center(
                                                child:
                                                    CircularProgressIndicator(
                                                        color: Colors.blue),
                                              ),
                                            ),
                                          ),
                                        )
                                      : SizedBox.shrink()
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
      ),
    );
  }
}

class SearchTermItem extends StatefulWidget {
  final Store<AppState> store;
  final int index;
  final SearchTerm searchTerm;
  final String currencyCode;

  SearchTermItem(/*Key key, */ this.store, this.searchTerm, this.currencyCode, this.index);
  //: super(key: key);

  @override
  _SearchTermItemState createState() =>
      _SearchTermItemState(this.searchTerm, this.index);
}

class _SearchTermItemState extends State<SearchTermItem> {
  final int index;
  _SearchTermItemState(this.searchTerm, this.index);

  SearchTerm searchTerm;
  final ScrollController _metricsScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    // _metricsScrollController.addListener(_listener);
    
    // int metricIndex = widget.store.state.searchTermMetrics.indexWhere((m) => m.name == 'Added_excluded');
    // this.setState(() {
    //   this.isAddExcludedVisible = metricIndex > -1;
    // });
  }

  @override
  void dispose() {
    super.dispose();
    // _metricsScrollController.dispose();
  }

  // void _listener() {
  //   double offset = _metricsScrollController.offset;
  //   var direction = _metricsScrollController.position.userScrollDirection;
  // }

  List<Widget> _statsColumns(List<List<Metric>> splitMetrics) {
    List<Widget> out = [];
    // print("searchTerm.metrics: ${searchTerm.metrics['clicks'].value}");

    for (List<Metric> metrics in splitMetrics) {
      out.add(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: new List<Widget>.generate(
          metrics.length,
          (int index) => _statContainer(
              metrics[index].displayName,
              getMetricDisplayValue(searchTerm.metrics, metrics[index].name,
                  metrics[index].valueType, widget.currencyCode)),
        ),
      ));
    }
    return out;
  }

  Widget _statsContainer() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      height: 65,
      // child:
      // NotificationListener<ScrollNotification>(
      //   onNotification: (notification) => true,
      // child: SingleChildScrollView(
      // controller: this._metricsScrollController,
      // isAlwaysShown: true,
      // child: SizedBox(
      // height: 64,
      child: StoreConnector<AppState, List<List<Metric>>>(
        converter: (store) => splitArray(store.state.searchTermMetrics
            .where((f) => f.isOn == true && f.displayName != 'Added/Excluded')
            .toList()),
        builder: (context, metrics) => Scrollbar(
            // child: ListView(
            controller: this._metricsScrollController,
            //   scrollDirection: Axis.horizontal,
            //   // physics: NeverScrollableScrollPhysics(),
            //   // physics: AlwaysScrollableScrollPhysics(),
            //   children: _statsColumns(metrics),
            // ),
            child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: _statsColumns(metrics),
                ))),
      ),
      // ),
      // ),
    );
  }

  Widget _statContainer(String key, String value) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 50, 5),
      width: MediaQuery.of(context).size.width * 0.5,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            fit: FlexFit.loose,
            child: Container(
              child: Text(
                convertToDisplayName(key),
                softWrap: true,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 10,
                ),
              ),
            ),
          ),
          Text(value,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ))
        ],
      ),
      // ),
    );
  }

  String convertMatchTypeToDisplay(String searchTermMatchType) {
    String stmt = this.searchTerm.searchTermMatchType;
    if (stmt == 'NEAR_EXACT') {
      return "EXACT MATCH (Close variant)";
    } else if (stmt == 'NEAR_PHRASE') {
      return "PHRASE MATCH (Close variant)";
    }
    return stmt;
  }

  bool _isInPositiveChanges(List<ChangeAction> changes, String searchTerm) {
    if (changes.isEmpty) {
      return false;
    }
    ChangeAction ca = changes.firstWhere((element) {
      SearchTermSaveAction searchTermSaveAction = element.changeObject;
      return searchTermSaveAction.searchTermText == searchTerm &&
          searchTermSaveAction.isNegative == false;
    }, orElse: () => null);
    return ca != null;
  }

  bool _isInNegativeChanges(List<ChangeAction> changes, String searchTerm) {
    if (changes.isEmpty) {
      return false;
    }
    ChangeAction ca = changes.firstWhere((element) {
      SearchTermSaveAction searchTermSaveAction = element.changeObject;
      return searchTermSaveAction.searchTermText == searchTerm &&
          searchTermSaveAction.isNegative == true;
    }, orElse: () => null);
    return ca != null;
  }

  // Future<void> executeAfterBuild() async {
  //   print("SearchTermItem BUILT!!!");
  // }

  @override
  Widget build(BuildContext context) {

    int addExcludedIndex = widget.store.state
      .searchTermMetrics
      .indexWhere((m) => m.name == 'Added_excluded');

    bool isAddExcludedVisible = widget.store.state.searchTermMetrics[addExcludedIndex].isOn;

    // executeAfterBuild();
    return Container(
        margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(
              color: getColorFromIndex(index),
              width: 2.0,
            ),
          ),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.35),
              spreadRadius: 1,
              blurRadius: 2,
              offset: Offset(0, 0), // changes position of shadow
            ),
          ],
        ),
        width: MediaQuery.of(context).size.width * 0.75,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(0, 10, 10, 10),
              width: MediaQuery.of(context).size.width * 0.8,
              child: Text(searchTerm.text,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.none,
                    color: Colors.black,
                  )),
            ),
            // Text(date2String(searchTerm.date)), // TODO remove this.
            // Text("res: ${searchTerm.id}"),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                        /*this.searchTerm.id + "~" + this.searchTerm.campaignId + "~" + */ this
                            .searchTerm
                            .campaignName,
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          decoration: TextDecoration.none,
                          color: Colors.black45,
                          letterSpacing: -0.5,
                        )),
                  ),
                  Flexible(
                    child: Text(this.searchTerm.adGroupName,
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          decoration: TextDecoration.none,
                          color: Colors.black45,
                          letterSpacing: -0.5,
                        )),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 5),
              child: Row(children: [
                Text("Match type:", style: TextStyle(fontSize: 11)),
                Text(
                    " ${convertMatchTypeToDisplay(this.searchTerm.searchTermMatchType)}",
                    style: TextStyle(
                        fontSize: 11,
                        color: Colors.blue.withOpacity(.85),
                        fontWeight: FontWeight.w600)),
                SizedBox(width: 15,),
              ]),
            ),
            Row(
              children: [
                isAddExcludedVisible
                  ? Text("Added/Excluded: ", style: TextStyle(fontSize: 11),)
                  : SizedBox.shrink(),
                isAddExcludedVisible
                  ? Text(
                    " ${this.searchTerm.status}",
                    style: TextStyle(
                      fontSize: 11,
                      color: Colors.blue.withOpacity(.85),
                      fontWeight: FontWeight.w600,
                    ),
                  )
                  : SizedBox.shrink(),
              ]
            ),
            _statsContainer(),
            StoreConnector<AppState, List<ChangeAction>>(converter: (store) {
              return new List.from(store.state.positiveKeywords)
                ..addAll(store.state.negativeKeywords);
            }, builder: (context, changes) {
              bool isInPositiveChanges =
                  this._isInPositiveChanges(changes, this.searchTerm.text);
              bool isInNegativeChanges =
                  this._isInNegativeChanges(changes, this.searchTerm.text);
              return Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Visibility(
                        visible:
                            !isInNegativeChanges, // only visible if other one is not
                        child: StoreConnector<AppState, Store<AppState>>(
                          converter: (store) => store,
                          builder: (context, store) => GestureDetector(
                            onTap: () {
                              // if (isInChanges) {
                              //   return;
                              // }
                              //  (
                              //   this.customerId,
                              //   this.managerId,
                              //   this.searchTerm.text,
                              //   "customers/4710197191/adGroups/92874977456", //TODO user to set this from a dropdown of available adgroups
                              //   false,
                              // );

                              ANALYTICS_logEvent(
                                  store, 'Added Positive Searchterm');

                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AddSearchTermToKeywordDialog(
                                      store,
                                      this.searchTerm.id,
                                      this.searchTerm.text,
                                      this.searchTerm.resourceName,
                                      "Add keyword",
                                      "Done",
                                      this.searchTerm.campaignName,
                                      this.searchTerm.campaignResourceName,
                                      this.searchTerm.adGroupName,
                                      this.searchTerm.adGroupResourceName,
                                      matchType: EnumToString.convertToString(
                                          KEYWORD_MATCH_TYPE.BROAD),
                                      isNegative: false,
                                      dontShowCancel: true,
                                    );
                                  });
                            },
                            child: Container(
                              padding: EdgeInsets.fromLTRB(5, 5, 10, 5),
                              margin: EdgeInsets.fromLTRB(0, 0, 5, 5),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  color: isInPositiveChanges
                                      ? Color.fromRGBO(0, 0, 0, .15)
                                      : Colors.blue.shade100,
                                  width: 2.0,
                                ),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                              ),
                              child: RichText(
                                  text: TextSpan(children: [
                                WidgetSpan(
                                    alignment: PlaceholderAlignment.middle,
                                    child: Icon(Icons.add,
                                        color: isInPositiveChanges
                                            ? Color.fromRGBO(
                                                155, 155, 155, 0.95)
                                            : Colors.blue)),
                                TextSpan(
                                    text: isInPositiveChanges
                                        ? "Added as keyword"
                                        : "Select as keyword",
                                    style: TextStyle(
                                      color: isInPositiveChanges
                                          ? Color.fromRGBO(155, 155, 155, 0.95)
                                          : Colors.blue,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      decoration: TextDecoration.none,
                                      letterSpacing: -.5,
                                    )),
                              ])),
                            ),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: !isInPositiveChanges,
                        child: StoreConnector<AppState, Store<AppState>>(
                          converter: (store) => store,
                          builder: (context, store) => GestureDetector(
                            onTap: () {
                              // if (isInChanges) {
                              //   return;
                              // }
                              //  (
                              //   this.customerId,
                              //   this.managerId,
                              //   this.searchTerm.text,
                              //   "customers/4710197191/adGroups/92874977456", //TODO user to set this from a dropdown of available adgroups
                              //   false,
                              // );

                              ANALYTICS_logEvent(
                                  store, 'Added Negative Searchterm');

                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AddSearchTermToKeywordDialog(
                                      store,
                                      this.searchTerm.id,
                                      this.searchTerm.text,
                                      this.searchTerm.resourceName,
                                      "Add negative keyword",
                                      "Done",
                                      this.searchTerm.campaignName,
                                      this.searchTerm.campaignResourceName,
                                      this.searchTerm.adGroupName,
                                      this.searchTerm.adGroupResourceName,
                                      matchType: EnumToString.convertToString(
                                          KEYWORD_MATCH_TYPE.BROAD),
                                      isNegative: true,
                                      dontShowCancel: true,
                                    );
                                  });
                            },
                            child: Container(
                              padding: EdgeInsets.fromLTRB(5, 5, 10, 5),
                              margin: EdgeInsets.fromLTRB(0, 0, 5, 5),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  color: isInNegativeChanges
                                      ? Color.fromRGBO(0, 0, 0, .15)
                                      : Colors.blue.shade100,
                                  width: 2.0,
                                ),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                              ),
                              child: RichText(
                                  text: TextSpan(children: [
                                WidgetSpan(
                                    alignment: PlaceholderAlignment.middle,
                                    child: Icon(Icons.add,
                                        color: isInNegativeChanges
                                            ? Color.fromRGBO(
                                                155, 155, 155, 0.95)
                                            : Colors.blue)),
                                TextSpan(
                                    text: isInNegativeChanges
                                        ? "Added as negative keyword"
                                        : "Select as negative keyword",
                                    style: TextStyle(
                                      color: isInNegativeChanges
                                          ? Color.fromRGBO(155, 155, 155, 0.95)
                                          : Colors.blue,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      decoration: TextDecoration.none,
                                      letterSpacing: -.5,
                                    )),
                              ])),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ));
            })

            // Add in campaign name here.
            // Add in account name here.
          ],
        ));
  }
}

// GestureDetector(
//   onTap: () {
//     showDialog(
//         context: context,
//         builder: (BuildContext context) {
//           return AddSearchTermToKeywordDialog(
//               this.searchTerm,
//               "Add this SearchTerm as a Keyword");
//         });
//   },
// child: Container(
//   padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
//   margin: EdgeInsets.fromLTRB(0, 5, 5, 5),
//   decoration: BoxDecoration(
//     color: Colors.white,
//     border: Border.all(
//       color: Color.fromRGBO(0, 0, 0, .2),
//       width: 2.0,
//     ),
//     borderRadius: BorderRadius.all(Radius.circular(5)),
//   ),
//   child: RichText(
//       text: TextSpan(children: [
//     WidgetSpan(
//         alignment: PlaceholderAlignment.middle,
//         child: Icon(Icons.remove, color: Colors.blue)),
//     TextSpan(
//         text: "Select as negative",
//         style: TextStyle(
//           color: Colors.blue,
//           fontWeight: FontWeight.w400,
//           fontSize: 12,
//           decoration: TextDecoration.none,
//           letterSpacing: -.5,
//         )),
//   ])),
// ),
// ),

/*return Container(
        padding: EdgeInsets.fromLTRB(0, 10, 0, 5),
        width: MediaQuery.of(context).size.width * 9,
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                _statContainer("Impr.", this.searchTerm.impressions),
                _statContainer("Clicks", this.searchTerm.clicks),
                _statContainer("CTR", this.searchTerm.ctr),
                _statContainer(
                    "Cost / Conversion", this.searchTerm.cost_per_conversion),
                _statContainer(
                    "Conversions", this.searchTerm.search_impression_share),
              ]),
          Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                _statContainer("Avg. CPC", this.searchTerm.average_cpc),
                _statContainer("Cost", this.searchTerm.cost_micros),
                _statContainer("Conversions", this.searchTerm.conversions),
                _statContainer(
                    "Conversion rate", "\$${this.searchTerm.conversion_rate}"),
              ]),
        ]));
        */

// SizedBox(
// height: 75,
// child: GridView(//.count(
//   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//     crossAxisCount: 2,
//     mainAxisSpacing: 1,
//     crossAxisSpacing: 150,
//   ),
// primary: false,
// padding: EdgeInsets.fromLTRB(0, 5, 5, 5),
// crossAxisSpacing: 10,
// mainAxisSpacing: 10,
// crossAxisCount: 2,

// List<SearchTerm> testData = [
//   SearchTerm("abc","Hello World 1","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 2","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 3","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 4","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 5","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 6","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 7","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 8","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 9","ENABLED","Default AdGroup"),
//   SearchTerm("abc","Hello World 10","ENABLED","Default AdGroup"),
// ];

// Column(
//     crossAxisAlignment: CrossAxisAlignment.start,
//     mainAxisAlignment: MainAxisAlignment.start,
//     children: [
//       _statContainer("Impr.", this.searchTerm.impressions),
//       _statContainer("Clicks", this.searchTerm.clicks),
//       _statContainer("CTR", this.searchTerm.ctr),
//     ]),
// Column(
//   crossAxisAlignment: CrossAxisAlignment.start,
//   mainAxisAlignment: MainAxisAlignment.start,
//   children: [
//     _statContainer(
//         "Cost / Conversion", this.searchTerm.cost_per_conversion),
//     _statContainer(
//         "Conversions", this.searchTerm.search_impression_share),
//     _statContainer("Avg. CPC", this.searchTerm.average_cpc),
//   ],
// ),
// Column(
//   crossAxisAlignment: CrossAxisAlignment.start,
//   mainAxisAlignment: MainAxisAlignment.start,
//   children: [
//     _statContainer("Cost", this.searchTerm.cost_micros),
//     _statContainer("Conversions", this.searchTerm.conversions),
//     _statContainer(
//         "Conversion rate", "\$${this.searchTerm.conversion_rate}"),
//   ],
// )
