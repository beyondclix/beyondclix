// Select customers to work with
// List the available customers
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';

class AdGroupsListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Select an AdGroup"),
        ),
        body: SingleChildScrollView(
            child: StoreConnector<AppState, AppState>(
                converter: (store) => store.state,
                builder: (context, state) => state.loading
                    ? Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height - 300,
                        child: Center(child: CircularProgressIndicator()))
                    : Container(
                        alignment: Alignment.topCenter,
                        child: ListView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: state.adGroups.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              AdGroup adGroup = state.adGroups[index];
                              return Container(
                                  height: 72.0,
                                  margin: EdgeInsets.fromLTRB(10, 5, 10, 0),
                                  decoration: BoxDecoration(
                                      border: Border(
                                    bottom: BorderSide(
                                        color: Color.fromRGBO(0, 0, 0, .2),
                                        width: 2.0),
                                    left: BorderSide(
                                      color: getColorFromIndex(index),
                                      width: 4.0,
                                    ),
                                  )),
                                  child: StoreConnector<AppState,
                                          Function(AdGroup a)>(
                                      converter: (store) {
                                        return (a) => store.dispatch(
                                            ModifyCurrentAdGroupAction(
                                                store, store.state, a));
                                      },
                                      builder: (context, callback) =>
                                          new ListTile(
                                              title: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.75,
                                                    child: Text(
                                                      adGroup.name.toString(),
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 15,
                                                      ),
                                                    ),
                                                  ),
                                                  Icon(
                                                    Icons.arrow_forward_ios,
                                                    color: Colors.black54,
                                                    size: 16.0,
                                                  )
                                                ],
                                              ),
                                              onTap: () {
                                                callback(adGroup);
                                                Navigator.of(context).popUntil(
                                                    (route) => route.isFirst);
                                              })));
                            })))));
  }
}
