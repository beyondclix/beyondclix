import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import '../common_functions.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

class CampaignsOverviewPage extends StatelessWidget {
  final List<Campaign> campaigns;

  CampaignsOverviewPage(this.campaigns);

  // final ScrollController _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: StoreConnector<AppState, ItemScrollController>(
            converter: (store) => store.state.campaignsScrollController,
            builder: (context, scrollController) {
              return Scrollbar(
                interactive: true,
                isAlwaysShown: true,
                controller: scrollController.scrollController,
                child: ScrollablePositionedList.builder(
                    itemScrollController: scrollController,
                    //ListView.builder(
                    //controller: scrollController,
                    padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
                    itemCount: campaigns.length,
                    itemBuilder: (context, index) {
                      // return AutoScrollTag(
                      //   key: ValueKey(index),
                      //   controller: scrollController,
                      //   index: index,
                      //   child: _CampaignItem(campaigns[index], index),
                      // );
                      return _CampaignItem(campaigns[index], index);
                    }),
              );
            }),
      ),
    );
  }
}

class _CampaignItem extends StatefulWidget {
  final int index;
  final Campaign campaign;

  _CampaignItem(this.campaign, this.index);

  @override
  _CampaignItemState createState() =>
      _CampaignItemState(this.campaign, this.index);
}

class _CampaignItemState extends State<_CampaignItem> {
  final int index;

  _CampaignItemState(this.campaign, this.index);

  Campaign campaign;
  List<Widget> _statsColumns(List<List<Metric>> splitMetrics) {
    // print("this.campaign.metrics.length: ${this.campaign.metrics.length}");
    // for (String key in this.campaign.metrics.keys) {
    //   print(key);
    // }
    // print("snake2Camel(metrics[index].name): ${metrics[0].name}");
    List<Widget> out = [];
    for (List<Metric> metrics in splitMetrics) {
      out.add(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: new List<Widget>.generate(
          metrics.length,
          (int index) => _statContainer(
              metrics[index].name,
              getMetricDisplayValue(campaign.metrics, metrics[index].name,
                  metrics[index].valueType, null)
              // campaign.metrics[metrics[index].name].value.toString()
              ),
        ),
      ));
    }
    return out;
  }

  Widget _statsContainer() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      height: 65,
      child: StoreConnector<AppState, List<List<Metric>>>(
          converter: (store) => splitArray(store.state.campaignMetrics
              .where((f) => f.isOn == true)
              .toList()),
          builder: (context, metrics) => Scrollbar(
              child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _statsColumns(metrics),
                  )))),
    );
  }

  Widget _statContainer(String key, String value) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 35, 5),
      width: MediaQuery.of(context).size.width * 0.425,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Flexible(
            fit: FlexFit.loose,
            child: Container(
              height: 15,
              child: Text(
                convertToDisplayName(key),
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 10,
                ),
              ),
            ),
          ),
          Text(value,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ))
        ],
      ),
      // ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.fromLTRB(5, 5, 5, 5),
        padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
        decoration: BoxDecoration(
          border: Border(
            left: BorderSide(
              color: getColorFromIndex(index),
              width: 2.0,
            ),
          ),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.35),
              spreadRadius: 1,
              blurRadius: 2,
              offset: Offset(0, 0), // changes position of shadow
            ),
          ],
        ),
        width: MediaQuery.of(context).size.width * 0.75,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(0, 10, 10, 10),
              width: MediaQuery.of(context).size.width * 0.8,
              child: Text(campaign.name,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.none,
                    color: Colors.black,
                  )),
            ),
            _statsContainer(),
            StoreConnector<AppState, Campaign>(converter: (store) {
              return store.state.currentCampaign;
            }, builder: (context, currentCampaign) {
              bool _selected = currentCampaign == null
                  ? false
                  : currentCampaign.id == campaign.id;
              return Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      StoreConnector<AppState, Function(Campaign c)>(
                        converter: (store) {
                          return (c) => store.dispatch(
                              ModifyCurrentCampaignAction(
                                  store, store.state, c));
                        },
                        builder: (context, callback) => GestureDetector(
                          onTap: () {
                            if (_selected) {
                              callback(null);
                            } else {
                              callback(campaign);
                            }
                          },
                          child: Container(
                            padding: EdgeInsets.fromLTRB(5, 5, 10, 5),
                            margin: EdgeInsets.fromLTRB(0, 0, 5, 5),
                            decoration: BoxDecoration(
                              color: _selected ? Colors.blue : Colors.white,
                              border: Border.all(
                                color: _selected
                                    ? Colors.white
                                    : Colors.blue.shade100,
                                width: 2.0,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                            ),
                            child: RichText(
                                text: TextSpan(children: [
                              WidgetSpan(
                                  alignment: PlaceholderAlignment.middle,
                                  child: Icon(
                                      _selected ? Icons.remove : Icons.add,
                                      color: _selected
                                          ? Colors.white
                                          : Colors.blue)),
                              TextSpan(
                                  text: _selected
                                      ? "Filtering Search Terms"
                                      : "Filter Search Terms",
                                  style: TextStyle(
                                    color:
                                        _selected ? Colors.white : Colors.blue,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    decoration: TextDecoration.none,
                                    letterSpacing: -.5,
                                  )),
                            ])),
                          ),
                        ),
                      ),
                    ],
                  ));
            })
          ],
        ));
  }
}


  // Column(
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               mainAxisAlignment: MainAxisAlignment.start,
  //               children: [
  //                 _statContainer(metric)
  //                 _statContainer("Impr.", "0"),
  //                 _statContainer("Clicks", "0"),
  //                 _statContainer("CTR", "0"),
  //               ]),
  //           Column(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             mainAxisAlignment: MainAxisAlignment.start,
  //             children: [
  //               // _statContainer(
  //               //     "Cost / Conversion", this.searchTerm.cost_per_conversion),
  //               // _statContainer(
  //               //     "Conversions", this.searchTerm.search_impression_share),
  //               // _statContainer("Avg. CPC", this.searchTerm.average_cpc),
  //             ],
  //           ),
  //           Column(
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             mainAxisAlignment: MainAxisAlignment.start,
  //             children: [
  //               // _statContainer("Cost", this.searchTerm.cost_micros),
  //               // _statContainer("Conversions", this.searchTerm.conversions),
  //               // _statContainer(
  //               //     "Conversion rate", "\$${this.searchTerm.conversion_rate}"),
  //             ],
  //           )