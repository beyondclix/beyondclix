// Selecting which metrics to display.
// One for each of search terms, campaigns, and adgroups.

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/models/column_group.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_column_item.dart';
import 'package:searchTermAnalyzerFlutter/widgets/single_column_item.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:after_layout/after_layout.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';

class MetricsPage extends StatefulWidget {
  final String metricsFor;
  final Store<AppState> _store;

  const MetricsPage(this.metricsFor, this._store);

  @override
  _MetricsPageState createState() =>
      _MetricsPageState(this.metricsFor, this._store);
}

class _MetricsPageState extends State<MetricsPage> {
  List<Metric> _metrics;
  final Store<AppState> _store;
  final String metricsFor;
  List<ColumnGroup> _columnGroups = [];

  _MetricsPageState(this.metricsFor, this._store);

  @override
  void initState() {
    super.initState();

    ANALYTICS_logScreenEnteredEvent(_store, "Visible Columns List");

    this.setState(() {
      this._metrics = getMetricsByCategory(this._store.state);
      this._columnGroups = createColumnGroups(_store);
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  List<Metric> getMetricsByCategory(AppState state) {
    // print('metricsFor: ${this.metricsFor}');
    switch (this.metricsFor) {
      case "CAMPAIGN":
        // Get a shallow copy
        // state.campaignMetrics.asMap().forEach((int i, Metric m) {
        //   print('$i: ${m.isOn}');
        // });
        return List.from(state.campaignMetrics);
      case "ADGROUPS":
        return List.from(state.adGroupMetrics);
      case 'SEARCHTERMS':
        return List.from(state.searchTermMetrics);
    }
  }

  String getDisplayTitle(String metricsFor) {
    switch (metricsFor) {
      case 'CAMPAIGN':
        return "Campaign";
      case 'ADGROUPS':
        return "Adgroup";
      default:
        return 'Search Term';
    }
  }

  // Update by reference to original state object.
  void updateMetrics(String metricName, bool metricIsOn) {
    int index = this._metrics.indexWhere((m) => m.name == metricName);
    this.setState(() {
      this._metrics[index].isOn = metricIsOn;
    });
    DB_UpdateMetrics([this._metrics[index]], this.metricsFor);
    this._store.dispatch(UpdateDisplayMetricsAction(
        this.metricsFor, this._metrics, this._store));
    // List.generate(1, (index) => this._metrics[index])
  }

  @override
  Widget build(BuildContext context) {
    // print("this._metrics: ${this._metrics}");
    return
        // StoreConnector<AppState, List<Metric>>(
        // converter: (store) =>  getMetricsByCategory(store.state, this.metricsFor),
        // builder: (context, metrics) =>
        Scaffold(
      appBar: AppBar(
        title: Text(
            "Select Columns To Display"), //getDisplayTitle(this.metricsFor) + " Metrics"),
        // actions: <Widget>[
        //   Padding(
        //     padding: EdgeInsets.only(right: 20.0),
        //     child: StoreConnector<AppState, Function(List<Metric> metrics)>(
        //       converter: (store) {
        //         return (metrics) => store
        //             .dispatch(UpdateMetricsAction(this.metricsFor, metrics));
        //       },
        //       builder: (context, callback) => GestureDetector(
        //         onTap: () {
        //           Navigator.of(context).pop();
        //           callback(this._metrics);
        //           // callback(metrics);
        //         },
        //         child: Center(child: Text("Save",
        //             style: TextStyle(
        //                 color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
        //         ),
        //       ),
        //     ),
        //   ),
        // ]
      ),
      body: Scrollbar(
        isAlwaysShown: true,
        child: ListView.builder(
            padding: EdgeInsets.fromLTRB(5, 10, 5, 10),
            itemCount: this._columnGroups.length + 1,
            itemBuilder: (context, index) {

              if (index == this._columnGroups.length) {
                return (SafeArea(
                  bottom: true,
                  top: true,
                  child: SingleColumnItem(this._store, "Added_excluded",
                      this._metrics, this.metricsFor),
                ));
              }

              return ExpandableColumnItem(
                  this._columnGroups[index].title,
                  this._columnGroups[index].columnValues,
                  this._store,
                  updateMetrics);
            }),
      ),
      // ),
    );
  }
}
