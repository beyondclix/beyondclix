// Pure functions to apply to application state to make changes happen.
// https://hackernoon.com/flutter-redux-how-to-make-shopping-list-app-1cd315e79b65

import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list_to_save.dart';
import 'actions.dart';
import 'models.dart';

AppState appReducers(AppState appState, dynamic action) {
  // print('REDUCER ACTION CALLED: ' + action.toString());
  if (action is AddChangeAction) {
    return addChange(appState, action);
  } else if (action is ModifyChangeAction) {
    return modifyChange(appState, action);
  } else if (action is ModifyChangeActionRangeAction) {
    return modifyChangeRange(appState, action);
  } else if (action is RemoveChangeAction) {
    return removeChange(appState, action);
  } else if (action is ResetChangesAction) {
    return resetChangesForAccount(appState, action);
    // } else if (action is ToggleChangeAction) {
    //   return toggleChange(appState, action);
  } else if (action is AddDataToSaveAction) {
    return addDataToSave(appState, action);
  } else if (action is RemoveDataToSaveAction) {
    return removeDataToSave(appState, action);
  } else if (action is ModifyDateRangeAction) {
    return modifyCurrentDateRange(appState, action);
  } else if (action is ModifyCurrentCustomerAction) {
    return modifyCurrentCustomer(appState, action);
  } else if (action is ModifyCurrentCustomerClientAction) {
    return modifyCurrentCustomerClient(appState, action);
  } else if (action is ModifyCurrentCampaignAction) {
    return modifyCurrentCampaign(appState, action);
  } else if (action is ModifyCurrentAdGroupAction) {
    return modifyCurrentAdGroup(appState, action);
  } else if (action is RemoveNegativeKeywordListToSaveAction) {
    return removeNegativeKeywordListToSave(appState, action);
  } else if (action is ResetNegativeKeywordListToSaveAction) {
    return resetNegativeKeywordListToSave(appState, action);
  } else if (action is AddResourceNameToNegativeKeywordListToSaveAction) {
    return addResourceNameToNegativeKeywordListToSave(appState, action);
  } else if (action is InitialStateLoadedAction) {
    return fetchInitialState(appState, action);
  } else if (action is FetchAPIDataAction) {
    return fetchAPIData(appState, action);
  } else if (action is StartLoadingAction) {
    return startLoading(appState, action);
  } else if (action is ClearCurrentDataAction) {
    return clearCurrentData(appState, action);
  } else if (action is UpdateVisibleCustomerClientsAction) {
    return updateVisibleCustomerClients(appState, action);
  } else if (action is UpdateVisibleCampaignsAction) {
    return updateVisibleCampaigns(appState, action);
  } else if (action is UpdateVisibleAdGroupsAction) {
    return updateVisibleAdGroups(appState, action);
  } else if (action is UpdateVisibleKeywordsAction) {
    return updateVisibleKeywords(appState, action);
  } else if (action is UpdateVisibleSearchTermsAction) {
    return updateVisibleSearchTerms(appState, action);
  } else if (action is ClearVisibleSearchTermsAction) {
    return clearVisibleSearchTerms(appState, action);
  } else if (action is LoadCustomersAndCustomerClientsAction) {
    return loadCustomersAndCustomerClients(appState, action);
  } else if (action is StartCampaignsLoadingAction) {
    return startCampaignsLoading(appState, action);
  } else if (action is StartAdGroupsLoadingAction) {
    return startAdGroupsLoading(appState, action);
  } else if (action is StartSearchTermsLoadingAction) {
    return startSearchTermsLoading(appState, action);
  } else if (action is FinishCampaignsLoadingAction) {
    return finishCampaignsLoading(appState, action);
  } else if (action is FinishAdGroupsLoadingAction) {
    return finishAdGroupsLoading(appState, action);
  } else if (action is FinishSearchTermsLoadingAction) {
    return finishSearchTermsLoading(appState, action);
  } else if (action is UpdateMetricsAction) {
    return updateMetrics(appState, action);
  } else if (action is UpdateCurrentPageIndexAction) {
    return updateCurrentPageIndexAction(appState, action);
  } else if (action is RemoveFilterAction) {
    return removeFilter(appState, action);
  } else if (action is AddFilterAction) {
    return addFilter(appState, action);
  } else if (action is IncrementLoadedAction) {
    return incrementLoaded(appState, action);
  } else if (action is UpdateFilterAction) {
    return updateFilter(appState, action);
  } else if (action is FinishLoadingToastAction) {
    return finishLoadingToast(appState, action);
  } else if (action is StartLoadingToastAction) {
    return startLoadingToast(appState, action);
  } else if (action is LoadMoreSearchTermsPaginatedAction) {
    return loadMoreSearchTermsPaginated(appState, action);
  } else if (action is LoadMoreCampaignsPaginatedAction) {
    return loadMoreCampaignsPaginated(appState, action);
  } else if (action is LoadMoreAdGroupsPaginatedAction) {
    return loadMoreAdGroupsPaginated(appState, action);
  } else if (action is StartLoadingCustomerAction) {
    return startLoadingCustomer(appState, action);
  } else if (action is IncrementLoadedCustomerAction) {
    return incrementLoadedCustomer(appState, action);
  } else if (action is ReduceTotalCustomerToLoadCountAction) {
    return reduceTotalCustomerToLoadCount(appState, action);
  } else if (action is UpdateOrderAction) {
    return updateOrder(appState, action);
  } else if (action is IncrementLoadedCustomerClientAction) {
    return incrementLoadedCustomerClient(appState, action);
  } else if (action is StartLoadingCustomerClientsAction) {
    return startLoadingCustomerClients(appState, action);
  } else if (action is IAPAvailabilityUpdateAction) {
    return iapAvailabilityUpdate(appState, action);
  } else if (action is LoadIAPProductsAction) {
    return loadIAPProducts(appState, action);
  } /*else if (action is AddIAPPurchaseAction) {
    return addIAPPurchase(appState, action);
  } */
  else if (action is UpdateLoadingAction) {
    return updateLoading(appState, action);
  } else if (action is NewDatabaseSizeAction) {
    return newDatabaseSize(appState, action);
  } else if (action is UpdateMembershipTypeAction) {
    return updateMembershipType(appState, action);
  } else if (action is SetChangesPageBuildContextAction) {
    return setChangesPageBuildContext(appState, action);
  } else if (action is SetSingleSavePurchaseDialogBuildContextAction) {
    return setSingleSavePurchaseDialogBuildContext(appState, action);
  } else if (action is UpdateIsWaitingForPurchaseToBeValidatedAction) {
    return updateIsWaitingForPurchaseToBeValidated(appState, action);
  } else if (action is UpdatePastPurchasesAction) {
    return updatePastPurchases(appState, action);
  } else if (action is UpdatePastConsumablesAction) {
    return updatePastConsumables(appState, action);
  } else if (action is UpdateIsInitialSearchTermsLoadingAction) {
    return updateIsInitialSearchTermsLoading(appState, action);
  } else if (action is FetchLocalCustomersAction) {
    return fetchLocalCustomers(appState, action);
  } else if (action is DowngradeMonthlySubscriptionAction) {
    return downgradeMonthlySubscription(appState, action);
  } else if (action is UpdateIsPurchasingAction) {
    return updateIsPurchasing(appState, action);
  } else if (action is ChangeCustomerAction) {
    return changeCustomer(appState, action);
  } else if (action is UpdateDisplayMetricsAction) {
    return updateDisplayMetrics(appState, action);
  } else if (action is UpdateIsWelcomeScreenShowingAction) {
    return updateIsWelcomeScreenShowing(appState, action);
  } else if (action is UpdateWaitingToConsumeSaveConsumableAction) {
    return updateWaitingToConsumeSaveConsumable(appState, action);
  } else if (action is UpdateSearchTermFiltersDisplayTopOffsetAction) {
    return updateSearchTermFiltersDisplayTopOffset(appState, action);
  } else if (action is UpdateIsLoadingPaginatedDataAction) {
    return updateIsLoadingPaginatedData(appState, action);
  } else if (action is ClearSearchTermsAction) {
    return clearSearchTermsAction(appState, action);
  } else if (action is ResumeLoadingSearchTermsAction) {
    return resumeLoadingSearchTerms(appState, action);
  } else if (action is RemoveCampaignAdGroupFiltersAction) {
    return removeCampaignAdGroupFilters(appState, action);
  } else if (action is UpdateMostRecentDataDateAction) {
    return updateMostRecentDataDate(appState, action);
  } else if (action is NoGoogleAdsAccountAction) {
    return noGoogleAdsAccount(appState, action);
  } else if (action is UpdateSignInButtonVisibilityAction) {
    return updateSignInButtonVisibility(appState, action);
  } else if (action is UpdateIsFinishedLoadingCustomersAction) {
    return updateIsFinishedLoadingCustomers(appState, action);
  } else if (action is UpdateIsShowingWelcomeScreenAction) {
    return updateIsShowingWelcomeScreen(appState, action);
  } else if (action is SavingKeywordsAction) {
    return savingKeywords(appState, action);
  }

  print("REDUCER ACTION LEAKED!!!! " + action.toString());
  return appState;
}

AppState addChange(AppState appState, AddChangeAction action) {
  // state.changes.add(changeAction);
  // print("ADDING CHANGE ACTION: " + action.changeAction.changeId);
  print("action.insertAtIndex: ${action.insertAtIndex}");
  if (action.isNegative) {
    if (action.insertAtIndex != null && action.insertAtIndex < appState.negativeKeywords.length) {
      print("Inserting at index: ${action.insertAtIndex}");
      appState.negativeKeywords = List.from(appState.negativeKeywords)
        ..insert(action.insertAtIndex, action.changeAction);
    } else {
      appState.negativeKeywords = List.from(appState.negativeKeywords)
        ..add(action.changeAction);
    }
  } else {
    if (action.insertAtIndex != null && action.insertAtIndex < appState.positiveKeywords.length) {
      print("Inserting at index: ${action.insertAtIndex}");
      appState.positiveKeywords = List.from(appState.positiveKeywords)
        ..insert(action.insertAtIndex, action.changeAction);
    } else {
      appState.positiveKeywords = List.from(appState.positiveKeywords)
        ..add(action.changeAction);
    }
  }

  if (action.newNegativeKeywordListName != null &&
      action.newNegativeKeywordListName.length > 0) {
    // if (action.insertAtIndex != null && action.insertAtIndex < appState.negativeKeywordListsToSave.length) {
    //   print("Inserting at index: ${action.insertAtIndex}");
    //   appState.negativeKeywordListsToSave =
    //     List.from(appState.negativeKeywordListsToSave)
    //       ..insert(
    //         action.insertAtIndex,
    //         NegativeKeywordListToSave(
    //           action.newNegativeKeywordListName,
    //           appState.currentCustomer.id,
    //           appState.currentManager.id,
    //           '',
    //           0,
    //           0),
    //       );
    // } else {
        appState.negativeKeywordListsToSave =
            List.from(appState.negativeKeywordListsToSave)
              ..add(
                NegativeKeywordListToSave(
                    action.newNegativeKeywordListName,
                    appState.currentCustomer.id,
                    appState.currentManager.id,
                    '',
                    0,
                    0),
              );
    // }
  }
  return appState;
}

AppState modifyChange(AppState appState, ModifyChangeAction action) {
  int modifyIndex;

  if (action.isNegative) {
    // print("action.changeId: " + action.changeId);
    // print("appState.negativeKeywords.length: " +
    // appState.negativeKeywords.length.toString());
    modifyIndex = appState.negativeKeywords
        .indexWhere((element) => element.changeId == action.changeId);
    // appState.negativeKeywords = List.from(appState.negativeKeywords);
    appState.negativeKeywords[modifyIndex] = action.changeAction;
  } else {
    modifyIndex = appState.positiveKeywords
        .indexWhere((element) => element.changeId == action.changeId);

    // for (var s in appState.positiveKeywords) {
    //   print("s: " + s.changeId.toString());
    // }
    // print("action.changeId: " + action.changeId.toString());
    // appState.positiveKeywords = List.from(appState.positiveKeywords);
    appState.positiveKeywords[modifyIndex] = action.changeAction;
  }
  // print("Modifying index: " + modifyIndex.toString());

  return appState;
}

// Modifies a range to fit with the templated searchTermSaveAction.
AppState modifyChangeRange(
    AppState appState, ModifyChangeActionRangeAction action) {
  List<ChangeAction> changeActions;

  if (action.isNegative) {
    changeActions = appState.negativeKeywords;
    print("TAKING NEGATIVE INDEX: " +
        action.low.toString() +
        ", : " +
        action.high.toString());
  } else {
    changeActions = appState.positiveKeywords;
    print("TAKING POSITIVE INDEX: " +
        action.low.toString() +
        ", : " +
        action.high.toString());
  }

  // out = appState.negativeKeywords.sublist(action.low, action.high);
  for (var i = action.low; i < action.high; i++) {
    SearchTermSaveAction existingSearchTermSaveAction =
        changeActions[i].changeObject as SearchTermSaveAction;
    SearchTermSaveAction templateSearchTermSaveAction =
        action.searchTermSaveAction;
    // Replace everything except id and searchTermText.
    SearchTermSaveAction newSearchTermSaveAction = templateSearchTermSaveAction;
    newSearchTermSaveAction.id = existingSearchTermSaveAction.id;
    newSearchTermSaveAction.searchTermText =
        existingSearchTermSaveAction.searchTermText;

    if (action.isNegative) {
      appState.negativeKeywords[i] = ChangeAction(newSearchTermSaveAction.id,
          'SearchTerm', "", "", newSearchTermSaveAction);
    } else {
      appState.positiveKeywords[i] = ChangeAction(newSearchTermSaveAction.id,
          'SearchTerm', "", "", newSearchTermSaveAction);
    }
    updateObject(
        newSearchTermSaveAction.toMap(), 'SEARCH_TERM_SAVE_ACTIONS', "id");
  }

  return appState;
}

AppState resetChangesForAccount(AppState appState, ResetChangesAction action) {
  appState.negativeKeywords = List.from(appState.negativeKeywords)..clear();
  appState.positiveKeywords = List.from(appState.positiveKeywords)..clear();
  truncateTableConditional(
      'SEARCH_TERM_SAVE_ACTIONS', 'customerId', action.customerId);
  return appState;
}

AppState removeChange(AppState appState, RemoveChangeAction action) {
  // print("Changes: " + appState.changes.toString());
  if (action.isNegative) {
    appState.negativeKeywords = List.from(appState.negativeKeywords)
      ..removeWhere((element) => element.changeId == action.changeId);
  } else {
    appState.positiveKeywords = List.from(appState.positiveKeywords)
      ..removeWhere((element) => element.changeId == action.changeId);
  }
  return appState;
}

// AppState toggleChange(AppState appState, ToggleChangeAction action) {
//   appState.changes = action.appState.changes;
//   // appState.changes = appState.changes
//   // .map((change) =>
//   //     change.changeName == action.appState.changes[0].changeName
//   //         ? action.appState
//   //         : appState.changes)
//   // .toList();
//   return appState;
// }

AppState addDataToSave(AppState appState, AddDataToSaveAction action) {
  appState.toSave = action.appState
      .toSave; //List.from(appState.changes)..add(action.appState.changes);
  return appState;
}

AppState removeDataToSave(AppState appState, RemoveDataToSaveAction action) {
  appState.toSave = {}; //List.from(appState.changes)..removeLast();
  return appState;
}

AppState clearSearchTermsAction(
    AppState appState, ClearSearchTermsAction action) {
  appState.searchTerms = [];
  return appState;
}

AppState modifyCurrentDateRange(
    AppState appState, ModifyDateRangeAction action) {
  appState.loading = false;

  appState.currentDateRange = action.dateRange;
  return appState;
}

AppState modifyCurrentCustomer(
    AppState appState, ModifyCurrentCustomerAction action) {
  appState.loading = false;
  appState.currentCustomer = action.customer;
  appState.currentManager = null;
  // Also reset date here?
  print(
      "Changing customer: " + action.appState.currentCustomer.descriptiveName);
  return appState;
}

AppState modifyCurrentCustomerClient(
    AppState appState, ModifyCurrentCustomerClientAction action) {
  appState.loading = false;
  appState.currentManager = action.customerClient;
  // print('Changing Customer Client: ' + appState.currentManager.toString());
  return appState;
}

AppState modifyCurrentCampaign(
    AppState appState, ModifyCurrentCampaignAction action) {
  appState.loading = false;
  appState.currentAdGroup = null;
  appState.currentCampaign = action.campaign;
  // appState.notifyListeners(); // Calls listener in main.dart to update search terms
  return appState;
}

AppState modifyCurrentAdGroup(
    AppState appState, ModifyCurrentAdGroupAction action) {
  appState.loading = false;
  appState.currentAdGroup = action.adGroup;
  // appState.notifyListeners(); // Calls listener in main.dart to update search terms
  return appState;
}

AppState updateVisibleCustomerClients(
    AppState appState, UpdateVisibleCustomerClientsAction action) {
  appState.loading = false;
  // Filter out current account from customerClients
  appState.customerClients = action.customerClients;
  // appState.customerClients = action.customerClients
  //     .where((cc) => cc.id != appState.currentCustomer.id)
  //     .toList();
  return appState;
}

AppState updateVisibleCampaigns(
    AppState appState, UpdateVisibleCampaignsAction action) {
  appState.campaigns = List.from(action.campaigns);
  appState.campaignsListKey += 1;
  appState.loading = false;
  return appState;
}

AppState updateVisibleAdGroups(
    AppState appState, UpdateVisibleAdGroupsAction action) {
  appState.adGroups = List.from(action.adGroups);
  // print("action.adGroups: ${action.adGroups.length}");
  appState.adGroupsListKey += 1;
  appState.loading = false;
  return appState;
}

AppState updateVisibleKeywords(
    AppState appState, UpdateVisibleKeywordsAction action) {
  appState.keywords = action.keywords;
  appState.loading = false;
  return appState;
}

AppState updateVisibleSearchTerms(
    AppState appState, UpdateVisibleSearchTermsAction action) {
  appState.searchTerms = List.from(action.searchTerms);
  // print('reducer saving search terms: ${action.searchTerms}');
  appState.searchTermsListKey += 1;
  appState.loading = false;
  return appState;
}

// For when drag down refresh is called on search terms page.
AppState clearVisibleSearchTerms(
  AppState appState, ClearVisibleSearchTermsAction action) {
    appState.searchTerms = List.from([]);
    appState.searchTermsListKey += 1;
    return appState;
  }

AppState removeNegativeKeywordListToSave(
    AppState appState, RemoveNegativeKeywordListToSaveAction action) {
  appState.negativeKeywordListsToSave =
      List.from(appState.negativeKeywordListsToSave)
        ..remove(action.negativeKeywordListToSave);
  truncateTableConditional('NEGATIVE_KEYWORD_LIST_TO_SAVE', 'name',
      action.negativeKeywordListToSave.name);

  return appState;
}

AppState resetNegativeKeywordListToSave(
    AppState appState, ResetNegativeKeywordListToSaveAction action) {
  appState.negativeKeywordListsToSave = [];
  truncateTableConditional(
      'NEGATIVE_KEYWORD_LIST_TO_SAVE', 'managerId', action.managerId);
  return appState;
}

AppState addResourceNameToNegativeKeywordListToSave(AppState appState,
    AddResourceNameToNegativeKeywordListToSaveAction action) {
  int index = appState.negativeKeywordListsToSave
      .indexWhere((el) => el.name == action.name);
  appState.negativeKeywordListsToSave[index].resourceName = action.resourceName;
  return appState;
}

AppState fetchInitialState(AppState appState, InitialStateLoadedAction action) {
  appState.loading = false;
  appState.positiveKeywords = action.positiveKeywords;
  appState.negativeKeywords = action.negativeKeywords;
  // print("FETCHINITIALSTATE => Setting currentCustomer: ${action.currentCustomer.descriptiveName}");
  appState.currentCustomer = action.currentCustomer;
  appState.currentManager = action.currentManager;
  appState.currentCampaign = action.currentCampaign;
  appState.currentAdGroup = action.currentAdGroup;
  action.customers.sort((Customer a, Customer b) {
    return a.descriptiveName.compareTo(b.descriptiveName);
  });
  appState.customers = action.customers;
  appState.customerClients = action.customerClients;
  appState.campaigns = action.campaigns;
  appState.adGroups = action.adGroups;
  appState.keywords = action.keywords;
  appState.searchTerms = action.searchTerms;
  appState.negativeKeywordListsToSave = action.negativeKeywordListsToSave;
  appState.fcmToken = action.fcmToken;
  // appState.iapProducts = action.iapProducts;
  // print("Setting customers of length: " + appState.customers.length.toString());
  // print('setting customerClients: ' + action.customerClients.toString());
  // print('Setting currentManager: ' + appState.currentManager.toString());

  // Set the current customer, customerClient, campaign, adGroup to what is available here.
  // var a = action.customers.where((c) => c.id == appState.initialCustomerId);
  // if (a.isNotEmpty) {
  //   appState.currentCustomer = a.first;
  // }

  // var b =
  //     action.customerClients.where((c) => c.id == appState.initialManagerId);
  // if (b.isNotEmpty) {
  //   appState.currentManager = b.first;
  // }
  // var c = action.campaigns.where((c) => c.id == appState.initialCampaignId);
  // if (c.isNotEmpty) {
  //   appState.currentCampaign = c.first;
  // }
  // var d = action.adGroups.where((c) => c.id == appState.initialAdGroupId);
  // if (d.isNotEmpty) {
  //   appState.currentAdGroup = d.first;
  // }

  return appState;
}

AppState changeCustomer(AppState appState, ChangeCustomerAction action) {
  appState.positiveKeywords = List.from(action.positiveKeywords);
  appState.negativeKeywords = List.from(action.negativeKeywords);
  appState.negativeKeywordListsToSave =
      List.from(action.negativeKeywordListsToSave);
  return appState;
}

AppState fetchAPIData(AppState appState, FetchAPIDataAction action) {
  appState.loading = false;
  // appState.customers = action.customers;
  // appState.customerClients = action.customerClients;
  appState.campaigns = action.campaigns;
  appState.adGroups = action.adGroups;
  appState.keywords = action.keywords;
  appState.searchTerms = action.searchTerms;
  return appState;
}

AppState loadCustomersAndCustomerClients(
    AppState appState, LoadCustomersAndCustomerClientsAction action) {
  appState.loading = false;
  action.customers.sort((Customer a, Customer b) {
    return a.descriptiveName.compareTo(b.descriptiveName);
  });
  appState.customers = action.customers;
  appState.customerClients = action.customerClients;
  return appState;
}

AppState updateDisplayMetrics(
    AppState appState, UpdateDisplayMetricsAction action) {
  if (action.displayMetricName == "CAMPAIGN") {
    appState.campaignMetrics = List.from(action.metrics);
  } else if (action.displayMetricName == "ADGROUPS") {
    appState.adGroupMetrics = List.from(action.metrics);
  } else if (action.displayMetricName == "SEARCHTERMS") {
    if (action.metrics.length > 0) {
      appState.searchTermMetrics = new List.from(action.metrics);
    }
  }
  return appState;
}

AppState clearCurrentData(AppState appState, ClearCurrentDataAction action) {
  AppState _appState = new AppState(
      positiveKeywords: appState.positiveKeywords, //positiveKeywords: [],
      negativeKeywords: appState.negativeKeywords, //negativeKeywords: [],
      initialDateRange: DateRange.fromName("", ""),
      initialCustomerId: "",
      initialManagerId: "",
      initialCampaign: "",
      initialAdGroup: "",
      mostRecentDataDate: null,
      oldestDataDate: null,
      iapProducts: appState.iapProducts,
      appLoadCount: null);
  _appState.isLoadingCustomers = 0;
  _appState.totalCustomers = 0;
  // _appState.campaignMetrics = [];
  // _appState.adGroupMetrics = [];
  // _appState.searchTermMetrics = [];
  // _appState.filterValues = [];
  return _appState;
}

AppState startLoading(AppState appState, StartLoadingAction action) {
  appState.loading = true;
  return appState;
}

AppState startCampaignsLoading(
    AppState appState, StartCampaignsLoadingAction action) {
  appState.isLoadingCampaigns = true;
  return appState;
}

AppState startAdGroupsLoading(
    AppState appState, StartAdGroupsLoadingAction action) {
  appState.isLoadingAdGroups = true;
  return appState;
}

AppState startSearchTermsLoading(
    AppState appState, StartSearchTermsLoadingAction action) {
  appState.isLoadingSearchTerms = true;
  return appState;
}

AppState finishCampaignsLoading(
    AppState appState, FinishCampaignsLoadingAction action) {
  appState.isLoadingCampaigns = false;
  return appState;
}

AppState finishAdGroupsLoading(
    AppState appState, FinishAdGroupsLoadingAction action) {
  appState.isLoadingAdGroups = false;
  return appState;
}

AppState finishSearchTermsLoading(
    AppState appState, FinishSearchTermsLoadingAction action) {
  appState.isLoadingSearchTerms = false;
  return appState;
}

AppState updateMetrics(AppState appState, UpdateMetricsAction action) {
  if (action.metricType == "CAMPAIGNS") {
    appState.campaignMetrics = action.metrics;
  } else if (action.metricType == "ADGROUPS") {
    appState.adGroupMetrics = action.metrics;
  } else {
    appState.searchTermMetrics = action.metrics;
  }

  return appState;
}

AppState updateCurrentPageIndexAction(
    AppState appState, UpdateCurrentPageIndexAction action) {
  appState.currentPageIndex = action.index;
  return appState;
}

AppState addFilter(AppState appState, AddFilterAction action) {
  // print("action.filterValue: ${action.filterValue}");
  print("appState.filterValues: ${appState.filterValues}");
  appState.filterValues = List.from(appState.filterValues)
    ..add(action.filterValue);
  return appState;
}

AppState updateFilter(AppState appState, UpdateFilterAction action) {
  List<FilterValue> filterValues = List.from(appState.filterValues);
  print(
      "index: ${filterValues.indexWhere((filterValue) => filterValue.id == action.filterValue.id)}");
  for (FilterValue fv in filterValues) {
    print(fv.toMap());
  }
  filterValues[filterValues.indexWhere(
          (filterValue) => filterValue.id == action.filterValue.id)] =
      action.filterValue;
  appState.filterValues = List.from(filterValues);
  return appState;
}

AppState removeFilter(AppState appState, RemoveFilterAction action) {
  // print("action.filterValue.name: ${action.filterValue.name}");
  appState.filterValues = List.from(appState.filterValues)
    ..removeWhere((element) =>
        element.name == action.filterValue.name &&
        element.type == action.filterValue.type &&
        element.value == action.filterValue.value);

  return appState;
}

AppState incrementLoaded(AppState appState, IncrementLoadedAction action) {
  if (action.incrementType == "searchTerm") {
    appState.searchTermsLoadedCount += action.incrementAmount;
  } else if (action.incrementType == "campaign") {
    appState.campaignsLoadedCount += action.incrementAmount;
  } else if (action.incrementType == "adGroup") {
    appState.adGroupsLoadedCount += action.incrementAmount;
  }
  return appState;
}

AppState startLoadingToast(AppState appState, StartLoadingToastAction action) {
  appState.showLoadingToast = true;
  return appState;
}

AppState finishLoadingToast(
    AppState appState, FinishLoadingToastAction action) {
  appState.showLoadingToast = false;
  return appState;
}

AppState loadMoreSearchTermsPaginated(
    AppState appState, LoadMoreSearchTermsPaginatedAction action) {
  // int lastIndex = appState.searchTerms.length;
  // print("Jumping to index: $lastIndex");
  appState.searchTerms = appState.searchTerms + action.searchTerms;
  // appState.isLoadingSearchTerms = false;
  // // Reset scrollController to previous location.
  // // appState.searchTermsScrollController.jumpTo(index: lastIndex);
  // Future.delayed(const Duration(milliseconds: 10), () {
  //   appState.searchTermsScrollController.jumpTo(index: lastIndex);
  // });
  return appState;
}

AppState loadMoreCampaignsPaginated(
    AppState appState, LoadMoreCampaignsPaginatedAction action) {
  appState.campaigns = appState.campaigns + action.campaigns;
  appState.isLoadingCampaigns = false;
  return appState;
}

AppState loadMoreAdGroupsPaginated(
    AppState appState, LoadMoreAdGroupsPaginatedAction action) {
  appState.adGroups = appState.adGroups + action.adGroups;
  print(
      "incoming adGroups: ${action.adGroups.length}, ${appState.adGroups.length}");
  appState.isLoadingAdGroups = false;
  return appState;
}

AppState updateOrder(AppState appState, UpdateOrderAction action) {
  appState.searchTermOrderBy = action.orderValue;
  return appState;
}

AppState startLoadingCustomer(
    AppState appState, StartLoadingCustomerAction action) {
  appState.isLoadingCustomers = 0;
  appState.totalCustomers = action.numberOfCustomers;
  return appState;
}

AppState incrementLoadedCustomer(
    AppState appState, IncrementLoadedCustomerAction action) {
  appState.isLoadingCustomers += 1;
  return appState;
}

AppState reduceTotalCustomerToLoadCount(
    AppState appState, ReduceTotalCustomerToLoadCountAction action) {
  appState.totalCustomers -= 1;
  return appState;
}

AppState startLoadingCustomerClients(
    AppState appState, StartLoadingCustomerClientsAction action) {
  appState.loadingCustomerClients = 0;
  appState.totalCustomerClients = action.numberOfCustomerClients;
  return appState;
}

AppState incrementLoadedCustomerClient(
    AppState appState, IncrementLoadedCustomerClientAction action) {
  appState.loadingCustomerClients += 1;
  return appState;
}

AppState iapAvailabilityUpdate(
    AppState appState, IAPAvailabilityUpdateAction action) {
  appState.isIAPAvailable = action.isAvailable;
  return appState;
}

AppState loadIAPProducts(AppState appState, LoadIAPProductsAction action) {
  // print("reducer iapProducts: ${action.iapProducts}");
  appState.iapProducts = action.iapProducts;
  return appState;
}

// AppState addIAPPurchase(AppState appState, AddIAPPurchaseAction action) {
//   appState.iapPurchases = List.from(appState.iapPurchases)
//     ..add(action.iapPurchase);
//   return appState;
// }

AppState updateLoading(AppState appState, UpdateLoadingAction action) {
  appState.cancelLoading = action.newLoading;
  return appState;
}

AppState newDatabaseSize(AppState appState, NewDatabaseSizeAction action) {
  appState.databaseSize = action.databaseSize;
  return appState;
}

AppState updateMembershipType(
    AppState appState, UpdateMembershipTypeAction action) {
  appState.membershipType = action.newMembershipType;
  return appState;
}

AppState setChangesPageBuildContext(
    AppState appState, SetChangesPageBuildContextAction action) {
  appState.changesPageBuildContext = action.buildContext;
  return appState;
}

AppState setSingleSavePurchaseDialogBuildContext(
    AppState appState, SetSingleSavePurchaseDialogBuildContextAction action) {
  appState.singleSavePaywallBuildContext = action.buildContext;
  return appState;
}

AppState updateIsWaitingForPurchaseToBeValidated(
    AppState appState, UpdateIsWaitingForPurchaseToBeValidatedAction action) {
  appState.isWaitingForPurchaseToBeValidated =
      action.isWaitingForPurchaseToBeValidated;
  return appState;
}

AppState updatePastPurchases(
    AppState appState, UpdatePastPurchasesAction action) {
  appState.pastPurchases = action.pastPurchases;
  return appState;
}

AppState updatePastConsumables(
    AppState appState, UpdatePastConsumablesAction action) {
  appState.pastConsumables = action.pastConsumables;
  return appState;
}

AppState updateIsInitialSearchTermsLoading(
    AppState appState, UpdateIsInitialSearchTermsLoadingAction action) {
  appState.isInitialSearchTermsLoading = action.isInitialSearchTermsLoading;
  return appState;
}

AppState fetchLocalCustomers(
    AppState appState, FetchLocalCustomersAction action) {
  appState.loading = false;

  action.customers.sort((Customer a, Customer b) {
    return a.descriptiveName.compareTo(b.descriptiveName);
  });
  appState.customers = action.customers;
  // appState.customerClients = action.customerClients;
  return appState;
}

AppState downgradeMonthlySubscription(
    AppState appState, DowngradeMonthlySubscriptionAction action) {
  appState.isWaitingForMonthlyDowngrade = action.isWaitingForMonthlyDowngrade;
  return appState;
}

AppState updateIsPurchasing(
    AppState appState, UpdateIsPurchasingAction action) {
  appState.isPurchasing = action.isPurchasing;
  return appState;
}

AppState updateIsWelcomeScreenShowing(
    AppState appState, UpdateIsWelcomeScreenShowingAction action) {
  // print("New welcome: ${action.isWelcomeScreenShowing}");
  appState.isWelcomeScreenShowing = action.isWelcomeScreenShowing;
  return appState;
}

AppState updateWaitingToConsumeSaveConsumable(
    AppState appState, UpdateWaitingToConsumeSaveConsumableAction action) {
  appState.isWaitingToConsumeSaveConsumable =
      action.isWaitingToConsumeSaveConsumable;
  return appState;
}

AppState updateSearchTermFiltersDisplayTopOffset(
    AppState appState, UpdateSearchTermFiltersDisplayTopOffsetAction action) {
  appState.updateSearchTermFiltersDisplayTopOffset =
      action.updateSearchTermFiltersDisplayTopOffset;
  return appState;
}

AppState updateIsLoadingPaginatedData(
    AppState appState, UpdateIsLoadingPaginatedDataAction action) {
  appState.isLoadingPaginatedData = action.isLoadingPaginatedData;
  return appState;
}

AppState resumeLoadingSearchTerms(
    AppState appState, ResumeLoadingSearchTermsAction action) {
  return appState;
}

AppState removeCampaignAdGroupFilters(
    AppState appState, RemoveCampaignAdGroupFiltersAction action) {
  return appState;
}

AppState updateMostRecentDataDate(
    AppState appState, UpdateMostRecentDataDateAction action) {
  appState.mostRecentDataDate = action.upperEpochDate;
  return appState;
}

AppState noGoogleAdsAccount(
    AppState appState, NoGoogleAdsAccountAction action) {
  appState.noGoogleAccountFound = true;
  return appState;
}

AppState updateSignInButtonVisibility(
  AppState appState, UpdateSignInButtonVisibilityAction action) {
    appState.isShowingSignInButton = action.newVisibility;
    return appState; 
  }

AppState updateIsFinishedLoadingCustomers(
  AppState appState, UpdateIsFinishedLoadingCustomersAction action) {
  appState.isFinishedLoadingCustomers = action.isLoadingCustomers;
  return appState;
}

AppState updateIsShowingWelcomeScreen(AppState appState, UpdateIsShowingWelcomeScreenAction action) {
  appState.isShowingInitialScreen = action.newState;
  return appState;
}

AppState savingKeywords(AppState appState, SavingKeywordsAction action) {
  appState.isSavingKeywords = action.newState;
  return appState;
}