import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword.dart';
import 'package:searchTermAnalyzerFlutter/models/membership_type.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list_to_save.dart';
import 'package:searchTermAnalyzerFlutter/models/order_value.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import '../local_data.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import '../constants.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:facebook_app_events/facebook_app_events.dart';

// Flutter-redux for global state management.
/*
Single source of truth. (Store)
State inside of an application is read-only. State changes must be created rather than mutated.
Changes to the state are made via pure functions and do not have side effects.
*/

class AppState with ChangeNotifier {
  // List of all of the changes, new changes are only added on.
  // List<ChangeAction> changes = [];
  List<ChangeAction> positiveKeywords = [];
  List<ChangeAction> negativeKeywords = [];
  DateRange currentDateRange = null; //DateRange.fromName("Last 7 Days");

  // Date of the most recent date the data has loaded, and the oldest date to store it for.
  int mostRecentDataDate;
  int oldestDataDate;

  bool loading = false;

  // bool showingInitialSequence = false;

  // Default stored/UserPreferences to load from the next time the app is started.
  String initialCustomerId = "";
  String initialManagerId = "";
  String initialCampaignId = "";
  String initialAdGroupId = "";

  BuildContext buildContext;

  Customer currentCustomer;
  CustomerClient currentManager;
  Campaign currentCampaign;
  AdGroup currentAdGroup;

  // This only contains visible data, the rest of the data is in the local db.
  List<Customer> customers = [];
  List<CustomerClient> customerClients = [];
  List<Campaign> campaigns = [];
  List<AdGroup> adGroups = [];
  List<Keyword> keywords = [];
  List<SearchTerm> searchTerms = [];

  bool isLoadingCampaigns = false;
  bool isLoadingAdGroups = false;
  bool isLoadingSearchTerms = false;
  bool isLoadingPaginatedData = false;

  // Initial loading of the search terms.
  // Triggered upon loading in the first information.
  // Whenever date changes, or data is coming in and there is nothing to display.
  bool isInitialSearchTermsLoading = false;

  // show/hide welcome screen sign in button.
  // Initialize to false when first loading. Assume an account exists.
  bool isShowingSignInButton = true;

  // Whether customers have finished loading. Customers.fromAPI has finished.
  bool isFinishedLoadingCustomers = false;

  bool isShowingInitialScreen = false;

  List<Metric> campaignMetrics = [];
  List<Metric> adGroupMetrics = [];
  List<Metric> searchTermMetrics = [];

  List<FilterValue> filterValues = [];

  // NegativeKeywordLists that have been created locally but yet to be saved.
  List<NegativeKeywordListToSave> negativeKeywordListsToSave = [];

  // Map of current state of search terms.
  Map toSave = Map();
  // Map of actual current state of search terms in Google Ads. // Can also be the intial state.
  Map saved = Map();

  // List<ProductDetails> products = [];

  int currentPageIndex;
  PageController bottomController;
  ItemScrollController campaignsScrollController;
  ItemScrollController adgroupsScrollController;
  ItemScrollController searchTermsScrollController;

  // When first loading data
  int searchTermsLoadedCount = 0;
  int campaignsLoadedCount = 0;
  int adGroupsLoadedCount = 0;

  bool showLoadingToast = false; //true; // TODO testing false;
  OrderValue searchTermOrderBy = OrderValue("Text", 'Search Term', 1, 'string',
      displayName: ''); // Default to order search terms in alphabetical order.

  // Loading customers at the start.
  // Number of customers loading.
  int isLoadingCustomers = 0;
  int totalCustomers = 0;
  int loadingCustomerClients = 0;
  int totalCustomerClients = 0;

  int searchTermsListKey = 1;
  int campaignsListKey = 1;
  int adGroupsListKey = 1;

  // In-app purchases
  bool isIAPAvailable = true;
  List<ProductDetails> iapProducts = [];
  List<PastPurchase> pastPurchases = [];
  List<PastPurchase> pastConsumables = [];

  String databaseSize = "";
  double updateSearchTermFiltersDisplayTopOffset = 0;

  // Flag to cancel loading of all data.
  // e.g. When the user changes accounts while API data is loading.
  bool cancelLoading = false;

  /* 
    When consumable has been bought, but keywords haven't been saved, this consumable remains in the background, unconsumed.
    After three days, if it hasn't been consumed,
    It will trigger a refund.
    Alternate option is to save to purchasing server under user, 
    And then they can have the consumable there, but it is less secure.
    This is called from saveAll() only after save completes successfully.
  */
  bool isWaitingToConsumeSaveConsumable = false;

  // The membership of the user, based on what in-app products they have purchased.
  MembershipType membershipType;

  // If a consumable was purchased, displays the productId.
  // Then is immediately reverted back to null.
  String consumableProductId;

  bool isWaitingForPurchaseToBeValidated = false;
  bool isWaitingForMonthlyDowngrade = false;
  bool isPurchasing = false;
  bool isSavingKeywords = false;

  bool isWelcomeScreenShowing = true;

  BuildContext changesPageBuildContext;
  BuildContext singleSavePaywallBuildContext;

  bool noGoogleAccountFound = false;

  FirebaseFirestore firestore;
  FirebaseFunctions functions;
  FirebaseAnalytics analytics;
  FirebaseCrashlytics crashlytics;
  FirebaseMessaging firebaseMessaging;
  String fcmToken; // Firebase Messaging token.

  // Facebook/Meta App events
  FacebookAppEvents facebookAppEvents = FacebookAppEvents();

  AppState(
      {@required this.positiveKeywords,
      @required this.negativeKeywords,
      @required initialDateRange,
      @required initialCustomerId,
      @required initialManagerId,
      @required initialCampaign,
      @required initialAdGroup,
      @required mostRecentDataDate,
      @required oldestDataDate,
      @required campaignMetrics,
      @required adGroupMetrics,
      @required searchTermMetrics,
      @required orderValue,
      @required filterValues,
      @required iapProducts,
      @required appLoadCount}) {
    this.currentDateRange = initialDateRange;
    this.initialCustomerId = initialCustomerId;
    this.initialManagerId = initialManagerId;
    this.initialCampaignId = initialCampaign;
    this.initialAdGroupId = initialAdGroup;
    this.currentCustomer = initialCustomerId.length > 0
        ? Customer(initialCustomerId, "", false, "", "", null, null, null, null,
            null, null, null)
        : null;
    this.currentManager = initialManagerId.length > 0
        ? CustomerClient(initialManagerId, "", "", false, "", "", "", null,
            null, null, null, null)
        : null;
    this.currentCampaign = initialCampaignId.length > 0
        ? Campaign(initialCampaignId, "", "", "", null, null)
        : null;
    this.currentAdGroup = initialAdGroupId.length > 0
        ? AdGroup(initialAdGroupId, "", "", "", "", "", null)
        : null;

    if (mostRecentDataDate == null || mostRecentDataDate == "") {
      // mostRecentDataDate = date2String(DateTime.now());
      // Save to SharedPreferences
      // setSharedPreferenceValue(
      //     SHARED_PREFERENCE_KEYS.MOST_RECENT_DATA_DATETIME, mostRecentDataDate);
      // mostRecentDataDate =
    }
    if (oldestDataDate == null || oldestDataDate == "") {
      // DateTime todayDate = DateTime.now();
      // DateTime previousDate =
      //     DateTime(todayDate.year, todayDate.month - 3, todayDate.day);
      // oldestDataDate = date2String(previousDate);
      // // Save to SharedPreferences
      // setSharedPreferenceValue(
      //     SHARED_PREFERENCE_KEYS.OLDEST_DATA_DATETIME, oldestDataDate);
    }
    this.mostRecentDataDate =
        mostRecentDataDate; //string2DateTime(mostRecentDataDate);
    // this.oldestDataDate = string2DateTime(oldestDataDate);
    // print('Initial customer id: ' + this.initialCustomerId);
    // print("Initial manager Id: " + this.initialManagerId);
    // print('Initial dateRange: ' + initialDateRange.toString());

    // this.showingInitialSequence = checkShowingInitialSequence(initialCustomerId, initialManagerId, initialDateRange);

    // First three times, or every twentieth.
    if (appLoadCount == null) { 
      // clearCurrentData() calls null
      this.isShowingInitialScreen = false;
    }
    else {
      this.isShowingInitialScreen = (appLoadCount <= 3 || appLoadCount % 15 == 0);
    }

    // Populate state based on local DB.

    // Load metrics.
    if (campaignMetrics == null) {
      campaignMetrics = new List<Metric>();
    }
    if (adGroupMetrics == null) {
      adGroupMetrics = new List<Metric>();
    }
    if (searchTermMetrics == null) {
      searchTermMetrics = new List<Metric>();
    }
    this.campaignMetrics = campaignMetrics;
    this.adGroupMetrics = adGroupMetrics;
    this.searchTermMetrics = searchTermMetrics;
    if (orderValue != null) {
      this.searchTermOrderBy = orderValue;
    }

    this.filterValues = filterValues;
    if (filterValues == null) {
      this.filterValues = [];
    }

    this.iapProducts = iapProducts;

    currentPageIndex = readSharedPreferenceValue<int>(
        SHARED_PREFERENCE_KEYS.CURRENT_BOTTOM_NAVIGATION_TAB);
    bottomController = PageController(initialPage: currentPageIndex);

    campaignsScrollController = ItemScrollController();
    adgroupsScrollController = ItemScrollController();
    searchTermsScrollController = ItemScrollController();

    firestore = FirebaseFirestore.instance;
    functions = FirebaseFunctions.instanceFor(region: CLOUD_REGION);
    analytics = FirebaseAnalytics.instance;
    crashlytics = FirebaseCrashlytics.instance;

    crashlytics.setCrashlyticsCollectionEnabled(CRASHLYTICS_IS_ON);

    facebookAppEvents = FacebookAppEvents();

    firebaseMessaging = FirebaseMessaging.instance;
    firebaseMessaging.onTokenRefresh.listen((fcmToken) {
      // TODO: If necessary send token to application server.

      // Note: This callback is fired at each app startup and whenever a new
      // token is generated.
      print("New fcm token generated: $fcmToken");
    }).onError((err) {
      // Error getting token.
      print("Error getting fcm token: $err");
    });

    // Async call to set default parameters
    analytics.setDefaultEventParameters({'version': APPLICATION_VERSION});
    // To demonstrate that user properties are useable.
    analytics.setUserProperty(
      name: 'default',
      value: 'Search Terms Manager',
    );

    // For testing Firebase functions locally
    if (USING_FIREBASE_FUNCTIONS_EMULATOR) {
      print("USING FIREBASE FUNCTIONS EMULATOR");
      functions.useFunctionsEmulator(
          /*'0.0.0.0'*/ 'localhost', FUNCTIONS_ENDPOINT);
    }
  }

  // AppState.initialState() : changes = List.unmodifiable(<Change>[]);
  factory AppState.initialState(
          DateRange initialDateRange,
          String initialCustomerId,
          String initialManagerId,
          String initialCampaignId,
          String initialAdgroupId,
          int mostRecentDataDate,
          String oldestDataDate,
          List<Metric> campaignMetrics,
          List<Metric> adGroupMetrics,
          List<Metric> searchTermMetrics,
          OrderValue orderValue,
          List<FilterValue> filterValues,
          List<ProductDetails> iapProducts,
          int appLoadCount) =>
      AppState(
        positiveKeywords: List.unmodifiable(<ChangeAction>[]),
        negativeKeywords: List.unmodifiable(<ChangeAction>[]),
        initialDateRange: initialDateRange,
        initialCustomerId: initialCustomerId,
        initialManagerId: initialManagerId,
        initialCampaign: initialCampaignId,
        initialAdGroup: initialAdgroupId,
        mostRecentDataDate: mostRecentDataDate,
        oldestDataDate: oldestDataDate,
        campaignMetrics: campaignMetrics,
        adGroupMetrics: adGroupMetrics,
        searchTermMetrics: searchTermMetrics,
        orderValue: orderValue,
        filterValues: filterValues,
        iapProducts: iapProducts,
        appLoadCount: appLoadCount,
      );
}
