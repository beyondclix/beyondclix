import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup_to_load.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword.dart';
import 'package:searchTermAnalyzerFlutter/models/membership_type.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list_to_save.dart';
import 'package:searchTermAnalyzerFlutter/models/order_value.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import '../shared_preferences.dart';
import 'models.dart';
import '../main.dart';
import '../constants.dart';

class AddChangeAction {
  final Store<AppState> store;
  final AppState appState;
  final ChangeAction changeAction;
  final bool isNegative;
  int insertAtIndex;
  final String newNegativeKeywordListName;

  AddChangeAction(this.store, this.appState, this.changeAction, this.isNegative,
      this.newNegativeKeywordListName, [this.insertAtIndex]) {
    if (this.changeAction.changeType == 'SearchTerm') {
      SearchTermSaveAction searchTermSaveAction =
          this.changeAction.changeObject as SearchTermSaveAction;
      insertObject(searchTermSaveAction.toMap(), 'SEARCH_TERM_SAVE_ACTIONS');

      // Save the new negativeKeywordList to LocalDB if it is a new one with no resourceName.
      // Null resourceName means it has not been saved yet.
      if (newNegativeKeywordListName != null &&
          newNegativeKeywordListName != "") {
        var nklts = NegativeKeywordListToSave.createBlank(
            this.newNegativeKeywordListName,
            this.appState.currentCustomer.id,
            this.appState.currentManager.id);
        insertObject(nklts, 'NEGATIVE_KEYWORD_LIST_TO_SAVE');
      }
    }
  }
}

class RemoveChangeAction {
  final String changeId;
  final String changeType;
  final AppState appState;
  final bool isNegative;

  RemoveChangeAction(
      this.appState, this.changeType, this.changeId, this.isNegative) {
    if (this.changeType == 'SearchTerm') {
      deleteObject('id', this.changeId, 'SEARCH_TERM_SAVE_ACTIONS');
    }
  }
}

class ResetChangesAction {
  final String customerId;
  ResetChangesAction(this.customerId);
}

class ModifyChangeAction {
  // final AppState appState;
  final String changeId;
  final ChangeAction changeAction;
  final bool isNegative;

  ModifyChangeAction(
      /*this.appState, */ this.changeId, this.changeAction, this.isNegative) {
    if (this.changeAction.changeType == "SearchTerm") {
      SearchTermSaveAction searchTermSaveAction =
          this.changeAction.changeObject as SearchTermSaveAction;
      updateObject(searchTermSaveAction.toMap(), 'SEARCH_TERM_SAVE_ACTIONS',
          "id" /*this.changeId*/);
    }
  }
}

// Modify multiple change actions at once (copyActions)
class ModifyChangeActionRangeAction {
  final AppState appState;
  final SearchTermSaveAction searchTermSaveAction;
  final bool isNegative;
  final int low;
  final int high;

  ModifyChangeActionRangeAction(this.appState, this.searchTermSaveAction,
      this.isNegative, this.low, this.high);
}

class ToggleChangeAction {
  final AppState appState;

  ToggleChangeAction(this.appState);
}

class AddDataToSaveAction {
  final AppState appState;

  AddDataToSaveAction(this.appState);
}

class RemoveDataToSaveAction {
  final AppState appState;

  RemoveDataToSaveAction(this.appState);
}

class ClearSearchTermsAction {
  ClearSearchTermsAction();
}

class ModifyDateRangeAction {
  Store<AppState> store;
  AppState appState;
  final DateRange dateRange;

  ModifyDateRangeAction(this.store, this.appState, this.dateRange) {
    /*
      1. Save to shared preferences.
      2. Truncate all tables to clear local data.
      3. Update the date in the store.
      4. Make all API calls with filters applied.
      5. Save new data into tables.
      6. Update after and until dates of local data.
    */
    setSharedPreferenceValue(
        SHARED_PREFERENCE_KEYS.CURRENT_DATE_RANGE, dateRange.getName());
    // appState.currentDateRange = dateRange;

    // Only load data if the new queried date requires data more recent than the current date.
    // isMoreRecentDataRequired(appState.currentDateRange, dateRange);
    // store.dispatch((x) => fetchAPIDataAction(store));
    // }

    // Reset AdGroups to reload all again.

    // Call .fromMaps() for all data.
    // store.dispatch((x) => fetchLocalDataAction(store));
    store.dispatch((x) => updateVisibleSearchTermsAction(store,
        noAPI: false, dateRange: dateRange));
  }
}

class ModifyCurrentCustomerAction {
  Store<AppState> store;
  AppState appState;
  List<CustomerClient> customerClients;
  final Customer customer;

  ModifyCurrentCustomerAction(
      this.store, this.appState, this.customer, this.customerClients) {
    setSharedPreferenceValue(
        SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_ID, customer.id);

    // Update customerClient data
    // store.dispatch((x) => updateVisibleCustomerAction(store));
    store.dispatch(
        (x) => updateVisibleCustomerClientsAction(store, this.customerClients));

    store.dispatch((x) => changeCustomerAction(store, this.customer));

    store.dispatch(RemoveCampaignAdGroupFiltersAction(store));

    // store.dispatch((x) => updateVisibleSearchTermsAction(store, noAPI: true));

    // Call .fromMaps() for all data.
    // Only if the other fields have been loaded.
    // Ignore the initial loading, when fields are missing.
    // print("store.state.currentCustomer: ${store.state.currentCustomer}");
    // print("store.state.currentManager: ${store.state.currentManager.id}");
    // if (store.state.currentCustomer != null &&
    //     store.state.currentManager != null &&
    //     store.state.currentCustomer.id != null &&
    //     store.state.currentCustomer.id != "" &&
    //     store.state.currentManager.id != null &&
    //     store.state.currentManager.id != "" &&
    //     store.state.currentDateRange != null &&
    //     store.state.currentDateRange.getName() != "") {
    // store.dispatch((x) => fetchLocalDataAction(store));
    // }
  }
}

class ModifyCurrentCustomerClientAction {
  final Store<AppState> store;
  final AppState appState;
  final CustomerClient customerClient;

  ModifyCurrentCustomerClientAction(
      this.store, this.appState, this.customerClient) {
    // print("this.appState.currentDateRange: ${this.appState.currentDateRange.getName()}");
    print("new CustomerClient: ${this.customerClient.toMap()}");

    print("store.state.searchTerms.length: ${store.state.searchTerms.length}");

    if (store.state.searchTerms.length > 0) {
      store.dispatch(ClearSearchTermsAction());
      appState.searchTerms = List.from([]);
    }

    setSharedPreferenceValue(
        SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_CLIENT_ID, customerClient.id);

    setSharedPreferenceValue(
        SHARED_PREFERENCE_KEYS.CURRENT_TIMEZONE, customerClient.timeZone);

    if (this.appState.currentDateRange != null &&
        this.appState.currentDateRange.getName() != "") {
      print("RESUMING LOADING SEARCH TERMS ModifyCurrentCustomerClient");

      store.dispatch((x) => resumeLoadingSearchTermsAction(
          store,
          store.state.currentCustomer.id,
          this.customerClient.id,
          store.state.currentDateRange,
          // Load without campaign/adgroup constraints.
          null,
          null));
    }

    store.dispatch(RemoveCampaignAdGroupFiltersAction(store));

    store.dispatch(ModifyCurrentCampaignAction(store, store.state, null));

    // Preload campaigns
    store.dispatch((x) => updateVisibleCampaignsAction(store,
        customerClientId: customerClient.id));
  }
}

class ModifyCurrentCampaignAction {
  Store<AppState> store;
  AppState appState;
  final Campaign campaign;

  ModifyCurrentCampaignAction(this.store, this.appState, this.campaign) {
    String campaignId;

    print("Modifying to new campaign: ${campaign}");

    if (campaign == null) {
      setSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_CAMPAIGN_ID, "");
    } else {
      setSharedPreferenceValue(
          SHARED_PREFERENCE_KEYS.CURRENT_CAMPAIGN_ID, campaign.id);
      campaignId = campaign.id;
      print("Updating with new campaign: ${campaign.name}, ${campaign.id}");
    }

    store.dispatch((x) => updateVisibleAdGroupsAction(store, campaignId));

    // Reset adGroup
    store.dispatch(ModifyCurrentAdGroupAction(store, store.state, null,
        campaignId: campaignId));
  }
}

class ModifyCurrentAdGroupAction {
  Store<AppState> store;
  AppState appState;
  AdGroup adGroup;
  String campaignId;

  ModifyCurrentAdGroupAction(this.store, this.appState, this.adGroup,
      {this.campaignId = null}) {
    String adGroupId;
    if (adGroup == null) {
      setSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_AD_GROUP_ID, "");
    } else {
      setSharedPreferenceValue(
          SHARED_PREFERENCE_KEYS.CURRENT_AD_GROUP_ID, adGroup.id);
      adGroupId = adGroup.id;
    }
    // print("ModifyingCurrentAdGroupAction");

    // appState.currentAdGroup = adGroup;

    // store.dispatch((x) => updateVisibleKeywordsAction(store));
    // store.dispatch(ClearSearchTermsAction());
    // store.dispatch((x) => updateVisibleSearchTermsAction(store,
    //     adGroupId: adGroupId,
    //     campaignId: campaignId
    //     ));

    // store.state.notifyListeners(); // Calls listener in main.dart to update search terms
  }
}

// Save the negative keyword lists stored in state memory.
// Update localDB with the new resourceNames.
// Deletes local state negative keyword lists.
class RemoveNegativeKeywordListToSaveAction {
  NegativeKeywordListToSave negativeKeywordListToSave;

  RemoveNegativeKeywordListToSaveAction(this.negativeKeywordListToSave);
}

class ResetNegativeKeywordListToSaveAction {
  final String managerId;
  ResetNegativeKeywordListToSaveAction(this.managerId);
}

class AddResourceNameToNegativeKeywordListToSaveAction {
  final String name;
  final String resourceName;
  AddResourceNameToNegativeKeywordListToSaveAction(
      this.name, this.resourceName);
}

class UpdateDisplayMetricsAction {
  final String displayMetricName;
  final List<Metric> metrics;
  final Store<AppState> store;
  UpdateDisplayMetricsAction(this.displayMetricName, this.metrics, this.store) {
    // print("UpdateDisplayMetricsAction");
    // print("metrics: $metrics");
    if (metrics.length == 0) {
      // Check later.
      Metric.fromDB(displayMetricName).then((_metrics) {
        Future.delayed(Duration(milliseconds: 1000), () {
          store.dispatch(
              UpdateDisplayMetricsAction(displayMetricName, _metrics, store));
        });
      });
    }
  }
}

class InitialStateLoadedAction {
  List<ChangeAction> positiveKeywords;
  List<ChangeAction> negativeKeywords;
  Customer currentCustomer;
  CustomerClient currentManager;
  Campaign currentCampaign;
  AdGroup currentAdGroup;
  List<Customer> customers;
  List<CustomerClient> customerClients;
  List<Campaign> campaigns;
  List<AdGroup> adGroups;
  List<Keyword> keywords;
  List<SearchTerm> searchTerms;
  List<NegativeKeywordListToSave> negativeKeywordListsToSave;
  String fcmToken;

  InitialStateLoadedAction(
      this.positiveKeywords,
      this.negativeKeywords,
      this.currentCustomer,
      this.currentManager,
      this.currentCampaign,
      this.currentAdGroup,
      this.customers,
      this.customerClients,
      this.campaigns,
      this.adGroups,
      this.keywords,
      this.searchTerms,
      this.negativeKeywordListsToSave,
      this.fcmToken);
}

// When the customers/managers have been loaded, but none were selected.
// Load them from the DB.
void fetchLocalCustomersAction(Store<AppState> store) async {
  store.dispatch(StartLoadingAction());
  List<Customer> customers = await Customer.fromMaps(store);
  // if (customers == null) {}
  // List<CustomerClient> customerClients =
  //     await CustomerClient.fromMaps(store, store.state.initialCustomerId);

  store.dispatch(FetchLocalCustomersAction(customers));
  store.dispatch((x) => updateIsFinishedLoadingCustomersAction(store, true));
}

class FetchLocalCustomersAction {
  final List<Customer> customers;
  // final List<CustomerClient> customerClients;

  FetchLocalCustomersAction(this.customers);
}

class ChangeCustomerAction {
  final List<ChangeAction> positiveKeywords;
  final List<ChangeAction> negativeKeywords;
  final List<NegativeKeywordListToSave> negativeKeywordListsToSave;
  ChangeCustomerAction(this.positiveKeywords, this.negativeKeywords,
      this.negativeKeywordListsToSave);
}

// Update data that is displayed per customer.
void changeCustomerAction(
    Store<AppState> store, Customer currentCustomer) async {
  print("New currentCustomer: ${currentCustomer.descriptiveName}");
  List<SearchTermSaveAction> searchTermSaveActions =
      await SearchTermSaveAction.fromMaps('customerId', currentCustomer.id);
  List<ChangeAction> negativeKeywords = [];
  List<ChangeAction> positiveKeywords = [];
  for (var s in searchTermSaveActions
      .where((element) => element.isNegative)
      .toList()) {
    negativeKeywords.add(ChangeAction(s.id, 'SearchTerm', '', '', s));
  }

  for (var s in searchTermSaveActions
      .where((element) => !element.isNegative)
      .toList()) {
    positiveKeywords.add(ChangeAction(s.id, 'SearchTerm', '', '', s));
  }
  // print("positiveKeywords: ${positiveKeywords.length}");
  // print("negativeKeywords: ${negativeKeywords.length}");

  List<NegativeKeywordListToSave> negativeKeywordListsToSave = [];
  // When moving from Rainbow Reading to MCC, manager is null.
  if (store.state.currentManager != null) {
    negativeKeywordListsToSave = await NegativeKeywordListToSave.fromMaps(
        currentCustomer.id, store.state.currentManager.id);
  }

  // (await getLocalObjectsWithConstraint("NEGATIVE_KEYWORD_LIST_TO_SAVE",
  //         "customerId", currentCustomer.id))
  //     .map((map) =>
  //         NegativeKeywordListToSave.map2NegativeKeywordListToSave(map))
  //     .toList();
  store.dispatch(ChangeCustomerAction(
      positiveKeywords, negativeKeywords, negativeKeywordListsToSave));
}

// Thunk action - asynchronous
// Called from main.dart for initial loading in of all data.
void fetchInitialStateAction(Store<AppState> store) async {
  // Selected values from initial values.
  Customer currentCustomer =
      await Customer.fromInitialId(store.state.initialCustomerId);
  if (currentCustomer == null) {
    loadCustomersAndCustomerClients(store);
    return;
  }
  CustomerClient currentManager =
      await CustomerClient.fromInitialId(store.state.initialManagerId);
  Campaign currentCampaign =
      await Campaign.fromInitialId(store.state.initialCampaignId, store);
  AdGroup currentAdGroup =
      await AdGroup.fromInitialId(store.state.initialAdGroupId, store);
  List<SearchTermSaveAction> searchTermSaveActions =
      await SearchTermSaveAction.fromMaps('customerId', currentCustomer.id);
  List<ChangeAction> negativeKeywords = [];
  List<ChangeAction> positiveKeywords = [];
  for (var s in searchTermSaveActions
      .where((element) => element.isNegative)
      .toList()) {
    negativeKeywords.add(ChangeAction(s.id, 'SearchTerm', '', '', s));
  }

  for (var s in searchTermSaveActions
      .where((element) => !element.isNegative)
      .toList()) {
    positiveKeywords.add(ChangeAction(s.id, 'SearchTerm', '', '', s));
  }

  List<NegativeKeywordListToSave> negativeKeywordListsToSave =
      await NegativeKeywordListToSave.fromMaps(
          store.state.initialCustomerId, store.state.initialManagerId);
  // (await getLocalObjectsWithConstraint("NEGATIVE_KEYWORD_LIST_TO_SAVE",
  //         "customerId", currentCustomer.id))
  //     .map((map) =>
  //         NegativeKeywordListToSave.map2NegativeKeywordListToSave(map))
  //     .toList();

  List<Customer> customers = await Customer.fromMaps(store);
  store.dispatch((x) => updateIsFinishedLoadingCustomersAction(store, true));
  if (customers == null) {}
  List<CustomerClient> customerClients = await CustomerClient.fromMaps(store,
      initialId: store.state.initialCustomerId);

  // Loading campaigns and adGroups here is blocking, and stops account data from showing until this is complete.
  List<Campaign> campaigns = [];
  // await Campaign.fromMaps(store, initialId: store.state.initialManagerId);
  campaigns = campaigns.where((f) => f.id != EMPTY_KEY).toList();
  List<AdGroup> adGroups = [];
  // await AdGroup.fromMaps(store, initialId: store.state.initialCampaignId);
  adGroups = adGroups.where((f) => f.id != EMPTY_KEY).toList();
  List<Keyword> keywords =
      await Keyword.fromMaps(store, store.state.initialAdGroupId);
  List<SearchTerm> searchTerms = [];
  SearchTerm.fromMaps(store, false, initialId: store.state.initialAdGroupId);
  searchTerms = searchTerms.where((f) => f.text != EMPTY_KEY).toList();
  // print('Loaded initial customers: ' + customers.length.toString());

  getDatabaseSize(store);

  final fcmToken = await FirebaseMessaging.instance.getToken();
  print("fcmToken: $fcmToken");
  String email = readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);
  
  // if (email != null && email.isNotEmpty) {
    
  //   ANALYTICS_logEvent(store, 'fcmToken:', {
  //     "token": fcmToken,
  //     "googleEmail": email,
  //   });

  // }

  store.dispatch(InitialStateLoadedAction(
      positiveKeywords,
      negativeKeywords,
      currentCustomer,
      currentManager,
      currentCampaign,
      currentAdGroup,
      customers,
      customerClients,
      campaigns,
      adGroups,
      keywords,
      searchTerms,
      negativeKeywordListsToSave,
      fcmToken));
}

class FetchAPIDataAction {
  List<Campaign> campaigns;
  List<AdGroup> adGroups;
  List<Keyword> keywords;
  List<SearchTerm> searchTerms;

  FetchAPIDataAction(
      this.campaigns, this.adGroups, this.keywords, this.searchTerms);
}

class UpdateVisibleCustomerClientsAction {
  final List<CustomerClient> customerClients;
  UpdateVisibleCustomerClientsAction(this.customerClients);
}

void updateVisibleCustomerClientsAction(
    Store<AppState> store, List<CustomerClient> customerClients) async {
  store.dispatch(StartLoadingAction());

  // Load customerClients who are children of this customer.
  // List<Map> customerClients =
  //     await getLocalObjectsWithConstraint<CustomerClient>(
  //         'CUSTOMER_CLIENTS', "parentId", store.state.currentCustomer.id);
  // List<CustomerClient> customerClients = await CustomerClient.fromMaps(store);
  // for(CustomerClient cc in customerClients) {
  //   print("customerClient: ${cc.toString()}");
  // }

  // If no customer clients are available, set this to the parent, and move straight to date range selector.
  // print("customerClients: ${customerClients.length}");
  if (customerClients.length == 0) {
    // Create CustomerClient from Customer.
    CustomerClient c = CustomerClient.fromCustomer(store.state.currentCustomer);
    print("Creating from current customer: ${c.id.toString()}");
    store.dispatch(ModifyCurrentCustomerClientAction(store, store.state, c));
    store.dispatch((x) => updateVisibleSearchTermsAction(store,
        noAPI: true, customerClientId: c.id));
  } else {
    store.dispatch(UpdateVisibleCustomerClientsAction(customerClients));
  }
}

class UpdateVisibleCampaignsAction {
  final List<Campaign> campaigns;
  UpdateVisibleCampaignsAction(this.campaigns);
}

void updateVisibleCampaignsAction(Store<AppState> store,
    {customerClientId: null, noAPI: false}) async {
  // store.dispatch(StartLoadingAction());
  print("Updating visible campaigns!!!: noAPI: $noAPI");
  List<Campaign> campaigns = await Campaign.fromMaps(
    store,
    initialId: customerClientId,
    noAPI: noAPI,
  );
  campaigns = campaigns.where((f) => f.name != EMPTY_KEY).toList();

  store.dispatch(UpdateVisibleCampaignsAction(campaigns));
}

class UpdateVisibleAdGroupsAction {
  final List<AdGroup> adGroups;
  UpdateVisibleAdGroupsAction(this.adGroups);
}

void updateVisibleAdGroupsAction(Store<AppState> store, String campaignId,
    {noAPI: false}) async {
  // print("Updating visible AdGroups!!!");

  // List<AdGroup> adGroups = await getLocalObjectsWithConstraint(
  //     'ADGROUPS', 'campaignId', store.state.currentCampaign.id);
  List<AdGroup> adGroups =
      await AdGroup.fromMaps(store, campaignId: campaignId, noAPI: noAPI);
  // print("Got adGroups from AdGroup.fromMaps(): ${adGroups.length}");
  adGroups = adGroups.where((f) => f.name != EMPTY_KEY).toList();

  store.dispatch(UpdateVisibleAdGroupsAction(adGroups));
}

class UpdateVisibleKeywordsAction {
  final List<Keyword> keywords;
  UpdateVisibleKeywordsAction(this.keywords);
}

void updateVisibleKeywordsAction(Store<AppState> store) async {
  // store.dispatch(StartLoadingAction());

  // List<Keyword> keywords = await getLocalObjectsWithConstraint(
  //     'KEYWORDS', 'adGroupId', store.state.currentAdGroup.id);
  List<Keyword> keywords = await Keyword.fromMaps(store);

  store.dispatch(UpdateVisibleKeywordsAction(keywords));
}

class UpdateVisibleSearchTermsAction {
  final List<SearchTerm> searchTerms;
  UpdateVisibleSearchTermsAction(this.searchTerms);
}

/*
  Called when main data is loaded.
  Called when Customer/CustomerClient/Campaign/AdGroup changes
  Called when SearchTerm API data is loaded (to show results before all loading is complete)
  Calls SearchTerm.fromMaps(), which may recursively call itself.
  Use noAPI:true to stop from recursively making API calls. 
*/
void updateVisibleSearchTermsAction(Store<AppState> store,
    {noAPI: false,
    // If null, use ModifyingCurrentAdGroupActio
    // Empty string means really empty
    DateRange dateRange,
    customerClientId: "",
    campaignId: "",
    adGroupId: ""}) async {
  if (store.state.searchTerms.length > 0) {
    // store.dispatch(ClearSearchTermsAction());
  }
  if (noAPI == false) {
    GLOBAL_adGroupsToLoadFinished = 0;
    GLOBAL_adGroupsToLoadTotal = 0;
  }
  // store.dispatch(StartLoadingAction());
  // print("updateVisibleSearchTermsAction, campaignId: $campaignId, adGroupId: $adGroupId, ${dateRange.lowerEpochDate}");

  // List<SearchTerm> searchTerms = await getLocalObjectsWithConstraint(
  //     'SEARCHTERMS', 'adGroupId', store.state.currentAdGroup.id);
  List<SearchTerm> searchTerms = await SearchTerm.fromMaps(store, noAPI,
      customerClientId: customerClientId,
      campaignId: campaignId,
      adGroupId: adGroupId,
      dateRange: dateRange);

  // List<SearchTerm> searchTerm = searchTerms.where((f) => f.id == EMPTY_KEY).toList();
  // print('textsearchTerm: ${searchTerm[0].toMap()}');
  // print('searchTerms length: ${searchTerms.length}');

  // Act on filters.
  // for (FilterValue fv in store.state.filterValues) {
  //   searchTerms = filterSearchTerms(fv, searchTerms);
  // }
  // searchTerms =
  //     await filterSearchTermsDB(store.state.filterValues, searchTerms);
  // print('new searchterms length: ${searchTerms.length}');

  if (searchTerms.length > 0 && store.state.isInitialSearchTermsLoading) {
    // Cancel showing the initial loading spinner.
    store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
  }

  // Remove EMPTY_KEY
  searchTerms = searchTerms.where((f) => f.text != EMPTY_KEY).toList();

  store.dispatch(UpdateVisibleSearchTermsAction(searchTerms));
  // store.dispatch(FinishSearchTermsLoadingAction());
}

class ClearVisibleSearchTermsAction {
  
  ClearVisibleSearchTermsAction();
  
}

class UpdateIsInitialSearchTermsLoadingAction {
  final bool isInitialSearchTermsLoading;
  UpdateIsInitialSearchTermsLoadingAction(this.isInitialSearchTermsLoading);
}

// Load all Customers and CustomerClients
void loadCustomersAndCustomerClients(Store<AppState> store,
    {googleEmail = null, forceAPI: false}) async {
  // print("LOADING CUSTOMERS AND CUSTOMER CLIENTS");
  if (googleEmail == null) {
    googleEmail =
        readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);
  }

  ANALYTICS_logEvent(store, "Loading Accounts And Customer Clients");
  ;

  store.dispatch(StartLoadingAction());

  // if (forceAPI == true) {
  //   // Empty customer and customer client tables and force reload.
  //   await truncateTable('CUSTOMERS');
  //   await truncateTable('CUSTOMER_CLIENTS');
  // }

  // Loads and saves to Local DB.
  List<Customer> customers = await Customer.fromMaps(store,
      googleEmail: googleEmail,
      forceAPI: forceAPI); //Customer.fromAPI(store, googleEmail);
  store.dispatch((x) => updateIsFinishedLoadingCustomersAction(store, true));

  List<CustomerClient> customerClients = [];
  for (Customer customer in customers) {
    
    // Concatenate into current list.
    customerClients.addAll(await CustomerClient.fromMaps(store,
        initialId: customer.id, forceAPI: forceAPI));
    
    // store.dispatch(IncrementLoadedCustomerAction());

  }
  // print("CUSTOMER CLIENTS: " + customerClients.length.toString());

  store.dispatch(
      LoadCustomersAndCustomerClientsAction(customers, customerClients));
}

class LoadCustomersAndCustomerClientsAction {
  List<Customer> customers;
  List<CustomerClient> customerClients;
  LoadCustomersAndCustomerClientsAction(this.customers, this.customerClients);
}

class UpdateSignInButtonVisibilityAction {
  bool newVisibility;
  UpdateSignInButtonVisibilityAction(this.newVisibility);
}

// Called whenever the date range is modified.
// DEPRECATED and replaced by updateVisibleSearchTermsAction();
/*
void fetchLocalDataAction(Store<AppState> store) async {
  store.dispatch(StartLoadingAction());
  // print("UPDATING LOCAL SEARCHTERMS");
  List futures = await Future.wait([
    // Customer.fromAPI(),
    // CustomerClient.fromAPI(store.state.currentCustomer.id),
    Campaign.fromMaps(store),
    AdGroup.fromMaps(store),
    Keyword.fromMaps(store),
    // SearchTerm.fromMaps(store, false),
  ]);

  // Remove EMPTY_KEY
  futures[3] = futures[3].where((f) => f.text != EMPTY_KEY).toList();

  // print('customers: ' + futures[0].length.toString());
  // print('customerClients: ' + futures[1].length.toString());
  // print('campaigns: ' + futures[0].length.toString());
  // print('adGroups: ' + futures[1].length.toString());
  // print('keywords: ' + futures[2].length.toString());
  // print('searchTerms: ' + futures[3].length.toString());
  // store.dispatch(FetchAPIDataAction(futures[0], futures[1], futures[2],
  //     futures[3], /*keywords*/ [], futures[4]));
  store.dispatch(
      FetchAPIDataAction(futures[0], futures[1], futures[2], futures[3]));
}
*/

// Call API's
// void fetchAPIDataAction(Store<AppState> store) async {
//   store.dispatch(StartLoadingAction());

//   // Remove all table data.
//   // truncateTable('CUSTOMERS');
//   // truncateTable('CUSTOMER_CLIENTS');

//   /*
//   truncateTable('CAMPAIGNS');
//   truncateTable('ADGROUPS');
//   truncateTable('KEYWORDS');
//   truncateTable('SEARCHTERMS');
//   */

//   // List<Customer> customers = await Customer.fromAPI();
//   // print('customers: ' + customers.length.toString());
//   // List<CustomerClient> customerClients =
//   //     await CustomerClient.fromAPI(store.state.currentCustomer.id);
//   // print('customerClients: ' + customerClients.length.toString());
//   // List<Campaign> campaigns = await Campaign.fromAPI(
//   //     store.state.currentCustomer.id, store.state.currentManager.id);
//   // print('campaigns: ' + campaigns.length.toString());
//   // List<AdGroup> adGroups = await AdGroup.fromAPI(
//   //     store.state.currentCustomer.id, store.state.currentManager.id);
//   // print('adGroups: ' + adGroups.length.toString());
//   // // List<Keyword> keywords = await Keyword.fromAPI(store.state.currentCustomer.id,
//   // //     store.state.currentManager.id, store.state.currentDateRange);
//   // // print('keywords: ' + keywords.length.toString());
//   // List<SearchTerm> searchTerms = await SearchTerm.fromAPI(
//   //     store.state.currentCustomer.id,
//   //     store.state.currentManager.id,
//   //     store.state.currentDateRange);
//   // print('searchTerms: ' + searchTerms.length.toString());

//   GLOBAL_searchTermsAPILoading = true;

//   List futures = await Future.wait([
//     // Customer.fromAPI(),
//     // CustomerClient.fromAPI(store.state.currentCustomer.id),
//     Campaign.fromAPI(store, store.state.currentCustomer.id,
//         store.state.currentManager.id, store.state.currentDateRange),
//     AdGroup.fromAPI(store, store.state.currentCustomer.id,
//         store.state.currentManager.id, store.state.currentDateRange),
//     Keyword.fromAPI(store.state.currentCustomer.id,
//         store.state.currentManager.id, store.state.currentDateRange),
//     SearchTerm.fromAPIPaginated(
//         store,
//         store.state.currentCustomer.id,
//         store.state.currentManager.id,
//         store.state.currentDateRange,
//         null,
//         null),
//   ]);
//   // print('customers: ' + futures[0].length.toString());
//   // print('customerClients: ' + futures[1].length.toString());
//   print('campaigns: ' + futures[0].length.toString());
//   print('adGroups: ' + futures[1].length.toString());
//   // print('keywords: ' + futures[2].length.toString());
//   print('searchTerms: ' + futures[3].length.toString());
//   // store.dispatch(FetchAPIDataAction(futures[0], futures[1], futures[2],
//   //     futures[3], /*keywords*/ [], futures[4]));
//   store.dispatch(
//       FetchAPIDataAction(futures[0], futures[1], futures[2], futures[3]));
// }

class ClearCurrentDataAction {
  ClearCurrentDataAction();
}

class StartLoadingAction {
  StartLoadingAction();
}

class StartCampaignsLoadingAction {
  StartCampaignsLoadingAction();
}

class StartAdGroupsLoadingAction {
  StartAdGroupsLoadingAction();
}

class StartSearchTermsLoadingAction {
  StartSearchTermsLoadingAction();
}

class FinishCampaignsLoadingAction {
  FinishCampaignsLoadingAction();
}

class FinishAdGroupsLoadingAction {
  FinishAdGroupsLoadingAction();
}

class FinishSearchTermsLoadingAction {
  FinishSearchTermsLoadingAction();
}

// Deprecated - update multiple metrics after save button is pressed.
// TODO reinstate this. The UX is better.
class UpdateMetricsAction {
  final String metricType;
  final List<Metric> metrics;

  UpdateMetricsAction(this.metricType, this.metrics) {
    DB_UpdateMetrics(metrics, metricType);
  }
}

class UpdateCurrentPageIndexAction {
  final int index;

  UpdateCurrentPageIndexAction(this.index);
}

class AddFilterAction {
  final FilterValue filterValue;
  AddFilterAction(this.filterValue) {
    // Save to DB
    insertObject(this.filterValue.toMap(), "FILTER_VALUE");
  }
}

class UpdateFilterAction {
  final FilterValue filterValue;
  UpdateFilterAction(this.filterValue) {
    // Update DB entry
    updateObject(
      this.filterValue.toMap(),
      "FILTER_VALUE",
      'id',
    );
  }
}

class RemoveFilterAction {
  final FilterValue filterValue;
  RemoveFilterAction(this.filterValue) {
    // print("filterValue: ${this.filterValue.toMap()}");
    String id = this.filterValue.id;
    // print("removing filterId: $id");
    removeObject("FILTER_VALUE", 'id', id);
  }
}

// Update single metric.
// class UpdateMetricAction {
//   final String metricFor;
//   final String metricName;
//   final bool isOn;

//   UpdateMetricAction(this.metricFor, this.metricName, this.isOn);
// }

class IncrementLoadedAction {
  final String incrementType;
  final int incrementAmount;
  IncrementLoadedAction(this.incrementType, this.incrementAmount);
}

class StartLoadingToastAction {
  StartLoadingToastAction();
}

class FinishLoadingToastAction {
  FinishLoadingToastAction();
}

class LoadMoreSearchTermsPaginatedAction {
  int offset;
  List<SearchTerm> searchTerms;
  LoadMoreSearchTermsPaginatedAction(this.offset, this.searchTerms);
}

void loadMoreSearchTermsPaginatedAction(
    Store<AppState> store, int offset) async {
  List<SearchTerm> searchTerms =
      await SearchTerm.loadMorePaginatedData(store, offset);
  store.dispatch(LoadMoreSearchTermsPaginatedAction(offset, searchTerms));
}

class LoadMoreAdGroupsPaginatedAction {
  final int offset;
  final List<AdGroup> adGroups;
  LoadMoreAdGroupsPaginatedAction(this.offset, this.adGroups);
}

void loadMoreAdGroupsPaginatedAction(Store<AppState> store, int offset) async {
  List<AdGroup> adGroups = await AdGroup.loadMorePaginated(store, offset);
  store.dispatch(LoadMoreAdGroupsPaginatedAction(offset, adGroups));
}

class LoadMoreCampaignsPaginatedAction {
  final int offset;
  final List<Campaign> campaigns;
  LoadMoreCampaignsPaginatedAction(this.offset, this.campaigns);
}

void loadMoreCampaignsPaginatedAction(Store<AppState> store, int offset) async {
  List<Campaign> campaigns = await Campaign.loadMorePaginated(store, offset);
  store.dispatch(LoadMoreCampaignsPaginatedAction(offset, campaigns));
}

class UpdateOrderAction {
  final OrderValue orderValue;
  UpdateOrderAction(this.orderValue) {
    print("this.orderValue.toMap(): ${this.orderValue.toMap()}");
    // removeObject('ORDER_VALUE', 'id', this.orderValue.id)
    // For now, do this, there's only one entry anyway.
    truncateTable('ORDER_VALUE').then((_) {
      print("SAVING ORDER VALUE: ${this.orderValue.toMap()}");
      insertObject(this.orderValue.toMap(), 'ORDER_VALUE');
    });
  }
}

class StartLoadingCustomerAction {
  final int numberOfCustomers;
  StartLoadingCustomerAction(this.numberOfCustomers);
}

class IncrementLoadedCustomerAction {
  IncrementLoadedCustomerAction();
}

// Used in conjunction with StartLoadingCustomerAction
class StartLoadingCustomerClientsAction {
  final int numberOfCustomerClients;
  StartLoadingCustomerClientsAction(this.numberOfCustomerClients);
}

class IncrementLoadedCustomerClientAction {
  IncrementLoadedCustomerClientAction();
}

class IAPAvailabilityUpdateAction {
  final bool isAvailable;
  IAPAvailabilityUpdateAction(this.isAvailable);
}

void iapAvailabilityUpdateAction(Store<AppState> store) async {
  bool isAvailable = await isInAppPurchaseAvailable(store);
  store.dispatch(IAPAvailabilityUpdateAction(isAvailable));
}

void loadIapProductsAction(Store<AppState> store) async {
  List<ProductDetails> iapProducts = await loadProducts(store);
  store.dispatch(LoadIAPProductsAction(iapProducts));
}

class LoadIAPProductsAction {
  final List<ProductDetails> iapProducts;
  LoadIAPProductsAction(this.iapProducts);
}

// class AddIAPPurchaseAction {
//   final PurchaseDetails iapPurchase;
//   AddIAPPurchaseAction(this.iapPurchase);
// }

class UpdateLoadingAction {
  final bool newLoading;
  UpdateLoadingAction(this.newLoading);
}

class NewDatabaseSizeAction {
  final String databaseSize;
  NewDatabaseSizeAction(this.databaseSize);
}

class UpdateMembershipTypeAction {
  final MembershipType newMembershipType;
  UpdateMembershipTypeAction(this.newMembershipType);
}

class SetChangesPageBuildContextAction {
  final BuildContext buildContext;
  SetChangesPageBuildContextAction(this.buildContext);
}

class SetSingleSavePurchaseDialogBuildContextAction {
  final BuildContext buildContext;
  SetSingleSavePurchaseDialogBuildContextAction(this.buildContext);
}

class CloseSingleSavePurchaseDialogAction {
  CloseSingleSavePurchaseDialogAction();
}

class UpdateIsWaitingForPurchaseToBeValidatedAction {
  final bool isWaitingForPurchaseToBeValidated;
  UpdateIsWaitingForPurchaseToBeValidatedAction(
      this.isWaitingForPurchaseToBeValidated);
}

// Only for active memberships.
class UpdatePastPurchasesAction {
  List<PastPurchase> pastPurchases;
  final Store<AppState> store;

  UpdatePastPurchasesAction(this.store, this.pastPurchases) {
    for (PastPurchase pp in pastPurchases) {
      
      // Prioritize Lifetime purchase.
      if (pp.productId == SKU_LIFETIME_PURCHASE /*&& pp.status == Status.ACTIVE*/) {

        store.dispatch(UpdateMembershipTypeAction(
            MEMBERSHIP_TYPES[SKU_LIFETIME_PURCHASE]));

      }

      else if (pp.productId == SKU_MONTHLY_SUBSCRIPTION &&
          pp.status == Status.ACTIVE) {
        
        // Monthly subscription is active.
        store.dispatch(UpdateMembershipTypeAction(
            MEMBERSHIP_TYPES[SKU_MONTHLY_SUBSCRIPTION]));

      } 

    }
  }
}

// Only for consumables. (save / lifetime_membership)
class UpdatePastConsumablesAction {
  List<PastPurchase> pastConsumables;
  final Store<AppState> store;
  
  UpdatePastConsumablesAction(this.store, this.pastConsumables) {
    
    for (PastPurchase pp in pastConsumables) {

      if (pp.productId == SKU_LIFETIME_PURCHASE) {

        store.dispatch(UpdateMembershipTypeAction(
          MEMBERSHIP_TYPES[SKU_LIFETIME_PURCHASE]));
      } 

    }

  }
}

class DowngradeMonthlySubscriptionAction {
  bool isWaitingForMonthlyDowngrade;
  DowngradeMonthlySubscriptionAction(this.isWaitingForMonthlyDowngrade);
}

class UpdateIsPurchasingAction {
  final bool isPurchasing;
  UpdateIsPurchasingAction(this.isPurchasing);
}

class UpdateIsWelcomeScreenShowingAction {
  final bool isWelcomeScreenShowing;
  UpdateIsWelcomeScreenShowingAction(this.isWelcomeScreenShowing);
}

class UpdateWaitingToConsumeSaveConsumableAction {
  final bool isWaitingToConsumeSaveConsumable;
  UpdateWaitingToConsumeSaveConsumableAction(
      this.isWaitingToConsumeSaveConsumable);
}

class UpdateSearchTermFiltersDisplayTopOffsetAction {
  final double updateSearchTermFiltersDisplayTopOffset;
  UpdateSearchTermFiltersDisplayTopOffsetAction(
      this.updateSearchTermFiltersDisplayTopOffset);
}

class ReduceTotalCustomerToLoadCountAction {
  ReduceTotalCustomerToLoadCountAction();
}

class UpdateIsLoadingPaginatedDataAction {
  final bool isLoadingPaginatedData;
  UpdateIsLoadingPaginatedDataAction(this.isLoadingPaginatedData);
}

void resumeLoadingSearchTermsAction(
    Store<AppState> store,
    String customerId,
    String customerClientId,
    DateRange dateRange,
    String campaignId,
    String adGroupId) async {
  List<AdGroupToLoad> adGroupToLoads =
      await AdGroupToLoad.fromMaps(store, customerClientId);
  print("Resuming loading search terms!!!");

  store.dispatch(ResumeLoadingSearchTermsAction(store, customerId,
      customerClientId, dateRange, campaignId, adGroupId, adGroupToLoads));
}

// Resume loading un-loaded adgroups.
// This can be moved into common_functions.dart as it doesn't modify state.
class ResumeLoadingSearchTermsAction {
  final Store<AppState> store;
  final String customerId;
  final String customerClientId;
  final DateRange dateRange;
  final String campaignId;
  final String adGroupId;
  final List<AdGroupToLoad> adGroupToLoads;

  ResumeLoadingSearchTermsAction(
    this.store,
    this.customerId,
    this.customerClientId,
    this.dateRange,
    this.campaignId,
    this.adGroupId,
    this.adGroupToLoads,
  ) {
    print("RESUMING INITIAL adGroupToLoads.length: ${adGroupToLoads.length}");

    // TODO
    return;

    if (adGroupToLoads.length > 0 || true) {
      // Resume loading from adgroups.
      print("RESUMING LOADING FROM ADGROUPS: ${adGroupToLoads.length}");
      store.dispatch(StartLoadingToastAction());

      GLOBAL_searchTermsAPILoading = true;

      SearchTerm.fromAPIPaginated(
        store,
        customerId,
        customerClientId,
        dateRange,
        campaignId,
        adGroupId,
        adGroupToLoads: adGroupToLoads,
      );
    }
  }
}

class RemoveCampaignAdGroupFiltersAction {
  final Store<AppState> store;

  RemoveCampaignAdGroupFiltersAction(this.store) {
    List<FilterValue> filterValuesToRemove = [];
    if (store.state.filterValues != null) {
      for (FilterValue fv in store.state.filterValues) {
        // Remove all child adgroups, and campaign existing filters.
        // For now, only allow one campaign filter.
        if (fv.name == "AdGroup" || fv.name == "Campaign") {
          filterValuesToRemove.add(fv);
        }
      }
      for (FilterValue ffv in filterValuesToRemove) {
        store.dispatch(RemoveFilterAction(ffv));
      }
    }
  }
}

class UpdateMostRecentDataDateAction {
  final int upperEpochDate;

  UpdateMostRecentDataDateAction(this.upperEpochDate);
}

class NoGoogleAdsAccountAction {
  NoGoogleAdsAccountAction();
}

class UpdateIsFinishedLoadingCustomersAction {
  bool isLoadingCustomers;
  UpdateIsFinishedLoadingCustomersAction(this.isLoadingCustomers);
}

void updateIsFinishedLoadingCustomersAction(Store<AppState> store, bool isLoadingCustomers) async {
  return Future.delayed(new Duration(milliseconds: 250), () {
    store.dispatch(UpdateIsFinishedLoadingCustomersAction(isLoadingCustomers));
  });
}

class UpdateIsShowingWelcomeScreenAction {
  bool newState;
  UpdateIsShowingWelcomeScreenAction(this.newState);
}

class SavingKeywordsAction {
  bool newState;
  SavingKeywordsAction(this.newState);
}