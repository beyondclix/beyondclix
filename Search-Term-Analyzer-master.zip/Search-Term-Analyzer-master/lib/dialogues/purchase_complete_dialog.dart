import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';

class PurchaseCompleteDialog extends StatefulWidget {
    final Store<AppState> _store;
    final String productID;
    final bool wasMonthlyPurchaseDowngraded;

    PurchaseCompleteDialog(this._store, this.productID, [this.wasMonthlyPurchaseDowngraded]);

    @override
    _PurchaseCompleteDialogState createState() => 
        _PurchaseCompleteDialogState();
}

class _PurchaseCompleteDialogState extends State<PurchaseCompleteDialog> {
    
    _PurchaseCompleteDialogState();

    @override
    void initState() {
        ANALYTICS_logEvent(widget._store, "Showing purchase complete dialog", {
            "wasMonthlyPurchaseDowngraded": widget.wasMonthlyPurchaseDowngraded.toString(),
        });
    }

    dynamic getDisplayTexts() {
        switch(widget.productID) {
            case SKU_SINGLE_SAVE: 
                // This is not displayed, can't purchase a single save by itself.
                return {
                    "title": "You're now able to save those search terms!",
                    "subtitle": "But you only have one chance, make it count",
                };
            case SKU_MONTHLY_SUBSCRIPTION:
                return {
                    "title": "You're on our monthly plan!",
                    "subtitle": "Go forth and save search terms",
                };
            case SKU_LIFETIME_PURCHASE:
                return {
                    "title": "You're a lifetime member!",
                    "subtitle": "Save all the search terms you can!"
                    // Handle monthly downgrade here as well.
                };
        }
    }

    @override
    Widget build(BuildContext context) {
        return Dialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
            elevation: 0,
            backgroundColor: Colors.white,
            child: _contentBox(context),
        );
    }

    Widget _contentBox(BuildContext context) {

        var textObj = getDisplayTexts();

        return Container(
            padding: EdgeInsets.all(25),
            child: Stack(
                alignment: Alignment.topCenter,
                children: [
                Positioned(
                    child: Container(
                    transform: Matrix4.translationValues(0.0, -55.0, 0.0),
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        // border: Border.all(width: 1, color: Colors.red),
                        color: Color.fromRGBO(52, 168, 83, 1),
                    ),
                    child: Icon(Icons.arrow_forward_rounded, 
                        color: Colors.white,
                        size: 65),
                    ),
                ),
                Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                    // Title
                    Container(
                        margin: EdgeInsets.only(top: 25, bottom: 10),
                        child: Text(
                        textObj['title'],
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w600,
                        ),
                        ),
                    ),
                    // Description
                    Text(
                        textObj['subtitle'],
                        style: TextStyle(
                            fontSize: 18,
                        )),
                    // CTA
                    // StoreConnector<AppState, ProductDetails>(
                    //     converter: (store) => store.state.iapProducts
                    //         .where((f) => f.id == SKU_SINGLE_SAVE)
                    //         .toList()[0],
                    //     builder: (context, productDetails) => GestureDetector(
                    //     child: Container(
                    //         margin: EdgeInsets.only(top: 25),
                    //         padding: EdgeInsets.fromLTRB(65, 10.5, 65, 10.5),
                    //         decoration: BoxDecoration(
                    //         color: Color.fromRGBO(52, 168, 83, 1),
                    //         borderRadius: BorderRadius.circular(6),
                    //         ),
                    //         child: Text(
                    //         "One-time ${productDetails.price.toString()}",
                    //         style: TextStyle(
                    //             fontSize: 16,
                    //             color: Colors.white,
                    //             fontWeight: FontWeight.w600,
                    //         ),
                    //         ),
                    //     ),
                    //     onTap: () async {
                    //         // Show the loading screen.
                    //         this.setState(() {
                    //         // this._isPurchasing = true;
                    //         });
                    //         this._store.dispatch(UpdateIsWaitingForPurchaseToBeValidatedAction(true));
                    //         this._store.dispatch(UpdateIsPurchasingAction(true));
                    //         // ssrd.updateIsPurchasing(true);

                    //         // Be notified whenever changes occur, in the main listening method for purchases, if it's the same ID and has been purchased successfully, close this dialog.
                    //         // Otherwise, show the error.

                    //         ANALYTICS_logEvent(this._store, 'Product Purchased From Paywall', {
                    //         "productName": productDetails.title
                    //             .replaceAll(" (webbi.ads.searchtermanalyzer (unreviewed))", "")
                    //             .replaceAll("(Search Terms Manager)", ""),
                    //         });
                    //         ANALYTICS_logPurchase(this._store, productDetails);

                    //         await purchaseProduct(productDetails);
                    //     },
                    //     ),
                    // ),
                    // StoreConnector<AppState, ProductDetails>(
                    //     converter: (store) => store.state.iapProducts
                    //     .where((f) => f.id == SKU_MONTHLY_SUBSCRIPTION)
                    //     .toList()[0],
                    //     builder: (context, productDetails) => GestureDetector(
                    //     onTap: () async {

                    //         ANALYTICS_logEvent(this._store, 'Product Purchased From Paywall', {
                    //         "productName": productDetails.title
                    //             .replaceAll(" (webbi.ads.searchtermanalyzer (unreviewed))", "")
                    //             .replaceAll("(Search Terms Manager)", ""),
                    //         });
                    //         ANALYTICS_logPurchase(this._store, productDetails);

                    //         this.setState(() {
                    //         // this._isPurchasing = true;
                    //         });
                    //         this._store.dispatch(UpdateIsWaitingForPurchaseToBeValidatedAction(true));
                    //         this._store.dispatch(UpdateIsPurchasingAction(true));
                    //         await purchaseProduct(productDetails);
                    //     },
                    //     child: Container(
                    //         margin: EdgeInsets.only(top: 25, bottom: 25),
                    //         padding: EdgeInsets.fromLTRB(50, 10.5, 50, 10.5),
                    //         decoration: BoxDecoration(
                    //         borderRadius: BorderRadius.circular(6),
                    //         border: Border.all(
                    //             color: Color.fromRGBO(52, 168, 83, 1),//Color.fromRGBO(0,0,0, 1.0),
                    //             width: 1.0,
                    //         ),
                    //         ),
                    //         child: Column(
                    //         crossAxisAlignment: CrossAxisAlignment.center,
                    //         mainAxisAlignment: MainAxisAlignment.center,
                    //         children: [
                    //             Text(
                    //             "${productDetails.price.toString()} / month",
                    //             style: TextStyle(
                    //                 fontSize: 16,
                    //                 // color: Colors.white,
                    //                 color: Color.fromRGBO(52, 168, 83, 1),
                    //                 fontWeight: FontWeight.w600,
                    //             ),
                    //             ),
                    //             SizedBox(height:2),
                    //             (_introductoryDetails == null
                    //             || _introductoryDetails.introductoryPrice == ""
                    //             || _introductoryDetails.introductoryPriceCycles == 0)
                    //                 ? SizedBox.shrink()
                    //                 : Row(
                    //                 mainAxisAlignment: MainAxisAlignment.center,
                    //                 mainAxisSize: MainAxisSize.min,
                    //                 children: [
                    //                     Text(
                    //                     "${_introductoryDetails.introductoryPrice} for the first ${_introductoryDetails.introductoryPriceCycles} months!",
                    //                     style: TextStyle(
                    //                         fontSize: 11,
                    //                         color: Color.fromRGBO(52, 168, 83, .95),
                    //                     ),
                    //                     ),
                    //                 ],
                    //                 ),
                    //         ],
                    //         ),
                    //     )
                    //     ),
                    // ),
                    ],
                ),
                ],
            ),
        );
    }

}