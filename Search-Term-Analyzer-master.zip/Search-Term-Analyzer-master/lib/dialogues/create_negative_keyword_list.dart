import 'package:flutter/material.dart';

class CreateNegativeKeywordList extends StatefulWidget {
  String name = "";

  CreateNegativeKeywordList({String name}) {
    this.name = name;
  }

  @override
  _CreateNegativeKeywordListState createState() =>
      _CreateNegativeKeywordListState(name);
}

class _CreateNegativeKeywordListState extends State<CreateNegativeKeywordList> {
  _CreateNegativeKeywordListState(this._initialName);

  final String _initialName;
  TextEditingController _textController;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController(text: this._initialName);
    _textController.addListener(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      elevation: 1,
      backgroundColor: Colors.transparent,
      child: _contentBox(context),
    );
  }

  Widget _contentBox(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
      ),
      padding: EdgeInsets.all(15),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Create negative keyword list",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w400,
              )),
          SizedBox(
            height: 20,
          ),
          TextField(
            decoration: InputDecoration(hintText: "Negative keyword list"),
            controller: this._textController,
            onChanged: (val) {},
          ),
          SizedBox(height: 20),
          Align(
            alignment: Alignment.bottomRight,
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop(this._initialName);
                  },
                  child: Container(
                    padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                    margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: Color.fromRGBO(155, 155, 155, .25),
                      ),
                    ),
                    child: Text(
                      "Cancel",
                      style: TextStyle(fontSize: 18, color: Colors.black87),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context, this._textController.text);
                  },
                  child: Container(
                    padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                    margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      "Ok",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
