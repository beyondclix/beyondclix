import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class OptionsFilterDialog extends StatefulWidget {
    final String id;
    final String name;
    final String type;
    final String value;
    final String valueType;
    final String stringFilterType;
    String metricType;
    String displayName = "";

    OptionsFilterDialog(this.name, this.type, this.value, {this.valueType, this.stringFilterType, this.id = ''});

    @override
    _OptionsFilterDialogState createState() => _OptionsFilterDialogState();
}

class _OptionsFilterDialogState extends State<OptionsFilterDialog> {
    String dropdownValue;

    @override
    void initState() {
        super.initState();
        this.dropdownValue = widget.value != "" ? getNewDropdownValue(widget.value) : "None";
    }

    Widget build(BuildContext context) {
        return Dialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
            elevation: 0,
            backgroundColor: Colors.transparent,
            child: _contentBox(context),
        );
    }

    String getNewDropdownValue(String value) {
        if (value == "NONE") {
            return "None";
        } else if (value == "ADDED") {
            return "Added";
        } else if (value == "EXCLUDED") {
            return "Excluded";
        } else if (value == "ADDED_EXCLUDED") {
            return "Added / Excluded";
        }
    }

    String convertDropdownValue(String dropdownValue) {
        // Enum in API search_term_view is uppercase.
        if (dropdownValue == 'Added / Excluded') {
            dropdownValue = 'ADDED_EXCLUDED';
        }
        return dropdownValue.toUpperCase();

    }

    Widget _contentBox(BuildContext context) {
        return GestureDetector(
            onTap: () {
                FocusScopeNode currentFocus = FocusScope.of(context);
                if (!currentFocus.hasPrimaryFocus) {
                    currentFocus.unfocus();
                }
            },
            child: Container(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                color: Colors.white,
                borderRadius: BorderRadius.circular(6),
                ),
                child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                    SizedBox(height: 22),
                    Text(widget.name,
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    SizedBox(height: 22),
                    Padding(
                        padding: EdgeInsets.only(left: 14.0, right: 14),
                        child: DropdownButton<String>(
                            value: dropdownValue,
                            isExpanded: false,
                            icon: const Icon(Icons.arrow_downward),
                            iconEnabledColor: Colors.blue,
                            iconDisabledColor: Colors.lightBlue,
                            iconSize: 16,
                            elevation: 16,
                            style: TextStyle(color: Colors.blueAccent),
                            underline: Container(height: 2, color: Colors.blue),
                            onChanged: (newFilterValue) {
                                this.setState(() {

                                    dropdownValue = newFilterValue.toString();

                                });
                            },
                            items: <String>[
                            "Added",
                            "Excluded",
                            "Added / Excluded",
                            "None",
                            ].map<DropdownMenuItem<String>>((String filterType) {
                            return DropdownMenuItem<String>(
                                value: filterType,
                                child: Text(filterType,
                                    style: TextStyle(
                                        fontSize: 18)),
                            );
                            }).toList(),
                        ),
                    ),
                    SizedBox(height: 25),
                    Align(
                    alignment: Alignment.bottomRight,
                    child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                        GestureDetector(
                            onTap: () {
                            Navigator.of(context).pop();
                            },
                            child: Container(
                            padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                            margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                            decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                color: Color.fromRGBO(155, 155, 155, .25),
                                ),
                            ),
                            child: Text(
                                "Cancel",
                                style: TextStyle(fontSize: 18, color: Colors.black87),
                            ),
                            ),
                        ),
                        StoreConnector<AppState, Store<AppState>>(
                            converter: (store) => store,
                            builder: (context, store) => GestureDetector(
                            onTap: () {
                                ANALYTICS_logEvent(store, 'Filter created', {
                                "name": widget.name,
                                "displayName": widget.displayName.isNotEmpty
                                        ? widget.displayName
                                        : widget.name,
                                });

                                FilterValue fv = FilterValue(
                                    widget.name, ":", 
                                    convertDropdownValue(this.dropdownValue),
                                    displayName: widget.displayName.isNotEmpty
                                        ? widget.displayName
                                        : widget.name,
                                    valueType: widget.valueType,
                                    stringFilterType: widget.stringFilterType,
                                    metricType: null,
                                    id: widget.id);
                                
                                Navigator.of(context).pop(fv);
                            },
                            child: Container(
                                padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                                margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                                decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                "Apply",
                                style: TextStyle(fontSize: 18, color: Colors.white),
                                ),
                            ),
                            ),
                        ),
                        ],
                    ),
                    ),
                ],
                ),
            ),
        );
    }
}