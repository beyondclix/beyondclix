import 'dart:math';

import 'package:enum_to_string/enum_to_string.dart';
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/create_negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/final_url.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/max_cpc_dialog.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list_to_save.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class AddSearchTermToKeywordDialog extends StatefulWidget {
  final Store<AppState> store;
  final String id;
  final String title;
  final String searchTermText;
  final String campaignName;
  final String campaignResourceName;
  final String adGroupId;
  final String adGroupName;
  final String adGroupResourceName;
  final String searchTermResourceName;
  final String matchType;
  final String finalUrls;
  final double maxCpc;
  final bool isNegative;
  final String confirmationButtonText;
  final bool dontShowCancel;
  final String negativeKeywordListName;
  final String negativeKeywordListResourceName;
  final String negativeKeywordSaveType;

  AddSearchTermToKeywordDialog(
      this.store,
      this.id,
      this.searchTermText,
      this.searchTermResourceName,
      this.title,
      this.confirmationButtonText,
      this.campaignName,
      this.campaignResourceName,
      this.adGroupName,
      this.adGroupResourceName,
      {this.negativeKeywordListName,
      this.negativeKeywordListResourceName,
      this.negativeKeywordSaveType,
      this.matchType,
      this.finalUrls,
      this.maxCpc,
      this.isNegative,
      this.adGroupId,
      this.dontShowCancel});

  @override
  _AddSearchTermToKeywordDialogState createState() =>
      _AddSearchTermToKeywordDialogState(this.negativeKeywordListName,
          this.negativeKeywordListResourceName, this.negativeKeywordSaveType,
          matchType: this.matchType,
          finalUrls: this.finalUrls,
          maxCpc: this.maxCpc,
          isNegative: this.isNegative,
          // adGroupId: this.adGroupId,
          dontShowCancel: this.dontShowCancel);
}

class _AddSearchTermToKeywordDialogState
    extends State<AddSearchTermToKeywordDialog> {
  final bool dontShowCancel;
  bool isNegative = false;
  String campaignId;
  String _campaignName;
  String _campaignResourceId;
  String _adGroupResourceId;
  String adGroupId;
  String _adGroupName;
  int currentCampaignIndex = 0;
  int currentAdGroupIndex = 0;
  int currentNegativeKeywordListIndex = -1;
  TextEditingController _searchTermTextController;
  FocusNode searchTermTextFocusNode;
  bool isEditingTitle = false;
  String searchTermSaveText;
  String negativeKeywordSaveTypeRadio;
  bool _showingNegativeKeywordLists;
  bool _usingNewNegativeKeywordList;
  String _negativeKeywordListName; // When selecting from existing
  String _newNegativeKeywordListName; // Only to store the new value.
  String _negativeKeywordListResourceName;

  // AdGroup _adGroup;
  String matchType = EnumToString.convertToString(KEYWORD_MATCH_TYPE.BROAD);
  String finalUrls;
  double maxCpc;

  bool _isReloading = false;

  Future<List<NegativeKeywordList>> _negativeKeywordLists;

  _AddSearchTermToKeywordDialogState(
      /*this.adGroupId, */
      negativeKeywordListName,
      negativeKeywordResourceName,
      negativeKeywordSaveType,
      {this.isNegative,
      this.matchType,
      this.finalUrls,
      this.maxCpc,
      this.dontShowCancel}) {
    this._showingNegativeKeywordLists =
        negativeKeywordSaveType == "Negative keyword list";
    print("negativeKeywordSaveType: " + negativeKeywordSaveType.toString());
    this.negativeKeywordSaveTypeRadio = negativeKeywordSaveType ?? "Ad group";
    this._negativeKeywordListName = negativeKeywordListName ?? "";
    this._negativeKeywordListResourceName = negativeKeywordResourceName ?? "";
    this._usingNewNegativeKeywordList = (negativeKeywordResourceName != null &&
        negativeKeywordResourceName.length == 0);
    if (this._usingNewNegativeKeywordList) {
      // If this is showing, then the negativeKeyword can be assumed to be the new one.
      this._newNegativeKeywordListName = negativeKeywordListName ?? "";
    }
  }

  @override
  void initState() {
    super.initState();
    _searchTermTextController = TextEditingController.fromValue(
      TextEditingValue(text: widget.searchTermText),
    );
    searchTermSaveText = widget.searchTermText;
    _searchTermTextController.addListener(_searchTermTextUpdated);

    this.setState(() {
      this._negativeKeywordLists = _loadNegativeKeywordLists(
          widget.store,
          widget.store.state,
          widget.store.state.currentCustomer.id,
          widget.store.state.currentManager.id,
          false);
    });
    //.then((nkls) {
    // this.setState(() {
    //   this._negativeKeywordLists = nkls;
    // });
    // });
  }
  // Editing this.
  // _AddSearchTermToKeywordDialogState.fromData(
  //     bool isNegative, String adGroupId, String matchType) {
  //   this.isNegative = isNegative;
  //   this.adGroupId = adGroupId;
  //   this.matchType = matchType;
  // }

  @override
  void dispose() {
    _searchTermTextController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: _contentBox(context),
    );
  }

  _searchTermTextUpdated() {
    // print('Search Term text updated: ${_searchTermTextController.text}');
  }

  Future<List<Campaign>> _loadCampaigns() async {
    List<Campaign> campaigns = (await getLocalObjects('CAMPAIGNS'))
        .map((map) => Campaign.map2Campaign(map, widget.store))
        .toList();
    campaigns.sort((Campaign a, Campaign b) {
      return a.name.compareTo(b.name);
    });

    if (this.campaignId != null) {
      this.currentCampaignIndex =
          campaigns.indexWhere((element) => element.id == this.campaignId);
      Campaign initialCampaign = campaigns[this.currentCampaignIndex];
      this._campaignName = initialCampaign.name;
      this._campaignResourceId = initialCampaign.resourceName;
    }
    return campaigns;
  }

  // Loads all AdGroups
  Future<List<AdGroup>> _loadAdGroups() async {
    List<AdGroup> adGroups = (await getLocalObjects('ADGROUPS'))
        .map((map) => AdGroup.map2AdGroup(map, widget.store))
        .toList();
    adGroups.sort((AdGroup a, AdGroup b) {
      return a.name.compareTo(b.name);
    });
    // this.setState(() {
    //   this._adGroup = adGroups.elementAt(0);
    // });
    // adGroups.map((e) => e.name);
    print('Displaying local adgroups: ' + adGroups.length.toString());

    // adgroupId exists for editing
    if (this.adGroupId != null) {
      this.currentAdGroupIndex =
          adGroups.indexWhere((element) => element.id == this.adGroupId);
      AdGroup initialAdGroup = adGroups[this.currentAdGroupIndex];
      this._adGroupName = initialAdGroup.name;
      this._adGroupResourceId = initialAdGroup.resourceName;
    }
    return adGroups;
  }

  Future<List<NegativeKeywordList>> _loadNegativeKeywordLists(
      Store<AppState> store,
      AppState state,
      String customerId,
      String managerId,
      bool isReloading) async {
    print("RUNNING _loadNegativeKeywordLists");

    List<NegativeKeywordList> negativeKeywordLists =
        await NegativeKeywordList.fromMaps(store, customerId, managerId,
            onlyAPI: isReloading); // If reloading, force API call.
    // If temporary negative keyword lists exist, add them.
    // print("negativeKeywordLists: $negativeKeywordLists");
    print("negativeKeywordListsToSave: ${state.negativeKeywordListsToSave}");
    negativeKeywordLists
      ..addAll(state.negativeKeywordListsToSave
          .map((e) => e.toNegativeKeywordList()));

    if (currentNegativeKeywordListIndex == -1) {
      print("widget.negativeKeywordListName: " +
          widget.negativeKeywordListName.toString());
      this.setState(() {
        this.currentNegativeKeywordListIndex = max(
            0,
            negativeKeywordLists
                .indexWhere((el) => el.name == widget.negativeKeywordListName));
      });
    }
    if (this._negativeKeywordListResourceName == "") {
      if (negativeKeywordLists.length > 0) {
        this.setState(() {
          this._negativeKeywordListResourceName =
              negativeKeywordLists[this.currentNegativeKeywordListIndex]
                  .resourceName;
          this._negativeKeywordListName =
              negativeKeywordLists[this.currentNegativeKeywordListIndex].name;
        });
      }
    }
    if (this._isReloading) {
      this.setState(() {
        this._isReloading = false;
      });
    }
    // print("negativeKeywordLists: $negativeKeywordLists");
    return negativeKeywordLists;
  }

  _searchTermTextInput() {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: !this.isEditingTitle
                ? Text(_searchTermTextController.text,
                    //widget.searchTermText,
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.black,
                        fontWeight: FontWeight.w600))
                : // : Flexible(
                //     // fit: FlexFit.tight,
                //     // width: double.infinity,
                //     child:
                TextField(
                    focusNode: searchTermTextFocusNode,
                    onSubmitted: (value) {},
                    controller: _searchTermTextController,
                    autocorrect: false,
                    autofocus: false,
                    maxLines: null,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      // labelText: "",
                      // labelStyle: TextStyle(
                      //   fontWeight: FontWeight.bold,
                      //   fontSize: 18,
                      //   color: Color.fromRGBO(25, 25, 25, .95),
                      // ),
                    ),
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      // color: Color.fromRGBO(25, 25, 25, .95),
                      decoration: TextDecoration.underline,
                      decorationStyle: TextDecorationStyle.dashed,
                    ),
                  ),
            // ),
          ),
          !this.isEditingTitle
              ? GestureDetector(
                  onTap: () {
                    ANALYTICS_logEvent(
                        widget.store, 'Editing Search Term Text');
                    this.setState(() {
                      this.isEditingTitle = !this.isEditingTitle;
                    });
                  },
                  child: Container(
                      padding: EdgeInsets.fromLTRB(5, 0, 5, 5),
                      margin: EdgeInsets.only(right: 5),
                      child: Icon(
                        Icons.edit,
                        color: Color.fromRGBO(100, 100, 100, .75),
                      )),
                )
              : Row(children: [
                  GestureDetector(
                    onTap: () {
                      // Set to last saved text.
                      this.setState(() {
                        this.isEditingTitle = !this.isEditingTitle;
                        _searchTermTextController.text =
                            this.searchTermSaveText;
                      });
                    },
                    child: Container(
                      padding: EdgeInsets.fromLTRB(5, 0, 5, 5),
                      margin: EdgeInsets.only(right: 5),
                      child: Icon(
                        Icons.close,
                        size: 32,
                        color: Color.fromRGBO(100, 100, 100, .75),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Update save text.
                      this.setState(() {
                        this.isEditingTitle = !this.isEditingTitle;
                        searchTermSaveText = _searchTermTextController.text;
                      });
                    },
                    child: Container(
                      padding: EdgeInsets.fromLTRB(5, 0, 5, 5),
                      margin: EdgeInsets.only(right: 5),
                      child: Icon(
                        Icons.check,
                        size: 32,
                        color: Color.fromRGBO(100, 205, 100, .75),
                      ),
                    ),
                  ),
                ]),
        ]);
    //);
  }

  Widget _negativeKeywordListDropdown() {
    return Column(children: [
      StoreConnector<AppState, Store<AppState>>(
        converter: (store) => store,
        builder: (context, store) => FutureBuilder(
          future: _negativeKeywordLists,
          builder: (BuildContext context,
              AsyncSnapshot<List<NegativeKeywordList>> snapshot) {
            if (snapshot.hasData && _isReloading == false) {
              if (snapshot.data.length == 0) {
                return SizedBox(height: 30);
              }
              return DropdownButton<NegativeKeywordList>(
                  isExpanded: true,
                  value:
                      //this._negativeKeywordList ?? snapshot.data.elementAt(0),
                      snapshot.data.elementAt(currentNegativeKeywordListIndex),
                  icon: const Icon(Icons.arrow_downward),
                  iconEnabledColor: Colors.blue,
                  iconDisabledColor: Colors.lightBlue,
                  iconSize: 16,
                  elevation: 16,
                  style: TextStyle(color: Colors.blueAccent),
                  underline: Container(height: 2, color: Colors.blue),
                  onChanged: (NegativeKeywordList negativeKeywordList) {
                    print("negativeKeywordList: " +
                        negativeKeywordList.toString());
                    this.setState(() {
                      this._negativeKeywordListName = negativeKeywordList.name;
                      this._negativeKeywordListResourceName =
                          negativeKeywordList.resourceName;
                      this.currentNegativeKeywordListIndex =
                          snapshot.data.indexOf(negativeKeywordList);
                    });
                  },
                  items: snapshot.data
                      .map<DropdownMenuItem<NegativeKeywordList>>(
                          (NegativeKeywordList negativeKeywordList) {
                    return DropdownMenuItem<NegativeKeywordList>(
                      value: negativeKeywordList,
                      child: Text(negativeKeywordList.name),
                    );
                  }).toList());
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          },
        ),
      ),
    ]);
  }

  _keywordTypeActions() {
    return !this.isNegative
        ? Row(mainAxisAlignment: MainAxisAlignment.start, children: [
            Flexible(
              fit: FlexFit.loose,
              child: GestureDetector(
                onTap: () {
                  ANALYTICS_logEvent(widget.store, 'Adding or Editing Final URL');
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return FinalUrlDialog(this.finalUrls);
                    },
                  ).then(
                    (newFinalUrls) => this.setState(() {
                      if (newFinalUrls != null) {
                        this.finalUrls = newFinalUrls;
                      }
                    }),
                  );
                },
                child: Container(
                    padding: EdgeInsets.fromLTRB(12, 6, 12, 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                      border:
                          Border.all(color: Color.fromRGBO(155, 155, 155, .25)),
                      // color:
                      //     Color.fromRGBO(155, 155, 155, .15),
                    ),
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Final URL",
                              style:
                                  TextStyle(color: Colors.black, fontSize: 12)),
                          (this.finalUrls != null && this.finalUrls.length > 0)
                              ? Text(
                                  this.finalUrls,
                                  style: TextStyle(color: Colors.blue),
                                  overflow: TextOverflow.ellipsis,
                                )
                              : Container(),
                        ])
                    // child: Text(
                    //   "Final URL",
                    //   style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    // ),
                    ),
              ),
            ),
            Flexible(
              fit: FlexFit.loose,
              child: GestureDetector(
                onTap: () {
                  ANALYTICS_logEvent(widget.store, 'Adding or Editing Max CPC');
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      double m = this.maxCpc;
                      if (m != null) {
                        // m = m * 1000000;
                      } else {
                        m = null;
                      }
                      return MaxCpcDialog(m);
                    },
                  ).then((newMaxCpc) => this.setState(() {
                        if (newMaxCpc != null) {
                          print("Got newMaxCpc: $newMaxCpc");
                          // Convert back to micros.
                          this.maxCpc =
                              newMaxCpc; //(newMaxCpc / 1000000).toInt();
                        }
                      }));
                },
                child: Container(
                    padding: EdgeInsets.fromLTRB(12, 6, 12, 6),
                    margin: EdgeInsets.only(left: 15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                      border:
                          Border.all(color: Color.fromRGBO(155, 155, 155, .25)),
                    ),
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Max CPC",
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w400),
                          ),
                          (this.maxCpc != null)
                              ? Text(
                                  this
                                      .maxCpc
                                      .toString(), // (this.maxCpc * 1000000).toString(),
                                  style: TextStyle(color: Colors.blue),
                                  overflow: TextOverflow.ellipsis,
                                )
                              : Container()
                        ])),
              ),
            ),
          ])
        : Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                _radioButton("Ad group"),
                _radioButton("Campaign"),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        _radioButton("Negative keyword list"),
                        _showingNegativeKeywordLists
                            ? StoreConnector<AppState, Store<AppState>>(
                                converter: (store) => store,
                                builder: (context, store) => GestureDetector(
                                  child: Container(
                                    margin:
                                        EdgeInsets.only(left: 7.5, bottom: 10),
                                    child:
                                        Icon(Icons.refresh, color: Colors.blue),
                                  ),
                                  onTap: () async {
                                    ANALYTICS_logEvent(widget.store,
                                        'Displaying Negative Keyword Lists');
                                    // Delete all existing negative keyword lists for managerId
                                    // This triggers a reload from API.
                                    await NegativeKeywordList
                                            .resetForCustomerClient(
                                                store.state.currentManager.id)
                                        .then((_) {
                                      this.setState(() {
                                        // Trigger a reload.
                                        this._isReloading = true;
                                        this._negativeKeywordLists =
                                            _loadNegativeKeywordLists(
                                                store,
                                                store.state,
                                                store.state.currentCustomer.id,
                                                store.state.currentManager.id,
                                                true);
                                      });
                                    });
                                  },
                                ),
                              )
                            : SizedBox.shrink(),
                      ],
                    ),
                    _showingNegativeKeywordLists
                        ? StoreConnector<AppState, Store<AppState>>(
                            converter: (store) => store,
                            builder: (context, store) => GestureDetector(
                              onTap: () {
                                if (this._usingNewNegativeKeywordList) {
                                  this.setState(() {
                                    // this._newNegativeKeywordListName = "";
                                    this._negativeKeywordListResourceName = "";
                                    this._usingNewNegativeKeywordList = false;
                                  });
                                } else {
                                  ANALYTICS_logEvent(widget.store,
                                      'Creating New Negative Keyword List');
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return CreateNegativeKeywordList(
                                          name:
                                              this._newNegativeKeywordListName);
                                    },
                                  ).then(
                                    (newNegativeKeywordListName) =>
                                        this.setState(() {
                                      this._usingNewNegativeKeywordList = true;
                                      if (newNegativeKeywordListName.length >
                                          0) {
                                        this._newNegativeKeywordListName =
                                            newNegativeKeywordListName;
                                      }
                                      this._negativeKeywordListResourceName =
                                          "";
                                    }),
                                  );
                                }
                              },
                              child: Container(
                                padding: EdgeInsets.fromLTRB(8, 6, 8, 6),
                                margin: EdgeInsets.only(left: 20),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4)),
                                  border: Border.all(color: Colors.blue),
                                  color: Colors.blue,
                                ),
                                child: Row(children: [
                                  Text(
                                      this._usingNewNegativeKeywordList
                                          ? "Add to existing"
                                          : "Use new list ",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w400)),
                                  this._usingNewNegativeKeywordList
                                      ? Container()
                                      : Icon(Icons.add,
                                          size: 16, color: Colors.white),
                                ]),
                              ),
                            ),
                          )
                        : Container(),
                  ],
                ),
                _showingNegativeKeywordLists
                    ? this._usingNewNegativeKeywordList
                        ? GestureDetector(
                            onTap: () {
                              ANALYTICS_logEvent(widget.store,
                                  'Creating Negative Keyword List');
                              showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return CreateNegativeKeywordList(
                                      name: this._newNegativeKeywordListName);
                                },
                              ).then(
                                (newNegativeKeywordListName) =>
                                    this.setState(() {
                                  this._newNegativeKeywordListName =
                                      newNegativeKeywordListName;
                                }),
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.fromLTRB(5, 15, 5, 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(this._newNegativeKeywordListName ?? "",
                                      style: TextStyle(fontSize: 16.5)),
                                  Container(
                                      margin: EdgeInsets.only(left: 8),
                                      child: Icon(Icons.edit,
                                          size: 15, color: Colors.black54)),
                                ],
                              ),
                            ),
                          )
                        : _negativeKeywordListDropdown()
                    : Container()
              ]);
  }

  _radioButton(String buttonText) {
    return GestureDetector(
      onTap: () {
        ANALYTICS_logEvent(
            widget.store, 'Selected Negative Keyword List button');
        this.setState(() {
          this.negativeKeywordSaveTypeRadio = buttonText;

          if (buttonText == "Negative keyword list") {
            this._showingNegativeKeywordLists = true;
          } else if (this._showingNegativeKeywordLists == true) {
            this._showingNegativeKeywordLists = false;
          }
        });
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(8, 6, 8, 6),
        margin: EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(4)),
          border: Border.all(
            color: Color.fromRGBO(155, 155, 155, .25),
          ),
          color: this.negativeKeywordSaveTypeRadio == buttonText
              ? Colors.blue
              : Colors.transparent,
        ),
        child: Text(
          buttonText,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: this.negativeKeywordSaveTypeRadio == buttonText
                ? Colors.white
                : Colors.black,
          ),
        ),
      ),
    );
  }

  _contentBox(context) {
    return GestureDetector(
        onTap: () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          if (!currentFocus.hasPrimaryFocus) {
            currentFocus.unfocus();
            this.setState(() {
              this.isEditingTitle = false;
            });
          }
        },
        child: StoreConnector<AppState, AppState>(
            converter: (store) => store.state,
            builder: (context, state) => Stack(children: [
                  Container(
                      child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                        // padding:
                        //     EdgeInsets.only(left: 10, top: 15, right: 10, bottom: 4),
                        // margin: EdgeInsets.only(top: 6),
                        decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black,
                                  offset: Offset(0, 10),
                                  blurRadius: 10),
                            ]),
                        child:
                            Column(mainAxisSize: MainAxisSize.min, children: [
                          Container(
                            padding: EdgeInsets.only(
                                left: 10, top: 6, right: 10, bottom: 6),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              shape: BoxShape.rectangle,
                              // border: Border.all(
                              //   color: Colors.blue,
                              //   style: BorderStyle.solid,
                              //   width: 10,
                              // ),
                              // borderRadius: BorderRadius.only(
                              //   topLeft: Radius.circular(6),
                              //   topRight: Radius.circular(6),
                              // ),
                            ),
                            child: Text(
                              widget.title,
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white.withAlpha(225)),
                            ),
                          ),
                          Container(
                            // height: MediaQuery.of(context).size.height * .8,
                            padding: EdgeInsets.only(
                                left: 10, top: 10, right: 10, bottom: 15),
                            child: SingleChildScrollView(
                                child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                  height: 15,
                                ),
                                _searchTermTextController.text !=
                                        widget.searchTermText
                                    ? Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("Original",
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 12)),
                                          Text(widget.searchTermText,
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 15)),
                                        ],
                                      )
                                    : Container(),
                                _searchTermTextInput(),
                                // SizedBox(
                                //   height: 15,
                                // ),
                                // Text(
                                //   "Modify this Search Term",
                                //   style: TextStyle(fontSize: 14),
                                //   textAlign: TextAlign.center,
                                // ),
                                SizedBox(
                                  height: 22,
                                ),
                                Text("Campaign",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12)),
                                !this.isNegative || true
                                    ? Text(widget.campaignName,
                                        style: TextStyle(color: Colors.blue))
                                    : FutureBuilder(
                                        future: _loadCampaigns(),
                                        builder: (BuildContext context,
                                            AsyncSnapshot<List<Campaign>>
                                                snapshot) {
                                          if (snapshot.hasData) {
                                            // print("CAMPAIGN ID: " +
                                            //     this.campaignId.toString() +
                                            //     ", : " +
                                            //     widget.campaignName);
                                            if (this.campaignId == null) {
                                              this.currentCampaignIndex =
                                                  snapshot.data.indexWhere(
                                                      (element) =>
                                                          element.name ==
                                                          widget.campaignName);
                                              Campaign initialCampaign =
                                                  snapshot.data[this
                                                      .currentCampaignIndex];
                                              this.campaignId =
                                                  initialCampaign.id;
                                              this._campaignName =
                                                  initialCampaign.name;
                                              this._campaignResourceId =
                                                  initialCampaign.resourceName;
                                            }
                                            return DropdownButton<Campaign>(
                                                isExpanded: true,
                                                value: snapshot.data.elementAt(
                                                    this.currentCampaignIndex),
                                                icon: const Icon(
                                                    Icons.arrow_downward),
                                                iconEnabledColor: Colors.blue,
                                                iconDisabledColor:
                                                    Colors.lightBlue,
                                                iconSize: 16,
                                                elevation: 16,
                                                style: TextStyle(
                                                    color: Colors.blueAccent),
                                                underline: Container(
                                                    height: 2,
                                                    color: Colors.blue),
                                                onChanged: (Campaign campaign) {
                                                  this.setState(() {
                                                    this.campaignId =
                                                        campaign.id;
                                                    this._campaignResourceId =
                                                        campaign.resourceName;
                                                    this._campaignName =
                                                        campaign.name;
                                                    this.currentCampaignIndex =
                                                        snapshot.data
                                                            .indexOf(campaign);
                                                  });
                                                },
                                                items: snapshot.data.map<
                                                        DropdownMenuItem<
                                                            Campaign>>(
                                                    (Campaign campaign) {
                                                  return DropdownMenuItem<
                                                      Campaign>(
                                                    value: campaign,
                                                    child: Text(campaign.name),
                                                  );
                                                }).toList());
                                          } else {
                                            return Center(
                                              child:
                                                  CircularProgressIndicator(),
                                            );
                                          }
                                        }),
                                SizedBox(
                                  height: 22,
                                ),
                                Text("Adgroup",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12)),
                                Text(widget.adGroupName,
                                    style: TextStyle(color: Colors.blue)),
                                // Loop through all adgroups and display them in a dropdown.
                                // FutureBuilder(
                                //     future: _loadAdGroups(),
                                //     builder: (BuildContext context,
                                //         AsyncSnapshot<List<AdGroup>>
                                //             snapshot) {
                                //       if (snapshot.hasData) {
                                //         print("ADGROUP ID: " +
                                //             adGroupId.toString() +
                                //             ", : " +
                                //             widget.adGroupName);
                                //         if (this.adGroupId == null) {
                                //           // snapshot.data.elementAt(0);
                                //           this.currentAdGroupIndex = snapshot
                                //               .data
                                //               .indexWhere((element) =>
                                //                   element.name ==
                                //                   widget.adGroupName);
                                //           AdGroup initialAdGroup = snapshot
                                //               .data[this.currentAdGroupIndex];
                                //           this.adGroupId = initialAdGroup.id;
                                //           this._adGroupName =
                                //               initialAdGroup.name;
                                //           this._adGroupResourceId =
                                //               initialAdGroup.resourceName;
                                //         }
                                //         return DropdownButton<AdGroup>(
                                //             isExpanded: true,
                                //             value: snapshot.data.elementAt(
                                //                 this.currentAdGroupIndex),
                                //             icon: const Icon(
                                //                 Icons.arrow_downward),
                                //             iconEnabledColor: Colors.blue,
                                //             iconDisabledColor:
                                //                 Colors.lightBlue,
                                //             iconSize: 16,
                                //             elevation: 16,
                                //             style: TextStyle(
                                //                 color: Colors.blueAccent),
                                //             underline: Container(
                                //                 height: 2,
                                //                 color: Colors.blue),
                                //             onChanged: (AdGroup adGroup) {
                                //               this.setState(() {
                                //                 this.adGroupId = adGroup.id;
                                //                 this._adGroupResourceId =
                                //                     adGroup.resourceName;
                                //                 this._adGroupName =
                                //                     adGroup.name;
                                //                 this.currentAdGroupIndex =
                                //                     snapshot.data
                                //                         .indexOf(adGroup);
                                //                 // this._adGroup = adGroup;
                                //               });
                                //             },
                                //             items: snapshot.data.map<
                                //                     DropdownMenuItem<
                                //                         AdGroup>>(
                                //                 (AdGroup adGroup) {
                                //               return DropdownMenuItem<
                                //                   AdGroup>(
                                //                 value: adGroup,
                                //                 child: Text(adGroup.name),
                                //               );
                                //             }).toList());
                                //       } else {
                                //         return Center(
                                //           child: CircularProgressIndicator(),
                                //         );
                                //       }
                                //     }),
                                SizedBox(
                                  height: 22,
                                ),
                                Text("Match type",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12)),
                                DropdownButton<String>(
                                  value: this.matchType,
                                  icon: const Icon(Icons.arrow_downward),
                                  iconEnabledColor: Colors.blue,
                                  iconDisabledColor: Colors.lightBlue,
                                  iconSize: 16,
                                  elevation: 16,
                                  style: TextStyle(color: Colors.blueAccent),
                                  underline:
                                      Container(height: 2, color: Colors.blue),
                                  onChanged: (String newValue) {
                                    setState(() {
                                      matchType = newValue;
                                    });
                                  },
                                  items: EnumToString.toList(
                                          KEYWORD_MATCH_TYPE.values)
                                      .map<DropdownMenuItem<String>>(
                                          (String value) {
                                    return DropdownMenuItem<String>(
                                      child: Text(value),
                                      value: value,
                                    );
                                  }).toList(),
                                  hint: Text("Match type",
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500)),
                                ),
                                SizedBox(
                                  height: 22,
                                ),
                                Container(
                                  margin: EdgeInsets.only(bottom: 5),
                                  child: Text(
                                    this.isNegative
                                        ? "Add as negative keyword to:"
                                        : "Click below to set the:",
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.black),
                                  ),
                                ),
                                _keywordTypeActions(),
                                SizedBox(
                                  height: 22,
                                ),

                                // Text("Keyword type",
                                //     style: TextStyle(
                                //         color: Colors.black, fontSize: 12)),
                                // DropdownButton<String>(
                                //     value:
                                //         isNegative ? "Negative" : "Positive",
                                //     icon: const Icon(Icons.arrow_downward),
                                //     iconEnabledColor: Colors.blue,
                                //     iconDisabledColor: Colors.lightBlue,
                                //     iconSize: 16,
                                //     elevation: 16,
                                //     style:
                                //         TextStyle(color: Colors.blueAccent),
                                //     underline: Container(
                                //         height: 2, color: Colors.blue),
                                //     onChanged: (String newValue) {
                                //       this.setState(() {
                                //         this.isNegative =
                                //             newValue == "Negative";
                                //       });
                                //     },
                                //     items: <String>["Positive", "Negative"]
                                //         .map<DropdownMenuItem<String>>(
                                //             (String s) {
                                //       return DropdownMenuItem<String>(
                                //           value: s, child: Text(s));
                                //     }).toList()),
                                // SizedBox(
                                //   height: 22,
                                // ),
                                Align(
                                    alignment: Alignment.bottomRight,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        // GestureDetector(
                                        //     onTap: () {},
                                        //     child: Container(
                                        //         padding: EdgeInsets.fromLTRB(
                                        //             15, 8, 15, 8),
                                        //         decoration: BoxDecoration(
                                        //             borderRadius:
                                        //                 BorderRadius.all(
                                        //                     Radius.circular(
                                        //                         4)),
                                        //             border: Border.all(
                                        //                 color: Color.fromRGBO(
                                        //                     155,
                                        //                     155,
                                        //                     155,
                                        //                     .25))),
                                        //         child: Text(
                                        //           "Duplicate",
                                        //           style: TextStyle(
                                        //               fontSize: 15,
                                        //               fontWeight:
                                        //                   FontWeight.w400),
                                        //         ))),
                                        !this.dontShowCancel
                                            ? StoreConnector<AppState,
                                                Function()>(
                                                converter: (store) {
                                                  return () => store.dispatch(
                                                      RemoveChangeAction(
                                                          store.state,
                                                          "SearchTerm",
                                                          widget.id,
                                                          // widget
                                                          //     .searchTermResourceName,
                                                          this.isNegative));
                                                },
                                                builder: (context, callback) =>
                                                    GestureDetector(
                                                        onTap: () {
                                                          ANALYTICS_logEvent(
                                                              widget.store,
                                                              'Remove Search Term To Save Pressed');
                                                          // state.changes.removeWhere((element) =>
                                                          //     element.changeId ==
                                                          //     widget._searchTerm.resourceName);
                                                          Widget alertDialog =
                                                              AlertDialog(
                                                            title: Container(
                                                              margin: EdgeInsets
                                                                  .only(
                                                                      bottom:
                                                                          15),
                                                              child: Text(
                                                                  "Are you sure you want to remove this keyword?"),
                                                            ),
                                                            content: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                InkWell(
                                                                  onTap: () {
                                                                    ANALYTICS_logEvent(
                                                                        widget
                                                                            .store,
                                                                        'Remove Search Term To Save Cancelled');
                                                                    Navigator.of(
                                                                            context)
                                                                        .pop(
                                                                            false);
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    padding: EdgeInsets
                                                                        .fromLTRB(
                                                                            15,
                                                                            10,
                                                                            15,
                                                                            10),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      shape: BoxShape
                                                                          .rectangle,
                                                                      color: Colors
                                                                          .white,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              6),
                                                                      border:
                                                                          Border
                                                                              .all(
                                                                        color: Color.fromRGBO(
                                                                            155,
                                                                            155,
                                                                            155,
                                                                            .25),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      'Cancel', //'Let us know about this issue',
                                                                      style:
                                                                          TextStyle(
                                                                        color: Colors
                                                                            .black
                                                                            .withOpacity(.65),
                                                                        fontSize:
                                                                            16,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                InkWell(
                                                                  onTap: () {
                                                                    ANALYTICS_logEvent(
                                                                        widget
                                                                            .store,
                                                                        'Remove Search Term To Save Confirmed');
                                                                    callback();
                                                                    // Close this alert dialog.
                                                                    Navigator.of(
                                                                            context)
                                                                        .pop(
                                                                            true);
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    padding: EdgeInsets
                                                                        .fromLTRB(
                                                                            15,
                                                                            10,
                                                                            15,
                                                                            10),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .blue,
                                                                      borderRadius:
                                                                          BorderRadius.all(
                                                                              Radius.circular(6)),
                                                                    ),
                                                                    child: Text(
                                                                      'Ok', //'Let us know about this issue',
                                                                      style:
                                                                          TextStyle(
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            16,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                          showDialog(
                                                            context: context,
                                                            builder:
                                                                (BuildContext
                                                                    context) {
                                                              return alertDialog;
                                                            },
                                                          ).then((okPressed) {
                                                            print(
                                                                "okPressed: $okPressed");
                                                            if (okPressed ==
                                                                true) {
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            }
                                                          });
                                                        },
                                                        child: Container(
                                                            padding: EdgeInsets
                                                                .fromLTRB(15, 8,
                                                                    15, 8),
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .all(Radius
                                                                          .circular(
                                                                              4)),
                                                              border: Border.all(
                                                                  color: Color
                                                                      .fromRGBO(
                                                                          155,
                                                                          155,
                                                                          155,
                                                                          .25)),
                                                              // color:
                                                              //     Color.fromRGBO(155, 155, 155, .15),
                                                            ),
                                                            child: Text(
                                                              "Remove keyword",
                                                              style: TextStyle(
                                                                  fontSize: 15,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400),
                                                            ))),
                                              )
                                            : Container(),
                                        StoreConnector<
                                            AppState,
                                            Function(ChangeAction changeAction,
                                                bool isNegative)>(
                                          converter: (store) {
                                            return (changeAction, isNegative) => this
                                                    .dontShowCancel
                                                ? store.dispatch(AddChangeAction(
                                                    store,
                                                    store.state,
                                                    changeAction,
                                                    isNegative,
                                                    this
                                                        ._newNegativeKeywordListName))
                                                : store.dispatch(
                                                    ModifyChangeAction(
                                                        // store.state,
                                                        changeAction.changeId,
                                                        changeAction,
                                                        isNegative));
                                          },
                                          builder: (context, callback) =>
                                              StoreConnector<AppState,
                                                  AppState>(
                                            converter: (store) => store.state,
                                            builder: (context, state) =>
                                                ElevatedButton(
                                                    onPressed: () {
                                                      // If editing, id will come from existing, otherwise will be generated as new.
                                                      String id = widget.id;
                                                      if (widget.id == null) {
                                                        id = generateId();
                                                      }
                                                      // DateTime.now()
                                                      //     .millisecondsSinceEpoch
                                                      //     .toString();
                                                      // }
                                                      // print("new name: " +
                                                      //     this
                                                      //         .matchType
                                                      //         .toString());
                                                      // print(" name: " +
                                                      //     id.toString());
                                                      // return;

                                                      // Add to changes of what to save.
                                                      SearchTermSaveAction
                                                          searchTermSaveAction =
                                                          SearchTermSaveAction(
                                                              id,
                                                              state
                                                                  .currentCustomer
                                                                  .id,
                                                              state
                                                                  .currentManager
                                                                  .id,
                                                              this
                                                                  .negativeKeywordSaveTypeRadio,
                                                              this._usingNewNegativeKeywordList
                                                                  ? this
                                                                      ._newNegativeKeywordListName
                                                                  : this
                                                                      ._negativeKeywordListName,
                                                              this._usingNewNegativeKeywordList
                                                                  ? ""
                                                                  : this
                                                                      ._negativeKeywordListResourceName,
                                                              widget
                                                                  .searchTermResourceName,
                                                              widget
                                                                  .adGroupResourceName,
                                                              // this._adGroupResourceId,
                                                              this.isNegative,
                                                              matchType,
                                                              finalUrls,
                                                              maxCpc,
                                                              this
                                                                  ._searchTermTextController
                                                                  .text,
                                                              // widget
                                                              //     .searchTermText,
                                                              // this.adGroupId,
                                                              widget.adGroupId,
                                                              widget
                                                                  .adGroupName,
                                                              // this._adGroupName,
                                                              widget
                                                                  .campaignName,
                                                              widget
                                                                  .campaignResourceName,
                                                              DateTime.now());
                                                      ChangeAction
                                                          changeAction =
                                                          ChangeAction(
                                                              id,
                                                              "SearchTerm",
                                                              '',
                                                              '',
                                                              searchTermSaveAction);
                                                      callback(changeAction,
                                                          this.isNegative);
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                    child: Text(
                                                      widget
                                                          .confirmationButtonText,
                                                      style: TextStyle(
                                                          fontSize: 15,
                                                          fontWeight:
                                                              FontWeight.w400),
                                                    )),
                                          ),
                                        )
                                      ],
                                    )),
                              ],
                            )),
                          )
                        ])),
                  ))
                ])));
  }
}
