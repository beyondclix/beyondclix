import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/models/product_introductory_details.dart';
import 'package:searchTermAnalyzerFlutter/models/membership_type.dart';
import 'package:searchTermAnalyzerFlutter/widgets/gradient_icon.dart';

class PurchaseableProductsDialog extends StatelessWidget {
  final Store<AppState> store;

  PurchaseableProductsDialog(this.store);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      elevation: 0,
      insetPadding: EdgeInsets.all(0),
      backgroundColor:
          Color.fromRGBO(0, 0, 0, .65), //Colors.transparent, // white
      child: Stack(
        children: [
          // Overlay to detect all back clicks
          GestureDetector(
              onTap: () {
                Navigator.of(context).pop();
              },
              child: Container(
                color: Colors.transparent,
              )),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 40.0, vertical: 24.0),
            child: _contentBox(context),
          ),
          // Positioned(
          //   top: 5,
          //   right: 10,
          //   child: Icon(Icons.close, color: Colors.white.withOpacity(.75), size: 35),
          // ),
        ],
      ),
    );
  }

  Widget _introductoryPricingText(
      ProductIntroductoryDetails introductoryDetails) {
    if (introductoryDetails == null ||
        introductoryDetails.introductoryPrice == "" ||
        introductoryDetails.introductoryPriceCycles == 0) {
      return SizedBox.shrink();
    }
    return Row(children: [
      Text(
        "${introductoryDetails.introductoryPrice} for the first ${introductoryDetails.introductoryPriceCycles} months",
        style: TextStyle(
          fontSize: 13,
          color: Colors.white.withOpacity(.85),
        ),
      ),
      GradientIcon(
        Icons.local_fire_department,
        20.0,
        LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Colors.red, Colors.orange],
        ),
      ),
    ]);
  }

  Widget _product(
      BuildContext context, ProductDetails pd, List<PastPurchase> purchases) {
    bool isPurchased = false;

    MembershipType membershipType = MEMBERSHIP_TYPES[pd.id];

    ProductIntroductoryDetails introductoryDetails = getIntroductoryDetails(pd);

    return GestureDetector(
      onTap: () async {
        ANALYTICS_logEvent(store, 'Product Purchased', {
          "productName": pd.title
              .replaceAll(" (webbi.ads.searchtermanalyzer (unreviewed))", "")
              .replaceAll("(Search Terms Manager)", ""),
        });
        ANALYTICS_logPurchase(store, pd);

        await purchaseProduct(pd);
        Navigator.of(context).pop();
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 25, 15, 25),
        decoration: BoxDecoration(
          // color: membershipType.color,
          borderRadius: BorderRadius.all(Radius.circular(6)),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            // colors: [Colors.white.withOpacity(.0), membershipType.color],
            colors: [membershipType.colorDark, membershipType.color],
          ),
        ),
        margin: EdgeInsets.symmetric(vertical: 15),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(
                bottom: 5,
              ),
              child: membershipType.icon,
            ),
            SizedBox(height: 2.5),
            Text(
              pd.price.toString(),
              style: TextStyle(
                fontSize: 30,
                color: Colors.white,
                // color: Colors.blue,
                fontWeight: FontWeight.w600,
              ),
            ),
            _introductoryPricingText(introductoryDetails),
            SizedBox(height: 2.5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                      pd.title
                          .replaceAll(
                              " (webbi.ads.searchtermanalyzer (unreviewed))",
                              "")
                          .replaceAll("(Search Terms Manager)", ""),
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      )),
                ),
              ],
            ),
            Container(
              margin: EdgeInsets.only(top: 5),
              child: Text(
                pd.description,
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.white.withOpacity(.85),
                ),
              ),
            ),
            GestureDetector(
              child: Container(
                // width: 125,
                margin: EdgeInsets.only(top: 15),
                padding: EdgeInsets.fromLTRB(15, 5, 15, 5),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                ),
                child: Text("PURCHASE",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.black.withOpacity(.65),
                      fontSize: 16,
                      letterSpacing: .5,
                    )),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _contentBox(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus) {
          currentFocus.unfocus();
        }
      },
      child: StoreConnector<AppState, AppState>(
        converter: (store) => store.state,
        builder: (context, state) => Scrollbar(
          // isAlwaysShown: true,
          child: !state.isIAPAvailable
              ? Center(
                  child: Text("In-app purchases are not available"),
                )
              : Container(
                  height: MediaQuery.of(context).size.height * 1, //.95,
                  // padding: EdgeInsets.all(25),
                  child: ListView.builder(
                    // padding: EdgeInsets.all(15),
                    itemCount: state.iapProducts.length,
                    itemBuilder: (context, index) =>
                        state.iapProducts[index].id != SKU_SINGLE_SAVE
                            ? _product(
                                context,
                                state.iapProducts[index],
                                state.pastPurchases,
                              )
                            : SizedBox.shrink(),
                  ),
                ),
        ),
      ),
    );
  }
}
