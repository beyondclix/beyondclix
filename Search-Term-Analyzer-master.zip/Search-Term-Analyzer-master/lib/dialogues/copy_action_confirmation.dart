import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'dart:ui';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class CopyActionConfirmation extends StatefulWidget {
  final SearchTermSaveAction searchTermSaveAction;
  final bool isNegative;
  final int low;
  final int high;

  CopyActionConfirmation(
      this.searchTermSaveAction, this.isNegative, this.low, this.high);

  @override
  _CopyActionConfirmationState createState() => _CopyActionConfirmationState();
}

class _CopyActionConfirmationState extends State<CopyActionConfirmation> {
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: _contentBox(context),
    );
  }

  Widget _contentBox(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // print('Tapped outside of screen');
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus) {
          currentFocus.unfocus();
        }
      },
      child: StoreConnector<
          AppState,
          Function(SearchTermSaveAction searchTermSaveAction, bool isNegative,
              int low, int high)>(
        converter: (store) {
          return (searchTermSaveAction, isNegative, low, high) =>
              store.dispatch(ModifyChangeActionRangeAction(
                  store.state, searchTermSaveAction, isNegative, low, high));
        },
        builder: (context, changeActions) => Container(
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            color: Colors.white,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(15),
                child: Text(
                  "This will affect " +
                      (widget.high - widget.low - 1).toString() +
                      " keywords",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
                ),
              ),
              // SizedBox(
              //   height: 15,
              // ),
              // Text(
              //   widget.descriptions,
              //   style: TextStyle(fontSize: 14),
              //   textAlign: TextAlign.center,
              // ),
              SizedBox(
                height: 22,
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    StoreConnector<AppState, Store<AppState>>(
                      converter: (store) => store,
                      builder: (context, store) => GestureDetector(
                        onTap: () {
                          ANALYTICS_logEvent(store, 'Copy Action Cancelled');
                          Navigator.of(context).pop();
                        },
                        child: Container(
                          padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                          margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: Color.fromRGBO(155, 155, 155, .25),
                            ),
                          ),
                          child: Text(
                            "Cancel",
                            style:
                                TextStyle(fontSize: 18, color: Colors.black87),
                          ),
                        ),
                      ),
                    ),
                    StoreConnector<
                        AppState,
                        Function(SearchTermSaveAction searchTermSaveAction,
                            bool isNegative, int low, int high)>(
                      converter: (store) {
                        return (searchTermSaveAction, isNegative, low, high) =>
                            store.dispatch(ModifyChangeActionRangeAction(
                                store.state,
                                searchTermSaveAction,
                                isNegative,
                                low,
                                high));
                      },
                      builder: (context, callback) =>
                          StoreConnector<AppState, Store<AppState>>(
                        converter: (store) => store,
                        builder: (context, store) => GestureDetector(
                          onTap: () {
                            ANALYTICS_logEvent(store, 'Copy Action Confirmed');
                            callback(widget.searchTermSaveAction,
                                widget.isNegative, widget.low, widget.high);
                            Navigator.of(context).pop();
                          },
                          child: Container(
                            padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                            margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              "Ok",
                              style:
                                  TextStyle(fontSize: 18, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
