import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class StringFilterDialog extends StatefulWidget {
  final String id;
  final String name;
  final String type;
  final String value;
  final String displayName;
  final String metricType;
  final String stringFilterType;

  StringFilterDialog(this.name, this.type, this.value, this.displayName,
      this.metricType, this.stringFilterType,
      {this.id = ''}) {
    print(
        "StringFilterDialog, ${this.name}, ${this.type}, ${this.displayName}, ${this.stringFilterType}");
  }

  @override
  _StringFilterDialogState createState() => _StringFilterDialogState();
}

class _StringFilterDialogState extends State<StringFilterDialog> {
  String dropdownValue;
  String valueText;

  @override
  void initState() {
    super.initState();
    this.dropdownValue = widget.type != "" ? widget.type : "contains";
    this.valueText = widget.value != "" ? widget.value : "";
  }

  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: _contentBox(context),
    );
  }

  String getStringFilterType(name) {
    if (name == 'Campaign name') {
      return 'campaignName';
    } else if (name == 'AdGroup name') {
      return 'adGroupName';
    } else {
      return 'text';
    }
  }

  Widget _contentBox(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus) {
          currentFocus.unfocus();
        }
      },
      child: Container(
        padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
        decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          color: Colors.white,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(height: 22),
            Text(widget.displayName, //convertToDisplayName(widget.name),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 22),
            Padding(
              padding: EdgeInsets.only(left: 14.0, right: 14),
              child: DropdownButton<String>(
                value: dropdownValue,
                isExpanded: false,
                icon: const Icon(Icons.arrow_downward),
                iconEnabledColor: Colors.blue,
                iconDisabledColor: Colors.lightBlue,
                iconSize: 16,
                elevation: 16,
                style: TextStyle(color: Colors.blueAccent),
                underline: Container(height: 2, color: Colors.blue),
                onChanged: (newFilterValue) {
                  this.setState(() {
                    dropdownValue = newFilterValue.toString();
                  });
                },
                items: <String>[
                  "contains",
                  "does not contain",
                  // "contains (case sensitive)", // SQLITE 'LIKE' can't do this.
                  // "does not contain (case sensitive)", // SQLITE 'LIKE' can't do this.
                  "equals",
                  "starts with",
                  "ends with"
                ].map<DropdownMenuItem<String>>((String filterType) {
                  return DropdownMenuItem<String>(
                    value: filterType,
                    child: Text(filterType,
                        style: TextStyle(
                            // color: Colors.blue
                            fontSize: 18)),
                  );
                }).toList(),
                hint: Text("Text to filter",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w500)),
              ),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.all(15),
              child: TextFormField(
                initialValue: widget.value != null && widget.value.isNotEmpty
                    ? widget.value
                    : "",
                // keyboardType: TextInputType.,
                // inputFormatters: <TextInputFormatter>[
                //   FilteringTextInputFormatter.allow(RegExp(r'[0-9.-]')),
                // ],
                onChanged: (text) {
                  setState(() {
                    valueText = text; //int.parse(text); // as int;
                  });
                },
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Value",
                ),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
              ),
            ),
            SizedBox(
              height: 22,
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                      margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: Color.fromRGBO(155, 155, 155, .25),
                        ),
                      ),
                      child: Text(
                        "Cancel",
                        style: TextStyle(fontSize: 18, color: Colors.black87),
                      ),
                    ),
                  ),
                  StoreConnector<AppState, Store<AppState>>(
                    converter: (store) => store,
                    builder: (context, store) => GestureDetector(
                      onTap: () {
                        ANALYTICS_logEvent(store, 'Filter created', {
                          "name": widget.name,
                          "displayName": widget.displayName,
                        });

                        FilterValue fv = FilterValue(
                            widget.name, this.dropdownValue, this.valueText,
                            displayName: widget.displayName.isNotEmpty
                                ? widget.displayName
                                : widget.name, //this.valueText,
                            valueType: 'string',
                            stringFilterType: getStringFilterType(widget.name),
                            metricType: widget.metricType,
                            id: widget.id);
                        // callback(fv);
                        Navigator.of(context).pop(fv);
                      },
                      child: Container(
                        padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
                        margin: EdgeInsets.fromLTRB(15, 15, 15, 15),
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          "Apply",
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
