import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:searchTermAnalyzerFlutter/models/product_introductory_details.dart';
import 'package:searchTermAnalyzerFlutter/models/membership_type.dart';
import 'package:searchTermAnalyzerFlutter/widgets/gradient_icon.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';

class SingleSavePaywallDialog extends StatefulWidget {
  final Store<AppState> _store;

  SingleSavePaywallDialog(this._store);

  @override
  _SingleSavePaywallDialogState createState() =>
      _SingleSavePaywallDialogState(this._store);
}

class _SingleSavePaywallDialogState extends State<SingleSavePaywallDialog> {
  final Store<AppState> _store;
  bool _isPurchasing = false;
  ProductIntroductoryDetails _introductoryDetails;

  _SingleSavePaywallDialogState(this._store);

  @override
  void initState() {
    if (_store.state.iapProducts.length > 0) {
      ProductDetails monthlyProduct = _store.state.iapProducts
        .where((f) => f.id == SKU_MONTHLY_SUBSCRIPTION)
        .toList()[0];
      _introductoryDetails = getIntroductoryDetails(monthlyProduct);
    }

    ANALYTICS_logEvent(_store, "Paywall Displayed");

  }

  @override
  Widget build(BuildContext context) {
    _store.dispatch(SetSingleSavePurchaseDialogBuildContextAction(context));

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      elevation: 0,
      backgroundColor: Colors.white,
      child: _contentBox(context),
    );
  }

  Widget _contentBox(BuildContext context) {
    return Container(//Consumer<SingleSaveChangeNotifier>( builder: (context, ssrd, child) =>
      padding: EdgeInsets.all(25),
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Positioned(
            child: Container(
              transform: Matrix4.translationValues(0.0, -55.0, 0.0),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                // border: Border.all(width: 1, color: Colors.red),
                color: Color.fromRGBO(52, 168, 83, 1),
              ),
              child: Icon(Icons.arrow_forward_rounded, 
                color: Colors.white,
                size: 65),
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Title
              Container(
                margin: EdgeInsets.only(top: 25, bottom: 10),
                child: Text(
                  "Save to Google Ads",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              // Description
              Text(
                  "Update your Google Ads keywords based on these search terms.",
                  style: TextStyle(
                    fontSize: 18,
                  )),
              // CTA
              StoreConnector<AppState, ProductDetails>(
                converter: (store) => store.state.iapProducts
                    .where((f) => f.id == SKU_SINGLE_SAVE)
                    .toList()[0],
                builder: (context, productDetails) => GestureDetector(
                  child: Container(
                    margin: EdgeInsets.only(top: 25),
                    padding: EdgeInsets.fromLTRB(65, 10.5, 65, 10.5),
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(52, 168, 83, 1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      "One-time ${productDetails.price.toString()}",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  onTap: () async {
                    // Show the loading screen.
                    this.setState(() {
                      // this._isPurchasing = true;
                    });
                    this._store.dispatch(UpdateIsWaitingForPurchaseToBeValidatedAction(true));
                    this._store.dispatch(UpdateIsPurchasingAction(true));
                    // ssrd.updateIsPurchasing(true);

                    // Be notified whenever changes occur, in the main listening method for purchases, if it's the same ID and has been purchased successfully, close this dialog.
                    // Otherwise, show the error.

                    ANALYTICS_logEvent(this._store, 'Product Purchased From Paywall', {
                      "productName": productDetails.title
                          .replaceAll(" (webbi.ads.searchtermanalyzer (unreviewed))", "")
                          .replaceAll("(Search Terms Manager)", ""),
                    });
                    ANALYTICS_logPurchase(this._store, productDetails);

                    await purchaseProduct(productDetails);
                  },
                ),
              ),
              StoreConnector<AppState, ProductDetails>(
                converter: (store) => store.state.iapProducts
                  .where((f) => f.id == SKU_MONTHLY_SUBSCRIPTION)
                  .toList()[0],
                builder: (context, productDetails) => GestureDetector(
                  onTap: () async {

                    ANALYTICS_logEvent(this._store, 'Product Purchased From Paywall', {
                      "productName": productDetails.title
                          .replaceAll(" (webbi.ads.searchtermanalyzer (unreviewed))", "")
                          .replaceAll("(Search Terms Manager)", ""),
                    });
                    ANALYTICS_logPurchase(this._store, productDetails);

                    this.setState(() {
                      // this._isPurchasing = true;
                    });
                    this._store.dispatch(UpdateIsWaitingForPurchaseToBeValidatedAction(true));
                    this._store.dispatch(UpdateIsPurchasingAction(true));
                    await purchaseProduct(productDetails);
                  },
                  child: Container(
                    margin: EdgeInsets.only(top: 25, bottom: 25),
                    padding: EdgeInsets.fromLTRB(50, 10.5, 50, 10.5),
                    decoration: BoxDecoration(
                      // color: Color.fromRGBO(52, 168, 83, 1),
                      borderRadius: BorderRadius.circular(6),
                      // gradient: LinearGradient(
                      //   begin: Alignment.bottomCenter,
                      //   end: Alignment.topCenter,
                      //   colors: [Colors.yellow, Color.fromRGBO(52,168,83,1)],
                      // ),
                      border: Border.all(
                        color: Color.fromRGBO(52, 168, 83, 1),//Color.fromRGBO(0,0,0, 1.0),
                        width: 1.0,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "${productDetails.price.toString()} / month",
                          style: TextStyle(
                            fontSize: 16,
                            // color: Colors.white,
                            color: Color.fromRGBO(52, 168, 83, 1),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height:2),
                        (_introductoryDetails == null
                          || _introductoryDetails.introductoryPrice == ""
                          || _introductoryDetails.introductoryPriceCycles == 0)
                            ? SizedBox.shrink()
                            : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  "${_introductoryDetails.introductoryPrice} for the first ${_introductoryDetails.introductoryPriceCycles} months!",
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: Color.fromRGBO(52, 168, 83, .95),
                                  ),
                                ),
                                // GradientIcon(
                                //   Icons.local_fire_department,
                                //   20.0,
                                //   LinearGradient(
                                //       begin: Alignment.bottomCenter,
                                //       end: Alignment.topCenter,
                                //       colors: [Colors.red, Colors.orange],
                                //   ),
                                // ),
                              ],
                            ),
                      ],
                    ),
                  )
                ),
              ),
              StoreConnector<AppState, ProductDetails>(
                converter: (store) => store.state.iapProducts
                  .where((f) => f.id == SKU_LIFETIME_PURCHASE)
                  .toList()[0],
                builder: (context, productDetails) => GestureDetector(
                  onTap: () async {

                    ANALYTICS_logEvent(this._store, 'Product Purchased From Paywall', {
                      "productName": productDetails.title
                          .replaceAll(" (webbi.ads.searchtermanalyzer (unreviewed))", "")
                          .replaceAll("(Search Terms Manager)", ""),
                    });
                    ANALYTICS_logPurchase(this._store, productDetails);
                    
                    this._store.dispatch(UpdateIsWaitingForPurchaseToBeValidatedAction(true));
                    this._store.dispatch(UpdateIsPurchasingAction(true));
                    await purchaseProduct(productDetails);
                  },
                  child: Container(
                    // width: double.infinity,
                    margin: EdgeInsets.only(top: 0, bottom: 15),
                    padding: EdgeInsets.fromLTRB(60, 10.5, 60, 10.5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: Color.fromRGBO(52, 168, 83, 1),//Color.fromRGBO(0,0,0, 1.0),
                        width: 1.0,
                      ),
                    ),
                    child: Text(
                      "Lifetime ${productDetails.price.toString()}",
                      style: TextStyle(
                        fontSize: 16,
                        // color: Colors.white,
                        color: Color.fromRGBO(52, 168, 83, 1),
                        fontWeight: FontWeight.w600,
                      ),
                    )
                  )
                ),
              ),
            ],
          ),
        this._isPurchasing
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  StoreConnector<AppState, String>(
                    converter: (store) => store.state.consumableProductId,
                    builder: (context, consumableProductId) =>
                        consumableProductId != null
                            ? Text(consumableProductId)
                            : SizedBox.shrink(),
                  ),
                  CircularProgressIndicator(
                    color: Color.fromRGBO(52, 168, 83, 1),
                  ),
                ],
              )
            : SizedBox.shrink(),
        ],
      ),
    );
  }
}
