// import 'dart:convert';
// import 'dart:io';
// import 'constants.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'main.dart'; // For accessToken

// class AdGroups extends StatelessWidget {
//   AdGroups(this.customerId);
//   final int customerId;
//   List<AdGroup> adGroups;

//   int getCount() {
//     return 0;//adGroups.length;
//   }

//   Future<List<AdGroup>> getAdGroups() async {
//     final response = await http.get(
//       "https://googleads.googleapis.com/v6/customers/" + this.customerId.toString() + "/adGroups:search",
//       headers: {
//         "Authorization": "Bearer " + accessToken,
//         "developer-token": DEVELOPER_TOKEN,
//       }
//     );
//     final responseJson = jsonDecode(response.body);
//     print(responseJson["resourceNames"].toString());
//     this.adGroups = responseJson["resourceNames"];
//     return responseJson["resourceNames"];
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("AdGroups"),
//       ),
//       body: Center(
//         child: FutureBuilder(
//           future: getAdGroups(),
//           builder: (context, snapshot) {
//             if(snapshot.hasData || snapshot.data != null){
//               this.adGroups = snapshot.data;
//               return Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: this.adGroups,
//               );
//             }
//             return CircularProgressIndicator(),
//           }
//         )
//       )
//     );
//   }
// }