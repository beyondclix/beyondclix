// Save data locally into SQLite database.
// This is better than using SharedPreferences, or writing to a file.Alignment

import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:path/path.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup_to_load.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/models/order_value.dart';
import 'package:searchTermAnalyzerFlutter/models/search_result.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_order_item.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:sqflite/sqflite.dart';
import 'package:redux/redux.dart';

dynamic database;

Future<void> getDatabaseSize(Store<AppState> store) async {
  store.dispatch(NewDatabaseSizeAction(""));
  String path =
      join(await getDatabasesPath(), 'searchtermanalyzer_local_data.db');
  String size = await getFileSize(path, 2);
  store.dispatch(NewDatabaseSizeAction(size));
}

Future<String> getFileSize(String filepath, int decimals) async {
  var file = File(filepath);
  int bytes = await file.length();
  if (bytes <= 0) return "0 B";
  const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
  var i = (log(bytes) / log(1024)).floor();
  return ((bytes / pow(1024, i)).toStringAsFixed(decimals)) + ' ' + suffixes[i];
}

Future<void> initializeDB() async {
  // String path = await getDatabasesPath();
  // print('path: ' + path);
  database = openDatabase(
    join(await getDatabasesPath(), 'searchtermanalyzer_local_data.db'),
    onCreate: (db, version) {
      init(db);
      return;
    },
    onOpen: (db) {
      // truncateTable("SEARCHTERMS");
      // truncateTable("SEARCHTERMS_METRICS");
      // truncateTable("ADGROUPS_TO_LOAD");
      // truncateTable("CACHED_QUERIES");
      // truncateTable("METRICS");

      // resetAdGroupsToLoad('6611091893');
      // db.execute("DROP TABLE METRICS");
      // init(db);

      // Debug tables.
      // debugTables(db);

      return;
    },

    // Schema change happens here.
    // Called when version is newer than existing version.
    onUpgrade: (db, oldVersion, newVersion) async {
      print("UPGRADING DATABASE FROM $oldVersion to $newVersion");

      // Drop all tables, then reinitialize.
      removeAllSharedPreferences();
      await dropAll(db);
      await init(db);

      return;
    },

    // Called when version is older than existing version.
    // Mainly for debugging and restoring db.
    onDowngrade: (db, oldVersion, newVersion) async {
      print("DOWNGRADING DATABASE FROM $oldVersion to $newVersion");

      // Drop all tables, then reinitialize.
      removeAllSharedPreferences();
      await dropAll(db);
      await init(db);

      return;
    },

    // Set the version. This executes the onCreate function and provides a
    // path to perform database upgrades and downgrades.
    // https://pub.dev/documentation/sqflite/latest/sqflite/openDatabase.html
    version: 1,
  );

  //https://pub.dev/documentation/sqflite_common/latest/sqlite_api/OnDatabaseVersionChangeFn.html
  // OnDatabaseVersionChangeFn
}

Future<void> dropAll(Database db) async {
  await db.execute("DROP TABLE CUSTOMERS");
  await db.execute("DROP TABLE CUSTOMER_CLIENTS");
  await db.execute("DROP TABLE CAMPAIGNS");
  await db.execute("DROP TABLE ADGROUPS");
  await db.execute("DROP TABLE KEYWORDS");
  await db.execute("DROP TABLE SEARCHTERMS");
  await db.execute("DROP TABLE SEARCH_TERM_SAVE_ACTIONS");
  await db.execute("DROP TABLE NEGATIVE_KEYWORD_LIST");
  await db.execute("DROP TABLE NEGATIVE_KEYWORD_LIST_TO_SAVE");
  await db.execute("DROP TABLE METRICS");
  await db.execute("DROP TABLE METRIC_VALUE");
  await db.execute("DROP TABLE FILTER_VALUE");
  await db.execute("DROP TABLE ORDER_VALUE");
  await db.execute("DROP TABLE ADGROUPS_TO_LOAD");
  await db.execute("DROP TABLE CAMPAIGN_METRICS");
  await db.execute("DROP TABLE ADGROUPS_METRICS");
  await db.execute("DROP TABLE SEARCHTERMS_METRICS");
  await db.execute("DROP TABLE CACHED_QUERIES");
  print('FINISHED DROPPING TABLES');
}

Future<void> init(Database db) async {
  db.execute(
      'CREATE TABLE IF NOT EXISTS CUSTOMERS (id TEXT PRIMARY KEY, resourceName TEXT, isManager INTEGER, descriptiveName TEXT, googleEmail TEXT, timeZone TEXT, currencyCode TEXT, clicks INT, costMicros INT, impressions INT, conversions INT, allConversions INT)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS CUSTOMER_CLIENTS (id TEXT PRIMARY KEY, resourceName TEXT, name TEXT, isManager INTEGER, parentId TEXT, timeZone TEXT, currencyCode TEXT, clicks INT, costMicros INT, impressions INT, conversions INT, allConversions INT)');
  db.execute(
      // Add client ID
      'CREATE TABLE IF NOT EXISTS CAMPAIGNS (id TEXT PRIMARY KEY, customerClientId TEXT, resourceName TEXT, name TEXT, status TEXT)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS ADGROUPS (id TEXT PRIMARY KEY, customerClientId TEXT, campaignId TEXT, campaignName TEXT, resourceName TEXT, name TEXT)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS KEYWORDS (id TEXT PRIMARY KEY, resourceName TEXT, adGroupId TEXT, text TEXT, isNegative INTEGER, adGroup TEXT, matchType TEXT, date INTEGER)');
  // db.execute('CREATE TABLE IF NOT EXISTS SEARCHTERMS (id TEXT PRIMARY KEY, resourceName TEXT, adGroupId TEXT, adGroupResourceName TEXT, text TEXT, status TEXT, adGroupName TEXT, campaignId TEXT, campaignName TEXT, campaignResourceName TEXT, impressions TEXT, clicks TEXT, ctr TEXT, average_cpc TEXT, cost_micros TEXT, conversions TEXT, cost_per_conversion TEXT, conversion_rate TEXT, search_impression_share TEXT, date INTEGER)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS SEARCHTERMS (id TEXT PRIMARY KEY, resourceName TEXT, queryId TEXT, customerId TEXT, adGroupId TEXT, adGroupResourceName TEXT, text TEXT, status TEXT, adGroupName TEXT, campaignId TEXT, campaignName TEXT, campaignResourceName TEXT, date INTEGER, searchTermMatchType TEXT)');
  // db.execute(
  //   'CREATE TABLE IF NOT EXISTS CHANGE_ACTIONS (id changeId TEXT PRIMARY KEY, changeType TEXT, changeField TEXT, changeValue TEXT)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS SEARCH_TERM_SAVE_ACTIONS (id TEXT PRIMARY KEY, customerId TEXT, managerId TEXT, negativeKeywordSaveType TEXT, negativeKeywordListName TEXT, negativeKeywordListResourceName TEXT, searchTermResourceName TEXT, adGroupResourceId TEXT, isNegative INT, matchType TEXT, finalUrls TEXT, maxCpc REAL, searchTermText TEXT, adGroupId TEXT, adGroupName TEXT, campaignName TEXT, campaignResourceName TEXT, date INTEGER)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS NEGATIVE_KEYWORD_LIST (id TEXT PRIMARY KEY, customerId TEXT, managerId TEXT, resourceName TEXT, memberCount INTEGER, referenceCount INTEGER)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS NEGATIVE_KEYWORD_LIST_TO_SAVE (id TEXT PRIMARY KEY, customerId TEXT, managerId TEXT, resourceName TEXT, memberCount INTEGER, referenceCount INTEGER)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS METRICS (metricFor TEXT, name TEXT, displayName TEXT, valueType TEXT, isOn INT)');
  // Deprecated, and replaced by dynamically created tables SEARCHTERMS_METRICS/CAMPAIGN_METRICS/ADGROUPS_METRICS
  db.execute(
      'CREATE TABLE IF NOT EXISTS METRIC_VALUE (parentId TEXT, metricFor TEXT, name TEXT, value REAL)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS FILTER_VALUE (id TEXT PRIMARY KEY, name TEXT, type TEXT, value TEXT, valueType TEXT, displayName TEXT, stringFilterType TEXT, metricType TEXT)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS ORDER_VALUE (id TEXT PRIMARY KEY, name TEXT, groupName TEXT, displayName TEXT, value TEXT, valueType TEXT, stringFilterType TEXT)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS ADGROUPS_TO_LOAD (adGroupId INTEGER PRIMARY KEY, adGroupName TEXT, campaignId TEXT, customerId TEXT, isLoaded INTEGER)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS LATEST_DATA_LOADED_DATE (customerClientId TEXT PRIMARY KEY, date INTEGER)');
  db.execute(
      'CREATE TABLE IF NOT EXISTS CACHED_QUERIES (id TEXT PRIMARY KEY, queryUpperEpoch TEXT, queryLowerEpoch TEXT)');

  // print(getMetricsTableCreationString("CAMPAIGN"));
  // print(getMetricsTableCreationString("ADGROUPS"));
  // print(getMetricsTableCreationString("SEARCHTERMS"));
  db.execute(getMetricsTableCreationString("CAMPAIGN"));
  db.execute(getMetricsTableCreationString("ADGROUPS"));
  db.execute(getMetricsTableCreationString("SEARCHTERMS"));
  initializeMetrics();
}

// ignore: non_constant_identifier_names
// Called from API functions when no data is returned.
// This lets the client know that there is no need to load more data for this, as it has already been queried.
Future<void> DB_InsertBlank(String tableName, Map<String, dynamic> map) async {
  final db = await database;
  // print("INSERTING BLANK into $tableName=> ${map.toString()}");

  // Removed due to using CACHED_QUERIES now.
  // await db.insert(tableName, map, conflictAlgorithm: ConflictAlgorithm.replace);
  return;
}

// ignore: non_constant_identifier_names
/*
  Removes all blanks per customer. //for a given adGroupId or campaignId.

  This has an issue where it always loads more data when a date is changed and there is no data for that result on that date.
*/
Future<void> DB_RemoveBlank(String tableName, String columnKey,
    String columnValue, String blankColumnName) async {
  // print("REMOVING BLANK for $columnKey, $columnValue, $blankColumnName");
  final db = await database;
  String query = """
    DELETE FROM $tableName
    WHERE $columnKey = '$columnValue'
    AND $blankColumnName = '$EMPTY_KEY'
  """;
  try {
    // Removed due to using CACHED_QUERIES now.
    // await db.rawQuery(query);
    return;
  } catch (err) {
    print("ERROR REMOVING OBJECT: err: $err, query: $query");
    return;
  }
}

Future<void> addCachedQuery(String cachedQueryName, int lowerEpoch, int upperEpoch) async {
  final db = await database;
  
  print("ADDING CACHED QUERY: $cachedQueryName");
  
  // String query = """
  //   INSERT INTO CACHED_QUERIES
  //   VALUES ($cachedQueryName)
  // """;
  var map = {
    "id": cachedQueryName,
    "queryLowerEpoch": lowerEpoch.toString(),
    "queryUpperEpoch": upperEpoch.toString(),
  };
  try {
    await db.insert('CACHED_QUERIES', map, conflictAlgorithm: ConflictAlgorithm.replace);
    // await db.rawQuery(query);
  } catch (err) {
    print("ERROR ADDING CACHED QUERY: $err");
  }
}

// Creating new cache entry, delete existing data.
// Future<void> removeCachedSearchTermsAndMetrics(String cachedQueryName) async {
//   final db = await database;

//   try {
//     await db.rawQuery("""
//       DELETE FROM SEARCHTERMS
//       WHERE queryId = '$cachedQueryName'
//     """);
//   } catch (err) {
//     print("ERROR REMOVING CACHED SEARCH TERMS: $err");
//   }

//   try {
//     await db.rawQuery("""
//       DELETE FROM SEARCHTERMS_METRICS
//       WHERE uniqueId = '$cachedQueryName'
//     """);
//   } catch (err) {
//     print("ERROR REMOVING CACHED METRICS: $err");
//   }
// }

// Reset all values in DB to reload all per customer.
Future<void> resetAdGroupsToLoad(String customerId) async {
  // print("resetAdGroupsToLoad!!!");
  final db = await database;

  // await truncateTable("SEARCHTERMS");

  String query = """
    UPDATE ADGROUPS_TO_LOAD
    SET isLoaded = 0
    WHERE customerId = $customerId
  """;
  try {
    await db.rawQuery(query);
  } catch (err) {
    print("ERROR RESETTING ADGROUPS_TO_LOAD");
  }
  return;
}

// Set list of adGroupToLoads all to complete
Future<void> finishMultipleAdGroupToLoads(
    List<AdGroupToLoad> adGroupToLoads) async {
  final db = await database;

  await db.transaction((txn) async {
    for (AdGroupToLoad adGroupToLoad in adGroupToLoads) {
      // print("ObjectMap: $objectMap");
      await txn.rawUpdate("""
        UPDATE ADGROUPS_TO_LOAD
        SET isLoaded = 1
        WHERE adGroupId = ${adGroupToLoad.adGroupId}
      """);
    }
  });
}

Future<List<dynamic>> getMetricsForCategory(
    String category, onlyGetVisible) async {
  final db = await database;

  String query = """
      SELECT * FROM METRICS WHERE 
      metricFor = '$category' ORDER BY name
      """;
  if (onlyGetVisible) {
    query += " WHERE isOn = 1";
  }
  try {
    // print("METRICS QUERY: " + query);
    // int r = await getRowCount("METRICS");
    // print("MEtrics row count: $r");
    // var m = await db.rawQuery("SELECT metricFor FROM METRICS GROUP BY metricFor");
    // print("m: $m");
    final maps = await db.rawQuery(query);

    return maps;
  } catch (err) {
    print("ERROR MAKING QUERY: " + err.toString());
    return null;
  }
}

Future<void> insertOrUpdateMetrics(String tableName,
    List<Map<String, dynamic>> objectMaps, String metricFor) async {
  final db = await database;
  await db.transaction((txn) async {
    for (Map<String, dynamic> objectMap in objectMaps) {
      // print("ObjectMap: $objectMap");
      await txn.insert('${tableName}_METRICS', objectMap,
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  });
  // print("insertOrUpdateMetrics");
}

// Future<void> insertOrUpdateMetrics(Map<String, dynamic> map,
//     String metricFor, String id) async {
//   final db = await database;
//   await db.transaction((txn) async {
//     for (String key in map.keys) {
//       Map<String, dynamic> objectMap = {
//         "parentId": id.replaceAll("'", ""),
//         "metricFor": metricFor,
//         "name": key,
//         "value": map[key]
//       };

//       // print('key: $key : ${map[key]}');
//       await txn.insert('METRIC_VALUE', objectMap,
//           conflictAlgorithm: ConflictAlgorithm.replace);
//       // await txn.insert('METRIC_VALUE', objectMap,
//       //     conflictAlgorithm: ConflictAlgorithm.replace);
//     }
//   });
// }

// ignore: non_constant_identifier_names
Future<void> DB_UpdateMetrics(List<Metric> metrics, String metricType) async {
  final db = await database;
  await db.transaction((txn) async {
    for (Metric m in metrics) {
      await txn.rawQuery('''
        UPDATE METRICS
        SET isOn=${m.isOn}
        WHERE metricFor='${m.metricFor}'
        AND name='${m.name}'
      ''');
      //   await txn.rawQuery('''
      //   UPDATE ?
      //   SET ?=?
      //   WHERE ?=?
      //   AND ?=?
      // ''', ["METRICS", "isOn", m.isOn, "metricFor", m.metricFor, "name", m.name]);
    }
  });
}

Future<void> insertObjectIfNotExistUpdateIfExistConditional(
    Map<String, dynamic> objectMap,
    String tableName,
    String columnName,
    String columnValue,
    {bool valueIsString = false}) async {
  final db = await database;

  if (valueIsString) {
    columnValue = '"' + columnValue + '"';
  }

  var queryResult = await db
      .rawQuery('SELECT * FROM $tableName WHERE $columnName = $columnValue');
  if (queryResult != null && queryResult.length > 0) {
    await updateObject(objectMap, tableName, columnValue);
  } else {
    // print("INSERTING OBJECT: " + objectMap.toString());
    await db.insert(tableName, objectMap,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

// Inserts object into the database if it does not exist.
// If it does exist, then updates it.
// This means local memory storage grows as the app becomes more reliant on local data.
Future<void> insertObjectIfNotExistUpdateIfExist(
    Map<String, dynamic> objectMap, String tableName, String primaryKeyValue,
    [bool primaryKeyIsString = false]) async {
  final db = await database;

  if (primaryKeyIsString) {
    primaryKeyValue = '"' + primaryKeyValue + '"';
  }

  // print("insertObjectIfNotExistUpdateIfExist: " + objectMap.toString());

  var queryResult = await db
      .rawQuery('SELECT * FROM $tableName WHERE id = ?', [primaryKeyValue]);
  // print('queryResult: ' + queryResult.toString());
  if (queryResult != null && queryResult.length > 0) {
    await updateObject(objectMap, tableName, primaryKeyValue);
  } else {
    // print("INSERTING OBJECT: " + objectMap.toString());
    await db.insert(tableName, objectMap,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

Future<void> insertMultipleObjects(
    List<Map<String, dynamic>> objectMaps, String tableName) async {
  final db = await database;

  await db.transaction((txn) async {
    for (var objectMap in objectMaps) {
      await txn.insert(tableName, objectMap,
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  });
  // print("insertMultipleObjects");
}

// ignore: non_constant_identifier_names
Future<void> insertMultipleObject_TRANSACTION(
    List<Map<String, dynamic>> objectMaps,
    String tableName,
    String primaryKeyValue,
    [bool primaryKeyIsString = false]) async {
  final db = await database;

  if (primaryKeyIsString) {
    primaryKeyValue = '"' + primaryKeyValue + '"';
  }

  await db.transaction((txn) async {
    for (Map<String, dynamic> objectMap in objectMaps) {
      // await txn.rawInsert(
      //   "INSERT INTO $tableName ()"
      // )
      await txn.insert(tableName, objectMap,
          conflictAlgorithm: ConflictAlgorithm.replace);
      print('Inserted one objectMap via TRANSACTION');
    }
  });
  print("insertMultipleObject");
}

Future<void> insertObject(
    Map<String, dynamic> objectMap, String tableName) async {
  final db = await database;
  await db.insert(tableName, objectMap,
      conflictAlgorithm: ConflictAlgorithm.replace);
  // print("insertObject");
  return;
}

Future<void> removeObject(
    String tableName, String columnName, String columnValue) async {
  final db = await database;
  String query = """
      DELETE FROM $tableName
      WHERE $columnName = '$columnValue'
    """;
  try {
    await db.rawQuery(query);
    return;
  } catch (err) {
    print("ERROR REMOVING OBJECT: " + err.toString());
    return;
  }
}

Future<void> updateObject(
    Map<String, dynamic> objectMap, String tableName, String primaryKey) async {
  final db = await database;

  // print("UPDATING LOCAL DATABASE OBJECT: " +
  //     primaryKey +
  //     ": " +
  //     objectMap.toString() +
  //     ", value: " +
  //     objectMap[primaryKey].toString());
  // db.rawQuery(
  //   """
  //     UPDATE $tableName
  //     SET $primaryKey = ${objectMap['primaryKeyValue']}

  //   """
  // )

  await db.update(tableName, objectMap,
      where: primaryKey + ' = ?', whereArgs: [objectMap[primaryKey]]);
}

Future<void> updateObjectWithCustomFieldAndValue(
    String tableName,
    String primaryKey,
    String primaryKeyValue,
    String customField,
    String customFieldValue) async {
  final db = await database;

  print("UPDATING CUSTOM FIELD IN DB: " +
      primaryKeyValue.toString() +
      ", customField: " +
      customField +
      ", customFieldValue: " +
      customFieldValue);

  await db.rawQuery('''
      UPDATE ?
      SET ? = ?
      WHERE ? = ?
    ''',
      [tableName, customField, customFieldValue, primaryKey, primaryKeyValue]);
}

Future<void> deleteObject(
    dynamic primaryKey, dynamic value, String tableName) async {
  final db = await database;
  print("DELETING OBJECT: " + primaryKey.toString() + ": " + value.toString());

  await db.delete(tableName, where: primaryKey + ' = ?', whereArgs: [value]);
}

// Removes all data from a table.
Future<void> truncateTable(String tableName) async {
  final db = await database;

  try {
    await db.execute("DELETE FROM " + tableName);
  } catch (err) {
    print("ERROR TRUNCATING TABLE: " + tableName + ", " + err.toString());
  }
}

Future<void> truncateTableConditional(
    String tableName, String columnName, String columnValue) async {
  final db = await database;
  try {
    await db.execute("DELETE FROM $tableName WHERE $columnName = $columnValue");
  } catch (err) {
    print(
        "ERROR TRUNCATING TABLE CONDITIONAL $tableName, $columnName, $columnValue");
  }
}

Future<List<dynamic>> getLocalObjects(String tableName) async {
  final db = await database;

  final List<Map<String, dynamic>> maps = await db.query(tableName);
  // print('Found local data for table ' +
  //     tableName +
  //     ": " +
  //     maps.length.toString());
  return maps;
}

Future<List<Map<String, dynamic>>> getAdGroupsYetToLoad(
    String customerId) async {
  if (customerId == null || customerId == "") {
    return [];
  }
  final db = await database;
  try {
    final List<Map<String, dynamic>> maps = await db.rawQuery("""
      SELECT * FROM ADGROUPS_TO_LOAD WHERE isLoaded = 0 AND customerId = $customerId
    """);
    return maps;
  } catch (err) {
    print("ERROR GETTING ADGROUPS_TO_LOAD: ${err.toString()}");
  }
  return [];
}

Future<List<dynamic>> getCampaignsWithConstraintsPaginatedFiltered(
    String customerClientId, int limit, int offset,
    {bool emptiesOnly}) async {
  final db = await database;
  String query = "SELECT * FROM CAMPAIGNS";
  query += " WHERE customerClientId = $customerClientId ";

  if (emptiesOnly) {
    query += " AND name = '$EMPTY_KEY' ";
  } else {
    query += " AND name != '$EMPTY_KEY' ";
  }
  query += " ORDER BY name ";
  query += " LIMIT $limit";
  if (offset > 0) {
    query += " OFFSET $offset";
  }

  // print("CAMPAIGN DB QUERY: $query");

  try {
    final maps = await db.rawQuery(query);
    // print("FOUND CAMPAIGNS IN DB: ${maps.length}");

    return maps;
  } catch (err) {
    print("ERROR MAKING CAMPAIGN QUERY: " + err.toString());
    return null;
  }
}

Future<List<dynamic>> getAdGroupsWithConstraintsPaginatedFiltered(
    String customerClientId, String campaignId, int limit, int offset,
    {bool emptiesOnly}) async {
  final db = await database;
  String query = "SELECT * FROM ADGROUPS";
  query += " WHERE customerClientId = $customerClientId ";
  if (campaignId != null && campaignId.length > 0) {
    if (!query.contains("WHERE")) {
      query += " WHERE campaignId = $campaignId ";
    } else {
      query += " AND campaignId = $campaignId ";
    }
  }

  if (!query.contains("WHERE")) {
    query += " WHERE ";
  } else {
    query += " AND ";
  }
  if (emptiesOnly) {
    query += "name = '$EMPTY_KEY' ";
  } else {
    query += "name != '$EMPTY_KEY' ";
  }
  query += " ORDER BY name ";
  query += " LIMIT $limit";
  if (offset > 0) {
    query += " OFFSET $offset";
  }

  // print("ADGROUPS DB QUERY: $query");

  try {
    final maps = await db.rawQuery(query);
    // int r = await getRowCountConstrained("ADGROUPS","customerClientId",customerClientId);
    // print("adgroups row sin DB: $r");
    // print("FOUND ADGROUPS IN DB: ${maps.length}");

    return maps;
  } catch (err) {
    print("ERROR MAKING ADGROUPS QUERY: " + err.toString());
    return null;
  }
}

Future<List<dynamic>> getSearchTermsWithConstraintsPaginatedFiltered<T>(
    String campaignIdConstraint,
    String adGroupIdConstraint,
    String customerIdConstraint,
    int lowerDateEpoch,
    int upperDateEpoch,
    List<FilterValue> filterValues,
    OrderValue orderBy,
    int limit,
    int offset,
    String currentTimeZone,
    String queryId,
    /* emptiesOnly flag:
      if true, only load empty entries to check if this has been checked before.
      if false, only load non-empty entries, so SearchTerm.fromMaps() knows not to reload data again as it is genuinely empty.
    */
    {bool emptiesOnly}) async {
  final db = await database;
  // print("lowerDateEpoch: $lowerDateEpoch");
  // print("upperDateEpoch: $upperDateEpoch");


  String query = "SELECT * FROM SEARCHTERMS";
  // If metrics exist to be filtered on, inner join the metrics.
  // print("filterValues: $filterValues");
  // if (filterValues != null) {
  //   for (FilterValue filterValue in filterValues) {
  //     print("filterValue.name: ${filterValue.name}, filterValue.valueType: ${filterValue.valueType}");
  //   }
  // }
  // print("orderBy.toMap(): ${orderBy.toMap()}");
  bool isUsingMetrics = orderBy.valueType == 'num';
  if (filterValues != null && !isUsingMetrics) {
    isUsingMetrics = filterValues.any((fv) => fv.valueType == 'num');
  }

  if (isUsingMetrics) {
    query +=
        " INNER JOIN SEARCHTERMS_METRICS ON SEARCHTERMS_METRICS.parentId = SEARCHTERMS.id ";
  }

  query += " WHERE customerId = $customerIdConstraint ";

  if (campaignIdConstraint != null && adGroupIdConstraint != null) {
    query +=
        " AND campaignId = '$campaignIdConstraint' AND adGroupId = '$adGroupIdConstraint'";
  } else if (campaignIdConstraint != null && adGroupIdConstraint == null) {
    query += " AND campaignId = '$campaignIdConstraint'";
  } else if (adGroupIdConstraint != null && campaignIdConstraint == null) {
    query += " AND adGroupId = '$adGroupIdConstraint'";
  }

  if (emptiesOnly) {
    query += " AND text = '$EMPTY_KEY' ";
  } else {
    query += " AND text != '$EMPTY_KEY' ";
  }

  // if (lowerDateEpoch != null) {
  //   if (!query.contains("WHERE")) {
  //     query +=
  //         " WHERE date >= ${epochToLocalEpoch(lowerDateEpoch, currentTimeZone)} "; // + 10
  //     // " WHERE date >= ${lowerDateEpoch} ";
  //   } else {
  //     query +=
  //         " AND date >= ${epochToLocalEpoch(lowerDateEpoch, currentTimeZone)} "; // + 10
  //     // " AND date >= ${lowerDateEpoch} ";
  //   }
  // }
  // if (upperDateEpoch != null) {
  //   if (!query.contains("WHERE")) {
  //     query +=
  //         " WHERE date <= ${epochToLocalEpoch(upperDateEpoch, currentTimeZone)} ";
  //     // " WHERE date <= ${upperDateEpoch} ";
  //   } else {
  //     query +=
  //         " AND date <= ${epochToLocalEpoch(upperDateEpoch, currentTimeZone)} ";
  //     // " AND date <= ${upperDateEpoch} ";
  //   }
  // }

  // Using cached results system per query rather than per date.
  if (!query.contains("WHERE")) {
    query += " WHERE ";
  } else {
    query += " AND ";
  }
  query += "queryId = '${queryId}' ";
  

  // print('filterValues: $filterValues');
  if (filterValues != null) {
    query = addSearchTermFilters(query, filterValues);
  }

  if (ORDER_SEQUENCE[orderBy.value] != "") {
    if (orderBy.valueType == 'num') {
      // Need to have table name, as it is from SEARCHTERMS_METRICS table.
      query += ' ORDER BY SEARCHTERMS_METRICS."${snake2Camel(orderBy.name)}"';
    } else {
      // Check for special type for campaign/adgroup.
      if (orderBy.stringFilterType != '') {
        query += ' ORDER BY SEARCHTERMS."${orderBy.stringFilterType}"';
      } else {
        query += ' ORDER BY SEARCHTERMS."${orderBy.name}"';
      }
    }
    if (ORDER_SEQUENCE[orderBy.value] == "DESC") {
      query += " DESC ";
    }
  }
  query += " LIMIT $limit";
  if (offset > 0) {
    query += " OFFSET $offset";
  }

  // print("currentTimeZone: $currentTimeZone, $lowerDateEpoch, $upperDateEpoch");


  print("SearchTerm DB QUERY: $query");

  try {
    final maps = await db.rawQuery(query);

    // print('QUERIED search terms: ' + maps.length.toString());
    // print(maps.toString());
    return maps;
  } catch (err) {
    print("ERROR MAKING QUERY: " + err.toString());
    return null;
  }
}

/*Future<List<dynamic>> getSearchTermsWithConstraints<T>(
    String campaignIdConstraint,
    String adGroupIdConstraint,
    int lowerDateEpoch,
    int upperDateEpoch) async {
  final db = await database;
  // print("lowerDateEpoch: $lowerDateEpoch");
  // print("upperDateEpoch: $upperDateEpoch");

  String query = "SELECT * FROM SEARCHTERMS";

  if (campaignIdConstraint != null && adGroupIdConstraint != null) {
    query +=
        " WHERE campaignId = '$campaignIdConstraint' AND adGroupId = '$adGroupIdConstraint'";
  } else if (campaignIdConstraint != null && adGroupIdConstraint == null) {
    query += " WHERE campaignId = '$campaignIdConstraint'";
  } else if (adGroupIdConstraint != null && campaignIdConstraint == null) {
    query += " WHERE adGroupId = '$adGroupIdConstraint'";
  }

  if (lowerDateEpoch != null) {
    if (!query.contains("WHERE")) {
      query += " WHERE date > $lowerDateEpoch ";
    } else {
      query += " AND date > $lowerDateEpoch ";
    }
  }
  if (upperDateEpoch != null) {
    if (!query.contains("WHERE")) {
      query += " WHERE date < $upperDateEpoch ";
    } else {
      query += " AND date < $upperDateEpoch ";
    }
  }
  print("SearchTerm QUERY: $query");

  try {
    final maps = await db.rawQuery(query);

    
    return maps;
  } catch (err) {
    print("ERROR MAKING QUERY: " + err.toString());
    return null;
  }
}*/

// Future<List<SearchResult>> getLikeText(
//     String tableName, String query, String column) async {
//   final db = await database;
//   final maps = await db.rawQuery("""
//       SELECT * FROM $tableName WHERE
//       $column LIKE %'$query'%
//       """);
//   return maps.map((m) {
//     return map2SearchTerm(m);
//   });
// }

// SearchResult map2SearchTerm(Map<String, dynamic> map) {
//   return SearchResult(map['name'], map['parentName'], map['resultType'], 0);
// }

Future<List<dynamic>> getLocalObjectsWithConstraint<T>(
    String tableName, String tableKey, String value,
    [bool primaryKeyIsString = false]) async {
  final db = await database;
  // print("getLocalObjectsWithConstraint: $tableName, $tableKey, $value");

  // print("QUERY: " +
  //     "SELECT * FROM " +
  //     tableName +
  //     " WHERE " +
  //     tableKey +
  //     "=" +
  //     value);

  if (value == null || value == "") {
    return null;
  }

  if (primaryKeyIsString) {
    value = '"' + value + '"';
  }

  try {
    final maps = await db.rawQuery("""
      SELECT * FROM $tableName WHERE 
      $tableKey = '$value' ORDER BY id
      """);

    // print('Found CONSTRAINED local data for table ' +
    // tableName +
    // ": " +
    // maps.length.toString());

    return maps; //.toList();
  } catch (err) {
    print("ERROR MAKING QUERY getLocalObjectsWithConstraint(): " +
        err.toString());
    return null;
  }
}

Future<List<dynamic>> getLocalObjectsWithConstraintNoID<T>(
    String tableName, String tableKey, String value) async {
  final db = await database;

  // print("QUERY: " +
  //     "SELECT * FROM " +
  //     tableName +
  //     " WHERE " +
  //     tableKey +
  //     "=" +
  //     value);

  print("getLocalObjectsWithConstraintNoID");

  try {
    final maps = await db.rawQuery("""
      SELECT * FROM $tableName WHERE 
      $tableKey = '$value'
      """);

    // print('Found CONSTRAINED local data for table ' +
    //     tableName +
    //     ": " +
    //     maps.length.toString());

    return maps;
  } catch (err) {
    print("ERROR MAKING QUERY getLocalObjectsWithConstraintNoID(): " +
        err.toString());
    return null;
  }
}

Future<List<T>> getMetricObject<T>(
    String tableName, String parentId, String uniqueId) async {
  final db = await database;
  // print("getMetricObject");
  String query = """
      SELECT * FROM $tableName 
      WHERE parentId = '$parentId' 
    """;

  // UniqueId is empty for adgroup and campaign queries.
  if (uniqueId != '') {
    query += " AND uniqueId = '$uniqueId' ";
  }
  // print('query: $query');
  final maps = await db.rawQuery(query);
  // print("received metrics: $query => $maps");
  if (maps.length == 0) {
    print("Metrics not found:  $query => $maps");
  }
  return maps;
}

Future<List<T>> getLocalObjectsWithConstraintAndPagination<T>(String tableName,
    String tableKey, String value, String orderByColumn, String lastValue,
    [bool primaryKeyIsString = false]) async {
  final db = await database;
  print("getLocalObjectsWithConstraintAndPagination");

  if (primaryKeyIsString) {
    value = '"' + value + '"';
  }

  // print("QUERY: " +
  //     "SELECT * FROM " +
  //     tableName +
  //     " WHERE " +
  //     tableKey +
  //     "=" +
  //     value);
  final maps = await db.rawQuery(
      "SELECT * FROM $tableName WHERE $tableKey = $value AND $orderByColumn > $lastValue ORDER BY $orderByColumn LIMIT 50");
  // print('Found CONSTRAINED local data for table ' +
  //     tableName +
  //     ": " +
  //     maps.length.toString());

  return maps; //.toList();
}

Future<void> debugTables(Database db) async {
  List<Map<String, dynamic>> c = await db.query('CUSTOMERS');
  // print('customers count: ' + c.length.toString());
  // for (var cc in c) {
  //   print("customer: ${cc}");
  // }
  // List<Map<String, dynamic>> cc = await db.query('CUSTOMER_CLIENTS');
  // print('customer_client count: ' + cc.length.toString());
  // for (var ccc in cc) {
  //   print("customerCLient:${ccc['id']}, ${ccc['name']}");
  // }
  // List<Map<String, dynamic>> cam = await db.query('CAMPAIGNS');
  // print('campaigns count: ' + cam.length.toString());
  // List<Map<String, dynamic>> maps = await db.query('ADGROUPS_TO_LOAD');
  // print("ADGROUPS_TO_LOAD DATA LENGTH: " + maps.length.toString());
  // for (var c in maps) {
  //   print("ADGROUP_TO_LOAD: " + c.toString());
  // }
  // List<Map<String, dynamic>> searchTermSaveActions = await db.query('SEARCH_TERM_SAVE_ACTIONS');
  // print("Search Term Save Actions count: " + searchTermSaveActions.length.toString());
  // for (var m in searchTermSaveActions) {
  //   print("SearchTermSaveAction: " + m.toString());
  //   print("---------------------------------------------------------");
  // }
  // List<Map<String, dynamic>> searchTerms = await db.query('SEARCHTERMS');
  // print("Search Terms count: " + searchTerms.length.toString());
  // for (var searchTerm in searchTerms) {
  //   print("searchTerm: $searchTerm");
  // }
  // List<Map<String, dynamic>> searchTermMetrics = (await db.query("SEARCHTERMS_METRICS"));//[0];
  // for (var s in searchTermMetrics) {
  //   print("SearchTermMetrics: $searchTermMetrics");
  // }

  int searchTermsCount = await getRowCount("SEARCHTERMS");
  print("Search terms count: $searchTermsCount");
  
  int metricsCount = await getRowCount("SEARCHTERMS_METRICS");
  print("Searchterms metrics count: $metricsCount");

  var cachedQueries = await db.query("CACHED_QUERIES");
  for (var cq in cachedQueries) {
    print('cached query: $cq');
  }

  // List<dynamic> nklts = await db.query('NEGATIVE_KEYWORD_LIST_TO_SAVE');
  // for (var nklt in nklts) {
  //   print("nklt: $nklt");
  // }
  // print("nklts.length: ${nklts.length}");

  List<Map<String, dynamic>> metrics = await db.query('METRICS');
  print("Metrics count: " + metrics.length.toString());
  for (var m in metrics) {
    if (m['metricFor'] == 'SEARCHTERMS') {
      print('Metric: ' + m.toString());
      print('------------------------------------------------');
    }
  }
  // truncateTable('SEARCH_TERM_SAVE_ACTIONS');
  // truncateTable('SEARCHTERMS');
  // truncateTable("NEGATIVE_KEYWORD_LIST_TO_SAVE");
}

Future<int> getRowCount(String tableName) async {
  final db = await database;
  int count = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM $tableName'));
  // Only add if it doesn't exist.
  return count;
}

Future<int> getRowCountConstrained(
    String tableName, String columnName, String value) async {
  final db = await database;
  int count = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM $tableName WHERE $columnName = '$value'"));
  if (count == null) {
    count = 0;
  }
  return count;
}

Future<int> getAdGroupToLoadRowCount(
    String tableName, String customerId) async {
  final db = await database;
  int count = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM $tableName WHERE customerId = '$customerId' "));

  return count;
}

Future<int> getAdGroupNotLoadedRowCount(
    String tableName, String columnName, String value) async {
  final db = await database;
  int count = Sqflite.firstIntValue(await db.rawQuery(
      "SELECT COUNT(*) FROM $tableName WHERE $columnName = '$value' AND isLoaded = 0 "));
  return count;
}

// Initialize all DISPLAY metrics here.
// Metric values are not stored here, this is only for the columns to display.
Future<void> initializeMetrics() async {
  final db = await database;

  int count =
      Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM METRICS"));
  // Only add if it doesn't exist.
  // print('METRICS count: $count');

  if (count == 0) {
    for (String s in ["CAMPAIGN", "ADGROUPS", "SEARCHTERMS"]) {
      for (var m in METRIC_TYPES[s]) {
        // await txn.rawInsert(
        //   "INSERT INTO $tableName ()"
        // )
        // print("ADDING");
        var objectMap = {
          'metricFor': s,
          'isOn': 1,
          'name': m['name'],
          'displayName':
              m['displayName'] != null ? m['displayName'] : m['name'],
          'valueType': m['value']
        };
        await db.insert("METRICS", objectMap,
            conflictAlgorithm: ConflictAlgorithm.replace);
      }

      // Add additional column displays.
      if (s == "SEARCHTERMS") {
        print("Adding added_excluded");
        var objectMapSingle = {
          "metricFor": s,
          "isOn": 1,
          "name": "Added_excluded",
          "displayName": "Added/Excluded",
          "valueType": "string",
        };

        await db.insert("METRICS", objectMapSingle, conflictAlgorithm: ConflictAlgorithm.replace);

      }

    }
  }
}

// SEARCHTERM_METRICS parentId = searchTerm.text;
String getMetricsTableCreationString(String tableName) {
  var metrics = METRIC_TYPES[tableName].map((m) => m['name']);
  StringBuffer buffer = StringBuffer(
      "CREATE TABLE IF NOT EXISTS ${tableName.toUpperCase()}_METRICS (parentId TEXT PRIMARY KEY, uniqueId TEXT, metricFor TEXT");
  // List each metric as a column in the table.
  for (String metric in metrics) {
    buffer.write(", ${snake2Camel(metric)} REAL"); //TEXT
  }
  buffer.write(")");
  return buffer.toString();
}
