import 'package:flutter_smartlook/flutter_smartlook.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:facebook_app_events/facebook_app_events.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:in_app_purchase_android/billing_client_wrappers.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'dart:convert';

// Log to both Smartlook and Firebase Analytics at the same time.
// ignore: non_constant_identifier_names
void ANALYTICS_logEvent(Store<AppState> store, String eventName,
    [Map<String, dynamic> map]) async {
      
  eventName = eventName.replaceAll(" ", "_");

  // Logging custom events
  Map<String, dynamic> out = {};

  if (map != null) {
    map.forEach((key, value) {
      var k = key.toString().replaceAll(" ", "_");
      var v = value.toString().replaceAll(" ", "_");
      // print("k: $k, v: $v");
      out[k] = v;
    });
  }

  Smartlook.trackCustomEvent(eventName, out);

  await store.state.analytics.logEvent(name: eventName, parameters: out);

  try {
    
    store.state.facebookAppEvents.logEvent(
      name: eventName,
      parameters: out,
    );
  } catch (err) {
    print("Caught facebook app events initStore error");
  }
}

// ignore: non_constant_identifier_names
void ANALYTICS_logScreenEnteredEvent(
    Store<AppState> store, String screenName) async {
  screenName = screenName.replaceAll(" ", "_");

  try {

    Smartlook.trackNavigationEvent(
        screenName,
        SmartlookNavigationEventType
            .enter); // Can also use another for screen closed.

    await store.state.analytics.setCurrentScreen(screenName: screenName);
  
  } catch (err) {
    print("Caught error trying to log screen entered event: $err");
  }
}

void ANALYTICS_logPurchase(Store<AppState> store, ProductDetails pd) {
  // store.state.facebookAppEvents.logPurchase(
  //   amount: pd.price.toString(),
  // );
}

// https://firebase.flutter.dev/docs/crashlytics/usage
void ANALYTICS_logErrorEvent(Store<AppState> store, String errorText) {
  store.state.crashlytics.log(errorText);

  String email = readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);

  logError(store, {
    "email": email,
    "error": errorText,//json.encode(errorText),
    "date": DateTime.now().toString(),
  });
}
