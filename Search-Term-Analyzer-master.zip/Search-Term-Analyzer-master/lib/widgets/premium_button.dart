import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/pages/purchaseable_products_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/purchaseable_products_dialog.dart';
Widget premiumButton(BuildContext context) {
  return StoreConnector<AppState, Store<AppState>>(
    converter: (store) => store,
    builder: (context, store) {
      return //SizedBox(
        // width: double.infinity,
          // AnimatedPositioned(
          //   bottom: store.state.showLoadingToast ? 10 : -40,
          //   right: 10,
          //   // width: 150,//MediaQuery.of(context).size.width,
          //   height: 40.0,
          //   duration: const Duration(milliseconds: 250),
          //   curve: Curves.ease,
          //   child: AnimatedOpacity(
          // opacity: store.state.showLoadingToast ? 1.0 : 0.0,
          // duration: const Duration(milliseconds: 150),
          // child:
          // child: 
          GestureDetector(
        onTap: () {
          // Navigator.of(context).push(
          //   new MaterialPageRoute(builder: (context) {
          //     return PurchaseableProductsPage(store);
          //   }),
          // );

          ANALYTICS_logEvent(store, 'Show products pressed from side menu');

          showDialog(
            context: context,
            builder: (BuildContext context) {
              return PurchaseableProductsDialog(store);
            }
          );
        },
        child: Row(
          // mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              // width: 50,
              // margin: EdgeInsets.only(top: 15),
              height: 50,
              padding: EdgeInsets.only(left: 25, right: 25, top: 5, bottom: 5),
              decoration: BoxDecoration(
                // color: Colors.orange,
                // color: Colors.white,
                color: Colors.blue,
              
                // gradient: LinearGradient(
                //   begin: Alignment.bottomCenter,
                //   end: Alignment.topCenter,
                //   colors: [Color.fromRGBO(38, 120, 52,1), Color.fromRGBO(52,168,83,1)],
                // ),
                borderRadius: BorderRadius.all(Radius.circular(50)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.25),
                    spreadRadius: 2,
                    blurRadius: 1.5,
                    offset: Offset(2, 2), // changes position of shadow
                  ),
                ],
              ),
              child: Center(
                // fit: FlexFit.loose,
                child: Text(
                  "Search Terms Manager PRO", //"Get more",//"Premium features",//"Save with premium",
                  overflow: TextOverflow.ellipsis,
                  softWrap: false,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Colors.white,//white,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
          // ),
      );
      // ),
      // );
    },
  );
}
