import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/pages/date_range_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/metrics_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/order_filters_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/search_term_filters_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/search_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class DateRangeBar extends StatelessWidget {
  int currentIndex;

  DateRangeBar(this.currentIndex);

  @override
  Widget build(BuildContext context) => Container(
      width: MediaQuery.of(context).size.width,
      child: StoreConnector<AppState, Store<AppState>>(
          converter: (store) => store,
          builder: (context, store) => GestureDetector(
              onTap: () {
                ANALYTICS_logEvent(store, 'Top Date Range Bar Selected');
                Navigator.push(
                    context,
                    new MaterialPageRoute(
                        builder: (context) => DateRangePage(
                            store.state.currentManager.timeZone)));
              },
              child: Material(
                elevation: 2,
                child: Container(
                    padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                    width: MediaQuery.of(context).size.width / 3,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border(
                        bottom: BorderSide(width: 1.0, color: Colors.black12),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Flexible(
                          fit: FlexFit.loose,
                          child: Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(right: 5),
                                child: Icon(
                                  Icons.calendar_today_rounded,
                                  color: Colors.black87,
                                ),
                              ),
                              StoreConnector<AppState, CustomerClient>(
                                converter: (store) =>
                                    store.state.currentManager,
                                builder: (context, currentManager) => Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      store.state.currentDateRange.getName(),
                                      // + currentDateRange.getAdditionalName(),
                                      textAlign: TextAlign.left,
                                      overflow: TextOverflow.ellipsis,
                                      softWrap: false,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black87),
                                    ),
                                    store.state.currentDateRange.getName() ==
                                                "Today" ||
                                            store.state.currentDateRange
                                                    .getName() ==
                                                "Yesterday"
                                        ? Text(
                                            date2String(epochTime2Date(
                                              //epochToLocalEpoch(
                                              store.state.currentDateRange
                                                  .upperEpochDate,
                                              //currentManager.timeZone)
                                            )),
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 11,
                                              color: Colors.black87
                                                  .withOpacity(.5),
                                            ),
                                          )
                                        : store.state.currentDateRange
                                                    .getName() !=
                                                "All Time"
                                            ? Text(
                                                date2String(epochTime2Date(
                                                      // epochToLocalEpoch(
                                                      store
                                                          .state
                                                          .currentDateRange
                                                          .lowerEpochDate,
                                                      // currentManager.timeZone)
                                                    )) +
                                                    " to " +
                                                    date2String(epochTime2Date(
                                                      //epochToLocalEpoch(
                                                      store
                                                          .state
                                                          .currentDateRange
                                                          .upperEpochDate,
                                                      //currentManager.timeZone)
                                                    )),
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 11,
                                                  color: Colors.black87
                                                      .withOpacity(.5),
                                                ),
                                              )
                                            : SizedBox.shrink()
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 7.5,
                              ),
                              // Custom date range column.
                              // currentDateRange.getAdditionalName().contains(' to ')
                              // ? Column(
                              //   children: [
                              //     Text(currentDateRange.getAdditionalName().split(" to ")[0] + ' to',
                              //     style: TextStyle(
                              //       fontWeight: FontWeight.bold,
                              //       fontSize: 12,
                              //       color: Colors.black87.withOpacity(.5)),),
                              //     // Text("to", style: TextStyle(
                              //     //   fontWeight: FontWeight.bold,
                              //     //   fontSize: 10,
                              //     //   color: Colors.black87),),
                              //     Text(currentDateRange.getAdditionalName().split(" to ")[1] + '    ',
                              //     style: TextStyle(
                              //       fontWeight: FontWeight.bold,
                              //       fontSize: 12,
                              //       color: Colors.black87.withOpacity(.5)),)
                              //   ]
                              // )
                              // : Container()
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            // StoreConnector<AppState, Store<AppState>>(
                            //     converter: (store) => store,
                            //     builder: (context, store) =>
                            //         // For now, always enabled, since campaigns and adGroups pages have been removed.
                            //         store.state.currentPageIndex == 2 || true
                            //             ? GestureDetector(
                            //                 onTap: () {
                            //                   Navigator.of(context).push(
                            //                     new MaterialPageRoute(
                            //                         builder: (context) {
                            //                       return OrderFiltersPage(
                            //                           store);
                            //                     }),
                            //                   );
                            //                 },
                            //                 child: Icon(
                            //                   Icons.swap_vert_outlined,
                            //                   color: Colors.black54,
                            //                   size: 28,
                            //                 ))
                            //             : Container()),
                            StoreConnector<AppState, Store<AppState>>(
                                converter: (store) => store,
                                builder: (context, store) =>
                                    // For now, always enabled, since campaigns and adGroups pages have been removed.
                                    store.state.currentPageIndex == 2 || true
                                        ? Container(
                                            margin: EdgeInsets.fromLTRB(
                                                10, 0, 5, 0),
                                            child: GestureDetector(
                                                onTap: () {
                                                  ANALYTICS_logEvent(store,
                                                      'Filter Button Pressed From Main Page');
                                                  Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (context) {
                                                      return SearchTermFiltersPage(
                                                          store);
                                                    }),
                                                  );
                                                },
                                                child: Icon(
                                                  Icons.filter_alt,
                                                  color: Colors.black54,
                                                  size: 28,
                                                )),
                                          )
                                        : Container()),
                            // StoreConnector<AppState, Store<AppState>>(
                            //   converter: (store) => store,
                            //   builder: (context, store) => Container(
                            //     margin: EdgeInsets.fromLTRB(10, 0, 5, 0),
                            //     child: GestureDetector(
                            //       onTap: () {
                            //         Navigator.of(context).push(
                            //             new MaterialPageRoute(
                            //                 builder: (context) {
                            //           return SearchPage(store);
                            //         }));
                            //       },
                            //       child: Icon(
                            //         Icons.search,
                            //         color: Colors.black54,
                            //         size: 28,
                            //       ),
                            //     ),
                            //   ),
                            // ),
                            StoreConnector<AppState, Store<AppState>>(
                              converter: (store) => store,
                              builder: (context, store) => Container(
                                margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                                child: GestureDetector(
                                  onTap: () {
                                    ANALYTICS_logEvent(store,
                                        'Columns Button Selected From Main Page');
                                    Navigator.of(context).push(
                                        new MaterialPageRoute(
                                            builder: (context) {
                                      // switch (this.currentIndex) {
                                      //   case 0:
                                      //     return MetricsPage("CAMPAIGN", store);
                                      //   case 1:
                                      //     return MetricsPage("ADGROUPS", store);
                                      //   case 2:
                                      return MetricsPage("SEARCHTERMS", store);
                                      //   default:
                                      //     return null;
                                      // }
                                    }));
                                  },
                                  child: Icon(
                                    Icons.view_column_outlined,
                                    color: Colors.black54,
                                    size: 28,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    )),
              ))));
}

// child: Align(
// alignment: Alignment.centerLeft,
// child: Text(
//   currentDateRange.getName(),
//   textAlign: TextAlign.left,
//   style: TextStyle(
//       fontWeight: FontWeight.bold,
//       fontSize: 17,
//       color: Colors.black87),
// ))
