// import 'package:flutter/material.dart';

// class SnackBarFilter() extends StatelessWidget {
//     const SnackBarFilter({Key? key},
//      @required String text) : super(key: key);

//     @override
//     Widget build(BuildContext context) {
//         return ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//                 content: Text("Filtering on $text"),
//                 duration: Duration(seconds: 10),
//                 action: SnackBarAction(
//                     label: 'View',
//                     onPressed: () {
//                         // Navigate to index
//                     }
//                 )
//             )   
//         );
//     }
// }