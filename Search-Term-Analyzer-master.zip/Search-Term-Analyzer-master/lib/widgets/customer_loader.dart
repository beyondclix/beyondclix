// Loading customers at the very start.
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/auth.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';

class CustomerLoader extends StatelessWidget {
  CustomerLoader();

  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, AppState>(
      converter: (store) => store.state,
      builder: (context, state) => 
        Container(
          color: Colors.white,
          child: state.totalCustomers == -1 
              ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Searching for accounts", 
                    style: TextStyle(
                      color: Color.fromRGBO(55,55,55,.75),//Color.fromRGBO(75, 95, 135, .7),
                      fontSize: 18,
                    )),
                    SizedBox(height: 25),
                    CircularProgressIndicator()
                  ]),
              )
              : state.isLoadingCustomers < state.totalCustomers 
                && state.totalCustomers != 0
            ? 
            // Material(
            //   elevation: 10,
            //   child: 
              Center(
                child: Container(
                  padding: EdgeInsets.fromLTRB(50, 25, 50, 25),
                    // decoration: BoxDecoration(
                    //   color: Colors.white,
                    //   borderRadius: BorderRadius.all(Radius.circular(6)),
                    //   boxShadow: [
                    //     BoxShadow(
                    //       color: Colors.grey.withOpacity(0.5),
                    //       spreadRadius: 2,
                    //       blurRadius: 3.5,
                    //       offset: Offset(0, 3.5), // changes position of shadow
                    //     ),
                    //   ],
                    // ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          // "Loading accounts: ${state.isLoadingCustomers} / ${state.totalCustomers}",
                          "Loading ${state.totalCustomers} account" + (state.totalCustomers > 1 ? "s" : ""),
                          style: TextStyle(
                            fontSize: 18,
                            color: Color.fromRGBO(55,55,55,.75),
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(height: 25),
                        CircularProgressIndicator()
                      ],
                    ),
                ),
              
            )
            
            // Only show this if a customer was not enabled and no accounts were loaded.
            // Don't need to show this if some accounts were loaded.
            : state.customers.length > 0
            ? SizedBox.shrink()
            : GLOBAL_customerNotEnabled == true || (state.customers.length == 0
              && state.isFinishedLoadingCustomers) // This has to be true to display this. API has to be called.
              ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // state.customers.length == 0
                    //   ? Icon(
                    //     Icons.warning_amber,
                    //     size: 55,
                    //     color: Color.fromRGBO(237, 179, 62, 1),//Colors.yellow,
                    //   )
                    //   : SizedBox.shrink(),
                    state.customers.length == 0 && state.isFinishedLoadingCustomers
                    ? Container(
                      margin: EdgeInsets.all(15),
                      child: Column(
                        children: [
                          Text("No Google Ads accounts to display",
                            style: TextStyle(
                              fontSize: 16,
                              color: Color.fromRGBO(55,55,55,75),
                            ),
                          ),
                          SizedBox(height: 15),
                          StoreConnector<AppState, Store<AppState>>(
                            converter: (store) => store,
                            builder: (context, store) => GestureDetector(
                              onTap: () {
                                ANALYTICS_logEvent(
                                  store, 'Use another account pressed');
                                signOut(store);
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                                decoration: BoxDecoration(
                                  color: Colors.blue,
                                  borderRadius: BorderRadius.all(Radius.circular(2)),
                                ),
                                child: Flexible(
                                  child: Text(
                                    "Use another account",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      fontFamily: 'Roboto',
                                      decoration: TextDecoration.none,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                    : SizedBox.shrink(), 
                    GLOBAL_customerNotEnabled && state.customers.length == 0
                    ? Container(
                      // color: Colors.blue,
                      margin: EdgeInsets.only(top: 15),
                      padding: EdgeInsets.all(5),
                      child: Text("One or more accounts were not enabled",
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                    : SizedBox.shrink(),
                    GLOBAL_customerNotEnabled && state.customers.length == 0
                    ? Container(
                      padding: EdgeInsets.all(15),
                      margin: EdgeInsets.only(top: 5),
                      width: MediaQuery.of(context).size.width * .75,
                      child: _bulletRow("Search Terms Manager uses search terms from your linked Google Ads account. Please connect a Google Ads account or finish setting up an existing account."),
                        
                    )
                    : SizedBox.shrink(),
                    GLOBAL_customerNotEnabled && state.customers.length == 0
                    ? Container(
                      padding: EdgeInsets.all(15),
                      margin: EdgeInsets.only(top: 5),
                      width: MediaQuery.of(context).size.width * .75,
                      child: _bulletRow("If you believe this error is a mistake, please send an email to $FEEDBACK_URL and let us know."),
                    )
                    : SizedBox.shrink()
                  ],
                ),
              )
              :SizedBox.shrink(),
      ),
    );
  }
}

Widget _bulletRow(String text) {
  return Row(
    children: [
      Icon(
        // Icons.radio_button_unchecked,
        // Icons.priority_high,
        Icons.report_gmailerrorred,
        color: Color.fromRGBO(55,55,55,.85),
        // color: Colors.blue,
      ),
      SizedBox(width: 15),
      Flexible(
        child: Text(text, 
          style: TextStyle(
            fontSize: 12,
            color: Color.fromRGBO(55,55,55,.75),
          ),
        ),
      ),
    ]
  );
}