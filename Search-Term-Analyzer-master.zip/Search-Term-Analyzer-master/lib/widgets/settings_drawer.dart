// Settings drawer that appears on the side.
/*
    Handles versioning.
    Handles account switch
    Handles account premium level, and displays who it is linked to.
    Displays the number of Search Terms loaded.
    Option to clear all data.
*/

import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/models/membership_type.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/auth.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/widgets/premium_button.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';

class SettingsDrawer extends StatelessWidget {

  final Uri _feedbackUrl = Uri.parse('mailto:' + FEEDBACK_URL);

  void _launchUrl(Store store, Uri url, {Uri fallbackUrl}) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.externalApplication,
    )) {
      // mode: LaunchMode.inAppWebView)) {
      ANALYTICS_logEvent(store,
          "Error launching $url, using fallback https URL: $fallbackUrl");

      if (fallbackUrl != null) {
        if (await launchUrl(
          fallbackUrl,
          // mode: LaunchMode.inAppWebView,
        )) {
          ANALYTICS_logEvent(
              store, "Successfully Launched fallback Url");
        } else {
          ANALYTICS_logEvent(
              store, "Error launching fallback URL: $fallbackUrl");
        }
      }

      // throw 'Could not launch $_feedbackUrl';
    } else {
      ANALYTICS_logEvent(store, "Successfully Launched feedback Url");
    }
  }

  Widget _accountTile() {
    String imageUrl = readSharedPreferenceValue(
        SHARED_PREFERENCE_KEYS.CURRENT_USER_PHOTO_URL);
    String username =
        readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_NAME);
    String email =
        readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);

    return Container(
      padding: EdgeInsets.only(left: 7.5, right: 7.5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(6)),
        color: Colors.white, //.withOpacity(.5),
      ),
      child: Row(
          // crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.max,
          children: [
            Flexible(
              fit: FlexFit.loose,
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  imageUrl != null && imageUrl != ""
                      ? Container(
                          width: 50.0,
                          height: 50.0,
                          decoration: new BoxDecoration(
                              shape: BoxShape.circle,
                              image: new DecorationImage(
                                  fit: BoxFit.fill,
                                  image: new NetworkImage(imageUrl))
                              //         Image.network(readSharedPreferenceValue(
                              // SHARED_PREFERENCE_KEYS.CURRENT_USER_PHOTO_URL))
                              ))
                      : Icon(Icons.person),
                  Flexible(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        username != null
                            ? Container(
                                margin: EdgeInsets.only(left: 10),
                                child: Text(username,
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontSize: 16,
                                    )),
                              )
                            : SizedBox.shrink(),
                        email != null
                            ? Container(
                                padding: EdgeInsets.only(left: 10, top: 5),
                                child: Text(
                                  email,
                                  overflow: TextOverflow.ellipsis,
                                  softWrap: false,
                                  style: TextStyle(
                                    fontSize: 12,
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              )
                            : SizedBox.shrink(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            StoreConnector<AppState, Store<AppState>>(
              converter: (store) => store,
              builder: (context, store) => GestureDetector(
                  child: Icon(Icons.close),
                  onTap: () {
                    ANALYTICS_logEvent(store, 'Sign out pressed');

                    Widget alertDialog = AlertDialog(
                      title: Text("Are you sure you want to sign out?"),
                      content: Container(
                          margin: EdgeInsets.only(
                            top: 15,
                          ),
                          child:
                              Column(mainAxisSize: MainAxisSize.min, children: [
                            Text(
                                "The search terms you selected to save will not be deleted."),
                            SizedBox(height: 35),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () {
                                    ANALYTICS_logEvent(
                                        store, 'Sign out cancelled');

                                    Navigator.of(context).pop();
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.rectangle,
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color:
                                            Color.fromRGBO(155, 155, 155, .25),
                                      ),
                                    ),
                                    padding:
                                        EdgeInsets.fromLTRB(15, 10, 15, 10),
                                    margin: EdgeInsets.only(right: 15),
                                    child: Text('Cancel',
                                        style: TextStyle(
                                            color:
                                                Colors.black.withOpacity(.75))),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    ANALYTICS_logEvent(
                                        store, 'Sign out confirmed');

                                    Navigator.of(context).pop(true);
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.blue,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    padding:
                                        EdgeInsets.fromLTRB(15, 10, 15, 10),
                                    child: Text('Ok',
                                        style: TextStyle(color: Colors.white)),
                                  ),
                                ),
                              ],
                            ),
                          ])),
                    );
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return alertDialog;
                      },
                    ).then(
                      (response) {
                        print("response: $response");
                        if (response != null) {
                          signOut(store);
                        }
                      },
                    );
                  }),
            ),
          ]),
    );
  }

  Widget _membershipWidget(MembershipType membershipType) {
    if (membershipType == null) {
      membershipType = MEMBERSHIP_TYPES["FREE"];
    }

    return Container(
      padding: EdgeInsets.fromLTRB(5, 20, 5, 20),
      decoration: BoxDecoration(
        color: membershipType.color,
        borderRadius: BorderRadius.all(Radius.circular(6)),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade900, //grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 3.5,
            offset: Offset(2, 2), // changes position of shadow
          ),
        ],
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [membershipType.colorDark, membershipType.color],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          //   ],
          // ),
          Container(
            padding: EdgeInsets.fromLTRB(15, 10, 15, 25),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.only(top: 15, bottom: 15),
                  child: membershipType.icon,
                ),
                // Icon(
                //   membershipType.iconData,
                //   color: membershipType.displayIconColor,
                // ),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(left: 15),
                    child: Text(membershipType.displayName,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          color: membershipType.skuId == "FREE"
                              ? Colors.black
                              : Colors.white,
                        )),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  build(BuildContext context) {
    return Drawer(
      child: Container(
        // padding: EdgeInsets.all(15),
        // color: Colors.blue,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.bottomLeft,
            end: Alignment.topRight,
            // colors: [Colors.white.withOpacity(.0), membershipType.color],
            colors: [
              /*Colors.tealAccent.shade700, */ Colors.blue.shade900,
              Colors.blue
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          // padding: EdgeInsets.zero,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 100,
                  child: DrawerHeader(
                    decoration: BoxDecoration(
                      color: Colors.blue,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Center(
                          child: Container(
                            // height: 150,
                            child: Text(
                              'Settings',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        ),
                        // GestureDetector(
                        //   child: Icon(Icons.close, color: Colors.white),
                        //   onTap: () {
                        //     Navigator.pop(context);
                        //   }
                        // ),
                      ],
                    ),
                  ),
                ),
                ListTile(
                  // title: const Text('Account', style: TextStyle(
                  //   fontSize: 18,
                  //   ),
                  // ),
                  title: Container(
                    height: 85,
                    child: _accountTile(),
                  ),
                  onTap: () {},
                ),
                // StoreConnector<AppState, Store<AppState>>(
                //   converter: (store) => store,
                //   builder: (context, store) => ListTile(
                //     title: const Text('Sign out', style: TextStyle(
                //       fontSize: 18,
                //       ),
                //     ),
                //     onTap: () {
                //       // Widget alertDialog = AlertDialog(
                //       //     title: Text("Are you sure you want to sign out?"),
                //       //     content: Container(
                //       //       margin: EdgeInsets.only(top: 15,),
                //       //       child: Row(
                //       //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //       //         children: [
                //       //           InkWell(
                //       //             onTap: () {
                //       //               Navigator.of(context).pop();
                //       //             },
                //       //             child: Container(
                //       //               decoration: BoxDecoration(
                //       //                 color: Color.fromRGBO(200,200,200,1),
                //       //                 borderRadius: BorderRadius.circular(6),
                //       //               ),
                //       //               padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                //       //               margin: EdgeInsets.only(right: 15),
                //       //               child: Text('Cancel', style: TextStyle(color: Colors.white)),
                //       //             ),
                //       //           ),
                //       //           InkWell(
                //       //               onTap: () {
                //       //                 Navigator.of(context).pop(true);
                //       //               },
                //       //               child: Container(
                //       //                 decoration: BoxDecoration(
                //       //                   color: Colors.blue,
                //       //                   borderRadius: BorderRadius.circular(6),
                //       //                 ),
                //       //                 padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                //       //                 child: Text('Ok', style: TextStyle(color: Colors.white)),
                //       //             ),
                //       //           ),
                //       //         ],
                //       //       ),
                //       //     ),
                //       // );
                //       // showDialog(
                //       //   context: context,
                //       //   builder: (BuildContext context) {
                //       //     return alertDialog;
                //       //   },
                //       // ).then(
                //       //   (response) {
                //       //     print("response: $response");
                //       //     if (response != null) {
                //       //       signOut(store);
                //       //     }
                //       //   },
                //       // );
                //     },
                //   ),
                // ),
                SizedBox(height: 15),
                Flexible(
                  fit: FlexFit.loose,
                  // flex: 1,
                  child: Container(
                    // color: Color.fromRGBO(52, 168, 83, 1),
                    child: Text(
                      "My membership", //"MEMBERSHIP",
                      style: TextStyle(
                        // fontSize: 16,
                        // decoration: TextDecoration.underline,
                        color: Colors.white.withOpacity(
                            0.85), //Color.fromRGBO(52, 168, 83, 1),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 2.5),
                StoreConnector<AppState, Store<AppState>>(
                  converter: (store) => store,
                  builder: (context, store) => ListTile(
                      title: _membershipWidget(store.state.membershipType)),
                ),
                SizedBox(height: 25),

                Text("Save anytime with",
                    style: TextStyle(
                      color: Colors.white.withOpacity(.75),
                      // fontSize: 15,
                    )),
                SizedBox(height: 2.5),
                // Row(
                // children: [
                // padding: EdgeInsets.all(25),
                // leading:
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    premiumButton(context),
                  ],
                ),
              ],
            ),

            // StoreConnector<AppState, Store<AppState>>(
            //   converter: (store) => store,
            //   builder: (context, store) {
            //     if (store.state.databaseSize == null || store.state.databaseSize == "") {
            //       getDatabaseSize(store);
            //     }
            //     return ListTile(
            //       title: Text(
            //         'Latest data date: ${store.state.mostRecentDataDate}',
            //         style: TextStyle(
            //           // fontSize: 16,
            //           color: Colors.white,
            //         ),
            //       ),
            //       trailing: Icon(
            //         Icons.refresh,
            //         color: Colors.white.withOpacity(.5),
            //       ),
            //       onTap: () {
            //         // TODO animate/spin/rotate the refresh icon.
            //         getDatabaseSize(store);
            //       },
            //     );
            //   }
            // ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                StoreConnector<AppState, Store<AppState>>(
                  converter: (store) => store,
                  builder: (context, store) => GestureDetector(
                    onTap: () {
                      ANALYTICS_logEvent(
                          store, "Pressed GIVE FEEDBACK");
                      _launchUrl(store, Uri.parse(FEEDBACK_FALLBACK_URL),
                          fallbackUrl: _feedbackUrl);
                    },
                    child: Container(
                      color: Colors.blue,
                      padding:
                          EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                      margin: EdgeInsets.only(top: 15, bottom: 5, left: 15),
                      child: Text(
                        "GIVE FEEDBACK",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
                StoreConnector<AppState, Store<AppState>>(
                  converter: (store) => store,
                  builder: (context, store) {
                    if (store.state.databaseSize == null ||
                        store.state.databaseSize == "") {
                      getDatabaseSize(store);
                    }
                    return ListTile(
                      title: Text(
                        'Stored Data: ${store.state.databaseSize}',
                        style: TextStyle(
                          // fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                      trailing: Icon(
                        Icons.refresh,
                        color: Colors.white.withOpacity(.5),
                      ),
                      onTap: () {
                        print("Recalculating data");
                        // TODO animate/spin/rotate the refresh icon.
                        getDatabaseSize(store);

                        ANALYTICS_logEvent(store, 'Recalculating data preseed');
                      },
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
