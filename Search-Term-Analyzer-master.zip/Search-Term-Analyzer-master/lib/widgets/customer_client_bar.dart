import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';
import 'package:searchTermAnalyzerFlutter/pages/customer_client_list_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';

class CustomerClientBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 20,
      child: Container(
        color: Colors.blue,
        // padding: EdgeInsets.all(6),
        // padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
        // height: 50,
        // width: MediaQuery.of(context).size.width / 3,
        // decoration: BoxDecoration(
        //     color: Colors.blue,
        //     border: Border(
        //       bottom: BorderSide(width: 1.0, color: Colors.black12),
        //     ),
        //     boxShadow: [
        //       BoxShadow(
        //         color: Colors.red, //.grey.withOpacity(0.35),
        //         spreadRadius: 5,
        //         blurRadius: 25,
        //         offset: Offset(0, 0), // changes position of shadow
        //       ),
        //     ]),
        child: StoreConnector<AppState, Store<AppState>>(
          converter: (store) => store,
          builder: (context, store) => GestureDetector(
              onTap: () async {
                ANALYTICS_logEvent(store, 'Top Customer Client Bar Selected');
                List<CustomerClient> customerClients =
                    await CustomerClient.fromMaps(store);
                customerClients = customerClients
                    .where((cc) => cc.id != store.state.currentCustomer.id)
                    .toList();
                store.dispatch((x) =>
                    updateVisibleCustomerClientsAction(store, customerClients));
                Navigator.push(
                    context,
                    new MaterialPageRoute(
                        builder: (context) => CustomerClientListPage(store)));
              },
              child: store.state.currentCustomer != null &&
                      store.state.currentManager != null &&
                      store.state.currentCustomer.id !=
                          store.state.currentManager.id
                  ? Container(
                      padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                              fit: FlexFit.loose,
                              // padding: EdgeInsets.only(right: 13.0),
                              child: Text(
                                store.state.currentManager != null &&
                                        store.state.currentManager.name != ""
                                    ? store.state.currentManager.name
                                    : "Select Customer Client",
                                overflow: TextOverflow.ellipsis,
                                softWrap: false,
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 20,
                                    color: Colors.white),
                              )),
                          Icon(
                            Icons.arrow_drop_down,
                            color: Colors.white,
                            size: 32,
                          )
                        ],
                      ),
                    )
                  : SizedBox.shrink()),
        ),
      ),
    );
  }
}
