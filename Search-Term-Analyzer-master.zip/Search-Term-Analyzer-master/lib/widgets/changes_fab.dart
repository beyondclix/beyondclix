// Animated Floating Action Button
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/pages/changes_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class ChangesFAB extends StatefulWidget {
  const ChangesFAB({Key key});

  @override
  _ChangesFABState createState() => _ChangesFABState();
}

class _ChangesFABState extends State<ChangesFAB>
    with SingleTickerProviderStateMixin {
  AnimationController _animationController;

  Animation<double> _visibilityAnimation;
  bool _isVisible = false;
  final double directionInDegrees = 90;
  final double maxDistance = 115;

  @override
  void initState() {
    super.initState();
    this._animationController = AnimationController(
        value: _isVisible ? 1.0 : 0.0,
        duration: Duration(milliseconds: 250),
        vsync: this);
    this._visibilityAnimation = CurvedAnimation(
        parent: _animationController,
        curve: Curves.fastOutSlowIn,
        reverseCurve: Curves.easeOutQuad);
  }

  @override
  void dispose() {
    this._animationController.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() {
      _isVisible = !_isVisible;
      if (_isVisible) {
        this._animationController.forward();
      } else {
        this._animationController.reverse();
      }
    });
  }

  void _pressed(BuildContext context, Store<AppState> store) {
    Navigator.of(context)
        .push(new MaterialPageRoute(builder: (context) => ChangesPage(store)));
  }

  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, Store<AppState>>(
      converter: (store) => store,
      builder: (context, store) => GestureDetector(
        onTap: () {
          ANALYTICS_logEvent(store, 'Search Terms To Save Button Pressed', {
            "numberOfChanges": store.state.positiveKeywords.length +
                store.state.negativeKeywords.length
          });

          this._pressed(context, store);
        },
        child: SizedBox.expand(
          child: StoreConnector<AppState, int>(
            converter: (store) {
              // Check whether or not to toggle animation
              int combinedLength = store.state.positiveKeywords.length +
                  store.state.negativeKeywords.length;
              if (combinedLength == 0 && this._isVisible) {
                this._toggle();
              } else if (combinedLength > 0 && !this._isVisible) {
                this._toggle();
              }
              return combinedLength;
            },
            builder: (context, totalChangesCount) => AnimatedBuilder(
                animation: this._visibilityAnimation,
                // child: FadeTransition(opacity: this._visibilityAnimation, child: ),
                builder: (context, child) {
                  final offset = Offset.lerp(Offset(-50, 0), Offset(7.5, 0),
                      this._visibilityAnimation.value);
                  // Offset.fromDirection(
                  //     directionInDegrees * (math.pi / 180.0),
                  //     this._visibilityAnimation.value * maxDistance);
                  return Stack(
                    // alignment: Alignment.bottomRight,
                    // clipBehavior: Clip.none,
                    children: [
                      // _buildTapToCloseFab(),
                      // ..._

                      Positioned(
                        bottom: 40,
                        left: offset.dx,
                        child: Transform.translate(
                          offset: offset,
                          // Transform.rotate(
                          //   angle: (1.0 - this._visibilityAnimation.value) *
                          //       math.pi /
                          //       2,
                          child: Container(
                              decoration: BoxDecoration(color: Colors.white,
                                  // shape: BoxShape.circle,
                                  boxShadow: [
                                    // BoxShadow(
                                    //   color: Colors.grey.withOpacity(1),
                                    //   spreadRadius: 1,
                                    //   blurRadius: 2,
                                    //   offset: Offset(
                                    //       0, 0), // changes position of shadow
                                    // ),
                                  ]),
                              child: Container(
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      // color: Colors.white,
                                      border: Border.all(
                                        color: Color.fromRGBO(0, 0, 0, .2),
                                        width: 1.0,
                                      ),
                                      borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(4),
                                          bottomRight: Radius.circular(4))),
                                  child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.cached,
                                            color: Colors.blue, size: 30),
                                        Text(
                                            totalChangesCount.toString() +
                                                ' change${totalChangesCount == 1 ? '' : 's'}',
                                            style: TextStyle(
                                                color: Colors.blue,
                                                fontSize: 12)),
                                        // Text('changes',
                                        //     style: TextStyle(
                                        //         color: Colors.blue, fontSize: 12))
                                      ]))),
                        ),
                      )
                      // Stack(children: [
                      //   Positioned(
                      //       // top: 0,
                      //       bottom: 0,
                      //       left: 0,
                      //       child: Container(
                      //           padding: EdgeInsets.all(4),
                      //           decoration: BoxDecoration(
                      //               shape: BoxShape.circle,
                      //               color: Colors.white,
                      //               border: Border.all(
                      //                 color: Color.fromRGBO(0, 0, 0, 0.2),
                      //                 width: 1.0,
                      //               ),
                      //               boxShadow: [
                      //                 BoxShadow(
                      //                   color: Colors.grey.withOpacity(0.35),
                      //                   spreadRadius: 1,
                      //                   blurRadius: 2,
                      //                   offset: Offset(
                      //                       0, 0), // changes position of shadow
                      //                 ),
                      //               ]),
                      //           child: Text(changes.length.toString(),
                      //               style: TextStyle(
                      //                   color: Colors.blue, fontSize: 18))))
                      // ])
                    ],
                  );
                }),
          ),
        ),
      ),
    );
  }
}
