// Expands list items when pressed
// https://stackoverflow.com/questions/50530152/how-to-create-expandable-listview-in-flutter

import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/string_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/order_value.dart';
import 'package:searchTermAnalyzerFlutter/pages/adgroups_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';

const ORDER_SEQUENCE = {
  0: "", // NO ACTION
  1: "ASC",
  2: "DESC",
};

class ExpandableOrderItem extends StatefulWidget {
  final Store<AppState> _store;
  final String title;
  final List<FilterValue> items;

  ExpandableOrderItem(this.title, this.items, this._store);

  @override
  _ExpandableOrderItemState createState() => new _ExpandableOrderItemState();
}

class _ExpandableOrderItemState extends State<ExpandableOrderItem> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: true,
      child: ExpansionTile(
        title: Text(
          widget.title,
          style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic),
        ),
        children: <Widget>[
          SafeArea(
              bottom: true, child: Column(children: _buildExpandableContent()))
        ],
      ),
    );
  }

  _buildExpandableContent() {
    List<Widget> columnContent = [];

    for (FilterValue content in widget.items) {
      columnContent.add(
        SafeArea(
          bottom: true,
          child: Column(children: [
            StoreConnector<AppState, AppState>(
              converter: (store) => store.state,
              builder: (context, state) => GestureDetector(
                onTap: () {
                  ANALYTICS_logEvent(widget._store, 'Expanding order subgroup',
                      {"name": content.name});
                  print(
                      "content.name: ${content.name}, ${content.stringFilterType}, ${content.displayName}");
                  // If same item is tapped, increment it.
                  // Otherwise, set it to this.
                  OrderValue ov = state.searchTermOrderBy;
                  ov.displayName = "";

                  if (state.searchTermOrderBy.name == content.name) {
                    int currentValue = state.searchTermOrderBy.value;
                    currentValue += 1;
                    if (currentValue == 3) {
                      currentValue = 0;
                    }
                    ov.value = currentValue;
                  } else {
                    ov.name = content.name;
                    ov.value = 1; // First tap is 'ASC'
                  }
                  // 'string' type
                  if (['text', 'campaignname', 'adgroupname']
                      .contains(content.stringFilterType.toLowerCase())) {
                    ov.valueType = 'string';
                    ov.stringFilterType = content.stringFilterType;
                  } else {
                    ov.valueType = 'num';
                  }
                  ov.groupName = widget.title;
                  ov.displayName = content.displayName != null &&
                          content.displayName.isNotEmpty
                      ? content.displayName
                      : content.name.replaceAll('_', ' ');

                  widget._store.dispatch(StartSearchTermsLoadingAction());
                  widget._store.dispatch(UpdateOrderAction(ov));
                  widget._store.dispatch(
                      (x) => updateVisibleSearchTermsAction(widget._store));
                },
                child: ListTile(
                  contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                  tileColor: Colors.transparent,
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                        width: MediaQuery.of(context).size.width * 0.75,
                        child: content.name != null && content.name.length > 0
                            ? Text(
                                content.displayName.isNotEmpty
                                    ? content.displayName
                                    : content
                                        .name, //convertToDisplayName(content.name),
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.black87))
                            : Container(),
                      ),
                      state.searchTermOrderBy.name.toLowerCase() ==
                              content.name.toLowerCase()
                          ? Text(
                              ORDER_SEQUENCE[state.searchTermOrderBy.value],
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                              ),
                            )
                          : Container(
                              // child: Text(
                              //   "${state.searchTermOrderBy.name}, ${content.name}",
                              //   style: TextStyle(fontSize: 10)
                              // ),
                              ),
                    ],
                  ),
                ),
              ),
            ),
            Divider(
              height: 1,
            ),
          ]),
        ),
      );
    }

    return columnContent;
  }
}
