import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/auth.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';

// Welcome screen.

class WelcomeScreen extends StatelessWidget {
  final Store<AppState> store;
  final String currentAccountId;
  final int appLoadCount;

  bool _isSignInButtonVisible = false;

  WelcomeScreen(this.store, this.currentAccountId, this.appLoadCount) {
    this._isSignInButtonVisible = 
      accessToken == null || accessToken.length == 0 ||
      this.currentAccountId == null || this.currentAccountId.isEmpty ||
      store.state.isShowingSignInButton;

    Future.delayed(const Duration(milliseconds: 2000), () {
      // Use AccessToken to check if user is authenticated.
      if (accessToken != null && accessToken.length > 0) {
        this.store.dispatch(UpdateIsWelcomeScreenShowingAction(false));
      }
      isWelcomeScreenAllowedToHide = true;
    });

    ANALYTICS_logScreenEnteredEvent(this.store, "Sign-in and welcome page");
  }

  Widget _signInButton() {
    return AnimatedOpacity(
      opacity: !store.state.isShowingSignInButton //!_isSignInButtonVisible
          ? 0.0
          : 1.0,
      duration: const Duration(milliseconds: 300),
      child: GestureDetector(
        onTap: () {
          // Immediately hide this, and only reappear if authentication failed.
          // Have to use state management here.
          store.dispatch(UpdateSignInButtonVisibilityAction(false));

          ANALYTICS_logEvent(store, 'Welcome Screen Sign In Pressed');
          signIn(this.store);
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
          decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.all(Radius.circular(2)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            ClipRRect(
              borderRadius: BorderRadius.all(
                Radius.circular(8.0),
              ),
              child: Container(
                // padding: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  // color: Colors.white,
                ),
                child: Image.asset(
                  "lib/assets/google-logo.png",
                  height: 40,
                  width: 40,
                  fit: BoxFit.fill,
                ),
              ),
            ),
            SizedBox(width: 10),
            Flexible(
              child: Text(
                "Secure Sign In ",// To Your Google Ads Account",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  fontFamily: 'Roboto',
                  decoration: TextDecoration.none,
                ),
              ),
            ),
            SizedBox(width: 5),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StoreConnector<AppState, Store<AppState>>(
      converter: (store) => store,
      builder: (context, store) => IgnorePointer(
        ignoring: !store.state.isWelcomeScreenShowing,
        child: AnimatedOpacity(
          opacity: store.state.isWelcomeScreenShowing ? 1.0 : 0,
          duration: const Duration(milliseconds: 300),
          child: Stack(
            children: [
              Container(
                child: Center(
                  child: Container(
                    color: Colors.white,
                  ),
                ),
              ),
              Center(
                child: Container(
                    padding: EdgeInsets.all(25),
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 25),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 1000),
                          curve: Curves.easeOutCirc,
                          margin: EdgeInsets.only(
                            bottom: store.state.isWelcomeScreenShowing
                                ? 0
                                : MediaQuery.of(context).size.height / 2, // 200
                          ),
                          child: Column(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(8.0),
                                  topRight: Radius.circular(8.0),
                                ),
                                child: Image.asset(
                                  'lib/assets/icon.png',
                                  height: 150,
                                  width: 150,
                                  fit: BoxFit.fill,
                                ),
                              ),
                              // SizedBox(height: 5),
                              Text(
                                WELCOME_DESCRIPTION,
                                style: TextStyle(
                                  color: Color.fromRGBO(75, 95, 135, .7),
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,

                                  fontFamily: 'Roboto',
                                  decoration: TextDecoration.none,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 35),
                        _signInButton(),
                        SizedBox(height: 10),
                        Container(
                          child: AnimatedOpacity(
                            opacity: store.state.isShowingSignInButton
                            ? 1.0
                            : 0.0,
                            duration: const Duration(milliseconds: 300),
                            child: Column(
                              children: [
                                SizedBox(height: 25),
                                Container(
                                  margin: EdgeInsets.only(left: 15, right: 15),
                                  child: Row(
                                    children: [
                                      Icon(Icons.info,
                                        color: Color.fromRGBO(75, 95, 135, .7),
                                        size: 16,
                                      ),
                                      SizedBox(width: 5),
                                      Text(
                                        "A Google Ads Account Is Required",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                              color: Color.fromRGBO(75, 95, 135, .7),
                                              fontWeight: FontWeight.w600,
                                              fontSize: 16,
                                              fontFamily: 'Roboto',
                                              decoration: TextDecoration.none,),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 10),
                                Container(
                                  margin: EdgeInsets.only(left: 15, right: 15),
                                  child: Text(
                                    DISCLAIMER_TEXT,
                                    style: TextStyle(
                                        color: Color.fromRGBO(75, 95, 135, .7),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        fontFamily: 'Roboto',
                                        decoration: TextDecoration.none,)),
                                ),
                                SizedBox(height: 10),
                                Container(
                                  margin: EdgeInsets.only(left: 15, right: 15),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Icon(
                                        Icons.lock,
                                        color: Color.fromRGBO(75, 95, 135, .7),
                                        size: 16,
                                      ),
                                      SizedBox(width: 5),
                                      Flexible(
                                        child: 
                                        Text(
                                          "TSL/SSL Secure",
                                          style: TextStyle(
                                            color: Color.fromRGBO(75, 95, 135, .7),
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            fontFamily: 'Roboto',
                                            decoration: TextDecoration.none,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 10),
                                Container(
                                  margin: EdgeInsets.only(left: 15, right: 15),
                                  child: Text(
                                    "Google OAuth handles the entire login process and uses the latest protocols to ensure it is secure. We do not come across or store sensitive data.",
                                    style: TextStyle(
                                      color: Color.fromRGBO(75, 95, 135, .7),
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      decoration: TextDecoration.none,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
