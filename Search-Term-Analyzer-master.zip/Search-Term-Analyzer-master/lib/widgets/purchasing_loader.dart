import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';

class PurchasingLoader extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
        return (
            StoreConnector<AppState, AppState>(
                converter: (store) => store.state,
                builder: (context, state) => state.isPurchasing
                    ? Stack(
                        children: [
                            Flex(
                                direction: Axis.horizontal,
                                children: [
                                    Expanded(
                                        child: Container(
                                            color: Colors.black.withOpacity(.75),//Color.fromRGBO(55,55,55,.75)
                                        ),
                                    ),
                                ],
                            ),
                            Center(
                                child: Container(
                                    padding: EdgeInsets.all(25),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.all(Radius.circular(6)),
                                        // boxShadow: [
                                        //     BoxShadow(
                                        //     color: Colors.grey.withOpacity(0.5),
                                        //     spreadRadius: 2,
                                        //     blurRadius: 3.5,
                                        //     offset: Offset(0, 3.5), // changes position of shadow
                                        //     ),
                                        // ],
                                    ),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                            CircularProgressIndicator(
                                                color: Color.fromRGBO(52, 168, 83, 1),
                                            ),
                                            SizedBox(height: 25),
                                            Text(
                                                state.isSavingKeywords
                                                    ? "Saving keywords"
                                                    : "Doing clever things...", 
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 18,
                                                    decoration: TextDecoration.none,
                                                ),
                                            ),
                                        ]
                                    ),
                                ),
                            ),
                        ],
                    )
                    : SizedBox.shrink(),
            )
        );
    }
}