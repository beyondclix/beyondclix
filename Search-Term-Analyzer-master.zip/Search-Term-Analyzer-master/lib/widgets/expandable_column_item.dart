import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/models/column_group.dart';
import 'package:searchTermAnalyzerFlutter/widgets/on_off_switch.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';

class ExpandableColumnItem extends StatefulWidget {
    final Store<AppState> _store;
    final String title;
    final List<Metric> items;
    final Function updateMetrics;

    ExpandableColumnItem(this.title, this.items, this._store, this.updateMetrics);

    @override
    _ExpandableColumnItemState createState() => new _ExpandableColumnItemState();
}

class _ExpandableColumnItemState extends State<ExpandableColumnItem> {
    @override
    Widget build(BuildContext context) {
        return SafeArea(
            child: ExpansionTile(
                title: Text(
                    widget.title,
                    style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                    )
                ),
                children: <Widget>[
                    SafeArea(
                        bottom: true,
                        child: Column(
                            children: _buildExpandableContent()),
                    ),
                ],
            ),
        );
    }

    Widget _metricItem(Metric metric) {
        return Column(children: [
        ListTile(
            contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
            tileColor: Colors.transparent,
            title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
                Container(
                padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                width: MediaQuery.of(context).size.width * 0.65,
                child: Text(
                    metric.displayName,//convertToDisplayName(metric.name),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.black87),
                    ),
                ),
                OnOffSwitch(metric.name, metric.isOn, widget.updateMetrics),
            ],
            ),
        ),
        Divider(
            height: 1,
        ),
        ]);
    }

    _buildExpandableContent() {
        List<Widget> columnContent = [];

        for (Metric content in widget.items) {
            columnContent.add(
                SafeArea(
                    bottom: true,
                    child: Column(
                        children: [
                            _metricItem(content),
                            Divider(height: 1),
                        ],
                    ),
                ),
            );
        }

        return columnContent;
    }
}