import 'package:flutter/material.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/widgets/on_off_switch.dart';

class SingleColumnItem extends StatefulWidget {
  final Store<AppState> store;
  final String columnName;
  final List<Metric> _metrics;
  final String metricsFor;
  Metric _metric;
  int _metricIndex;

  SingleColumnItem(
      this.store, this.columnName, this._metrics, this.metricsFor) {
        // print('columnName: $columnName');
        // print('this._metrics');
        // for (Metric m in this._metrics) {
        //   print('m.name: ${m.name}');
        // }
    this._metricIndex =
        this._metrics.indexWhere((m) => m.name == this.columnName);
    // print("this._metricIndex: ${this._metricIndex}");
    this._metric = this._metrics[this._metricIndex];
  }

  @override
  _SingleColumnItemState createState() => _SingleColumnItemState();
}

class _SingleColumnItemState extends State<SingleColumnItem> {
  // Update by reference to original state object.
  void updateMetrics(String columnName, bool metricIsOn) {
    this.setState(() {
      widget._metrics[widget._metricIndex].isOn = metricIsOn;
    });
    DB_UpdateMetrics([widget._metrics[widget._metricIndex]], widget.metricsFor);

    widget.store.dispatch(UpdateDisplayMetricsAction(
        widget.metricsFor, widget._metrics, widget.store));
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
      tileColor: Colors.transparent,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
            width: MediaQuery.of(context).size.width * 0.65,
            child: Text(
              widget._metric.displayName,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.black87),
            ),
          ),
          OnOffSwitch(
              widget._metric.name, widget._metric.isOn, this.updateMetrics),
        ],
      ),
    );
  }
}
