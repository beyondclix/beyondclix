// Expands list items when pressed
// https://stackoverflow.com/questions/50530152/how-to-create-expandable-listview-in-flutter

import 'package:flutter/material.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/string_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/options_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/pages/adgroups_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/adgroups_selection_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_selection_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';

class ExpandableFilterItem extends StatefulWidget {
  final Store<AppState> _store;
  final String title;
  final List<FilterValue> items;

  ExpandableFilterItem(this.title, this.items, this._store);

  @override
  _ExpandableFilterItemState createState() => new _ExpandableFilterItemState();
}

class _ExpandableFilterItemState extends State<ExpandableFilterItem> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: true,
      child: ExpansionTile(
          title: Text(
            widget.title,
            style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic),
          ),
          children: <Widget>[
            SafeArea(
                bottom: true,
                child: Column(children: _buildExpandableContent()))
          ]),
    );
  }

  _buildExpandableContent() {
    List<Widget> columnContent = [];

    for (FilterValue content in widget.items) {
      columnContent.add(
        SafeArea(
          bottom: true,
          child: Column(children: [
            GestureDetector(
              onTap: () {
                // print("opening content: ${content.valueType}, ${content.name}, ${content.displayName}");
                // Open popup
                ANALYTICS_logEvent(widget._store, 'Expanding filter subgroup',
                    {"name": content.name});
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    if (content.valueType == "string") {
                      return StringFilterDialog(
                          content.name, "", "", content.displayName, "", "");
                    }
                    else if (content.valueType == "added_excluded") {
                      return OptionsFilterDialog(
                        content.name, "", "", 
                        valueType: content.valueType, 
                        stringFilterType: content.stringFilterType,
                      );
                    }
                    // List of Campaign / AdGroups
                    else if (content.valueType == "campaign") {
                      return CampaignsSelectionPage(false, widget._store);
                    } else if (content.valueType == "adGroup") {
                      return AdGroupsSelectionPage(widget._store);
                    } else {
                      return MetricFilterDialog(
                          content.name, "", "", content.displayName,
                          metricType: content.metricType);
                    }
                  },
                ).then(
                  // newFilterValue is empty for campaign and adgroups.
                  (newFilterValue) => this.setState(() {
                    if (newFilterValue != null) {
                      // This updates the redux store, which is a bad design pattern.
                      // this._filterValues.add(newFilterValue);
                      widget._store.dispatch(StartSearchTermsLoadingAction());
                      widget._store.dispatch(AddFilterAction(newFilterValue));
                      // Don't update filters for campaigns or adgroups.
                      // These are already updated because modifyCurrentAdGroup/modifyCurrentCampaign redux actions are called.
                      if (newFilterValue.name != "Campaign" &&
                          newFilterValue.name != "AdGroup") {
                        widget._store.dispatch((x) =>
                            updateVisibleSearchTermsAction(widget._store));
                      }
                    }
                  }),
                );
              },
              child: ListTile(
                contentPadding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                tileColor: Colors.transparent,
                title: StoreConnector<AppState, AppState>(
                  converter: (store) => store.state,
                  builder: (context, state) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                        width: MediaQuery.of(context).size.width * 0.75,
                        child: Text(
                          content.displayName.isNotEmpty
                              ? content.displayName
                              : content.name,
                          // convertToDisplayName(content.name),
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.black87),
                        ),
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.black54,
                        size: 16.0,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Divider(
              height: 1,
            ),
          ]),
        ),
      );
    }

    return columnContent;
  }
}
