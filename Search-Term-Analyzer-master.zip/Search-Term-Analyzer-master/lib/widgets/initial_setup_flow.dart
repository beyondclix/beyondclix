import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux/redux.dart';
import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/pages/initial_screen.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/pages/logo_page.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:flutter/rendering.dart';

// Using PageView

@immutable
class InitialSetupFlow extends StatefulWidget {
  final Store<AppState> store;

  InitialSetupFlow(this.store);

  @override
  _InitialSetupFlowState createState() => _InitialSetupFlowState();
}

class _InitialSetupFlowState extends State<InitialSetupFlow> {
  GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  final _setupController = new PageController();

  final Uri _feedbackUrl = Uri.parse('mailto:' + FEEDBACK_URL);

  void _launchUrl(Uri url, {Uri fallbackUrl}) async {
    if (!await launchUrl(
      url,
      mode: LaunchMode.externalApplication,
    )) {
      // mode: LaunchMode.inAppWebView)) {
      ANALYTICS_logEvent(widget.store,
          "Error launching $url, using fallback https URL: $fallbackUrl");

      if (fallbackUrl != null) {
        if (await launchUrl(
          fallbackUrl,
          // mode: LaunchMode.inAppWebView,
        )) {
          ANALYTICS_logEvent(
              widget.store, "Successfully Launched fallback Url");
        } else {
          ANALYTICS_logEvent(
              widget.store, "Error launching fallback URL: $fallbackUrl");
        }
      }

      // throw 'Could not launch $_feedbackUrl';
    } else {
      ANALYTICS_logEvent(widget.store, "Successfully Launched feedback Url");
    }
  }

  static const _kDuration = const Duration(milliseconds: 125);
  static const _kCurve = Curves.ease;

  int _pageIndex = 0;

  @override
  void initState() {
    _setupController.addListener(_pageListener);
    super.initState();
  }

  _pageListener() {
    setState(() {
      if (_setupController.position.userScrollDirection == ScrollDirection.reverse) {
        // print("swiped to right: ${_setupController.page.toInt()}");
        _pageIndex = _setupController.page.toInt();
      } else {
        // print("swiped to left: ${_setupController.page.toInt()}");
        _pageIndex = _setupController.page.toInt();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          top: true,
          bottom: true,
          child: Column(children: [
            Flexible(
                child: PageView.builder(
                    controller: _setupController,
                    itemCount: 2,
                    itemBuilder: (BuildContext context, int index) {
                      if (index == 0) {
                        return LogoPage(_navigatorKey, widget.store);
                      }

                      if (index == 1) {
                        return InitialScreen(_navigatorKey, widget.store);
                      } else {
                        return IgnorePointer(
                          ignoring: true,
                          child: SizedBox.shrink(),
                        );
                      }
                    })),
            Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 25, vertical: 20,),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween, // .end
                children: <Widget>[
                  GestureDetector(
                    onTap: () {
                      ANALYTICS_logEvent(
                          widget.store, "Pressed GIVE FEEDBACK");
                      _launchUrl(Uri.parse(FEEDBACK_FALLBACK_URL),
                          fallbackUrl: _feedbackUrl);
                    },
                    child: Container(
                      color: Colors.blue,
                      padding:
                          EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                      margin: EdgeInsets.only(top: 15, bottom: 15),
                      child: Text(
                        "GIVE FEEDBACK",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),

                  GestureDetector(
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.blue),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                      child: Text('Next',
                        style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        )),
                    ),
                    onTap: () {
                      _setupController.nextPage(
                          duration: _kDuration, curve: _kCurve);
                      if (_pageIndex == 1) {
                        widget.store.dispatch(UpdateIsShowingWelcomeScreenAction(false));
                      }
                    },
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


// Using Nested Navigator
// https://docs.flutter.dev/cookbook/effects/nested-nav

// @immutable
// class InitialSetupFlow extends StatefulWidget {
//   final Store<AppState> store;

//   InitialSetupFlow(this.store);

//   @override
//   _InitialSetupFlowState createState() => _InitialSetupFlowState();
// }

// class _InitialSetupFlowState extends State<InitialSetupFlow> {
//   GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

//   @override
//   Widget build(BuildContext context) {
//     return WillPopScope(
//       onWillPop: () async => true, // _isExitDesired
//       child: Scaffold(
//         body: SafeArea(
//           bottom: true,
//           child: MaterialApp(
//             home: Navigator(
//                 key: _navigatorKey,//_navigatorKey,
//                 initialRoute: '/1',
//                 onGenerateRoute: _onGenerateRoute,
//               ),
//           ),
//         ),
//       ),
//     );
//   }

//   Route _onGenerateRoute(RouteSettings settings) {
//     Widget page;
//     switch (settings.name) {
//       case '/1':
//         page = LogoPage(_navigatorKey, widget.store);
//         break;
//       case '/2':
//         page = InitialScreen(_navigatorKey, widget.store);
//         break;
//       default:
//         page = Container();
//         break;
//         // throw Exception('Unknown route: ${settings.name}');
//     }

//     return MaterialPageRoute<dynamic>(
//       builder: (context) {
//         return 
//           DefaultTextStyle(
//             textAlign: TextAlign.left,
//             style: new TextStyle(
//                 inherit: true,
//                 fontSize: 15.0,
//                 color: Colors.black,
//                 fontWeight: FontWeight.w400,
//                 // decoration: TextDecoration.underline,
//                 decorationColor: Colors.black,
//                 decorationStyle: TextDecorationStyle.wavy,
//             ),
//             child: page,
//           );
//       },
//       // settings: settings,
//     );
//   }
// }
