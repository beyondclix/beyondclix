import 'package:flutter/material.dart';

class OnOffSwitch extends StatefulWidget {
  final bool isOn;
  final String label;
  final Function updateParentMetrics;

  OnOffSwitch(this.label, this.isOn, this.updateParentMetrics);

  @override
  _OnOffSwitchState createState() => _OnOffSwitchState(this.label, this.isOn, this.updateParentMetrics);
}

class _OnOffSwitchState extends State<OnOffSwitch> {
  bool _isOn;
  final String _label;
  final Function updateParentMetrics;

  _OnOffSwitchState(this._label, this._isOn, this.updateParentMetrics);

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void toggle(bool value) {
    this.setState(() {
      this._isOn = value;
    });
    this.updateParentMetrics(this._label, this._isOn);
  }

  Widget build(BuildContext context) {
    return Row(
      children: [
        // Text(this._label),
        Switch(
          onChanged: this.toggle,
          value: this._isOn,
          activeColor: Colors.blue,
          activeTrackColor: Color.fromRGBO(225,225,225,1),
          inactiveThumbColor: Color.fromRGBO(200,200,200,1),
          inactiveTrackColor: Color.fromRGBO(225,225,225,1),
        ),
      ],
    );
  }
}
