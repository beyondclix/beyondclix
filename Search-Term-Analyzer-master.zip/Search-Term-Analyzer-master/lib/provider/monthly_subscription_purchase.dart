import 'package:flutter/foundation.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';

class MonthlySubscriptionPurchase extends ChangeNotifier {
  StoreState storeState = StoreState.AVAILABLE;
  List<PurchaseableProduct> products = [
    PurchaseableProduct(
        "Monthly Subscription", "Full access for a monthly fee", '\$9.99')
  ];

  MonthlySubscriptionPurchase();

  Future<void> buy(PurchaseableProduct product) async {
    product.status = ProductStatus.PENDING;
    notifyListeners();
    await Future<void>.delayed(const Duration(seconds: 5));
    product.status = ProductStatus.PURCHASED;
  }
}
