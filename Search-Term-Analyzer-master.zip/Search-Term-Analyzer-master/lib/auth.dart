import 'package:flutter/material.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import './api.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:searchTermAnalyzerFlutter/pages/customers_list_page.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:cron/cron.dart';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:flutter_smartlook/flutter_smartlook.dart';

void authenticate() {
  // FirebaseAuth auth = FirebaseAuth.instance;

  // auth
  //   .authStateChanges()
  //   .listen((User user) {
  //     if (user == null) {
  //       print('User is currently signed out!');
  //     } else {
  //       print('User is signed in!');
  //     }
  //   });
}

final GoogleSignIn _googleSignIn = GoogleSignIn(scopes: [
  // 'https://www.googleapis.com/auth/adsense',
  'https://www.googleapis.com/auth/adwords',
]);

// Called by Welcome screen.
Future<void> signIn(Store<AppState> store) async {
  // // Automatically refreshes credentials by silently refreshing the authentication token.
  // _googleSignIn.signInSilently();

  final GoogleSignInAccount googleUser = await _googleSignIn.signIn();

  // If user cancels signin (presses back button), googleUser is undefined.
  if (googleUser != null) {
    // Obtain the auth details from the request
    final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

    accessToken = googleAuth.accessToken;

    // print("accessToken: $accessToken");

    await signInWithGoogleAuth(store, googleAuth);
  } else {
    // User cancelled signin.
    // Check if we are already logged in, if so, hide this screen.
    store.dispatch(UpdateSignInButtonVisibilityAction(true));
    // if (accessToken != "" && accessToken.isNotEmpty) {
    //   // readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER
    //   store.dispatch(UpdateIsWelcomeScreenShowingAction(false));
    // }
  }

  // if (isWelcomeScreenAllowedToHide) {
  //   store.dispatch(UpdateIsWelcomeScreenShowingAction(false));
  // }
}

/*
  Access token expires after 30 minutes.
  Every 20 minutes, sign the user in again.

  // https://stackoverflow.com/questions/52569602/flutter-run-function-every-x-amount-of-seconds
*/
void periodicallyCheckSignIn(Store<AppState> store) {
  var cron = new Cron();

  // '*/3 * * * *' = every 3 minutes.
  cron.schedule(new Schedule.parse('*/1 * * * *'), () async {
    // print('PERIODIC CHECKER Checking authentication');

    // bool isSignedIn = await _googleSignIn.isSignedIn();
    // print("isSignedIn: $isSignedIn");
    // if (!isSignedIn) {
    // print("PERIODIC CHECKER Signing in SILENTLY");
    if (!store.state.isWelcomeScreenShowing) {
      signInSILENT(store);
    }
    // }
    // UserCredential uc = await FirebaseAuth.instance.signInWithCredential(credential);
    // Once signed in, return the UserCredential
    // var firebaseUser = FirebaseAuth.instance.currentUser;
    // print("firebaseUser: $firebaseUser");
  });
}

// https://pub.dev/documentation/google_sign_in/latest/google_sign_in/GoogleSignIn-class.html
Future<void> signInSILENT(Store<AppState> store) async {
  GoogleSignInAccount googleUser = await _googleSignIn.signInSilently();

  if (googleUser == null) {
    googleUser = await _googleSignIn.signIn();
  }
  final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

  accessToken = googleAuth.accessToken;

  // print("SILENT accessToken: $accessToken");

  // await signInWithGoogleAuth(store, googleAuth);
  return;
}

Future<void> signOut(Store<AppState> store) async {
  print('SIGNING OUT');

  // print("RESETTING LOCAL STATE");
  // store.dispatch(ClearCurrentDataAction());
  store.dispatch(UpdateLoadingAction(true));
  await _googleSignIn.signOut();

  // Automatically request signin. (Change to the onboarding process)
  // await _googleSignIn.signIn();
}

Future<GoogleSignInAuthentication> getGoogleAuth(Store<AppState> store) async {
  // Trigger the authentication flow

  _googleSignIn.onCurrentUserChanged
      .listen((GoogleSignInAccount account) async {
    print('Signin changed: ' + account.toString());

    if (account == null) {
      // print('Signing in again');
      // _googleSignIn.signIn();
      // setSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER, "");
      accessToken = "";

      // GLOBAL_showingSignInButton = true;
      store.dispatch(UpdateSignInButtonVisibilityAction(true));
      GLOBAL_customerNotEnabled = false;

      // Attach to analytics listener
      Smartlook.setUserIdentifier(null);
      await store.state.analytics.setUserId(id: null);
      // await store.state.crashlytics.setUserIdentifier(null);

      store.dispatch(UpdateIsWelcomeScreenShowingAction(true));

      String displayName =
          readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_NAME);
      String email =
          readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);

      ANALYTICS_logEvent(
          store, 'Logout', {"displayName": displayName, "email": email});

      removeAllSharedPreferences();

      ANALYTICS_logScreenEnteredEvent(store, "Sign-in and welcome page");

    } else {
      // GLOBAL_showingSignInButton = false;
      store.dispatch(UpdateSignInButtonVisibilityAction(false));
      GLOBAL_customerNotEnabled = false;

      // Attach to analytics listener
      Smartlook.setUserIdentifier(account.email);
      await store.state.analytics.setUserId(
        id: account.id,
      );
      await store.state.crashlytics.setUserIdentifier(account.email);
      try {
        store.state.facebookAppEvents.setUserData(
          email: account.email,
          firstName: account.displayName,
        );
      } catch (err) {
        print("Caught Error setting facebook app event user data");
      }

      ANALYTICS_logEvent(store, 'Login',
          {"email": account.email, "displayName": account.displayName});

      accessToken = (await account.authentication).accessToken;

      // START OF DEBUG
      // String customerId = readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_ID);
      // String managerId = readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_CLIENT_ID);
      // getAllAdGroups(store, customerId, managerId);
      // END OF DEBUG

      await signInWithGoogleAuth(store, await account.authentication);

      if (readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER) !=
              account.id
          /*||
          store.state.customers.length == 0*/
          ) {
        // Truncate all tables.
        // print("TRUNCATING CUSTOMER!!!");
        // await truncateTable('CUSTOMERS');
        // truncateTable('CUSTOMER_CLIENTS');
        truncateTable('CAMPAIGNS');
        truncateTable('ADGROUPS');
        truncateTable('KEYWORDS');
        truncateTable('SEARCHTERMS');
        // truncateTable('SEARCH_TERM_SAVE_ACTIONS');
        truncateTable('NEGATIVE_KEYWORD_LIST');
        // truncateTable('NEGATIVE_KEYWORD_LIST_TO_SAVE');
        // truncateTable('METRICS');
        truncateTable('METRIC_VALUE');
        truncateTable('FILTER_VALUE');
        truncateTable('ORDER_VALUE');
        truncateTable("ADGROUPS_TO_LOAD");
        truncateTable("CAMPAIGN_METRICS");
        truncateTable("ADGROUPS_METRICS");
        truncateTable("SEARCHTERMS_METRICS");
        truncateTable("CACHED_QUERIES");

        // print('CLEARING SHARED PREFERENCES');
        removeAllSharedPreferences();

        // print("RESETTING LOCAL STATE");
        store.dispatch(ClearCurrentDataAction());

        if (store.state.iapProducts.length == 0) {
          if (defaultTargetPlatform == TargetPlatform.android) {
            InAppPurchaseAndroidPlatformAddition.enablePendingPurchases();

            store.dispatch((x) => iapAvailabilityUpdateAction(store));
          }
        }

        setSharedPreferenceValue(
            SHARED_PREFERENCE_KEYS.CURRENT_USER, account.id);

        if (account.photoUrl != null) {
          setSharedPreferenceValue(
              SHARED_PREFERENCE_KEYS.CURRENT_USER_PHOTO_URL, account.photoUrl);
        }

        if (account.displayName != null) {
          setSharedPreferenceValue(
              SHARED_PREFERENCE_KEYS.CURRENT_USER_NAME, account.displayName);
        }
        if (account.email != null) {
          setSharedPreferenceValue(
              SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL, account.email);
        }

        // print('Loading customers and customerClients for new login user: ' +
        // accessToken.toString());

        store.dispatch(UpdateLoadingAction(false));

        store.dispatch(UpdateDisplayMetricsAction(
            "CAMPAIGN", store.state.campaignMetrics, store));
        store.dispatch(UpdateDisplayMetricsAction(
            "ADGROUPS", store.state.adGroupMetrics, store));
        store.dispatch(UpdateDisplayMetricsAction(
            "SEARCHTERMS", store.state.searchTermMetrics, store));

        store.dispatch((x) =>
            loadCustomersAndCustomerClients(store, googleEmail: account.email));

        // if (checkShowingInitialSequence(store.state.initialCustomerId, this.initialManagerId, this.initialDateRange)) {
        // print("NAVIGATE TO INITIAL LOADING SCREEN");
        //   Navigator.push(
        //     context,
        //     new MaterialPageRoute(
        //         builder: (context) => CustomersList(false)));
        // }
      } else {
        // Resume loading search termsfrom the same account.

        DateRange initialDateRange = DateRange.fromName(
            readSharedPreferenceValue(
                SHARED_PREFERENCE_KEYS.CURRENT_DATE_RANGE),
            readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_TIMEZONE));

        if (initialDateRange != null &&
            initialDateRange.getName() == 'Custom') {
          // Load the selected start and end dates as well.
          String customDateRangeStart = readSharedPreferenceValue(
              SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_START);
          print('customDateRangeStart: ' + customDateRangeStart.toString());
          String customDateRangeEnd = readSharedPreferenceValue(
              SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_END);

          if (customDateRangeStart.length > 1 &&
              customDateRangeEnd.length > 1) {
            initialDateRange.setKeyName(
                "BETWEEN ${epochTime2DateString(int.parse(customDateRangeStart))} AND ${epochTime2DateString(int.parse(customDateRangeEnd))}");
            initialDateRange.setAdditionalName(
                "(${epochTime2DateString(int.parse(customDateRangeStart))} to ${epochTime2DateString(int.parse(customDateRangeEnd))})");
            initialDateRange.lowerEpochDate = int.parse(customDateRangeStart);
            initialDateRange.upperEpochDate = int.parse(customDateRangeEnd);
          }
        }
        String initialCustomerId = readSharedPreferenceValue(
            SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_ID);
        String initialCustomerClientId = readSharedPreferenceValue(
            SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_CLIENT_ID);
        String initialCampaign = readSharedPreferenceValue(
            SHARED_PREFERENCE_KEYS.CURRENT_CAMPAIGN_ID);
        String initialAdgroup = readSharedPreferenceValue(
            SHARED_PREFERENCE_KEYS.CURRENT_AD_GROUP_ID);

        store.dispatch((x) => resumeLoadingSearchTermsAction(
              store,
              initialCustomerId,
              initialCustomerClientId,
              initialDateRange,
              initialCampaign,
              initialAdgroup,
            ));
      }

      // if (isWelcomeScreenAllowedToHide) {
        store.dispatch(UpdateIsWelcomeScreenShowingAction(false));
      // }

      // store.dispatch(UpdateLoadingAction(false));
    }
  });

  // Automatically refreshes credentials by silently refreshing the authentication token.
  _googleSignIn.signInSilently();

  // final GoogleSignInAccount googleUser = await _googleSignIn.signIn();

  // Obtain the auth details from the request
  // final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

  // accessToken = googleAuth.accessToken;
  // return googleAuth;
}

Future<void> signInSilently() {
  _googleSignIn.signInSilently();
}

Future<UserCredential> signInWithGoogleAuth(
    Store<AppState> store, GoogleSignInAuthentication googleAuth) async {
  // Create a new credential
  final GoogleAuthCredential credential = GoogleAuthProvider.credential(
    accessToken: googleAuth.accessToken,
    idToken: googleAuth.idToken,
  );
  // print("credential: " + credential.toString());
  // return credential;
  // Once signed in, return the UserCredential
  // FirebaseAuth.instance.currentUser;
  // return null;
  // This is unnecessary, it is never used.
  // Only accessToken is required.

  // Required to sign in to firebase in order to run firebase functions.
  UserCredential uc =
      await FirebaseAuth.instance.signInWithCredential(credential);
  // Once signed in, return the UserCredential
  // FirebaseAuth.instance.currentUser;

  // Listen to this to know when Firestore is authenticated,
  // to be able to access the purchases database.
  try {
    FirebaseAuth.instance.userChanges().listen((User user) {
      if (user == null) {
        print("FIREBASE User is currently signed out!");
      } else {
        // print("FIREBASE User is signed in! ${user.uid}");
        loadPastPurchases(store, user.uid);
        loadPastConsumables(store, user.uid);

        setSharedPreferenceValue(SHARED_PREFERENCE_KEYS.FIREBASE_UID, user.uid);
      }
    });
  } catch (err) {
    print("CAUGHT Error listening to Firestore: $err");
  }
  return uc;
}

/*


  // Load customer data if login user has changed or does not exist
  // print('readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER): ' +
  //     readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER)
  //         .toString());
  // print('googleuserid: ' + googleUser.id.toString());
  // if (readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER) !=
  //     googleUser.id) {
  // setSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER, googleUser.id);

  // print('Loading customers and customerClients for new login user: ' +
  //     accessToken.toString());
  // store.dispatch((x) => loadCustomersAndCustomerClients(store));
  // }
  

*/

/*
import 'package:flutter_appauth/flutter_appauth.dart';
import 'package:http/http.dart' as http;
// import 'package:oauth2_client/access_token_response.dart';
import 'constants.dart' as Constants;

const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/auth';
const CLIENT_ID = Constants.GOOGLE_ADS_API_CLIENT_ID;
const REDIRECT_URI = "com.example.searchtermanalyzerflutter:/login";//"urn:ietf:wg:oauth:2.0:oob";//'io.searchtermanalyzerflutter.login:/oauth2redirect'; //"com.example.searchtermanalyzerflutter:/urn:ietf:wg:oauth:2.0:oob&access_type=offline&prompt=consent";//
const TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
var scopes = [
    'https://www.googleapis.com/auth/adsense',
];

var httpClient = http.Client;

// class Oauth2Client {
//   Oauth2Client();

  Future<void> authenticate() async {
    print('Authenticating account!!!');

    FlutterAppAuth appAuth = FlutterAppAuth();
    
    final AuthorizationTokenResponse result = 
      await appAuth.authorizeAndExchangeCode(AuthorizationTokenRequest(
        CLIENT_ID, REDIRECT_URI,
        serviceConfiguration: AuthorizationServiceConfiguration(
          AUTH_ENDPOINT, TOKEN_ENDPOINT
        ), scopes: scopes,
      ));
    print(result.accessToken.toString());


  }
*/
// }

// import 'package:oauth2_client/oauth2_helper.dart';
// //We are going to use the google client for this example...
// import 'package:oauth2_client/google_oauth2_client.dart';
// import 'package:http/http.dart' as http;

// import 'constants.dart' as Constants;

// // https://developers.google.com/identity/protocols/oauth2/scopes

// // class Oauth2Client {
// //   Oauth2Client();

//   Future<void> authenticate() async {
//     print('Authenticating account');

//     GoogleOAuth2Client client = GoogleOAuth2Client(
//       customUriScheme: 'com.example.searchTermAnalyzerFlutter', //Must correspond to the AndroidManifest's "android:scheme" attribute
//       redirectUri: 'com.example.searchTermAnalyzerFlutter:/oauth2redirect'
//         //'com.example.searchTermAnalyzerFlutter:/oauth2redirect', //Can be any URI, but the scheme part must correspond to the customeUriScheme
//     );

//     OAuth2Helper oauth2Helper = OAuth2Helper(client,
//       grantType: OAuth2Helper.AUTHORIZATION_CODE,
//       clientId: Constants.GOOGLE_ADS_API_CLIENT_ID,
//       // clientSecret: 'your_client_secret',
//       scopes: ['https://www.googleapis.com/auth/adsense'],
//       // scopes: ['https://www.googleapis.com/auth/drive.readonly']
//     );

//     http.Response resp = await oauth2Helper.get(
//       'https://www.googleapis.com/drive/v3/files'
//       // 'https://googleads.googleapis.com/v6/customers/8120874448/'
//     );

//     print(resp.body);
//   }
// // }
