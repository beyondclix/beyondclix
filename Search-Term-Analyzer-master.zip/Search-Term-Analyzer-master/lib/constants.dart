import 'package:searchTermAnalyzerFlutter/models/membership_type.dart';
import 'package:flutter/material.dart';
import 'dart:math' as math;

const CRASHLYTICS_IS_ON = true;

// From version defined in pubspec.yaml.
const APPLICATION_VERSION = '1.0.14+19';

const String GOOGLE_ADS_API_CLIENT_ID =
// '800291765673-i8ogdtt9ek98o52e9pbh58h1hjvj2n2l.apps.googleusercontent.com';
    '800291765673-2pml312stocduevtcaumtcdm3uc80496.apps.googleusercontent.com';
// '800291765673-bap6jb51gaqt18q7snui71678q5a4fs1.apps.googleusercontent.com';
//'1026307519163-vtju1sv4dnrotijeg4f0g6at7otcdl8b.apps.googleusercontent.com';
const String DEVELOPER_TOKEN =
    // Samar Developer Token
    'iD1YtaFCx9H73RRAK7J7Zg';
// My Developer Token
// 'Hk_7wJUhGU9aSfQXFg8aAg';

const String SMARTLOOK_API_KEY = "681605062352785fd112b445c0a5e52c74f9dee9";
// SAMAR's project
// "681605062352785fd112b445c0a5e52c74f9dee9"
// JUN's project
// "226ecb06478e15108ab6d54185190addf95af186";

const CLOUD_REGION = "australia-southeast1";
const PAGE_SIZE = 1000; // 5000 // 1000; // 25;//500;//25; //100; //10000; //25

const SKU_SINGLE_SAVE = 'save';
const SKU_MONTHLY_SUBSCRIPTION =
    'monthly_subscription'; //'monthly_subscription'; // 'test_subscription';
const SKU_LIFETIME_PURCHASE = 'lifetime_membership';

const WELCOME_DESCRIPTION = "Analyze and Manage Your Search Terms";

const DISCLAIMER_TEXT = "Search Terms Manager works with search terms in your Google Ads account. You need to login with a Google Ads account";

const FEEDBACK_URL = 'contact@beyondclix.com';
const LINKEDIN_URL = 'https://www.linkedin.com/in/samarjit1978';
const FEEDBACK_FALLBACK_URL = 'https://form.typeform.com/to/y0tU0j8Z';

// "Search Terms Manager works with search terms in your Google Ads accounts. You need to login with an account that has access to a Google Ads Account.",
//  and will be empty if your Google account has no associated Google Ads account.
//  Securely sign in to your Google account and manage your search terms.

final int PAGINATION_LIMIT = 10; // 50

final MEMBERSHIP_TYPES = {
  "FREE": MembershipType(
    "FREE",
    "Pay as you go",
    Container(
      // color: Colors.grey,
      // child: Icon(Icons.work, size: 50,)),
      child: Transform.rotate(
        angle: 0 * math.pi / 180,
        child: Icon(
          Icons.arrow_forward_ios_sharp,
          size: 50,
          color: Colors.black,
        ),
      ),
    ),
    Color.fromRGBO(230, 230, 230, 1),
    colorDark: Color.fromRGBO(230, 230, 230, 1),
  ),
  SKU_MONTHLY_SUBSCRIPTION: MembershipType(
    SKU_MONTHLY_SUBSCRIPTION,
    // "Unlimited Monthly User",
    "Monthly Subscription",
    Container(
      padding: EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: Color.fromRGBO(52, 168, 83, 1),
        shape: BoxShape.circle,
        // border: Border.all(
        //   color: Color.fromRGBO(0, 0, 0, 0.0), // 0.2 opacity
        //   width: 1.0,
        // ),
      ),
      child: Icon(
        Icons.arrow_forward_ios_sharp,
        size: 35,
        color: Colors.white,
      ),
    ),
    Colors.blue,
    colorDark: Colors.purple,
  ),
  SKU_LIFETIME_PURCHASE: MembershipType(
    SKU_LIFETIME_PURCHASE,
    "Lifetime User",
    Container(
      padding: EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(6),
        // shape: BoxShape.circle,
      ),
      child: Row(children: [
        Icon(Icons.arrow_forward_ios_sharp,
            size: 35, color: Color.fromRGBO(92, 208, 123, 1)),
        Container(
          transform: Matrix4.translationValues(-17.5, 0.0, 0.0),
          child: Icon(
            Icons.arrow_forward_ios_sharp,
            size: 35,
            color: Color.fromRGBO(52, 168, 83, 1),
          ),
        ),
        Container(
          transform: Matrix4.translationValues(-35.0, 0.0, 0.0),
          child: Icon(
            Icons.arrow_forward_ios_sharp,
            size: 35,
            color: Color.fromRGBO(12, 128, 43, 1),
          ),
        ),
      ]),
    ),
    Color.fromRGBO(52, 168, 83, 1),
    colorDark: Colors
        .cyanAccent.shade700, //Colors.teal,//Color.fromRGBO(52, 168, 123, 1),
  ),
};

const EMPTY_KEY = '<<NONE>>';

// When running FIREBASE EMULATOR
// Set this flag to FALSE for production.
const USING_FIREBASE_FUNCTIONS_EMULATOR = false;

// Get this endpoint from $ firebase emulators:start
const FUNCTIONS_ENDPOINT = 5001; //'0.0.0.0:5001';

// Metric data types
// obj['metrics']['impressions'],
// obj['metrics']['clicks'],
// (obj['metrics']['ctr'] * 100).toStringAsFixed(2) + "%",
// /* double */ (averageCpc / 1000000).toString(), //.toStringAsFixed(2),
// /* int64*/ (int.parse(obj['metrics']['costMicros']) / 1000000)
//     .toStringAsFixed(2),
// obj['metrics']['conversions'].toString(),
// "0", //obj['metrics']['cost_per_conversion'],
// "0", //obj['metrics']['conversion_rate'],
// "0", //obj['metrics']['search_impression_share']

// For valueType info, view convertMetric under ./common_functions;
// No "value" field defaults to "double";

// Used to construct a dynamic query of all available metrics.
const METRIC_TYPES = {
  "CAMPAIGN": [
    {"name": "absolute_top_impression_percentage", "value": "percentage"},
    {"name": "active_view_cpm", "value": "double"},
    {"name": "active_view_ctr", "value": "double"},
    {"name": "active_view_impressions", "value": "double"},
    {"name": "active_view_measurability", "value": "double"},
    {"name": "active_view_measurable_cost_micros", "value": "int"},
    {"name": "active_view_measurable_impressions", "value": "int"},
    {"name": "active_view_viewability", "value": "double"},
    {"name": "all_conversions", "value": "double"},
    {"name": "all_conversions_by_conversion_date", "value": "double"},
    // "all_conversions_from_click_to_call",
    // "all_conversions_from_directions",
    {"name": "all_conversions_from_interactions_rate", "value": "double"},
    // "all_conversions_from_interactions_value_per_interaction",
    // "all_conversions_from_menu",
    // "all_conversions_from_order",
    {"name": "all_conversions_value", "value": "double"},
    // "all_conversions_value_per_cost",
    {"name": "average_cost"},
    {"name": "average_cpc"},
    {"name": "average_cpe"},
    {"name": "average_cpm"},
    {"name": "average_cpv"},
    {"name": "average_page_views"},
    {"name": "average_time_on_site"},
    // "benchmark_average_max_cpc",
    {"name": "bounce_rate", "value": "percentage"},
    {"name": "clicks", "value": "int"},
    {"name": "conversions"},
    {"name": "conversions_value"},
    // "conversions_value_per_cost",
    {"name": "cost_micros", "value": "int"},
    {"name": "cost_per_all_conversions"},
    {"name": "cost_per_conversion"},
    {"name": "ctr"},
    {"name": "engagement_rate"},
    {"name": "engagements", "value": "int"},
    {"name": "impressions", "value": "int"},
    {"name": "interaction_rate"},
    {"name": "interactions", "value": "int"},
    {"name": "relative_ctr"},
    {"name": "search_impression_share"},
    {"name": "search_top_impression_share"},
    {"name": "top_impression_percentage", "value": "percentage"},
    {"name": "value_per_conversion"}
  ],
  "ADGROUPS": [
    {"name": "absolute_top_impression_percentage", "value": "percentage"},
    {"name": "active_view_cpm"},
    {"name": "active_view_ctr"},
    {"name": "active_view_impressions"},
    {"name": "all_conversions"},
    {"name": "all_conversions_by_conversion_date"},
    {"name": "all_conversions_from_interactions_rate"},
    {"name": "all_conversions_value"},
    // "all_conversions_value_per_cost",
    {"name": "average_cost"},
    {"name": "average_cpc"},
    {"name": "average_cpe"},
    {"name": "average_cpm"},
    {"name": "average_cpv"},
    {"name": "average_page_views"},
    // "benchmark_average_max_cpc",
    {"name": "bounce_rate", "value": "percentage"},
    {"name": "clicks", "value": "int"},
    {"name": "conversions"},
    {"name": "conversions_by_conversion_date"},
    {"name": "conversions_value"},
    // "conversions_value_per_cost",
    {"name": "cost_micros", "value": "int"},
    {"name": "cost_per_all_conversions"},
    {"name": "cost_per_conversion"},
    {"name": "ctr"},
    {"name": "engagement_rate"},
    {"name": "engagements", "value": "int"},
    {"name": "impressions", "value": "int"},
    {"name": "interactions", "value": "int"},
    {"name": "relative_ctr"},
    {"name": "search_absolute_top_impression_share"},
    // "search_click_share",
    {"name": "search_impression_share"},
    {"name": "search_top_impression_share"},
    {"name": "top_impression_percentage", "value": "percentage"},
    {"name": "value_per_all_conversions"},
    {"name": "value_per_conversion"},
    {"name": "value_per_conversions_by_conversion_date"},
    {"name": "view_through_conversions"}
  ],
  "SEARCHTERMS": [
    {
      "name": "absolute_top_impression_percentage",
      "value": "percentage",
      "displayName": "Absolute Impr. (Top) %"
    },
    {"name": "all_conversions", "displayName": "All conv."},
    {
      "name": "all_conversions_from_interactions_rate",
      "displayName": "All conv. rate"
    },
    {
      "name": "all_conversions_from_interactions_value_per_interaction",
      "displayName": "All conv. / interaction"
    },
    {"name": "all_conversions_value", "displayName": "All conv. value"},
    {
      "name": "all_conversions_value_per_cost",
      "displayName": "All conv. value / cost"
    },
    {
      "name": "average_cost",
      "value": "micros_currency",
      "displayName": "Avg. cost"
    },
    {
      "name": "average_cpc",
      "value": "micros_currency",
      "displayName": "Avg. CPC"
    },
    {
      "name": "average_cpe",
      "value": "micros_currency",
      "displayName": "Avg. CPE"
    },
    {
      "name": "average_cpm",
      "value": "micros_currency",
      "displayName": "Avg. CPM"
    },
    // {"name": "average_cpv", "displayName": "Avg. CPV"}, // Doesn't work with segments.search_term_match_type
    {"name": "clicks", "value": "int", "displayName": "Clicks"},
    {"name": "conversions", "displayName": "Conversions"},
    {"name": "conversions_from_interactions_rate", "displayName": "Conv. rate"},
    {
      "name": "conversions_from_interactions_value_per_interaction",
      "displayName": "Conv. rate value / interaction"
    },
    {"name": "conversions_value", "displayName": "Conv. value"},
    {"name": "conversions_value_per_cost", "displayName": "Conv. value / cost"},
    {"name": "cost_micros", "value": "micros_currency", "displayName": "Cost"},
    {
      "name": "cost_per_all_conversions",
      "value": "micros_currency",
      "displayName": "Cost / all conv."
    },
    {
      "name": "cost_per_conversion",
      "value": "micros_currency",
      "displayName": "Cost / conv."
    },
    {"name": "ctr", "displayName": "CTR"},
    {"name": "engagement_rate", "displayName": "Engagement rate"},
    {"name": "engagements", "value": "int", "displayName": "Engagements"},
    {"name": "impressions", "value": "int", "displayName": "Impr."},
    // {"name": "interaction_event_types","value":"string"},
    {"name": "interaction_rate", "displayName": "Interaction rate"},
    {"name": "interactions", "value": "int", "displayName": "Interactions"},
    {
      "name": "top_impression_percentage",
      "value": "percentage",
      "displayName": "Impr. (Top) %"
    },
    {"name": "value_per_all_conversions", "displayName": "Value / all conv."},
    {"name": "value_per_conversion", "displayName": "Value / conv."},
    {"name": "view_through_conversions", "displayName": "View-through conv."}
  ],
};

// https://developers.google.com/google-ads/api/reference/rpc/v8/CriterionErrorEnum.CriterionError
// https://developers.google.com/google-ads/api/reference/rpc/v8/ContextErrorEnum.ContextError
const KEYWORD_ERRORS = {
  "OPERATION_NOT_PERMITTED_FOR_REMOVED_RESOURCE":
      "This Search term or the Campaign or Ad Group it is in has been removed.",
  "NEGATIVE_KEYWORDS_PER_SHAREDSET":
      "Too many keywords in Negative Keyword List.",
  "20": "Exceeded limit of 20 Negative Keyword Lists."
};
