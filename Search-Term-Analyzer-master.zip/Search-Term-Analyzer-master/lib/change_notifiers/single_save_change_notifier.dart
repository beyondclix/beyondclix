// import 'flutter:foundation';

// class SingleSaveChangeNotifier extends ChangeNotifier {
//     bool _isPurchasing = false;

//     void updateIsPurchasing(bool newValue) {
//         _isPurchasing = newValue;
//         notifyListeners();
//     }

//     bool get isPurchasing => _isPurchasing;
// }