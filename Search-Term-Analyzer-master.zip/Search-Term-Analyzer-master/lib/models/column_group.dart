import 'package:searchTermAnalyzerFlutter/models/metric.dart';

class ColumnGroup {
  final String title;
  final List<Metric> columnValues;

  ColumnGroup(this.title, this.columnValues);
}
