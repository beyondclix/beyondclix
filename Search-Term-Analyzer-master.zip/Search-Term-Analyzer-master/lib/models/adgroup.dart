import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/models/metric_value.dart';
import '../local_data.dart';
import 'package:redux/redux.dart';
import '../constants.dart';

class AdGroup {
  AdGroup(this.id, this.customerClientId, this.campaignId, this.campaignName,
      this.resourceName, this.name, Store<AppState> store /*, this.date*/) {
    if (this.id != EMPTY_KEY && this.id != null) {
      // this.loadMetrics(store);
    }
  }
  final String id;
  final String customerClientId;
  final String campaignId;
  final String campaignName;
  final String resourceName;
  final String name;
  Map<String, MetricValue> metrics;
  // final DateTime date;

  // Extract CustomerId from resourceName
  // https://developers.google.com/google-ads/api/fields/v7/ad_group#ad_group.resource_name
  String getCustomerId() {
    return new RegExp(r"([0-9]+)")
        .allMatches(this.resourceName)
        .elementAt(0)
        .group(0);
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerClientId': customerClientId,
      'campaignId': campaignId,
      'campaignName': campaignName,
      'resourceName': resourceName,
      'name': name,
      // 'date': date2EpochTime(date),
    };
  }

  Future<void> loadMetrics(Store<AppState> store) async {
    Map<String, MetricValue> _metrics = await MetricValue.fromDB(
        'ADGROUPS',
        this.id,
        SearchTerm.createCachedQueryId(customerClientId,
            store.state.currentDateRange, store.state.currentManager.timeZone));
    this.metrics = _metrics;
  }

  // Pagination last value.
  static String lastValue;

  static Future<List<AdGroup>> fromAPI(Store<AppState> store, String customerId,
      String managerId, DateRange dateRange,
      {String campaignId}) async {
    List<AdGroup> ad = await getAdGroups(
        store, managerId, customerId, dateRange,
        campaignId: campaignId);
    if (ad.length == 0) {
      DB_InsertBlank(
          'ADGROUPS',
          AdGroup(generateId(), managerId, campaignId, null, EMPTY_KEY,
                  EMPTY_KEY, null)
              .toMap());
    }
    return ad;
  }

  static Future<AdGroup> fromInitialId(String id, Store<AppState> store) async {
    List<Map<String, dynamic>> maps =
        await getLocalObjectsWithConstraint('ADGROUPS', 'id', id);
    if (maps == null || maps.length == 0) {
      return null;
    }
    return map2AdGroup(maps[0], store);
  }

  // Load everything from local database.
  static Future<List<AdGroup>> fromMaps(Store<AppState> store,
      {noAPI: false, campaignId: null, initialId: null}) async {
    List<Map<String, dynamic>> maps;
    List<Map<String, dynamic>> emptyMaps;
    String campaignIdConstraint;

    store.dispatch(StartAdGroupsLoadingAction());

    if (campaignId != null) {
      campaignIdConstraint = campaignId;
    }
    // Force using this if it has been set. (For initial loading when it is not in state)
    if (initialId != null) {
      campaignIdConstraint = initialId;
    }

    if (store.state.currentManager == null) {
      store.dispatch(FinishAdGroupsLoadingAction());
      return [];
    }

    print(
        "AdGroup.fromMaps() campaignIdConstraint: $campaignIdConstraint, customerClient: ${store.state.currentManager.name}");

    // Select all adgroups.
    // print("Displaying ALL AdGroups for managerId: ${store.state.currentManager.id}");
    maps = await getAdGroupsWithConstraintsPaginatedFiltered(
        store.state.currentManager.id,
        campaignIdConstraint,
        PAGINATION_LIMIT,
        0,
        emptiesOnly: false);
    // print("adGroup maps: ${maps.length}");

    if (maps == null || maps.length == 0) {
      emptyMaps = await getAdGroupsWithConstraintsPaginatedFiltered(
          store.state.currentManager.id,
          campaignIdConstraint,
          PAGINATION_LIMIT,
          0,
          emptiesOnly: true);

      // print("emptyMaps: ${emptyMaps.length}");

      if (emptyMaps != null && emptyMaps.length > 0) {
        // print("Empties exist, exiting AdGroup.fromMaps()");
        store.dispatch(FinishAdGroupsLoadingAction());
        return [];
      }

      print('AdGroup is empty, loading from API');
      if (noAPI == false) {
        await AdGroup.fromAPI(
          store, store.state.currentCustomer.id,
          store.state.currentManager.id, store.state.currentDateRange,
          // Load all campaigns so that empties don't block others from loading.
          // Remove campaign constraint.
          campaignId: campaignIdConstraint, //null,
        ); //store.state.currentCampaign.id);//null);

        store.dispatch((x) => updateVisibleAdGroupsAction(
            store, campaignIdConstraint,
            noAPI: true));
      }
      store.dispatch(FinishAdGroupsLoadingAction());
      return [];
    } else {
      // print("Found adGroups in DB ${maps.length}");

      store.dispatch(FinishAdGroupsLoadingAction());

      List<AdGroup> adGroups = List.generate(maps.length, (i) {
        return map2AdGroup(maps[i], store);
      });
      adGroups.sort((AdGroup a, AdGroup b) {
        return a.name.compareTo(b.name);
      });
      return adGroups;
    }

    // String constraintId = store.state.currentCampaign.id;
    // if (initialId != null) {
    //   constraintId = initialId;
    // }
    // maps = await getAdGroupsWithConstraintsPaginatedFiltered(
    //     store.currentManager.id, constraintId, LIMIT, 0,
    //     emptiesOnly: false);
    // if (maps == null || maps.length == 0) {
    //   // print('AdGroup is empty, loading from API: ' +
    //   // store.state.currentManager.id.toString());
    //   // store.dispatch(StartLoadingAction());
    //   // store.dispatch(StartAdGroupsLoadingAction());
    //   List<AdGroup> out = await AdGroup.fromAPI(
    //       store,
    //       store.state.currentCustomer.id,
    //       store.state.currentManager.id,
    //       store.state.currentDateRange,
    //       campaignId: constraintId);
    //   store.dispatch(FinishAdGroupsLoadingAction());
    //   return out;
    // } else {
    //   store.dispatch(FinishAdGroupsLoadingAction());
    //   return List.generate(maps.length, (i) {
    //     return map2AdGroup(maps[i]);
    //   });
    // }
  }

  static Future<List<AdGroup>> loadMorePaginated(
      Store<AppState> store, int offset) async {
    String campaignIdConstraint;

    if (store.state.currentCampaign != null) {
      campaignIdConstraint = store.state.currentCampaign.id;
    }
    List<Map<String, dynamic>> maps =
        await getAdGroupsWithConstraintsPaginatedFiltered(
            store.state.currentManager.id,
            campaignIdConstraint,
            PAGINATION_LIMIT,
            offset * PAGINATION_LIMIT,
            emptiesOnly: false);
    List<AdGroup> ads =
        List.generate(maps.length, (i) => map2AdGroup(maps[i], store));
    return ads;
  }

// Convert the map object into an AdGroup
  static AdGroup map2AdGroup(dynamic map, Store<AppState> store) {
    return AdGroup(
        map['id'].toString(),
        map['customerClientId'],
        map['campaignId'],
        map['campaignName'],
        map['resourceName'],
        map['name'],
        store
        //, epochTime2Date(map['date'])
        );
  }
}
