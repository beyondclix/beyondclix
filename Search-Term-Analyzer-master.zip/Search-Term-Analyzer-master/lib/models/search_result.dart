import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/customer_client.dart';

class SearchResult {
    final String name;
    final Customer customer;
    final CustomerClient customerClient;
    final String resultType;
    final int index;
    
    SearchResult(this.name, this.customer, this.customerClient, this.resultType, this.index);
}