import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';

// Not the actual metric value itself, but the display metric.
class Metric {
  String name;
  bool isOn;
  String metricFor;
  String valueType;
  String displayName;

  Metric(this.metricFor, this.name, this.displayName, this.valueType, this.isOn);

  Map<String, dynamic> toMap() {
    return {
      'metricFor': metricFor,
      'isOn': boolToInt(isOn),
      'name': name,
      'displayName': displayName,
      'valueType': valueType
    };
  }

  static Future<List<Metric>> fromDB(String metricFor,
      [bool onlyGetVisible = false]) async {
    List<Map<String, dynamic>> maps =
        await getMetricsForCategory(metricFor, onlyGetVisible);
    return List.generate(maps.length, (i) {
      return Metric(
          metricFor,
          maps[i]['name'], 
          maps[i]['displayName'],
          maps[i]['valueType'],
          intToBool(maps[i]['isOn']),
      );
    });
  }
}
