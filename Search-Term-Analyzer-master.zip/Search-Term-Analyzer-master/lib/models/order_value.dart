import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:redux/redux.dart';

class OrderValue {
  String id;
  String name;
  String groupName; // Parent filter group name.
  int value;
  String valueType; // 'string' / 'num';
  String stringFilterType = '';
  String displayName;

  OrderValue(this.name, this.groupName, this.value, this.valueType, {this.stringFilterType = '', this.id = '', this.displayName = ''}) {
    if (id == '' || id == null) {
      this.id = generateId();
    }
    if (stringFilterType != '') {
      this.stringFilterType = stringFilterType;
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'groupName': groupName,
      'displayName': displayName,
      'value': value.toString(),
      'valueType': valueType,
      'stringFilterType': stringFilterType,
    };
  }

  // This is better as a shared preference.
  // The thought process was that there would be multiple orderings in the future.
  static Future<OrderValue> fromDB() async {
    List<Map<String, dynamic>> maps = await getLocalObjects("ORDER_VALUE");
    
    List<OrderValue> ov = List.generate(maps.length, (i) {
      return OrderValue(
        maps[i]['name'],
        maps[i]['groupName'],
        int.parse(maps[i]['value']),
        maps[i]['valueType'],
        stringFilterType: maps[i]['stringFilterType'],
        id: maps[i]['id'],
        displayName: maps[i]['displayName'],
      );
    });

    if (ov != null && ov.length > 0) {
      return ov[0];
    }

    return null;
  }
}
