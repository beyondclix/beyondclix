import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';

class LatestDataLoadedDate {
    
    final String customerClientId;
    final int upperEpochDate;    

    LatestDataLoadedDate(this.customerClientId, this.upperEpochDate);

    Map<String, dynamic> toMap() {
        return {
            "customerClientId": customerClientId,
            "date": upperEpochDate,
        };
    }

    static Future<int> fromDB(String customerId) async {
        
        List<Map<String, dynamic>> maps = await getLocalObjectsWithConstraintNoID('LATEST_DATA_LOADED_DATE', 'customerClientId', customerId);
        print("Latest loaded data date: $maps");
        if (maps != null && maps.length > 0) {
            return fromMap(maps[0]).upperEpochDate;
        }

        return null;

    }

    static void toDB(LatestDataLoadedDate ldld) {

        insertObjectIfNotExistUpdateIfExistConditional(
          ldld.toMap(),
          'LATEST_DATA_LOADED_DATE',
          'customerClientId',
          ldld.customerClientId,
        );
    }

    static LatestDataLoadedDate fromMap(Map<String, dynamic> map) {
        return LatestDataLoadedDate(
            map['customerClientId'],
            map['date']
        );
    }
}