// https://pub.dev/documentation/in_app_purchase_android/latest/billing_client_wrappers/SkuDetailsWrapper-class.html
class ProductIntroductoryDetails {
    final String introductoryPrice;
    final int introductoryPriceCycles;

    ProductIntroductoryDetails(this.introductoryPrice, this.introductoryPriceCycles);
}