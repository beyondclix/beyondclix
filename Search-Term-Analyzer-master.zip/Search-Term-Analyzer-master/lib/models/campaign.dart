import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/metric_value.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';
import '../api.dart';
import '../local_data.dart';
import '../constants.dart';

class Campaign {
  Campaign(
    this.id,
    this.customerClientId,
    this.resourceName,
    this.name,
    this.status,
    Store<AppState> store,
    /*, this.date*/
  ) {
    if (this.id != EMPTY_KEY && this.id != null) {
      // this.loadMetrics(store);
    }
  }
  final String id;
  final String customerClientId;
  final String resourceName;
  final String name;
  final String status;
  Map<String, MetricValue> metrics;
  // final DateTime date;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerClientId': customerClientId,
      'resourceName': resourceName,
      'name': name,
      'status': status,
      // 'date': date2EpochTime(date),
    };
  }

  Future<void> loadMetrics(Store<AppState> store) async {
    Map<String, MetricValue> _metrics = await MetricValue.fromDB(
        'CAMPAIGN',
        this.id,
        SearchTerm.createCachedQueryId(customerClientId,
            store.state.currentDateRange, store.state.currentManager.timeZone));
    this.metrics = _metrics;
  }

  static Future<List<Campaign>> fromAPI(Store<AppState> store,
      String customerId, String managerId, DateRange dateRange) async {
    List<Campaign> c =
        await getCampaigns(store, managerId, customerId, dateRange);
    if (c.length == 0) {
      DB_InsertBlank(
          'CAMPAIGNS',
          Campaign(generateId(), managerId, EMPTY_KEY, EMPTY_KEY, null, null)
              .toMap());
    }
    return c;
  }

  static Future<Campaign> fromInitialId(
      String id, Store<AppState> store) async {
    List<Map<String, dynamic>> maps =
        await getLocalObjectsWithConstraint('CAMPAIGNS', 'id', id);
    if (maps == null || maps.length == 0) {
      return null;
    }
    return map2Campaign(maps[0], store);
  }

  // Move logic to load campaign here, otherwise just use local database.
  // Load from local database.
  static Future<List<Campaign>> fromMaps(Store<AppState> store,
      {noAPI: false, initialId: null}) async {
    if (store.state.currentManager == null) {
      return [];
    }

    List<Map<String, dynamic>> maps;
    List<Map<String, dynamic>> emptyMaps;

    store.dispatch(StartCampaignsLoadingAction());

    print("initialId: $initialId");
    String constraintId = store.state.currentManager.id;
    if (initialId != null) {
      constraintId = initialId;
    }
    
    maps = await getCampaignsWithConstraintsPaginatedFiltered(
        constraintId, PAGINATION_LIMIT, 0,
        emptiesOnly: false);

    // print("campaign maps: ${maps.length}");
    // If length is 0, call API to check.
    if (maps == null || maps.length == 0) {
      emptyMaps = await getCampaignsWithConstraintsPaginatedFiltered(
          constraintId, PAGINATION_LIMIT, 0,
          emptiesOnly: true);

      // print("campaign emptyMaps: ${emptyMaps.length}");

      if (emptyMaps != null && emptyMaps.length > 0) {
        // print("Empty campaigns exist, exiting Campaign.fromMaps()");
        store.dispatch(FinishCampaignsLoadingAction());
        // return [];//TODO Force loading API for now
      }

      print('Campaigns is empty, loading from API');
      // store.dispatch(StartLoadingAction());
      if (noAPI == false) {
        await Campaign.fromAPI(store, store.state.currentCustomer.id,
            store.state.currentManager.id, store.state.currentDateRange);
        store.dispatch((x) => updateVisibleCampaignsAction(store, noAPI: true));
      }
      store.dispatch(FinishCampaignsLoadingAction());
      return [];
      // out.sort((Campaign a, Campaign b) {
      //   return a.name.compareTo(b.name);
      // });
      // return out;
    } else {
      print("Found campaigns in DB: ${maps.length}");

      store.dispatch(FinishCampaignsLoadingAction());

      List<Campaign> campaigns = List.generate(maps.length, (i) {
        return map2Campaign(maps[i], store);
      });
      campaigns.sort((Campaign a, Campaign b) {
        return a.name.compareTo(b.name);
      });

      return campaigns;
    }
  }

  static Future<List<Campaign>> loadMorePaginated(
    Store<AppState> store,
    int offset,
  ) async {
    List<Map<String, dynamic>> maps =
        await getCampaignsWithConstraintsPaginatedFiltered(
      store.state.currentManager.id,
      PAGINATION_LIMIT,
      offset * PAGINATION_LIMIT,
      emptiesOnly: false,
    );
    List<Campaign> campaigns = List.generate(maps.length, (i) {
      return map2Campaign(maps[i], store);
    });
    return campaigns;
  }

  static Campaign map2Campaign(dynamic map, Store<AppState> store) {
    return Campaign(
        map['id'].toString(),
        map['customerClientId'],
        map['resourceName'],
        map['name'],
        map['status'],
        store /*, epochTime2Date(map['date'])*/);
  }
}
