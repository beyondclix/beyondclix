import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import '../api.dart';
import '../common_functions.dart';
import '../local_data.dart';
import 'package:redux/redux.dart';

class CustomerClient {
  CustomerClient(
      this.id,
      this.resourceName,
      this.name,
      this.isManager,
      this.parentId,
      this.timeZone,
      this.currencyCode,
      this.clicks,
      this.costMicros,
      this.impressions,
      this.conversions,
      this.allConversions);
  final String id;
  final String resourceName;
  final String name;
  final bool isManager;
  final String parentId;
  final String timeZone;
  final String currencyCode;
  int clicks;
  int costMicros;
  int impressions;
  int conversions;
  int allConversions;

  Map<String, dynamic> toMap() {
    // print('SAVING: ' + this.id + ", parentId: " + this.parentId);
    return {
      'id': id,
      'resourceName': resourceName,
      'name': name,
      'isManager': boolToInt(isManager),
      'parentId': parentId,
      'timeZone': timeZone,
      'currencyCode': currencyCode,
      'clicks': clicks,
      'costMicros': costMicros,
      'impressions': impressions,
      'conversions': conversions,
      'allConversions': allConversions,
    };
  }

  // When loading and there is no parent, use this directly as the customer client.
  static CustomerClient fromCustomer(Customer c) {
    return CustomerClient(
        c.id,
        c.resourceName,
        c.descriptiveName,
        c.isManager,
        null,
        c.timeZone,
        c.currencyCode,
        c.clicks,
        c.costMicros,
        c.impressions,
        c.conversions,
        c.allConversions);
  }

  static Future<List<CustomerClient>> fromAPI(
      Store<AppState> store, String customerId) async {
    // print("Loading customer clients from API!!!");
    return await getCustomerClients(store, customerId);
  }

  static Future<CustomerClient> fromInitialId(String id) async {
    List<Map<String, dynamic>> maps =
        await getLocalObjectsWithConstraint('CUSTOMER_CLIENTS', 'id', id);
    if (maps == null || maps.length == 0) {
      return null;
    }
    return CustomerClient(
      maps[0]['id'].toString(),
      maps[0]['resourceName'],
      maps[0]['name'],
      intToBool(maps[0]['isManager']),
      maps[0]['parentId'],
      maps[0]['timeZone'],
      maps[0]['currencyCode'],
      maps[0]['clicks'],
      maps[0]['costMicros'],
      maps[0]['impressions'],
      maps[0]['conversions'],
      maps[0]['allConversions'],
    );
  }

  // Load from local database.
  static Future<List<CustomerClient>> fromMaps(Store<AppState> store,
      {initialId = null, forceAPI: false}) async {
    // print("intialId: $initialId");
    if (store.state.currentCustomer == null && initialId == null) {
      // currentCustomer is null if user closed out of app before customerClients were loaded.
      // On intiial loading, currentCustomer will be null, but initialId will be passed in.
      // Need to make sure that both of these are the case to trigger a reload.
      // In this case, reset the load screen.
      store.dispatch(
          (x) => loadCustomersAndCustomerClients(store, forceAPI: forceAPI));
      return [];
    }
    String constraintId;
    if (store.state.currentCustomer != null) {
      constraintId = store.state.currentCustomer.id;
    }
    if (initialId != null) {
      constraintId = initialId;
    }

    List<Map<String, dynamic>> maps;
    // print('constraintId: ' + constraintId);
    if (forceAPI == false) {
      maps = await getLocalObjectsWithConstraint('CUSTOMER_CLIENTS', 'parentId',
          constraintId); //await getLocalObjects('CUSTOMER_CLIENTS');
    }
    if (maps == null || maps.length == 0 || forceAPI == true) {
      return await CustomerClient.fromAPI(store, constraintId);
    }
    return List.generate(maps.length, (i) {
      return CustomerClient(
        maps[i]['id'].toString(),
        maps[i]['resourceName'],
        maps[i]['name'],
        intToBool(maps[i]['isManager']),
        maps[i]['parentId'],
        maps[i]['timeZone'],
        maps[i]['currencyCode'],
        maps[i]['clicks'],
        maps[i]['costMicros'],
        maps[i]['impressions'],
        maps[i]['conversions'],
        maps[i]['allConversions'],
      );
    });
  }
}
