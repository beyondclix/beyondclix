import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword_response.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';

import '../local_data.dart';

class ChangeAction {
  String changeId;
  final String changeType;
  final String changeField;
  final String changeValue;

  // SearchTermSaveAction or other type, if other save types are required.
  dynamic changeObject;

  ChangeAction(this.changeId, this.changeType, this.changeField,
      this.changeValue, this.changeObject);

  static ChangeAction clone(ChangeAction ca) {
    return new ChangeAction(ca.changeId, ca.changeType, ca.changeField,
        ca.changeValue, ca.changeObject);
  }
}

class SearchTermSaveAction {
  String id;
  final String customerId;
  final String managerId;
  final String negativeKeywordSaveType;
  final String negativeKeywordListName;
  String negativeKeywordListResourceName;
  final String searchTermResourceName;
  final String adGroupResourceId;
  final bool isNegative;
  final String matchType;
  final String finalUrls;
  final double maxCpc;
  String searchTermText;
  final String adGroupId;
  final String adGroupName;
  final String campaignName;
  final String campaignResourceName;
  final DateTime date;
  List<KeywordError> keywordErrors;

  SearchTermSaveAction(
      this.id,
      this.customerId,
      this.managerId,

      // Different ways of saving a negative keyword, based on the keyword type.
      // Ad group, Campaign, Negative Keyword List
      this.negativeKeywordSaveType,
      this.negativeKeywordListName,
      this.negativeKeywordListResourceName,
      this.searchTermResourceName,
      this.adGroupResourceId,
      this.isNegative,
      this.matchType,
      this.finalUrls,
      this.maxCpc,
      this.searchTermText,
      this.adGroupId,
      this.adGroupName,
      this.campaignName,
      this.campaignResourceName,
      this.date);

  void setKeywordErrors(List<KeywordError> ke) {
    this.keywordErrors = new List.unmodifiable(List.from(ke));
  }

  // Saving to DB
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'managerId': managerId,
      'negativeKeywordSaveType': negativeKeywordSaveType,
      'negativeKeywordListName': negativeKeywordListName,
      'negativeKeywordListResourceName': negativeKeywordListResourceName,
      'searchTermResourceName': searchTermResourceName,
      'adGroupResourceId': adGroupResourceId,
      'isNegative': boolToInt(isNegative),
      'matchType': matchType,
      'finalUrls': finalUrls,
      'maxCpc': maxCpc,
      'searchTermText': searchTermText,
      'adGroupId': adGroupId,
      'adGroupName': adGroupName,
      'campaignName': campaignName,
      'campaignResourceName': campaignResourceName,
      'date': date2EpochTime(date),
    };
  }

  //Loading from DB
  static SearchTermSaveAction fromMap(Map<String, dynamic> map) {
    return SearchTermSaveAction(
        map['id'],
        map['customerId'],
        map['managerId'],
        map['negativeKeywordSaveType'],
        map['negativeKeywordListName'],
        map['negativeKeywordListResourceName'],
        map['searchTermResourceName'],
        map['adGroupResourceId'],
        intToBool(map['isNegative']),
        map['matchType'],
        map['finalUrls'],
        map['maxCpc'],
        map['searchTermText'],
        map['adGroupId'],
        map['adGroupName'],
        map['campaignName'],
        map['campaignResourceName'],
        epochTime2Date(map['date']));
  }

  static Future<List<SearchTermSaveAction>> fromMaps(String keyName, String valueName) async {
    List<Map<String, dynamic>> maps = await getLocalObjectsWithConstraint(
        'SEARCH_TERM_SAVE_ACTIONS', keyName, valueName);
    // print('SearchTermSaveActions Local DB data length: ' + maps.length.toString());
    return List.generate(maps.length, (i) {
      return fromMap(maps[i]);
    });
  }
}
