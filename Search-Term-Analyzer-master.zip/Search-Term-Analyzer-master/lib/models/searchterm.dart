import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup_to_load.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import '../local_data.dart';
import '../constants.dart';
import '../main.dart';
import 'date_range.dart';
import 'metric_value.dart';

// SearchTerms are automatically segmented by adGroup. So, date query limits adGroup, and searchTerms should be retrieved from available adGroups.

class SearchTerm {
  SearchTerm(
      this.id,
      this.resourceName,
      this.customerId,
      this.adGroupId,
      this.adGroupResourceName,
      this.text,
      this.status,
      // this.date,
      this.adGroupName,
      this.campaignId,
      this.campaignName,
      this.campaignResourceName,
      // this.impressions,
      // this.clicks,
      // this.ctr,
      // this.average_cpc,
      // this.cost_micros,
      // this.conversions,
      // this.cost_per_conversion,
      // this.conversion_rate,
      // this.search_impression_share,
      this.date,
      this.searchTermMatchType,
      this.queryId,
      Store<AppState> store,
      {noLoadMetrics = false}) {
    if (this.text != EMPTY_KEY && this.id != null) {
      if (noLoadMetrics == false) {
        this.loadMetrics(store, store.state.currentManager.timeZone,
            store.state.currentDateRange);
      }
    }
  }
  final String id;
  final String resourceName;
  final String customerId;
  final String adGroupId;
  final String adGroupResourceName;
  final String text;
  final String status;
  // final DateTime date;
  final String adGroupName;
  final String campaignId;
  final String campaignName;
  final String campaignResourceName;
  // final String impressions;
  // final String clicks;
  // final String ctr;
  // final String average_cpc;
  // final String cost_micros;
  // final String conversions;
  // final String cost_per_conversion;
  // final String conversion_rate;
  // final String search_impression_share;
  final DateTime date;
  final String searchTermMatchType;
  final String queryId;
  Map<String, MetricValue> metrics;

  // Store in local database
  Map<String, dynamic> toMap() {
    return {
      'id': id, //text,
      'resourceName': resourceName,
      'customerId': customerId,
      'adGroupId': adGroupId,
      'adGroupResourceName': adGroupResourceName,
      'text': text,
      'status': status,
      // 'date': date2EpochTime(date),
      'adGroupName': adGroupName,
      'campaignId': campaignId,
      'campaignName': campaignName,
      'campaignResourceName': campaignResourceName,
      // 'impressions': impressions,
      // 'clicks': clicks,
      // 'ctr': ctr,
      // 'average_cpc': average_cpc,
      // 'cost_micros': cost_micros,
      // 'conversions': conversions,
      // 'cost_per_conversion': cost_per_conversion,
      // 'conversion_rate': conversion_rate,
      // 'search_impression_share': search_impression_share,
      'date': date2EpochTime(date),
      'searchTermMatchType': searchTermMatchType,
      'queryId': queryId,
    };
  }

  // Load metrics for this date, if they don't exist, then load from DB
  Future<void> loadMetrics(
      Store<AppState> store, String timeZone, DateRange dateRange,
      {bool noAPI: false}) async {
    Map<String, MetricValue> _metrics = await MetricValue.fromDB(
      'SEARCHTERMS',
      this.id,
      SearchTerm.createCachedQueryId(store.state.currentManager.id, dateRange, store.state.currentManager.timeZone),
    );
    // print("impressions:  ${_metrics['impressions'].value}, ${MetricValue.generateUniqueId(customerId, dateRange, timeZone)}");
    // print("_metrics: $_metrics");

    if (_metrics == null || _metrics.keys.toList().length == 0) {
      if (noAPI == true) {
        return;
      }
      // Load metrics from DB.
      return;

      print("No metrics for query, loading from API: ${_metrics.length}");

      store.dispatch(StartLoadingToastAction());

      await resetAdGroupsToLoad(store.state.currentManager.id);

      // Search terms are not reloaded, they remain in DB.
      // but the blanks need to be removed so that data in their fields is read.
      DB_RemoveBlank(
          "SEARCHTERMS", 'customerId', store.state.currentManager.id, 'text');

      GLOBAL_searchTermsAPILoading = true;

      SearchTerm.fromAPIPaginated(
        store,
        store.state.currentCustomer.id,
        store.state.currentManager.id,
        store.state.currentDateRange,
        null, // store.state.currentCampaign.id,
        null, // store.state.currentAdGroup.id,
        adGroupToLoads: null,
        forceAPI: true,
        metricsOnly: true,
      );
      return;
    }
    // print("SETTING METRICS");
    this.metrics = _metrics;
  }

  // static Future<List<SearchTerm>> fromAPI(String customerId, String managerId,
  //     DateRange dateRange, String campaignId, String adGroupId) async {
  //   List<SearchTerm> s = await getSearchTerms(managerId, customerId, dateRange,
  //       campaignId: campaignId, adGroupId: adGroupId);
  //   if (s.length == 0) {
  //     // Insert blank entry into DB to stop loading this field.
  //     DB_InsertBlank(
  //       'SEARCHTERMS',
  //       SearchTerm(EMPTY_KEY, null, adGroupId, null, EMPTY_KEY, null, null,
  //               campaignId, null, null, null)
  //           .toMap(),
  //     );
  //   }
  //   return s;
  // }

  // Saves to DB, no memory overhead.
  // Afterwards, retrieve the relevant searchterms from DB.
  static Future<void> fromAPIPaginated(
      Store<AppState> store,
      String customerId,
      String managerId,
      DateRange dateRange,
      String campaignId,
      String adGroupId,
      {String nextPageToken,
      bool forceAPI = false,
      bool metricsOnly = false,
      List<AdGroupToLoad> adGroupToLoads}) async {
      
      // print("fromAPIPaginated!!!");
    // print("inherited adGroupToLoads: ${adGroupToLoads}");

    // if (forceAPI == true) {
    //   // Search terms page pull down force refreshes everything.
    //   await getAllAdGroups(
    //       store, store.state.currentCustomer.id, store.state.currentManager.id);
    //   adGroupToLoads = await AdGroupToLoad.fromMaps(store, managerId);
    //   print(
    //       "FORCE REFRESH - NEW ADGROUPS_TO_LOAD FOR CUSTOMER IN DB: ${adGroupToLoads.length}");
    // } else {
    //   if (adGroupToLoads == null) {
    //     adGroupToLoads = await AdGroupToLoad.fromMaps(store, managerId);
    //   }
    //   print("AdGroups yet to be loaded: ${adGroupToLoads.length}");

    //   if (adGroupToLoads == null || adGroupToLoads.length == 0) {
    //     int adGroupToLoadsCount =
    //         await AdGroupToLoad.numberOfTotalAdGroupsForCustomer(managerId);

    //     print(
    //         "TOTAL ADGROUPS_TO_LOAD FOR CUSTOMER IN DB: $adGroupToLoadsCount");
    //     if (adGroupToLoadsCount == 0) {
    //       print(
    //           "No ADGROUPS_TO_LOAD FOR CUSTOMER IN DB Getting AllAdGroups from API");
    //       await getAllAdGroups(store, store.state.currentCustomer.id,
    //           store.state.currentManager.id);
    //       // Wait to save to DB, then load adGroupToLoads that were saved.
    //       adGroupToLoads = await AdGroupToLoad.fromMaps(store, managerId);

    //       // for(AdGroupToLoad agtl in adGroupToLoads) {
    //       //   print("adGroupToLoads: ${agtl.toMap()}");
    //       // }
    //       print(
    //           "NEW ADGROUPS_TO_LOAD FOR CUSTOMER IN DB: ${adGroupToLoads.length}");
    //     }
    //   }
    // }

    // TODO remove this
    // adGroupToLoads = adGroupToLoads.sublist(1,10);
    // return;

    // print("adGroupToLoads: ${adGroupToLoads.length}");

    // if (adGroupToLoads.length == 0) {
    //   print("No adGroupsToLoads yet to load, cancelling");
    //   store.dispatch(FinishSearchTermsLoadingAction());
    //   store.dispatch(FinishLoadingToastAction());
    //   GLOBAL_searchTermsAPILoading = false;
    // } else {
    //   GLOBAL_adGroupsToLoadTotal = adGroupToLoads.length - 1;
    //   GLOBAL_adGroupsToLoadFinished = 0;
    // }

    // int searchTermCount = await getRowCount("SEARCHTERMS");

    // store.dispatch(IncrementLoadedAction('searchTerm', searchTermCount));

    // For new implementation just add this.
    adGroupToLoads = [];
    if (true || adGroupToLoads.length > 350) {
      // Every time.
      // Revert to traditional search terms loading mechanism.
      getSearchTerms(store, managerId, customerId, dateRange, adGroupToLoads,
          campaignId: campaignId,
          adGroupId: adGroupId,
          nextPageToken: nextPageToken,
          metricsOnly: metricsOnly);
    } else {
      int i = 0;

      for (AdGroupToLoad adGroupToLoad in adGroupToLoads) {
        // for (int i=0; i<adGroupToLoads.length; i++) {

        await Future.delayed(Duration(milliseconds: 15)); // 50 //100

        // Have to slow down the API requests even moreif there are many more ad groups.
        // Otherwise, this throws 429, resource exceeded.
        // if (adGroupToLoads.length > 1000) {
        //   await Future.delayed(Duration(milliseconds: 50));
        // }

        AdGroupToLoad adGroupToLoad = adGroupToLoads[i];
        // print("adGroupToLoad: ${i+1} / ${adGroupToLoads.length}");
        // Only true for the last adGroupToLoad.
        bool isLastAdGroupToLoad = (i == adGroupToLoads.length - 1);

        // print("isLastAdGroupToLoad: $isLastAdGroupToLoad");

        i += 1;
        // print("isLastAdGroupToLoad: $isLastAdGroupToLoad");

        String adGroupId = adGroupToLoad.adGroupId.toString();
        if (isDataParametersDifferent(
            store, managerId, customerId, dateRange)) {
          // Interrupt process
          // The variables to load from have changed, and a new load process should have been triggered.
          print(
              "SEARCHTERM LOADING PROCESS INTERRUPTED (Search term API loading): $customerId, $managerId: ${dateRange.toString()}");
          return;
        }

        // Removing 'await' drastically speeds up loading all data.
        /*await */ getSearchTermsPaginatedByAdGroup(
            store,
            /*store.state.currentCustomer.id,*/ managerId,
            /*store.state.currentManager.id,*/ customerId,
            dateRange,
            adGroupToLoad,
            isLastAdGroupToLoad,
            campaignId: adGroupToLoad.campaignId, //campaignId,
            adGroupId: adGroupId,
            nextPageToken: nextPageToken);
        // if (s.length == 0) {
        //   // Insert blank entry into DB to stop loading this field.
        //   DB_InsertBlank(
        //     'SEARCHTERMS',
        //     SearchTerm(EMPTY_KEY, null, adGroupId, null, EMPTY_KEY, null, null,
        //             campaignId, null, null, null)
        //         .toMap(),
        //   );
        // }

        // Write to DB that this adGroup has been loaded.
        // adGroupToLoad.isLoaded = true;
        // await updateObject(
        //     adGroupToLoad.toMap(), 'ADGROUPS_TO_LOAD', 'adGroupId');

        // If currently loading data (should always be true)
        // And if no data is currently displayed (during initial loading)
        // Update the visible search terms.
        // print("store.state.searchTerms.length: ${store.state.searchTerms.length}");
        // if (store.state.searchTerms.length > 0) {
        //   store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
        // }

        // print("store.state.showLoadingToast: ${store.state.showLoadingToast}");
        // print("store.state.isLoadingSearchTerms: ${store.state.isLoadingSearchTerms}");
        // print("store.state.isInitialSearchTermsLoading: ${store.state.isInitialSearchTermsLoading}");

        // if ((store.state.showLoadingToast
        //   || store.state.isLoadingSearchTerms
        //   || store.state.isInitialSearchTermsLoading)
        //   && store.state.searchTerms.length == 0) {
        /*
            This method recursively calls SearchTerm.fromMaps();
            Which calls this method again, resulting in repeated API calls.
            Solution is to add a flag which stops API calls from being made, and only pulls from local database.
            // updateVisibleSearchTermsAction() here is used only to begin showing data before loading is complete.
          */
        // store.dispatch(
        //     (x) => updateVisibleSearchTermsAction(store, noAPI: true));
        // }
      }
    }

    return;
  }

  // Load everything from local database.
  static Future<List<SearchTerm>> fromMaps(
    Store<AppState> store,
    bool noAPI, {
    customerClientId: "",
    DateRange dateRange: null,
    campaignId: null,
    adGroupId: "",
    initialId: "",
  }) async {
    // print("SearchTerm.fromMaps() called!!! $noAPI, inherited customerClientId: $customerClientId, campaignId: $campaignId, adGroupId: $adGroupId");

    GLOBAL_searchTermsDBLoading = true;

    List<Map<String, dynamic>> maps;
    List<Map<String, dynamic>> emptyMaps;

    GLOBAL_searchTermsLoading = true;

    store.dispatch(StartSearchTermsLoadingAction());

    String campaignIdConstraint;
    String adGroupIdConstraint;
    String customerClientIdConstraint;

    if (store.state.currentManager == null) {
      GLOBAL_searchTermsLoading = false;
      GLOBAL_searchTermsDBLoading = false;
      return [];
    }

    customerClientIdConstraint = store.state.currentManager.id;
    if (customerClientId != "") {
      customerClientIdConstraint = customerClientId;
    }

    if (store.state.currentCampaign != null) {
      // print("store.state.currentCampaign: ${store.state.currentCampaign.toMap()}");
      campaignIdConstraint = store.state.currentCampaign.id;
    }
    if (campaignId != "") {
      // print("inherited campaignId: $campaignId");
      campaignIdConstraint = campaignId;
    }
    if (store.state.currentAdGroup != null) {
      adGroupIdConstraint = store.state.currentAdGroup.id;
    }
    if (adGroupId != "") {
      adGroupIdConstraint = adGroupId;
    }

    DateRangeLocal dateRangeLocal;

    // Inheriting date range from ModifyDateRangeAction()
    if (dateRange != null) {
      dateRangeLocal =
          getUpperLowerDates(dateRange, store.state.currentManager.timeZone);
    } else {
      dateRangeLocal = getUpperLowerDates(
          store.state.currentDateRange, store.state.currentManager.timeZone);
      dateRange = store.state.currentDateRange;
    }

    // print("store.state.currentDateRange: ${store.state.currentDateRange.lowerDateEpoch}");

    List<Map<String, dynamic>> cachedQueries =
        await getLocalObjectsWithConstraintNoID(
            'CACHED_QUERIES',
            'id',
            SearchTerm.createCachedQueryId(store.state.currentManager.id,
                dateRange, store.state.currentManager.timeZone));

    var cachedQuery;

    if (cachedQueries != null && cachedQueries.length > 0) {
      cachedQuery = cachedQueries[0];

      // Check the upper/lower epoch dates.
      // Compares current day to the last cached day.
      // Local time of the cache query.
      String queryLowerEpoch = cachedQuery['queryLowerEpoch'];
      String queryUpperEpoch = cachedQuery['queryUpperEpoch'];
      // print("cachedQuery: $cachedQuery");
      print("in cache queryLowerEpoch: $queryLowerEpoch");
      // print("in cache queryUpperEpoch: $queryUpperEpoch");
      // print('dateRangeLocal.lowerDateEpoch: ${dateRangeLocal.lowerDateEpoch}');
      // print('dateRangeLocal.upperDateEpoch: ${dateRangeLocal.upperDateEpoch}');

      // GMT time.
      DateTime lowerDate = epochTime2Date(dateRangeLocal.lowerDateEpoch);
      DateTime upperDate = epochTime2Date(dateRangeLocal.upperDateEpoch);

      print("lowerDate adjusted: $lowerDate");
      // print("upperDate adjusted: $upperDate");
      
      DateTime lowerDateEpochStripped = DateTime(lowerDate.year, lowerDate.month, lowerDate.day);
      DateTime upperDateEpochStripped = DateTime(upperDate.year, upperDate.month, upperDate.day);

      print("lowerDateEpochStripped: $lowerDateEpochStripped");

      // GMT time.
      int localLowerEpoch = date2EpochTime(lowerDateEpochStripped);
      int localUpperEpoch = date2EpochTime(upperDateEpochStripped);

      print("localLowerEpoch: $localLowerEpoch, ${epochTime2Date(localLowerEpoch)}");

      int localTimezoneLowerEpoch = epochToLocalEpoch(localLowerEpoch, store.state.currentManager.timeZone);
      int localTimezoneUpperEpoch = epochToLocalEpoch(localUpperEpoch, store.state.currentManager.timeZone);

      print("localTimezoneLowerEpoch: $localTimezoneLowerEpoch");
      print("localTimezoneLowerDate: ${epochTime2Date(localTimezoneLowerEpoch)}");
      
      // print("localUpperEpoch: $localUpperEpoch");

      bool isDifferent = false;

      if (queryLowerEpoch != null || queryUpperEpoch != null) {
        if (queryLowerEpoch != localLowerEpoch.toString()) {
          print("lower is different: $queryLowerEpoch, $localLowerEpoch");
          isDifferent = true;
        }

        if (queryUpperEpoch != localUpperEpoch.toString()) {
          print("Upper is different$queryUpperEpoch, $localUpperEpoch");
          isDifferent = true;
        }
      }

      if (isDifferent) {
        print("CLEARING ALL CACHED DATA FOR: ${cachedQuery['id']}");
        // Delete all search terms and metrics with this uniqueId.
        await removeObject('SEARCHTERMS', 'queryId', cachedQuery['id']);
        // print("Removed cached searchterms");
        await removeObject(
            'SEARCHTERMS_METRICS', 'uniqueId', cachedQuery['id']);
        // print("Removed cached metrics");
        await removeObject('CACHED_QUERIES', 'id', cachedQuery['id']);
        // print("Removed cached queries");

        cachedQuery = null;
      }
    }

    // print("cachedQuery: $cachedQuery");
    
    // Retrieve queried data, 
    // Or, retrieve data if it is a display call.
    if (cachedQuery != null || noAPI == true) {
      // Exists in cache.
      print("Using cached query!!!");

      maps = await getSearchTermsWithConstraintsPaginatedFiltered(
          campaignIdConstraint,
          adGroupIdConstraint,
          customerClientIdConstraint,
          dateRangeLocal.lowerDateEpoch,
          dateRangeLocal.upperDateEpoch,
          store.state.filterValues,
          store.state.searchTermOrderBy,
          PAGINATION_LIMIT,
          0,
          store.state.currentManager.timeZone,
          SearchTerm.createCachedQueryId(store.state.currentManager.id,
              dateRange, store.state.currentManager.timeZone),
          emptiesOnly: false);

      // print("searchterm maps: ${maps}");

      if (maps != null && maps.length > 0) {
        print("Found search terms: " + maps.length.toString());

        store.dispatch(FinishSearchTermsLoadingAction());
        store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));

        List<SearchTerm> st = [];
        await Future.forEach(
            maps,
            (searchTerm) async =>
                st.add(await map2SearchTerm(searchTerm, store)));
        store.dispatch(UpdateVisibleSearchTermsAction(st));
        GLOBAL_isLoadingSearchTerms = false;
        GLOBAL_searchTermsDBLoading = false;
        return st;
      } else {
        // Check if there are any empties.
        // If there are empties, it means this data has been queried before, so ignore it.
        // emptyMaps = await getSearchTermsWithConstraintsPaginatedFiltered(
        //     campaignIdConstraint,
        //     adGroupIdConstraint,
        //     store.state.currentManager.id,
        //     dateRangeLocal.lowerDateEpoch,
        //     dateRangeLocal.upperDateEpoch,
        //     store.state.filterValues,
        //     store.state.searchTermOrderBy,
        //     PAGINATION_LIMIT,
        //     0,
        //     store.state.currentManager.timeZone,
        //     emptiesOnly: true);

        // print("searchterm emptyMaps: ${emptyMaps.length}");

        // else if (cachedQueryCount == 0) {
        // This has been cached.

        // if (emptyMaps != null && emptyMaps.length > 0) {
        // print("Empties exist, exiting SearchTerm.fromMaps()");
        // Empties exist, data was loaded so return.
        store.dispatch(FinishSearchTermsLoadingAction());

        store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
        GLOBAL_isLoadingSearchTerms = false;
        GLOBAL_searchTermsDBLoading = false;
        return [];
      }
    } else if (cachedQuery == null) {
      print("NO CACHED QUERIES, loading from API.");

      // If empties do not exist, and it is not a display call.
      if (noAPI == false) {
        // print('SearchTerms and empties is empty, loading from API');
        // store.dispatch(StartSearchTermsLoadingAction());
        store.dispatch(StartLoadingToastAction());
        store.dispatch(UpdateIsInitialSearchTermsLoadingAction(true));

        GLOBAL_searchTermsAPILoading = true;

        await SearchTerm.fromAPIPaginated(
            store,
            store.state.currentCustomer.id,
            store.state.currentManager.id,
            store.state.currentDateRange,
            campaignIdConstraint,
            adGroupIdConstraint);

        store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
        GLOBAL_searchTermsLoading = false;
        GLOBAL_searchTermsDBLoading = false;
        return [];
      } else {
        print("Display call");

        // if loading has finished, reload.
        // print("store.state.showLoadingToast: ${store.state.showLoadingToast}");
        // print("store.state.isLoadingSearchTerms: ${store.state.isLoadingSearchTerms}");
        // print("store.state.isInitialSearchTermsLoading: ${store.state.isInitialSearchTermsLoading}");

        // This was a display call.
        // noAPI requested, this is only for a display update, so direct return.
        // store.dispatch(FinishSearchTermsLoadingAction());
        // store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
        GLOBAL_isLoadingSearchTerms = false;
        GLOBAL_searchTermsDBLoading = false;
        return [];
      }
    }
    // else {
    // print("Found search terms: " + maps.length.toString());

    // store.dispatch(FinishSearchTermsLoadingAction());
    // store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));

    // List<SearchTerm> st = [];
    // await Future.forEach(
    //     maps, (searchTerm) async => st.add(await map2SearchTerm(searchTerm, store)));
    // store.dispatch(UpdateVisibleSearchTermsAction(st));
    // GLOBAL_isLoadingSearchTerms = false;
    // return st;
    // }
    GLOBAL_searchTermsDBLoading = false;
    return [];
  }

  static Future<List<SearchTerm>> loadMorePaginatedData(
      Store<AppState> store, int offset) async {
    String campaignIdConstraint;
    String adGroupIdConstraint;

    // store.dispatch(StartLoadingToastAction());
    print("Loading more paginated data!!!");

    if (store.state.currentCampaign != null) {
      campaignIdConstraint = store.state.currentCampaign.id;
    }
    if (store.state.currentAdGroup != null) {
      adGroupIdConstraint = store.state.currentAdGroup.id;
    }
    DateRangeLocal dateRangeLocal = getUpperLowerDates(
        store.state.currentDateRange, store.state.currentManager.timeZone);
    List<Map<String, dynamic>> maps =
        await getSearchTermsWithConstraintsPaginatedFiltered(
            campaignIdConstraint,
            adGroupIdConstraint,
            store.state.currentManager.id,
            dateRangeLocal.lowerDateEpoch,
            dateRangeLocal.upperDateEpoch,
            store.state.filterValues,
            store.state.searchTermOrderBy,
            PAGINATION_LIMIT,
            offset * PAGINATION_LIMIT,
            store.state.currentManager.timeZone,
            SearchTerm.createCachedQueryId(
                store.state.currentManager.id,
                store.state.currentDateRange,
                store.state.currentManager.timeZone),
            emptiesOnly: false);
    List<SearchTerm> st = [];
    await Future.forEach(maps,
        (searchTerm) async => st.add(await map2SearchTerm(searchTerm, store)));
    // store.dispatch(FinishSearchTermsLoadingAction());
    return st;
  }

  static Future<SearchTerm> createWaitMetrics(
      SearchTerm searchTerm, Store<AppState> store) async {
    await searchTerm.loadMetrics(store, store.state.currentManager.timeZone,
        store.state.currentDateRange);
    return searchTerm;
  }

  static Future<SearchTerm> map2SearchTerm(dynamic map, Store<AppState> store) {
    return SearchTerm.createWaitMetrics(
        SearchTerm(
          map['id'],
          map['resourceName'],
          map['customerId'],
          map['adGroupId'],
          map['adGroupResourceName'],
          map['text'],
          map['status'],
          map['adGroupName'],
          map['campaignId'],
          map['campaignName'],
          map['campaignResourceName'],
          epochTime2Date(map['date']),
          map['searchTermMatchType'],
          map['queryId'],
          store, /*noLoadMetrics: true*/
        ),
        store);
  }

  // Needs to be a unique id per adGroup/searchterm.
  static generateSearchTermId(String text, String campaignId, String adGroupId,
      String searchTermMatchType, DateRange dateRange, String timeZone) {
      text = text.replaceAll("'", "");
      text = text.replaceAll('"', "");
    // return "$text~$campaignId~$adGroupId~$searchTermMatchType~${epochToLocalEpoch(dateRange.lowerEpochDate, timeZone)}~${epochToLocalEpoch(dateRange.upperEpochDate, timeZone)}";
    return "$text~$campaignId~$adGroupId~$searchTermMatchType~${dateRange.lowerEpochDate}~${dateRange.upperEpochDate}";
  }

  static createCachedQueryId(
      String customerClientId, DateRange dateRange, String timeZone) {
    // return "$customerClientId~${epochToLocalEpoch(dateRange.lowerEpochDate, timeZone)}~${epochToLocalEpoch(dateRange.upperEpochDate, timeZone)}";
    // return "$customerClientId~${dateRange.lowerEpochDate}~${dateRange.upperEpochDate}";
    return "$customerClientId~${dateRange.getName().replaceAll(" ", "_")}";
  }
}

// static Future<List<SearchTerm>> fromMaps(Store<AppState> store, bool noAPI,
//     [initialId]) async {
//   print("SearchTerm.fromMaps() called!!! $noAPI");
//   List<Map<String, dynamic>> maps;
//   List<Map<String, dynamic>> emptyMaps;

//   store.dispatch(StartSearchTermsLoadingAction());
//   // store.dispatch(UpdateIsInitialSearchTermsLoadingAction(true));
//   // If adgroup is empty, filter based on campaign.
//   // If campaign is empty, load all.
//   // print("Campaign == null? " +
//   //     (store.state.currentCampaign == null).toString());
//   // print(
//   //     "Adgroup == null? " + (store.state.currentAdGroup == null).toString());

//   String campaignIdConstraint;
//   String adGroupIdConstraint;

//   if (store.state.currentCampaign != null) {
//     campaignIdConstraint = store.state.currentCampaign.id;
//   }
//   if (store.state.currentAdGroup != null) {
//     adGroupIdConstraint = store.state.currentAdGroup.id;
//   }

//   if (store.state.currentCampaign == null &&
//       store.state.currentAdGroup == null) {
//         // print("store.state.currentDateRange: ${store.state.currentDateRange.getKeyName()}");
//     // maps = await getLocalObjects("SEARCHTERMS");
//     DateRangeLocal dateRangeLocal =
//         getUpperLowerDates(store.state.currentDateRange);
//     SearchTerm.getLocalData(
//       campaignIdConstraint,
//       adGroupIdConstraint,
//       store.state.currentManager.id,
//       dateRangeLocal.lowerDateEpoch,
//       dateRangeLocal.upperDateEpoch,
//       store.state.filterValues,
//       store.state.searchTermOrderBy,
//       LIMIT,
//       0,
//     );
//     maps = await getSearchTermsWithConstraintsPaginatedFiltered(
//         campaignIdConstraint,
//         adGroupIdConstraint,
//         store.state.currentManager.id,
//         dateRangeLocal.lowerDateEpoch,
//         dateRangeLocal.upperDateEpoch,
//         store.state.filterValues,
//         store.state.searchTermOrderBy,
//         LIMIT,
//         0,
//         noEmpty: false);

//     // if (maps.length > 0) {
//     //   store.dispatch(FinishSearchTermsLoadingAction());
//     //   store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
//     //   List<SearchTerm> st = [];
//     //   await Future.forEach(maps,
//     //       (searchTerm) async => st.add(await map2SearchTerm(searchTerm)));
//     //   store.dispatch(UpdateVisibleSearchTermsAction(st));
//     //   return st;
//     // }
//     // return List.generate(maps.length, (i) {
//     //   return map2SearchTerm(maps[i]);
//     // });
//   } else if (campaignIdConstraint != null &&
//       campaignIdConstraint.length > 0) {
//     // Constrain by campaign.
//     DateRangeLocal dateRangeLocal =
//         getUpperLowerDates(store.state.currentDateRange);
//     maps = await getSearchTermsWithConstraintsPaginatedFiltered(
//         campaignIdConstraint,
//         adGroupIdConstraint,
//         store.state.currentManager.id,
//         dateRangeLocal.lowerDateEpoch,
//         dateRangeLocal.upperDateEpoch,
//         store.state.filterValues,
//         store.state.searchTermOrderBy,
//         LIMIT,
//         0);
//     // return List.generate(maps.length, (i) {
//     //   return map2SearchTerm(maps[i]);
//     // });
//     if (maps.length > 0) {
//       store.dispatch(FinishSearchTermsLoadingAction());
//       store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
//       List<SearchTerm> st = [];
//       await Future.forEach(maps,
//           (searchTerm) async => st.add(await map2SearchTerm(searchTerm)));
//       store.dispatch(UpdateVisibleSearchTermsAction(st));
//       return st;
//     }
//   }

//   // String constraintId = store.state.currentAdGroup.id;
//   // if (initialId != null) {
//   //   constraintId = initialId;
//   // }
//   // print("Searching for searchTerms: " + constraintId);
//   // maps = await getLocalObjectsWithConstraint(
//   //     'SEARCHTERMS', 'adGroupId', constraintId);
//   if ((maps == null || maps.length == 0) && noAPI == false) {
//     print('SearchTerms is empty, loading from API');
//     // store.dispatch(StartLoadingAction());
//     // store.dispatch(StartSearchTermsLoadingAction());
//     // List<SearchTerm> out =
//     store.dispatch(StartLoadingToastAction());
//     store.dispatch(UpdateIsInitialSearchTermsLoadingAction(true));
//     await SearchTerm.fromAPIPaginated(
//         store,
//         store.state.currentCustomer.id,
//         store.state.currentManager.id,
//         store.state.currentDateRange,
//         campaignIdConstraint,
//         adGroupIdConstraint);
//     // store.dispatch(FinishSearchTermsLoadingAction());
//     DateRangeLocal dateRangeLocal =
//         getUpperLowerDates(store.state.currentDateRange);
//     maps = await getSearchTermsWithConstraintsPaginatedFiltered(
//         campaignIdConstraint,
//         adGroupIdConstraint,
//         store.state.currentManager.id,
//         dateRangeLocal.lowerDateEpoch,
//         dateRangeLocal.upperDateEpoch,
//         store.state.filterValues,
//         store.state.searchTermOrderBy,
//         LIMIT,
//         0);
//     // print("FINISH LOADING!!!");
//     // store.dispatch(FinishLoadingToastAction());
//     // return out;
//     store.dispatch(FinishSearchTermsLoadingAction());
//     store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
//     List<SearchTerm> st = [];
//     await Future.forEach(
//         maps, (searchTerm) async => st.add(await map2SearchTerm(searchTerm)));
//     store.dispatch(UpdateVisibleSearchTermsAction(st));
//     return st;
//   } else {
//     // print("Found search terms: " + maps.length.toString());
//     store.dispatch(FinishSearchTermsLoadingAction());
//     store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
//     // return List.generate(maps.length, (i) async {
//     //   map2SearchTerm(maps[i]);
//     // });
//     List<SearchTerm> st = [];
//     await Future.forEach(
//         maps, (searchTerm) async => st.add(await map2SearchTerm(searchTerm)));
//     store.dispatch(UpdateVisibleSearchTermsAction(st));
//     return st;
//   }
// }

// static Future<void> fromLocalData(
//   String campaignIdConstraint,
//   String adGroupIdConstraint,
//   String store.state.currentManager.id,
//   int dateRangeLocal.lowerDateEpoch,
//   int dateRangeLocal.upperDateEpoch,
//   List<FilterValue> store.state.filterValues,
//   OrderValue store.state.searchTermOrderBy,
//   LIMIT,
//   0,
// ) async {
//   maps = await getSearchTermsWithConstraintsPaginatedFiltered(
//     campaignIdConstraint,
//     adGroupIdConstraint,
//     store.state.currentManager.id,
//     dateRangeLocal.lowerDateEpoch,
//     dateRangeLocal.upperDateEpoch,
//     store.state.filterValues,
//     store.state.searchTermOrderBy,
//     LIMIT,
//     0,
//     emptiesOnly: false);
//   if (maps == null || maps.length == 0) {
//     // No local data, check for empty keys.
//     emptyMaps = await getSearchTermsWithConstraintsPaginatedFiltered(
//       campaignIdConstraint,
//       adGroupIdConstraint,
//       store.state.currentManager.id,
//       dateRangeLocal.lowerDateEpoch,
//       dateRangeLocal.upperDateEpoch,
//       store.state.filterValues,
//       store.state.searchTermOrderBy,
//       LIMIT,
//       0,
//       emptiesOnly: true);

//     if (emptyMaps == null || emptyMaps.length == 0) {
//       // No results, load from API.
//     }
//   }
//   else {

//     store.dispatch(FinishSearchTermsLoadingAction());
//     store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));

//     List<SearchTerm> st = [];
//     await Future.forEach(
//         maps, (searchTerm) async => st.add(await map2SearchTerm(searchTerm)));

//     store.dispatch(UpdateVisibleSearchTermsAction(st));
//   }

//   return;
// }
