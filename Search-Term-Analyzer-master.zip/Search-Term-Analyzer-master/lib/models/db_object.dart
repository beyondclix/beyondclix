// Generic Local DB object
class DBObject {
  final String id;

  DBObject(this.id);
}
