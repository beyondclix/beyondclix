import 'package:flutter/widgets.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';

enum FirebaseState { LOADING, AVAILABLE, NOT_AVAILABLE }
enum StoreState { LOADING, AVAILABLE, NOT_AVAILABLE }
enum ProductStatus { PURCHASABLE, PURCHASED, PENDING }
enum PurchaseType { SUBSCRIPTION_PURCHASE, NON_SUBSCRIPTION_PURCHASE }
enum Status {
  PENDING,

  /* 
    AWAITING_CONSUMPTION status is for when the single save Consumable
    has been bought but has not yet been consumed.
  */
  // AWAITING_CONSUMPTION,

  COMPLETED,
  ACTIVE,
  EXPIRED
}
enum IAPStore { APP_STORE, GOOGLE_PLAY }

class PurchaseableProduct {
  final String title;
  final String description;
  final String price;
  ProductStatus status;

  PurchaseableProduct(this.title, this.description, this.price)
      : status = ProductStatus.PURCHASABLE;
}

@immutable
class PastPurchase {
  final PurchaseType type;
  final IAPStore store;
  final String orderId;
  final String token;
  final bool isConsumed;
  final String productId;
  final DateTime purchaseDate;
  final DateTime expiryDate;
  final Status status;

  String get title {
    switch (productId) {
      case SKU_MONTHLY_SUBSCRIPTION:
        return 'Subscription';
      // Upgrade
      default:
        return productId;
    }
  }

  PastPurchase.fromJson(Map<String, dynamic> json)
      : type = _typeFromString(json['type'] as String),
        store = _storeFromString(json['iapSource'] as String),
        orderId = json['orderId'] as String,
        token = json['token'] as String,
        isConsumed = json['isConsumed'] as bool,
        productId = json['productId'] as String,
        purchaseDate = DateTime.now(),
        expiryDate = null,
        status = _statusFromString(json['status'] as String);
}

PurchaseType _typeFromString(String type) {
  switch (type) {
    case 'NON_SUBSCRIPTION':
      return PurchaseType.NON_SUBSCRIPTION_PURCHASE;
    case 'SUBSCRIPTION':
      return PurchaseType.SUBSCRIPTION_PURCHASE;
    default:
      throw ArgumentError.value(type, '$type is not a supported type');
  }
}

IAPStore _storeFromString(String store) {
  switch (store) {
    case 'google_play':
      return IAPStore.GOOGLE_PLAY;
    case 'app_store':
      return IAPStore.APP_STORE;
    default:
      throw ArgumentError.value(store, '$store is not a supported store');
  }
}

String stringFromStore(IAPStore store) {
  switch (store) {
    case IAPStore.GOOGLE_PLAY:
      return 'google_play';
    case IAPStore.APP_STORE:
      return 'app_store';
    default:
      throw ArgumentError.value(store, '$store is not a supported store');
  }
}

Status _statusFromString(String status) {
  switch (status) {
    case 'PENDING':
      return Status.PENDING;
    case 'COMPLETED':
      return Status.COMPLETED;
    case 'ACTIVE':
      return Status.ACTIVE;
    case 'EXPIRED':
      return Status.EXPIRED;
    default:
      throw ArgumentError.value(status, '$status is not a supported status');
  }
}
