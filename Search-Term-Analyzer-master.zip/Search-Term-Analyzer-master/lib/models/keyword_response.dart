import '../constants.dart';

class KeywordResponse {
  final List<KeywordError> keywordErrors;

  // Raw statusCode or response.
  final int statusCode;

  // Sometimes a value is returned in the response, it is stored here.
  final String value;

  KeywordResponse(this.keywordErrors, this.statusCode, this.value);
}

class KeywordError {
  // If there is an error, the name and description are here.
  final String name;
  String description;

  KeywordError(this.name, this.description) {
    // Check if this is an error message to prettify.
    if (KEYWORD_ERRORS.containsKey(this.name)) {
      this.description = KEYWORD_ERRORS[this.name];
    }
  }
}
