import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';

class FilterGroup {
  final String title;
  final List<FilterValue> filterValues;

  FilterGroup(this.title, this.filterValues);
}
