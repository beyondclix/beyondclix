import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:redux/redux.dart';

class FilterValue {
  String id;
  String name;
  String type;
  String value;
  String valueType;
  String metricType;
  String stringFilterType;
  String displayName;

  FilterValue(this.name, this.type, this.value,
      {this.displayName = '', this.valueType = 'num', this.stringFilterType = '', this.id = '', this.metricType = ''}) {
        if (id == '' || id == null) {
          this.id = generateId();
        }
      }

  Map<String, dynamic> toMap() {
    return {
      'id': id, 
      'name': name, 
      'type': type, 
      'value': value, 
      'valueType': valueType, 
      'stringFilterType': stringFilterType, 
      'displayName': displayName,
      'metricType': metricType,
    };
  }

  static Future<List<FilterValue>> fromDB() async {
    List<Map<String, dynamic>> maps = await getLocalObjects("FILTER_VALUE");
    // print("filterValues: $maps");
    if (maps == null || maps.length == 0) {
      return [];
    }
    return List.generate(maps.length, (i) {
      return FilterValue(
        maps[i]['name'],
        maps[i]['type'], 
        maps[i]['value'],
        valueType: maps[i]['valueType'],
        stringFilterType: maps[i]['stringFilterType'],
        displayName: maps[i]['displayName'],
        id: maps[i]['id'], 
        metricType: maps[i]['metricType'],
      );
    });
  }
}
