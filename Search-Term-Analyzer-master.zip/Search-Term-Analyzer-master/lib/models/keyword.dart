import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import '../local_data.dart';
import 'date_range.dart';

enum KEYWORD_MATCH_TYPE { BROAD, EXACT, PHRASE, /*UNKNOWN, UNSPECIFIED*/ }

class Keyword {
  Keyword(this.id, this.resourceName, this.adGroupId, this.text,
      this.isNegative, this.adGroup, this.matchType);
  final String id;
  final String resourceName;
  final String adGroupId;
  final String text;
  final bool isNegative;
  final String adGroup;
  final String matchType;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'resourceName': resourceName,
      'adGroupId': adGroupId,
      'text': text,
      'isNegative': boolToInt(isNegative),
      'adGroup': adGroup,
      'matchType': matchType
    };
  }

  static Future<List<Keyword>> fromAPI(
      String customerId, String managerId, DateRange dateRange) async {
    // Disabled for now.
    return await Future.delayed(Duration.zero);
    //getKeywords(managerId, customerId, dateRange);
  }

  // Load everything from local database.
  static Future<List<Keyword>> fromMaps(Store<AppState> store,
      [initialId]) async {
        String constraintId = "";
    if (store.state.currentAdGroup != null){
      constraintId = store.state.currentAdGroup.id;
    }
    if (initialId != null) {
      constraintId = initialId;
    }
    List<Map<String, dynamic>> maps = await getLocalObjectsWithConstraint(
        'KEYWORDS', 'adGroupId', constraintId);
    if (maps == null || maps.length == 0) {
      return null;
    }
    return List.generate(maps.length, (i) {
      return Keyword(
        maps[i]['text'],
        maps[i]['resourceName'],
        maps[i]['adGroupId'],
        maps[i]['text'],
        intToBool(maps[i]['isNegative']),
        maps[i]['adGroup'],
        maps[i]['matchType'],
      );
    });
  }
}
