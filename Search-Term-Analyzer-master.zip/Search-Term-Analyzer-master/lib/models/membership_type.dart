import 'package:flutter/material.dart';

class MembershipType {
  final String skuId;
  final String displayName;
  // final IconData iconData;
  final Widget icon;
  final Color color;
  Color colorDark = Colors.white;

  MembershipType(this.skuId, this.displayName, this.icon, this.color, {this.colorDark});
}
