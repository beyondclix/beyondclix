import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';

// A negative keyword List that is stored in local memory but has not been saved to Google Ads.
class NegativeKeywordListToSave {
  NegativeKeywordListToSave(this.name, this.customerId, this.managerId,
      this.resourceName, this.memberCount, this.referenceCount);

  final String name;
  final String customerId;
  final String managerId;
  String resourceName;
  final int
      memberCount; // Number of keywords (sharedCriteria) within this Negative Keyword List.
  final int
      referenceCount; // Number of campaigns associated with this Negative Keyword List.

  Map<String, dynamic> toMap() {
    return {
      'id': name,
      'resourceName': resourceName,
      'customerId': customerId,
      'managerId': managerId,
      'memberCount': memberCount,
      'referenceCount': referenceCount,
    };
  }

  static Map<String, dynamic> createBlank(
      String name, String customerId, String managerId) {
    return {
      'id': name,
      'resourceName':
          '', // Deliberately left blank because this has to be created via API.
      'customerId': customerId,
      'managerId': managerId,
      'memberCount': 0,
      'referenceCount': 0,
    };
  }

  // Load everything from local database.
  static Future<List<NegativeKeywordListToSave>> fromMaps(
      String currentCustomerId, String currentManagerId,
      [initialId]) async {
    List<Map<String, dynamic>> maps =
        await getLocalObjectsWithConstraint('NEGATIVE_KEYWORD_LIST_TO_SAVE', 'managerId', currentManagerId);
    // print('NEGATIVE_KEYWORD_LIST_TO_SAVE length: ' + maps.length.toString());
    return List.generate(maps.length, (i) {
      return map2NegativeKeywordListToSave(maps[i]);
    });
  }

  // Convert form NegativeKeywordListToSave => NegativeKeywordList
  NegativeKeywordList toNegativeKeywordList() {
    return NegativeKeywordList(this.name, this.customerId, this.managerId,
        this.resourceName, this.memberCount, this.referenceCount);
  }

  // Convert the map object into NegativeKeywordList
  static NegativeKeywordListToSave map2NegativeKeywordListToSave(dynamic map) {
    return NegativeKeywordListToSave(
      map['id'].toString(),
      map['customerId'],
      map['managerId'],
      map['resourceName'],
      map['memberCount'],
      map['referenceCount'],
    );
  }
}
