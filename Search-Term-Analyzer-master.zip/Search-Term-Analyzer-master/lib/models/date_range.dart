// https://developers.google.com/google-ads/api/docs/query/date-ranges

import 'package:searchTermAnalyzerFlutter/common_functions.dart';

class DateRange {
  DateRange(this._name, this._keyName, this.lowerEpochDate, this.upperEpochDate, String timeZone) {
    if (this.lowerEpochDate == null || this.upperEpochDate == null && this._name !=  "") {
      DateRangeLocal drl = getUpperLowerDates(this, timeZone);
      this.lowerEpochDate = drl.lowerDateEpoch;
      this.upperEpochDate = drl.upperDateEpoch;

      // if (this._name == "Custom") {
      //   this.setAdditionalName("(${epochTime2DateString(drl.lowerDateEpoch)} to ${epochTime2DateString(drl.upperDateEpoch)})");
      // } else if (this._name == "Today" || this._name == "Yesterday") {
      //   this.setAdditionalName("${epochTime2DateString(drl.upperDateEpoch)}");
      // } else {
      //   this.setAdditionalName("${epochTime2DateString(drl.lowerDateEpoch)} to ${epochTime2DateString(drl.upperDateEpoch)}");
      // }
    }
  }
  
  final String _name;
  String _keyName;
  String _additionalName = '';
  
  // Custom date has lower and upper epoch dates to use in local data query.
  int lowerEpochDate;
  int upperEpochDate;

  // "yyyy-MM-dd" format
  // static DateTime customDateRangeAfter;
  // static DateTime customDateRangeUntil;

  String getKeyName() {
    return this._keyName;
  }

  String getName() {
    return this._name;
  }

  String setAdditionalName(String additionalName) {
    this._additionalName = additionalName;
  }

  String getAdditionalName() {
    return this._additionalName;
  }

  // To set dynamically for Custom field.
  void setKeyName(String s) {
    this._keyName = s;
  }

  static List<DateRange> dateOptions(String timeZone) {
    return [
      // https://developers.google.com/google-ads/api/docs/reporting/segmentation#rules_for_core_date_segment_fields
      DateRange("Today", "DURING TODAY", null, null, timeZone),
      DateRange("Yesterday", "DURING YESTERDAY", null, null, timeZone),
      DateRange("Last 7 Days", "DURING LAST_7_DAYS", null, null, timeZone),
      DateRange("Last Business Week", "DURING LAST_BUSINESS_WEEK", null, null, timeZone),
      DateRange("This Month", "DURING THIS_MONTH", null, null, timeZone),
      DateRange("Last Month", "DURING LAST_MONTH", null, null, timeZone),
      DateRange("Last 14 Days", "DURING LAST_14_DAYS", null, null, timeZone),
      DateRange("Last 30 Days", "DURING LAST_30_DAYS", null, null, timeZone),
      DateRange("This Week (Sun - Today)", "DURING THIS_WEEK_SUN_TODAY", null, null, timeZone),
      DateRange("This Week (Mon - Today)", "DURING THIS_WEEK_MON_TODAY", null, null, timeZone),
      DateRange("Last Week (Sunday - Sat)", "DURING LAST_WEEK_SUN_SAT", null, null, timeZone),
      DateRange("Last Week (Mon - Sun)", "DURING LAST_WEEK_MON_SUN", null, null, timeZone),
      DateRange("All Time", "", null, null, timeZone), // "> '2000-01-01'
      DateRange("Custom", "", null, null, timeZone),
    ];
  }

  // Used when loading from SharedPreferences
  static fromName(String name, String timeZone) {
    for (DateRange d in dateOptions(timeZone)) {
      if (d.getName() == name) {
        return d;
      }
    }
    // Default to All Time
    // return DateRange("All Time", "");
    return DateRange("", "", null, null, "");
    // return null;
  }

  static isDifferent(DateRange dr1, DateRange dr2) {
    return dr1.getName() != dr2.getName()
    || dr1.getKeyName() != dr2.getKeyName();
  }
}

class DateRangeLocal {
  int lowerDateEpoch;
  int upperDateEpoch;
  DateRangeLocal(this.lowerDateEpoch, this.upperDateEpoch);
}
