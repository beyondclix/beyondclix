import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import '../common_functions.dart';
import '../local_data.dart';
import 'db_object.dart';

class Customer extends DBObject {
  Customer(
      this.id,
      this.resourceName,
      this.isManager,
      this.descriptiveName,
      this.googleEmail,
      this.timeZone,
      this.currencyCode,
      this.clicks,
      this.costMicros,
      this.impressions,
      this.conversions,
      this.allConversions)
      : super(id);
  final String id;
  final String resourceName;
  final bool isManager;
  final String descriptiveName;
  final String googleEmail;
  final String timeZone;
  final String currencyCode;
  int clicks;
  int costMicros;
  int impressions;
  int conversions;
  int allConversions;

  // void loadMetrics() async {
  //   Map<String, dynamic> map = await getCustomerClientMetrics(this);
  //   this.clicks = map['clicks'];
  //   this.costMicros = map['costMicros'];
  //   this.impressions = map['impressions'];
  //   this.conversions = map['conversions'];
  //   this.allConversions = map['allConversions'];
  // }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'resourceName': resourceName,
      'isManager': boolToInt(isManager),
      'descriptiveName': descriptiveName,
      'googleEmail': googleEmail,
      'timeZone': timeZone,
      'currencyCode': currencyCode,
      'clicks': clicks,
      'costMicros': costMicros,
      'impressions': impressions,
      'conversions': conversions,
      'allConversions': allConversions,
    };
  }

  static Future<List<Customer>> fromAPI(
      Store<AppState> store, googleEmail) async {
    return await getCustomers(store, googleEmail);
  }

  static Future<Customer> fromInitialId(String id) async {
    List<Map<String, dynamic>> maps =
        await getLocalObjectsWithConstraint('CUSTOMERS', 'id', id);
    if (maps == null || maps.length == 0) {
      return null;
    }
    return Customer(
      maps[0]['id'],
      maps[0]['resourceName'],
      intToBool(maps[0]['isManager']),
      maps[0]['descriptiveName'],
      maps[0]['googleEmail'],
      maps[0]['timeZone'],
      maps[0]['currencyCode'],
      maps[0]['clicks'],
      maps[0]['costMicros'],
      maps[0]['impressions'],
      maps[0]['conversions'],
      maps[0]['allConversions'],
    );
  }

  // Load from local database.
  static Future<List<Customer>> fromMaps(Store<AppState> store,
      {googleEmail, forceAPI: false}) async {
    if (googleEmail == null) {
      googleEmail =
          readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);
    }

    store.dispatch((x) => updateIsFinishedLoadingCustomersAction(store, false));

    List<Map<String, dynamic>> maps;
    // print("Loading customers with google email: $googleEmail");
    if (forceAPI == false) {
      maps = await getLocalObjectsWithConstraint(
          'CUSTOMERS', 'googleEmail', googleEmail);
    }

    // Load customers from API if there is no DB data.
    if (maps == null || maps.length == 0 || forceAPI == true) {
      return await Customer.fromAPI(store, googleEmail);
    }
    return List.generate(maps.length, (i) {
      return Customer(
        maps[i]['id'].toString(),
        maps[i]['resourceName'],
        intToBool(maps[i]['isManager']),
        maps[i]['descriptiveName'],
        maps[i]['googleEmail'],
        maps[i]['timeZone'],
        maps[i]['currencyCode'],
        maps[i]['clicks'],
        maps[i]['costMicros'],
        maps[i]['impressions'],
        maps[i]['conversions'],
        maps[i]['allConversions'],
      );
    });
  }
}
