// Since pagination is limited in functionality, page token expires after two hours.
// This is an implementation which laods search terms via adgroups.
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';

class AdGroupToLoad {
  int adGroupId;
  String adGroupName;
  String campaignId;
  String customerId;
  bool isLoaded;

  AdGroupToLoad(this.adGroupId, this.adGroupName, this.campaignId, this.customerId, this.isLoaded);

  Map<String, dynamic> toMap() {
    return {
      'adGroupId': adGroupId, 
      'adGroupName': adGroupName,
      'campaignId': campaignId,
      'customerId': customerId,
      'isLoaded': boolToInt(isLoaded)};
  }

  static Future<List<AdGroupToLoad>> fromMaps(Store<AppState> store, String customerId) async {
    List<Map<String, dynamic>> maps = await getAdGroupsYetToLoad(customerId);
    // print("Adgroups yet to load: ${maps.length}");

    if (maps == null || maps.length == 0) {
      return [];
    }

    return List.generate(maps.length, (i) {
      return map2AdGroupToLoad(maps[i]);
    });
  }

  static Future<int> numberOfTotalAdGroupsForCustomer(String customerId) async {
    return await getRowCountConstrained('ADGROUPS_TO_LOAD', 'customerId', customerId);
  }

  static Future<int> notLoaded(String customerId) async {
    return await getAdGroupNotLoadedRowCount('ADGROUPS_TO_LOAD', 'customerId', customerId);
  }

  static AdGroupToLoad map2AdGroupToLoad(dynamic map) {
    return AdGroupToLoad(
      map['adGroupId'],
      map['adGroupName'],
      map['campaignId'],
      map['customerId'],
      intToBool(map['isLoaded']),
    );
  }
}
