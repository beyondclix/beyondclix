import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';

class MetricValue {
  String parentId;
  String metricFor;
  String name;
  num value;

  MetricValue(this.parentId, this.metricFor, this.name, this.value);

  static Future<Map<String, MetricValue>> fromDB(
      String tableName, String id, String uniqueId) async {
        // print("Querying for metric: $uniqueId");
    List<Map<String, dynamic>> maps = await getMetricObject(
        "${tableName}_METRICS", id.replaceAll("'", ""), uniqueId);
    Map<String, MetricValue> metrics = {};
    for (var map in maps) {
      String parentId = map['parentId'];
      String metricFor = map['metricFor'];
      for (String key in map.keys) {
        // Ignore these keys because they are not displayed.
        if (key == 'parentId' || key == 'metricFor' || key == 'uniqueId') {
          continue;
        }

        if (map[key] == null) {
          metrics[key] = new MetricValue(parentId, metricFor, key, 0.0);
        } else {
          metrics[key] = new MetricValue(
              parentId, metricFor, key, map[key] //double.parse()
              );
        }
      }
    }
    // print("searchterm metrics: ${metrics['impressions']}");
    return metrics;
  }

  // Creates a unique Id based on date range, filters, and order-by filters.
  // static String generateUniqueId(
  //     String managerId, DateRange dateRange, String timeZone) {
  //   // return "$managerId~${epochToLocalEpoch(dateRange.lowerEpochDate, timeZone)}~${epochToLocalEpoch(dateRange.upperEpochDate, timeZone)}";
  //   return "$managerId~${dateRange.lowerEpochDate}~${dateRange.upperEpochDate}";
  // }
}
