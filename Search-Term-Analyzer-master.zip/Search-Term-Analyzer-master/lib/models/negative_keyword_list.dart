import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:redux/redux.dart';

class NegativeKeywordList {
  NegativeKeywordList(this.name, this.customerId, this.managerId,
      this.resourceName, this.memberCount, this.referenceCount);

  final String name;
  final String customerId;
  final String managerId;
  String resourceName;
  final int
      memberCount; // Number of keywords (sharedCriteria) within this Negative Keyword List.
  final int
      referenceCount; // Number of campaigns associated with this Negative Keyword List.

  Map<String, dynamic> toMap() {
    return {
      'id': name,
      'resourceName': resourceName,
      'customerId': customerId,
      'managerId': managerId,
      'memberCount': memberCount,
      'referenceCount': referenceCount,
    };
  }

  static Future<List<NegativeKeywordList>> fromAPI(
      Store<AppState> store, String customerId, String managerId) async {
    List<NegativeKeywordList> allNegativeKeywords = await getSharedSets(store, customerId, managerId);
    if (customerId != managerId) {
      // List<NegativeKeywordList> out = [];
      // Use the exclusion process.
      List<String> negativeKeywordListsToExclude = await getSharedSetsToExclude(store, customerId, managerId);
      // for (int i=0; i<negativeKeywordListsToExclude.length;i++) {
      //   print("removing where: ${negativeKeywordListsToExclude[i]}");
      //   print("allNegativeKeywords: ${allNegativeKeywords[i].name}");
    
      // }
      
      allNegativeKeywords.removeWhere((item) => negativeKeywordListsToExclude.contains(item.name));
      // String nkl = negativeKeywordListsToExclude.firstWhere((item) => item == "Non NZ and AU Countries");
      // for (NegativeKeywordList nkl in allNegativeKeywords) {
      //   print(nkl.name);//nkl.resourceName);
      //   print("negativeKeywordListsToExclude.contains(nkl.name): ${negativeKeywordListsToExclude.contains(nkl.name)}");
      // }
      // print("nkl ${nkl}");
    }
    print("allNegativeKeywords: ${allNegativeKeywords.length}");

    for (NegativeKeywordList nkl in allNegativeKeywords) {
      insertObjectIfNotExistUpdateIfExist(
        nkl.toMap(), 'NEGATIVE_KEYWORD_LIST', 'id', true);
    }
    allNegativeKeywords.sort((NegativeKeywordList a, NegativeKeywordList b) {
      return a.name.compareTo(b.name);
    });
    return allNegativeKeywords;

  }

  static Future<void> resetForCustomerClient(String managerId) async {
    return await removeObject(
      'NEGATIVE_KEYWORD_LIST',
      'managerId',
      managerId
    );
  }

  // Load everything from local database.
  static Future<List<NegativeKeywordList>> fromMaps(
      Store<AppState> store, String currentCustomerId, String currentManagerId,
      {onlyAPI: false}) async {
      List<Map<String, dynamic>> maps = [];
    if (!onlyAPI) {
      maps =
        await getLocalObjectsWithConstraint(
          'NEGATIVE_KEYWORD_LIST',
          'managerId',
          currentManagerId);
    } else {
      maps = [];
    }
    print('NEGATIVE_KEYWORD_LIST FROM DB length: ' + maps.length.toString());
    if (maps.length == 0) {
      print('NEGATIVE_KEYWORD_LIST is empty, loading from API: ' +
          currentManagerId.toString());
      return await NegativeKeywordList.fromAPI(
          store, currentCustomerId, currentManagerId);
    } else {
      List<NegativeKeywordList> nkls = List.generate(maps.length, (i) {
        return map2NegativeKeywordList(maps[i]);
      });
      nkls.sort((NegativeKeywordList a, NegativeKeywordList b) {
        return a.name.compareTo(b.name);
      });
      return nkls;

    }
  }

  // Convert the map object into NegativeKeywordList
  static NegativeKeywordList map2NegativeKeywordList(dynamic map) {
    return NegativeKeywordList(
      map['id'].toString(),
      map['customerId'],
      map['managerId'],
      map['resourceName'],
      map['memberCount'],
      map['referenceCount'],
    );
  }
}
