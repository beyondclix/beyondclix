// API calls

import 'dart:convert';
import 'dart:core';
import 'package:http/http.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup_to_load.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/latest_data_loaded_date.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword_response.dart';
import 'package:searchTermAnalyzerFlutter/models/metric_value.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/auth.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'dart:io';
import 'common_functions.dart';
import 'models/customer_client.dart';
import 'models/date_range.dart';
import 'constants.dart';
import 'main.dart';
import 'package:http/http.dart' as http;
import 'models/adgroup.dart';
import 'models/campaign.dart';
import 'models/customer.dart';
import 'models/keyword.dart';
import 'models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
// import 'dart:developer';

// Load customer_client metrics by using their resource name.
Future<void> getManagerCustomerMetrics(
    Store<AppState> store,
    CustomerClient customerClient,
    customerResourceName,
    String managerId) async {
  try {
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v10/" +
            customerResourceName +
            "/googleAds:search"),
        body: json.encode({
          "pageSize": PAGE_SIZE,
          "query":
              "SELECT customer.id, metrics.clicks, metrics.cost_micros, metrics.impressions, metrics.conversions, metrics.all_conversions FROM customer" // WHERE customer.status IN (ENABLED)"
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": managerId,
          "Content-Type": "application/json",
        });

    print("customerClient response.statusCode: ${response.statusCode}");
    if (response.statusCode == 403) {
      // CUSTOMER_NOT_ENABLED
      GLOBAL_customerNotEnabled = true;
      return;
    }
    // print(response);
    // var responseJson = jsonDecode(response.body);
    // print("customerclient metrics resposne: $responseJson");
    if (response.statusCode != 200) {
      // print("Error getting customer metrics: ${response.body.toString()}");
      throw HttpException("Error retrieving customer: ${response.toString()}");
    }

    var _metricObj = jsonDecode(response.body)['results'][0]['metrics'];
    Map<String, dynamic> map = {
      "clicks": int.parse(_metricObj['clicks']),
      "costMicros": int.parse(_metricObj['costMicros']),
      "impressions": int.parse(_metricObj['impressions']),
      "conversions": int.parse(_metricObj['conversions'].toString()),
      "allConversions": int.parse(_metricObj['allConversions'].toString()),
    };
    customerClient.clicks = map['clicks'];
    customerClient.costMicros = map['costMicros'];
    customerClient.impressions = map['impressions'];
    customerClient.conversions = map['conversions'];
    customerClient.allConversions = map['allConversions'];
    // print("OVERRDING: ${customerClient.toMap()}");
    // Override existing customerClient in DB
    insertObjectIfNotExistUpdateIfExist(
        customerClient.toMap(), 'CUSTOMER_CLIENTS', customerClient.id, true);

    return;
  } catch (err) {
    // print("Error API getting customerClient metrics: $err");
    ANALYTICS_logErrorEvent(
        store, 'getManagerCustomerMetrics: ' + err.toString());
    return;
  }
}

// Loads just the metrics for the customer.
Future<void> getNonManagerCustomerMetrics(
    Store<AppState> store, Customer customer) async {
  try {
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v10/customers/" +
            customer.id +
            "/googleAds:search"),
        body: json.encode({
          "pageSize": PAGE_SIZE,
          "query":
              "SELECT customer.id, metrics.clicks, metrics.cost_micros, metrics.impressions, metrics.conversions, metrics.all_conversions FROM customer" // WHERE customer.status IN (ENABLED)"
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "Content-Type": "application/json",
        });

    // print("response.statusCode: ${response.statusCode}");
    // print(response);
    var responseJson = jsonDecode(response.body);
    // print("metrics resposne: $responseJson");
    if (response.statusCode != 200) {
      // print("Error getting customer metrics: ${response.body.toString()}");
      throw HttpException("Error retrieving customer: ${response.toString()}");
    }

    var _metricObj = jsonDecode(response.body)['results'][0]['metrics'];
    Map<String, dynamic> map = {
      "clicks": int.parse(_metricObj['clicks']),
      "costMicros": int.parse(_metricObj['costMicros']),
      "impressions": int.parse(_metricObj['impressions']),
      "conversions": int.parse(_metricObj['conversions'].toString()),
      "allConversions": int.parse(_metricObj['allConversions'].toString()),
    };
    customer.clicks = map['clicks'];
    customer.costMicros = map['costMicros'];
    customer.impressions = map['impressions'];
    customer.conversions = map['conversions'];
    customer.allConversions = map['allConversions'];

    // Override existing customer in DB
    insertObjectIfNotExistUpdateIfExist(
        customer.toMap(), 'CUSTOMERS', customer.id, true);

    return;
  } catch (err) {
    print("Error API getting customer metrics: $err");
    ANALYTICS_logErrorEvent(
        store, "Error API getting customer metrics: " + err.toString());
    return;
  }
}

// Get list of customers via API
Future<List<Customer>> getCustomers(
    Store<AppState> store, String googleEmail) async {
  var response;
  String _previousAccessToken = accessToken;
  
  print("getCustomers: $googleEmail");
  ANALYTICS_logEvent(store, "Getting customers",
      {"googleEmail": googleEmail, "date": DateTime.now().toString()});

  // This means it is loading.
  if (accessToken == null || accessToken.isEmpty) {
    return [];
  }
  store.dispatch(StartLoadingCustomerAction(-1));

  Stopwatch stopwatch = new Stopwatch()..start();

  try {
    response = await http.get(
        Uri.parse(
            "https://googleads.googleapis.com/v10/customers:listAccessibleCustomers"),
        headers: {
          // HttpHeaders.authorizationHeader: "Bearer " + accessToken,
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
        });
  } catch (err) {
    print(
        'Error listAccessibleCustomers: ${err.toString()}, accessToken: $accessToken');
    ANALYTICS_logErrorEvent(
        store, 'Error listAccessibleCustomers: ' + err.toString());
    // showQuickDialog("Error loading linked accounts: " + err.toString());
    stopwatch.stop();
    return [];
  }
  final responseJson = jsonDecode(response.body);
  print('customer: ' + responseJson.toString());
  // print('customer LISTING RESPONSE: ' + responseJson['error'].toString()); //responseJson["resourceNames"].toString());
  final List<Customer> out = [];
  /*
    Data format:
    customer: {resourceNames: [customers/3811261163, customers/6385635207, customers/3756163998, customers/8926448617, customers/5271047590, customers/6392552872, customers/4326910329, customers/3519909098]}
  */
  // responseJson["resourceNames"]
  if (responseJson["resourceNames"] == null) {
    responseJson["resourceNames"] = [];
  }

  if (response.statusCode == 403) {
    store.dispatch(NoGoogleAdsAccountAction());
    // store.dispatch(StartLoadingCustomerAction(0));
    GLOBAL_customerNotEnabled = true;
    ANALYTICS_logEvent(
        store, "No linked Google Ads account", {"googleAccount": googleEmail});
  }

  if (response.statusCode != 200) {
    ANALYTICS_logErrorEvent(
        store, responseJson.toString());
  }

  if (responseJson["resourceNames"].length == 0) {
    store.dispatch(NoGoogleAdsAccountAction());
    ANALYTICS_logEvent(
        store, "No linked Google Ads account", {"googleAccount": googleEmail});
    
    ANALYTICS_logErrorEvent(
        store, 'No accounts loaded getCustomer()');
    
    showQuickDialog("No accounts were loaded. Please use an email address linked to a Google Ads account.");
  }

  store.dispatch(
      StartLoadingCustomerAction(responseJson["resourceNames"].length));

  List<Future<Response>> customerDetailsFutures = [];

  for (var i = 0; i < responseJson["resourceNames"].length; i++) {
    customerDetailsFutures.add(API_loadCustomer(responseJson, i));
  }

  Future.wait(customerDetailsFutures).then((List<Response> responses) {
    // print('"Retrieving customer information: ' + responseJson["resourceNames"][i].toString());
    // Make API call to get resource name for each of these customers.
    responses.forEach((response) {
      try {
        // print("_previousAccessToken: $_previousAccessToken, accessToken: $accessToken");
        if (_previousAccessToken != accessToken ||
            store.state.cancelLoading == true) {
          // Interrupt process
          print("PROCESS INTERRUPTED");
          stopwatch.stop();
          return [];
        }
        // print("RESPONSE: " + response.body);
        // print("response.statusCode: ${response.statusCode}");
        if (response.statusCode == 429 && !GLOBAL_showingQuotaPopup) {
          GLOBAL_showingQuotaPopup = true;
          showQuickDialog(
              "RESOURCE_EXHAUSTED, quota exceeded while loading accounts.");
          ANALYTICS_logEvent(store,
              "RESOURCE_EXHAUSTED quota exceeded while loading accounts", {
            "statusCode": response.statusCode,
          });
        }
        if (response.statusCode != 200) {
          // print("Error getting customer: ${response.statusCode.toString()}");
          print("Error getting customer deatils: ${response.body.toString()}");
          ANALYTICS_logEvent(store, "Error getting customer details", {
            "statusCode": response.statusCode,
          });
          ANALYTICS_logErrorEvent(
            store, 'Error getCustomer(): ' + response.body.toString());

          store.dispatch(ReduceTotalCustomerToLoadCountAction());

          if (response.statusCode == 403) {
            store.dispatch(NoGoogleAdsAccountAction());
            GLOBAL_customerNotEnabled = true;
            ANALYTICS_logEvent(
                store, "No linked Google Ads account", {"googleAccount": googleEmail});
          }
          
          stopwatch.stop();

          throw HttpException(
              "Error retrieving customer: ${response.toString()}");
        } else {
          store.dispatch(IncrementLoadedCustomerAction());
        }
        final customerNameJson = jsonDecode(response.body)['results'];
        if (customerNameJson != null && customerNameJson.length > 0) {
          var _obj = customerNameJson[0]['customer'];
          // var _metricObj = customerNameJson[0]['metrics'];
          // print("metricObj: $_metricObj");
          // print('customer NAME RESPONSE: ' + _obj.toString());
          // print("runTimetype c; ${_metricObj['clicks'].runtimeType}");
          // print("runTimetype cm; ${_metricObj['costMicros'].runtimeType}");
          // print("runTimetype i; ${_metricObj['impressions'].runtimeType}");
          // print("runTimetype conv; ${_metricObj['conversions'].runtimeType}");
          // print(
          //     "runTimetype all conv.; ${_metricObj['allConversions'].runtimeType}");
          Customer c = Customer(
            _obj["id"],
            _obj["resourceName"],
            _obj["manager"],
            _obj["descriptiveName"].toString(),
            googleEmail,
            _obj['timeZone'],
            _obj['currencyCode'],
            null,
            null,
            null,
            null,
            null,
            // int.parse(_metricObj['clicks']),
            // int.parse(_metricObj['costMicros']),
            // int.parse(_metricObj['impressions']),
            // int.parse(_metricObj['conversions'].toString()),
            // int.parse(_metricObj['allConversions'].toString()),
          );

          out.add(c);
          // print("SAVING CUSTOEMR TO DB: ${c.toMap()}");
          insertObjectIfNotExistUpdateIfExist(
              c.toMap(), 'CUSTOMERS', c.id, true);

          // Load metrics if not a manager.
          // If manager, have to load from each client account individually.
          if (!c.isManager) {
            getNonManagerCustomerMetrics(store, c);
          }
        }
      } catch (err) {
        print('Error getCustomer(): ${err.toString()}');
        ANALYTICS_logErrorEvent(
            store, 'Error getCustomer(): ' + err.toString());
        stopwatch.stop();
      }
    });
    // } on HttpException {
    //   print('Going to next customer');
    // }
  });

  Duration elapsedTime = stopwatch.elapsed;
  if (responseJson["resourceNames"].length > 0) {
    ANALYTICS_logEvent(store, "Loading accounts elapsed time",
        {"milliseconds": elapsedTime.inMilliseconds});
    ANALYTICS_logEvent(store, "Finished loading accounts",
        {"numberOfAccounts": responseJson["resourceNames"].length});
  }

  stopwatch.stop();

  return out; //responseJson;
}

// Separated method call out for cleaner Future.wait([]) call.
Future<Response> API_loadCustomer(var responseJson, int i) async {
  String customerResourceName = responseJson['resourceNames'][i].toString();

  // String customerId = new RegExp(r"([0-9]+)")
  //     .allMatches(responseJson['resourceNames'][i].toString())
  //     .elementAt(0)
  //     .group(0);

  final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/" +
          customerResourceName +
          "/googleAds:search"),
      body: json.encode({
        "pageSize": PAGE_SIZE,
        "query":
            "SELECT customer.id, customer.resource_name, customer.descriptive_name, customer.manager, customer.time_zone, customer.currency_code FROM customer" // WHERE customer.status IN (ENABLED)"
      }),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        // "login-customer-id": customerId,
        "Content-Type": "application/json",
      });
  return response;
}

// Page token expires after two hours, so need to query in a different way that is not reliant on it.
// One such way is by getting all of the adGroupId's. (10,000 max), and looping through each of them and loading the search terms.
// This requires a new table and class object.
Future<void> getAllAdGroups(
    Store<AppState> store, String customerId, String managerId) async {
  print("GETTING ALL ADGROUPS: $customerId, $managerId");
  // print("adgroups accessToken: $accessToken");

  /*
    Querying search_term_view is more concise
    For Deal Hatke, result is 455 AdGroups.
    But, if using 'FROM ad_group', result is 10,000 Adgroups. Most of them being empty.

    IN (ENABLED, PAUSED)
  */

  // TODO check if this is working.
  // String query = """
  //   SELECT ad_group.id, ad_group.resource_name, ad_group.name, campaign.id FROM search_term_view
  //   WHERE ad_group.status IN (ENABLED, PAUSED)

  //   ORDER BY ad_group.name
  // """;
  // 10,000 results in Basic browns
  // Doesn't load all of the adGroups, so even after filtering unique, doesn't work very well.

  // String query = """
  //   SELECT search_term_view.ad_group FROM search_term_view
  // """;

  // String query = "SELECT campaign.name, campaign.id FROM campaign";
  // 33 unique Campaigns exist in Basic Browns

  // String query = """
  //   SELECT campaign.id, campaign.name FROM search_term_view ORDER BY campaign.name
  // """;
  // 10,000 results for campaigns in search_term_view.
  // This is because resource_name is implicitly returned, so every result.

  String query = """
    SELECT ad_group.id, ad_group.resource_name, ad_group.name, campaign.id FROM ad_group WHERE ad_group.status IN (ENABLED, PAUSED) ORDER BY ad_group.name
  """;
  // 92 result in Basic Browns
  // 10,000 in Deal Hatke

  if (customerId == null || customerId == "") {
    customerId = managerId;
  }

  try {
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v10/customers/" +
            managerId +
            "/googleAds:searchStream"),
        body: json.encode({
          // "pageSize": PAGE_SIZE,
          "query": query,
          // if (nextPageToken != null) 'pageToken': nextPageToken,
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": customerId,
          "Content-Type": "application/json",
        });
    var responseJson = jsonDecode(response.body);
    // print("responseJson: $responseJson");
    print("getAllAdGroups statusCode: ${response.statusCode}");
    if (response.statusCode == 429) {
      if (!GLOBAL_showingQuotaPopup) {
        GLOBAL_showingQuotaPopup = true;
        showQuickDialog(
            "RESOURCE_EXHAUSTED, quota exceeded while loading accounts.");
      }
      return [];
    }
    if (responseJson.length > 0) {
      responseJson = responseJson[0]; // :searchStream requirement.
    } else {
      return [];
    }
    print("getAllAdGroups RESULT: ${responseJson['results'].length}");

    // print("store.state.currentCustomer.id: ${store.state.currentCustomer.id}, customerId: $customerId");
    // print("store.state.currentManager.id: ${store.state.currentManager.id}");
    if (isDataParametersDifferent(store, managerId, customerId, null)) {
      // Interrupt process
      print("PROCESS INTERRUPTED");
      return [];
    }
    if (responseJson['results'] == null) {
      print("NO ADGROUPS_TO_LOAD FOUND IN API!!!");
    }
    List<Map<String, dynamic>> outMap = [];
    List<AdGroupToLoad> out = [];
    // Add to set.
    Map<String, int> alreadyAddedAdGroups = {};
    for (var i = 0; i < responseJson['results'].length; i++) {
      var obj = responseJson['results'][i];
      if (alreadyAddedAdGroups.containsKey(obj['adGroup']['resourceName'])) {
        // NO action
        continue;
      } else {
        alreadyAddedAdGroups[obj['adGroup']['resourceName']] = 1;
      }
      // print("adGroupName: ${obj['adGroup']['resourceName']}, ${obj['adGroup']['name']}");
      AdGroupToLoad agtl = AdGroupToLoad(
        int.parse(obj['adGroup']['id']),
        obj['adGroup']['name'],
        obj['campaign']['id'],
        managerId,
        false,
      );
      outMap.add(
        agtl.toMap(),
      );
      out.add(agtl);
    }

    print("UNIQUE ADGROUPS: ${alreadyAddedAdGroups.keys.toList().length}");

    // print("outMap: $outMap");
    await insertMultipleObjects(outMap, 'ADGROUPS_TO_LOAD');
    return out;
  } catch (err) {
    print('ERROR getAllAdGroups: $err');
    ANALYTICS_logErrorEvent(store, 'Error getAllAdGroups(): ' + err.toString());
  }
  return [];
}

// Search term exists, but date range changed, so metrics do not.
// Future<void> loadNewMetricsForQuery(
//   Store<AppState> store,
//   String managerId,
//   DateRange dateRange,
// ) async {

// }

Future<void> getSearchTermsPaginatedByAdGroup(
    Store<AppState> store,
    String customerId,
    String managerId,
    DateRange dateRange,
    AdGroupToLoad adGroupToLoad,
    bool isLastAdGroupToLoad,
    {String campaignId,
    String adGroupId,
    String nextPageToken,
    String lastSearchTerm}) async {
  print(
      "SEARCH TERMS LOADING API!!! customerId: $customerId, managerId: $managerId, campaignId: $campaignId, adGroupId: $adGroupId");

  bool isEmpty = false;

  // print("isLastAdGroupToLoad, $isLastAdGroupToLoad");

  try {
    if (managerId == null || managerId == "") {
      managerId = customerId;
    }
    StringBuffer buffer = StringBuffer(
        'SELECT search_term_view.status, search_term_view.resource_name, search_term_view.search_term, segments.search_term_match_type, customer.id, ad_group.id, ad_group.resource_name, ad_group.name, campaign.id, campaign.name, ');
    buffer.write(getMetricsQuery("SEARCHTERMS"));
    buffer.write(" segments.date FROM search_term_view ");
    if (dateRange.getKeyName().isNotEmpty) {
      if (dateRange.getName() == "Custom") {
        // buffer.write(" WHERE segments.date BETWEEN ${date2String(convertToLocalDateTime(epochTime2Date(dateRange.lowerEpochDate), store.state.currentManager.timeZone))} AND ${date2String(convertToLocalDateTime(epochTime2Date(dateRange.upperEpochDate), store.state.currentManager.timeZone))}");
        buffer.write(
            " WHERE segments.date BETWEEN '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.lowerEpochDate, store.state.currentManager.timeZone)))}' AND '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.upperEpochDate, store.state.currentManager.timeZone)))}'");
        // print("WHERE segments.date BETWEEN '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.lowerEpochDate, store.state.currentManager.timeZone)))}' AND '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.upperEpochDate, store.state.currentManager.timeZone)))}'");
      } else {
        // query = query + " WHERE segments.date ${dateRange.getKeyName()}";
        buffer.write(" WHERE segments.date ${dateRange.getKeyName()}");
        // print(" WHERE segments.date ${dateRange.getKeyName()}");
      }
    }
    // 'All Time' is empty, so set it here.
    else {
      buffer.write(
          " WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'");
    }

    // print("dateRange.getKeyName(): ${dateRange.getKeyName()}, ${dateRange.getKeyName().isNotEmpty}");
    // if (lastSearchTerm != null) {
    //   buffer.write(
    //     " "
    //   );
    // }

    // Remove these for now. Just load all data.
    // if (campaignId != null && campaignId.length > 0) {
    //   buffer.write(" AND campaign.id = $campaignId");
    // }
    if (adGroupId != null && adGroupId.length > 0) {
      buffer.write(" AND ad_group.id = $adGroupId ");
    }
    // Add ordering
    buffer.write(" ORDER BY search_term_view.search_term ASC ");

    // print("SEARCHTERMS API QUERY: ${buffer.toString()}");
    // print("accessToken: $accessToken");
    List<SearchTerm> out = [];
    List<Map<String, dynamic>> outMap = [];
    List<Map<String, dynamic>> metrics = [];
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v10/customers/" +
            customerId +
            "/googleAds:search"),
        body: json.encode({
          "pageSize": PAGE_SIZE,
          "query": buffer.toString(),
          if (nextPageToken != null) 'pageToken': nextPageToken,
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": managerId,
          "Content-Type": "application/json",
        });

    if (isDataParametersDifferent(store, customerId, managerId, dateRange)) {
      // Interrupt process
      print("PROCESS INTERRUPTED");
      store.dispatch(FinishSearchTermsLoadingAction());
      store.dispatch(FinishLoadingToastAction());
      return;
    }
    var responseJson = jsonDecode(response.body);
    // print("responseJson: ${responseJson}");

    if (response.statusCode == 429) {
      if (!GLOBAL_showingQuotaPopup) {
        GLOBAL_showingQuotaPopup = true;
        showQuickDialog(
            "RESOURCE_EXHAUSTED, quota exceeded while loading accounts.");
      }
      return;
    }

    // Handle PAGE_TOKEN_EXPIRED error.
    // if (responseJson.containsKey('error') && responseJson['error']['code'] == 400) {
    // Query using lastSearchTerm.
    // String lastSearchTerm = readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.LAST_SEARCH_TERM);
    // if (lastSearchTerm == null || lastSearchTerm.length == 0) {
    //   print("ERROR loading lastSearchTerm");
    // }
    // await getSearchTermsPaginatedByAdGroup(store, customerId, managerId, dateRange,
    //     campaignId: campaignId,
    //     adGroupId: adGroupId,
    //     lastSearchTerm: lastSearchTerm);
    // }

    // responseJson = responseJson[0]; // no longer using :searchStream
    if (responseJson["results"] == null || responseJson.length == 0) {
      DB_InsertBlank(
        'SEARCHTERMS',
        SearchTerm(
                SearchTerm.generateSearchTermId(
                    EMPTY_KEY,
                    campaignId,
                    adGroupId,
                    EMPTY_KEY,
                    dateRange,
                    store.state.currentManager.timeZone),
                null,
                customerId,
                /*managerId*/ adGroupId,
                null,
                EMPTY_KEY,
                null,
                null,
                campaignId,
                null,
                null,
                null,
                null,
                null,
                store,
                noLoadMetrics: true)
            .toMap(),
      );
      print(" ----- LENGTH: BLANK");
      isEmpty = true;
    }
    // if (responseJson.length == 0) {
    //   DB_InsertBlank(
    //     'SEARCHTERMS',
    //     SearchTerm(generateId(), null, customerId, adGroupId, null, EMPTY_KEY,
    //             null, null, campaignId, null, null, null,
    //             noLoadMetrics: true)
    //         .toMap(),
    //   );
    //   return;
    // }
    // if (responseJson['results'].length == 0) {
    //     print(" ----- LENGTH: 0");
    //   }
    if (!isEmpty) {
      print("SEARCH TERMS: " +
          "----- LENGTH: " +
          responseJson["results"].length.toString());
      // print('Results: ${responseJson["nextPageToken"]}');
      store.dispatch(
          IncrementLoadedAction('searchTerm', responseJson["results"].length));
      for (var i = 0; i < responseJson["results"].length; i++) {
        var obj = responseJson["results"][i];
        var averageCpc = obj['metrics']['averageCpc'];
        if (averageCpc == null) {
          averageCpc = 0;
        }

        // print('obj[segments]: ${obj["segments"]}');

        String searchTermId = SearchTerm.generateSearchTermId(
            obj['searchTermView']['searchTerm'],
            obj['campaign']['id'],
            obj['adGroup']['id'],
            obj['segments']['searchTermMatchType'],
            dateRange,
            store.state.currentManager.timeZone);
        obj['metrics']['parentId'] = searchTermId;
        // obj['searchTermView']['searchTerm'].toString().replaceAll("'", "");

        // Attach newly created unique id.
        obj['metrics']['uniqueId'] = SearchTerm.createCachedQueryId(
            customerId, dateRange, store.state.currentManager.timeZone);
        // print("Saving metric uniqueId: ${obj['metrics']['uniqueId']}");
        metrics.add(obj['metrics']);
        SearchTerm s = SearchTerm(
          // Has to be unique, or doesn't save in DB.
          //generateId(), //obj['searchTermView']['searchTerm'].toString(),
          searchTermId,
          obj['searchTermView']['resourceName'],
          customerId, // customerClientId
          // obj['customer']['id'], // API is giving the parent customer, rather than the customerClient.
          obj['adGroup']['id'],
          obj['adGroup']['resourceName'],
          obj['searchTermView']['searchTerm'],
          obj['searchTermView']['status'],
          obj['adGroup']['name'],
          obj['campaign']['id'],
          obj['campaign']['name'],
          obj['campaign']['resourceName'],
          string2DateTime(obj['segments']['date']),
          obj['segments']['searchTermMatchType'],
          SearchTerm.createCachedQueryId(
              customerId, dateRange, store.state.currentManager.timeZone),
          store,
          noLoadMetrics:
              true, // Don't load metrics, because they are not in DB, but manually load them below.
        );
        // out.add(s);
        // await s.loadMetrics(store, store.state.currentManager.timeZone, dateRange);
        outMap.add(s.toMap());
      }
      await insertOrUpdateMetrics('SEARCHTERMS', metrics, 'SEARCHTERM');
      await insertMultipleObjects(outMap, 'SEARCHTERMS');
      // If next page exists

      // Check to update visible search terms.
      if (store.state.searchTerms.length == 0 ||
          GLOBAL_adGroupsToLoadTotal == GLOBAL_adGroupsToLoadFinished) {
        // Also allow if this is the last, so a display call is made to update visible data.

        /*
          This method recursively calls SearchTerm.fromMaps();
          Which calls this method again, resulting in repeated API calls.
          Solution is to add a flag which stops API calls from being made, and only pulls from local database.
          updateVisibleSearchTermsAction() here is used only to begin showing data before loading is complete.
        */
        int nowTimestamp = DateTime.now().millisecondsSinceEpoch;

        // print("nowTimestamp - GLOBAL_lastSearchTermsDisplayCall: ${nowTimestamp - GLOBAL_lastSearchTermsDisplayCall}");

        // print("GLOBAL_adGroupsToLoadFinished: $GLOBAL_adGroupsToLoadFinished");
        // print("GLOBAL_adGroupsToLoadTotal: $GLOBAL_adGroupsToLoadTotal");

        if (nowTimestamp - GLOBAL_lastSearchTermsDisplayCall > 350 || // 750
            GLOBAL_adGroupsToLoadTotal == GLOBAL_adGroupsToLoadFinished) {
          print("API DISPLAY CALL TRIGGERED!!!");
          // print("API STORE CUSTOMER ID: ${store.state.currentManager.id}");
          store.dispatch((x) => updateVisibleSearchTermsAction(store,
              noAPI: true,
              adGroupId: adGroupId, // null
              campaignId: campaignId, // null
              customerClientId: /*customerId*/ store.state.currentManager.id));

          GLOBAL_lastSearchTermsDisplayCall = nowTimestamp;
        }
      }

      if (responseJson['nextPageToken'] != null) {
        // Recursively call next page
        // String nextPageToken = responseJson["nextPageToken"];
        // Save in case app is closed mid-load.
        // setSharedPreferenceValue(
        //     SHARED_PREFERENCE_KEYS.NEXT_PAGE_TOKEN, nextPageToken);
        // String lastSearchTerm = outMap.last.text;
        // setSharedPreferenceValue(
        //     SHARED_PREFERENCE_KEYS.LAST_SEARCH_TERM, lastSearchTerm);

        // Just remove the loading so main content is visible.
        // store.dispatch(FinishSearchTermsLoadingAction());
        print(
            "Loading next page API with nextPageToken: ${responseJson['nextPageToken']}");
        store.dispatch(UpdateIsLoadingPaginatedDataAction(true));

        // If this is the first page, add to paginated load count.
        if (nextPageToken == null) {
          GLOBAL_paginatedLoadTotal += 1;
        }

        await getSearchTermsPaginatedByAdGroup(store, customerId, managerId,
            dateRange, adGroupToLoad, isLastAdGroupToLoad,
            campaignId: campaignId,
            adGroupId: adGroupId,
            nextPageToken: responseJson['nextPageToken']);
      }

      // else {
      // End loading.
      // removeValue(SHARED_PREFERENCE_KEYS.NEXT_PAGE_TOKEN);
      // removeValue(SHARED_PREFERENCE_KEYS.LAST_SEARCH_TERM);
      // store.dispatch(FinishLoadingToastAction());

      // Only trigger if nextPageToken was passed through earlier.
      // if (nextPageToken != null) {
      //   store.dispatch(UpdateIsLoadingPaginatedDataAction(false));
      // }

      // print("paginated SearchTerms complete");
      // adGroupToLoad.isLoaded = true;
      // await updateObject(
      //     adGroupToLoad.toMap(), 'ADGROUPS_TO_LOAD', 'adGroupId');

      // }

    }

    // print("AdgroupIsLoaded");

    // print("store.state.showLoadingToast: ${store.state.showLoadingToast}");
    // print("store.state.isLoadingSearchTerms: ${store.state.isLoadingSearchTerms}");
    // print("store.state.isInitialSearchTermsLoading: ${store.state.isInitialSearchTermsLoading}");

    if (store.state.searchTerms.length > 0) {
      store.dispatch(UpdateIsInitialSearchTermsLoadingAction(false));
    }

    // If came from a next page and it is the last page, remove one paginated entry.
    if (nextPageToken != null && responseJson['nextPageToken'] == null) {
      GLOBAL_paginatedLoadComplete += 1;
    }

    // print("GLOBAL_paginatedLoadComplete: $GLOBAL_paginatedLoadComplete");
    // print("GLOBAL_paginatedLoadTotal: $GLOBAL_paginatedLoadTotal");

    // Check not loading paginated data.
    if (responseJson['nextPageToken'] == null) {
      // print("NONpaginated SearchTerms complete");

      if (nextPageToken != null) {
        store.dispatch(UpdateIsLoadingPaginatedDataAction(false));
      }

      // The last adGroup to load, and came from paginated next page.
      // if (isLastAdGroupToLoad) {
      // print("GLOBAL_adGroupsToLoadTotal: $GLOBAL_adGroupsToLoadTotal");
      // print("GLOBAL_adGroupsToLoadFinished: $GLOBAL_adGroupsToLoadFinished");
      if (GLOBAL_adGroupsToLoadTotal == GLOBAL_adGroupsToLoadFinished &&
          GLOBAL_adGroupsToLoadTotal > 0) {
        print("finished loading everything ADGROUPS PARTITION");
        store.dispatch(FinishLoadingToastAction());
        GLOBAL_searchTermsAPILoading = false;
        GLOBAL_adGroupsToLoadFinished = 0;
        GLOBAL_adGroupsToLoadTotal = 0;

        // Only update the latest date loaded for at the end of all API calls.
        LatestDataLoadedDate.toDB(LatestDataLoadedDate(
          customerId,
          dateRange.upperEpochDate,
        ));

        store
            .dispatch(UpdateMostRecentDataDateAction(dateRange.upperEpochDate));
      }

      store.dispatch(FinishSearchTermsLoadingAction());

      if (GLOBAL_adGroupsToLoadFinished < GLOBAL_adGroupsToLoadTotal) {
        GLOBAL_adGroupsToLoadFinished += 1;
      }

      adGroupToLoad.isLoaded = true;
      await updateObject(
          adGroupToLoad.toMap(), 'ADGROUPS_TO_LOAD', 'adGroupId');
    } else {
      // print("PAGINATED END -- NO ACTION");

    }

    return;
  } catch (err) {
    print('ERROR WITH SEARCH TERMS: $err');
    ANALYTICS_logErrorEvent(
        store, 'Error getSearchTermsPaginatedByAdGroup: ' + err.toString());
    return;
  }
}

Future<void> getSearchTerms(Store<AppState> store, String customerId,
    String managerId, DateRange dateRange, List<AdGroupToLoad> adGroupToLoads,
    {String campaignId,
    String adGroupId,
    String nextPageToken,
    bool metricsOnly = false}) async {
  if (nextPageToken == null) {
    print("SEARCH TERMS LOADING API!!!");
  }
  // print("Querying for search terms in date: " + dateRange.getName());
  try {
    if (managerId == null || managerId == "") {
      managerId = customerId;
    }
    StringBuffer buffer = StringBuffer(
        'SELECT search_term_view.status, search_term_view.resource_name, search_term_view.search_term, ad_group.id, ad_group.resource_name, ad_group.name, campaign.id, campaign.name, ');
    buffer.write(getMetricsQuery("SEARCHTERMS"));
    // buffer.write(" segments.date FROM search_term_view ");

    // If using segments.date > or  segments.date <  in WHERE clause, this needs to be present in SELECT clause.
    // But, this partitions the data so that a manual metrics calculation is necessary.
    // But, if using BETWEEN/DURING in WHERE clause, a segments.date is not required in SELECT clause, which avoids partitioning the data.
    buffer.write(" segments.search_term_match_type FROM search_term_view ");

    // String query =
    //     'SELECT search_term_view.status, search_term_view.resource_name, search_term_view.search_term, ad_group.id, ad_group.resource_name, ad_group.name, campaign.id, campaign.name, segments.date, ${getMetricsQuery("SEARCHTERMS")} FROM search_term_view ';
    // print("dateRange.getKeyName(): ${dateRange.getKeyName()}");
    if (dateRange.getKeyName().isNotEmpty) {
      if (dateRange.getName() == "Custom") {
        // buffer.write(" WHERE segments.date BETWEEN ${date2String(convertToLocalDateTime(epochTime2Date(dateRange.lowerEpochDate), store.state.currentManager.timeZone))} AND ${date2String(convertToLocalDateTime(epochTime2Date(dateRange.upperEpochDate), store.state.currentManager.timeZone))}");
        buffer.write(
            " WHERE segments.date BETWEEN '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.lowerEpochDate, store.state.currentManager.timeZone)))}' AND '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.upperEpochDate, store.state.currentManager.timeZone)))}'");
        // print("WHERE segments.date BETWEEN '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.lowerEpochDate, store.state.currentManager.timeZone)))}' AND '${date2String(epochTime2Date(epochToLocalEpoch(dateRange.upperEpochDate, store.state.currentManager.timeZone)))}'");
      } else {
        // query = query + " WHERE segments.date ${dateRange.getKeyName()}";
        // print(" WHERE segments.date ${dateRange.getKeyName()}");
        buffer.write(" WHERE segments.date ${dateRange.getKeyName()}");
      }
    }
    // 'All Time' is empty, so set it here.
    else {
      // query = query +
      //     " WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'";
      // buffer.write(" WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'");
      buffer.write(
          " WHERE segments.date BETWEEN '2000-01-01' AND '${date2String(DateTime.now())}'");
      // print(" WHERE segments.date BETWEEN '2000-01-01' AND '${date2String(DateTime.now())}'");
    }

    // Remove these for now. Just load all data.
    if (campaignId != null && campaignId.length > 0) {
      buffer.write(" AND campaign.id = $campaignId ");
    }
    if (adGroupId != null && adGroupId.length > 0) {
      buffer.write(" AND ad_group.id = $adGroupId ");
    }

    //TODO remove this.
    // buffer.write(" AND search_term_view.search_term IN ('air fryer cheap as chips', 'afterpay cheap as chips' )");
    // buffer.write(" AND search_term_view.search_term = 'afterpay cheap as chips'");
    // buffer.write(" OR search_term_view.search_term = 'air fryer cheap as chips' ");
    // buffer.write(" AND search_term_view.search_term REGEXP_MATCH 'air fryer cheap as chips|afterpay cheap as chips'");
    // buffer.write(" AND search_term_view.search_term LIKE '1zb childrens%' ");
    // buffer.write(
    //   " LIMIT 5"
    // );

    // print("dateRange.getKeyName(): ${dateRange.getKeyName()}, ${dateRange.getKeyName().isNotEmpty}");

    // if (campaignId != null && campaignId.length > 0) {
    //   // query = query + " AND campaign.id = $campaignId";
    //   buffer.write(" AND campaign.id = $campaignId");
    // }
    // if (adGroupId != null && adGroupId.length > 0) {
    //   // query = query + " AND ad_group.id = $adGroupId";
    //   buffer.write(" AND ad_group.id = $adGroupId");
    // }
    // log("SEARCH TERMS query: " + query);
    // query = buffer.toString();
    // print("SEARCHTERMS query: " + query.length.toString() + " : " + query.toString());
    List<SearchTerm> out = [];
    List<Map<String, dynamic>> outMap = [];
    List<Map<String, dynamic>> metrics = [];
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v8/customers/" +
            customerId +
            "/googleAds:search"), // "searchStream"
        body: json.encode({
          // First page is smaller to show data quickly.
          "pageSize": nextPageToken == null ? 50 : PAGE_SIZE,
          "query": buffer.toString(),
          if (nextPageToken != null) 'pageToken': nextPageToken,
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": managerId,
          "Content-Type": "application/json",
        });
    var responseJson = jsonDecode(response.body);

    if (isDataParametersDifferent(store, customerId, managerId, dateRange)) {
      // Interrupt process
      print("PROCESS INTERRUPTED");
      store.dispatch(FinishSearchTermsLoadingAction());
      store.dispatch(FinishLoadingToastAction());
      return;
    }
    // if (responseJson.length == 0) {
    //   return;
    // }
    // responseJson = responseJson[0];
    // print("SEARCHTERMS RESULTS: ${responseJson['results']}");
    if (responseJson["results"] == null) {
      print("NO RESULTS: finished loading everything ALL SEARCH TERMS");
      store.dispatch(FinishSearchTermsLoadingAction());
      store.dispatch(FinishLoadingToastAction());
      GLOBAL_searchTermsAPILoading = false;
      GLOBAL_adGroupsToLoadFinished = 0;
      GLOBAL_adGroupsToLoadTotal = 0;

      // Only update the latest date loaded for at the end of all API calls.
      LatestDataLoadedDate.toDB(LatestDataLoadedDate(
        customerId,
        dateRange.upperEpochDate,
      ));

      if (dateRange.getName() != "Today") {
        await addCachedQuery(
            SearchTerm.createCachedQueryId(
                customerId, dateRange, store.state.currentManager.timeZone),
            dateRange.lowerEpochDate,
            dateRange.upperEpochDate);
      }

      store.dispatch(UpdateMostRecentDataDateAction(dateRange.upperEpochDate));

      await finishMultipleAdGroupToLoads(adGroupToLoads);

      ANALYTICS_logEvent(store, "Finished Loading Search Terms",
          {"dateRange": dateRange.getName()});

      return;
    }
    print("SEARCH TERMS: " +
        // responseJson["results"].toString() +
        "----- LENGTH: " +
        responseJson["results"].length.toString());

    if (responseJson['results'].length == 0) {
      if (dateRange.getName() != "Today") {
        await addCachedQuery(
            SearchTerm.createCachedQueryId(
                customerId, dateRange, store.state.currentManager.timeZone),
            dateRange.lowerEpochDate,
            dateRange.upperEpochDate);
      }
    }

    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i];

      var averageCpc = obj['metrics']['averageCpc'];
      if (averageCpc == null) {
        averageCpc = 0;
      }

      String searchTermId = SearchTerm.generateSearchTermId(
          obj['searchTermView']['searchTerm'],
          obj['campaign']['id'],
          obj['adGroup']['id'],
          obj['segments']['searchTermMatchType'],
          dateRange,
          store.state.currentManager.timeZone);

      obj['metrics']['parentId'] = searchTermId;

      obj['metrics']['uniqueId'] = SearchTerm.createCachedQueryId(
          customerId, dateRange, store.state.currentManager.timeZone);
      // print("metrics uniqueId: ${obj['metrics']['uniqueId']}");

      // print("Saving metric uniqueId: ${obj['metrics']['uniqueId']}");
      // if (obj['searchTermView']['searchTerm'] == 'rainbow reading') {
      // print("obj['metrics']: ${obj['metrics']['impressions']}");
      // }
      metrics.add(obj['metrics']);

      SearchTerm s = SearchTerm(
        searchTermId,
        obj['searchTermView']['resourceName'],
        customerId,
        obj['adGroup']['id'],
        obj['adGroup']['resourceName'],
        obj['searchTermView']['searchTerm'],
        obj['searchTermView']['status'],
        obj['adGroup']['name'],
        obj['campaign']['id'],
        obj['campaign']['name'],
        obj['campaign']['resourceName'],
        // Local date.
        null, //string2DateTime(obj['segments']['date']),
        obj['segments']['searchTermMatchType'],
        SearchTerm.createCachedQueryId(
            customerId, dateRange, store.state.currentManager.timeZone),
        store,
        noLoadMetrics: true,
      );
      // print('saving search term date: ${s.date}');

      // await s.loadMetrics(
      //     store, store.state.currentManager.timeZone, dateRange, noAPI: true);
      outMap.add(s.toMap());
      // print('s: ${s.toMap()}');

    }
    await insertOrUpdateMetrics('SEARCHTERMS', metrics, 'SEARCHTERM');
    await insertMultipleObjects(outMap, 'SEARCHTERMS');

    // Check to update visible search terms.
    if (store.state.searchTerms.length ==
        0 /* || responseJson['nextPageToken'] == null */) {
      // Also allow if this is the last page, so a display call is made to update visible search terms.

      /*
        This method recursively calls SearchTerm.fromMaps();
        Which calls this method again, resulting in repeated API calls.
        Solution is to add a flag which stops API calls from being made, and only pulls from local database.
        updateVisibleSearchTermsAction() here is used only to begin showing data before loading is complete.
      */
      int nowTimestamp = DateTime.now().millisecondsSinceEpoch;

      // print("nowTimestamp - GLOBAL_lastSearchTermsDisplayCall: ${nowTimestamp - GLOBAL_lastSearchTermsDisplayCall}");

      // print("GLOBAL_adGroupsToLoadFinished: $GLOBAL_adGroupsToLoadFinished");
      // print("GLOBAL_adGroupsToLoadTotal: $GLOBAL_adGroupsToLoadTotal");

      if (nowTimestamp - GLOBAL_lastSearchTermsDisplayCall > 350 || // 750
          true ||
          responseJson['nextPageToken'] == null) {
        if (metricsOnly == false) {
          print("API DISPLAY CALL TRIGGERED!!!");

          if (responseJson['nextPageToken'] == null) {
            if (dateRange.getName() != "Today") {
              await addCachedQuery(
                  SearchTerm.createCachedQueryId(customerId, dateRange,
                      store.state.currentManager.timeZone),
                  dateRange.lowerEpochDate,
                  dateRange.upperEpochDate);
                  // print("Saving cached query: ${dateRange.lowerEpochDate}, ${dateRange.upperEpochDate}");
            }
          }

          store.dispatch((x) => updateVisibleSearchTermsAction(store,
              noAPI: true,
              adGroupId: adGroupId, // null
              campaignId: campaignId, // null
              customerClientId: /*customerId*/ store.state.currentManager.id));

          GLOBAL_lastSearchTermsDisplayCall = nowTimestamp;
        }
      }
    }

    if (responseJson['nextPageToken'] != null) {
      // Recursively call next page
      // String nextPageToken = responseJson["nextPageToken"];
      // Save in case app is closed mid-load.
      // setSharedPreferenceValue(
      //     SHARED_PREFERENCE_KEYS.NEXT_PAGE_TOKEN, nextPageToken);
      // String lastSearchTerm = outMap.last.text;
      // setSharedPreferenceValue(
      //     SHARED_PREFERENCE_KEYS.LAST_SEARCH_TERM, lastSearchTerm);

      // Just remove the loading so main content is visible.
      // store.dispatch(FinishSearchTermsLoadingAction());
      print(
          "Loading next page API with nextPageToken: ${responseJson['nextPageToken']}");
      store.dispatch(UpdateIsLoadingPaginatedDataAction(true));

      // If this is the first page, add to paginated load count.
      if (nextPageToken == null) {
        GLOBAL_paginatedLoadTotal += 1;
      }

      ANALYTICS_logEvent(store, "Loading next page for query",
          {"dateRange": dateRange.getName()});

      await getSearchTerms(
          store, customerId, managerId, dateRange, adGroupToLoads,
          campaignId: campaignId,
          adGroupId: adGroupId,
          nextPageToken: responseJson['nextPageToken']);
    } else if (responseJson['nextPageToken'] == null) {
      print("finished loading everything ALL SEARCH TERMS");
      store.dispatch(FinishLoadingToastAction());
      GLOBAL_searchTermsAPILoading = false;
      GLOBAL_adGroupsToLoadFinished = 0;
      GLOBAL_adGroupsToLoadTotal = 0;

      // Only update the latest date loaded for at the end of all API calls.
      LatestDataLoadedDate.toDB(LatestDataLoadedDate(
        customerId,
        dateRange.upperEpochDate,
      ));

      store.dispatch(UpdateMostRecentDataDateAction(dateRange.upperEpochDate));

      if (dateRange.getName() != "Today") {
        await addCachedQuery(
            SearchTerm.createCachedQueryId(
                customerId, dateRange, store.state.currentManager.timeZone),
            dateRange.lowerEpochDate,
            dateRange.upperEpochDate);
      }

      await finishMultipleAdGroupToLoads(adGroupToLoads);
    }

    store.dispatch(FinishSearchTermsLoadingAction());

    return;
  } catch (err) {
    print("accessToken: $accessToken");
    print('ERROR WITH SEARCH TERMS: ' + err.toString());

    ANALYTICS_logErrorEvent(store, 'Error getSearchTerms: ' + err.toString());

    // Reload after a delay
    Future.delayed(
        new Duration(milliseconds: 250),
        () async => {
          if (accessToken != null && accessToken.isNotEmpty) {
                // await getSearchTerms(
                //     store, customerId, managerId, dateRange, adGroupToLoads,
                //     campaignId: campaignId,
                //     adGroupId: adGroupId,
                //     nextPageToken: null);
          }
        });

    // store.dispatch(FinishLoadingToastAction());
    // GLOBAL_searchTermsAPILoading = false;
    // GLOBAL_adGroupsToLoadFinished = 0;
    // GLOBAL_adGroupsToLoadTotal = 0;

    return;
  }
}

// https://developers.google.com/adwords/api/docs/guides/negative-keywords-shared-sets#python
/*
Future<List<dynamic>> getNegativeKeywordLists(String customerId, String managerId) async {
  final response = await http.post(
    "https://googleads.googleapis.com/v8/customers/" + customerId +
    "/googleAds:search",
    body: json.encode({
      "pageSize": PAGE_SIZE,
      "query": 
        "SELECT * FROM customer_negative_criterion  WHERE customer_negative_criterion.type = 'KEYWORD' AND customer_negative_criterion.status = 'ENABLED'"
    })
  );
}
*/

// getSharedSets retrieves ALL shared sets for customer.
// Only if the current customerClientId is the manager, can you write to it.
// THEREFORE, it causes a MUTATION_ERROR, RESOURCE_NOT_FOUND.
// So, a hack is to load all of the shared sets by setting the customerId in the title.
// This is then the list of shared sets to exclude.
// Take this list and remove any duplicates, and the result is all mutateable negative keyword lists.
Future<List<String>> getSharedSetsToExclude(
    Store<AppState> store, String customerId, String managerId) async {
  try {
    final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId +
          "/googleAds:search"),
      body: json.encode({
        "pageSize": PAGE_SIZE,
        "query": """
              SELECT shared_set.name, shared_set.resource_name, shared_set.reference_count, shared_set.member_count, customer.id
              FROM shared_set 
              WHERE shared_set.type = 'NEGATIVE_KEYWORDS' 
              AND shared_set.status = 'ENABLED'
              """
      }),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "login-customer-id": customerId,
        "Content-Type": "application/json",
      },
    );
    final responseJson = jsonDecode(response.body);
    // print("getSharedSets: " + responseJson.toString());
    // print("getSharedSets STATUSCODE:" + response.statusCode.toString());
    List<String> out = [];
    // if (store.state.currentManager.id != customerId) {
    //   // Interrupt process
    //   print("PROCESS INTERRUPTED");
    //   return [];
    // }
    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i]['sharedSet'];

      String n = obj['name'];
      out.add(n);
      // print("EXCLUDE negativeKeywordList: ${n}");

    }
    return out;
  } catch (err) {
    print("Issue retrieving shared sets to EXCLUDE: $err");
    ANALYTICS_logErrorEvent(
        store, 'Issue retrieving shared sets to EXCLUDE: ' + err.toString());
    return [];
  }
}

// Loads Negative Keyword Lists.
Future<List<NegativeKeywordList>> getSharedSets(
    Store<AppState> store, String customerId, String managerId) async {
  try {
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v10/customers/" +
            managerId +
            "/googleAds:search"),
        body: json.encode({
          "pageSize": PAGE_SIZE,
          "query": """
              SELECT shared_set.name, shared_set.resource_name, shared_set.reference_count, shared_set.member_count, customer.id
              FROM shared_set 
              WHERE shared_set.type = 'NEGATIVE_KEYWORDS' 
              AND shared_set.status = 'ENABLED'
              """
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": customerId,
          "Content-Type": "application/json",
        });
    final responseJson = jsonDecode(response.body);
    // print("getSharedSets: " + responseJson.toString());
    // print("getSharedSets STATUSCODE:" + response.statusCode.toString());
    List<NegativeKeywordList> out = [];
    // if (store.state.currentManager.id != customerId) {
    //   // Interrupt process
    //   print("PROCESS INTERRUPTED");
    //   return [];
    // }
    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i]['sharedSet'];

      var n = NegativeKeywordList(
          obj['name'],
          customerId,
          responseJson["results"][i]['customer']['id'], // managerId
          obj['resourceName'],
          int.parse(obj['memberCount']),
          int.parse(obj['referenceCount']));
      out.add(n);
      // print("negativeKeywordList: ${n.toMap()}");
      // insertObjectIfNotExistUpdateIfExist(
      //     n.toMap(), 'NEGATIVE_KEYWORD_LIST', 'id', true);
    }
    return out;
  } catch (err) {
    print("Issue retrieving sharedSets: " + err.toString());
    ANALYTICS_logErrorEvent(
        store, 'Error retrieving shared sets: ' + err.toString());
    return [];
  }
  // return responseJson;
}

// https://developers.google.com/adwords/api/docs/guides/negative-keywords-shared-sets#shared_sets
// https://developers.google.com/google-ads/api/docs/samples/create-and-attach-shared-keyword-set
// https://developers.google.com/google-ads/api/reference/rpc/v8/SharedSet
Future<KeywordResponse> createNegativeKeywordList(
    Store<AppState> store,
    String customerId,
    String managerId,
    String negativeKeywordListName,
    Function addToErrorLogs) async {
  final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          managerId + //Use managerId here if login-customer-id is defined.
          "/sharedSets:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
        "login-customer-id":
            customerId, // Use customerId here if managerId is defined.
      },
      body: json.encode({
        "operations": [
          {
            "create": {
              "type": "NEGATIVE_KEYWORDS",
              "name":
                  negativeKeywordListName, //"Search Term Analyzer - Negative Keyword List",
            }
          }
        ]
      }));

  final responseJson = jsonDecode(response.body);

  print("createNegativeKeywordList STATUSCODE: " +
      response.statusCode.toString());
  print("createNegativeKeywordList: " + responseJson.toString());
  if (responseJson['results'] == null) {
    addToErrorLogs(responseJson.toString());
    return KeywordResponse(
        getKeywordErrors(response), response.statusCode, null);
  }
  if (response.statusCode != 200 && response.statusCode != 202) {
    return KeywordResponse(
        getKeywordErrors(response), response.statusCode, null);
  }
  print(
      "Created negative keyword list resource name: ${responseJson['results'][0]['resourceName']}");
  return KeywordResponse(
      [], response.statusCode, responseJson['results'][0]['resourceName']);
}

// Adds keyword to negative keyword list.
Future<KeywordResponse> addToNegativeKeywordList(
    Store<AppState> store,
    String customerId,
    String managerId,
    String matchType,
    String text,
    // List<SearchTermSaveAction> searchTermsToAdd,
    String sharedSetResourceName,
    /*String negativeKeywordListResourceName*/
    Function addToErrorLogs) async {
  List<dynamic> operations = [];

  print("sharedSetResourceName: $sharedSetResourceName");

  // for (SearchTermSaveAction stsa in searchTermsToAdd) {
  operations.add({
    "create": {
      "sharedSet": sharedSetResourceName,
      "keyword": {
        "match_type": matchType, //stsa.matchType,
        "text": text, //stsa.searchTermText
      },
    }
  });
  // }

  final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          managerId + //managerId + //customerId +
          "/sharedCriteria:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
        "login-customer-id": customerId, //managerId,
      },
      body: json.encode({
        "operations": operations,
      }));

  final responseJson = jsonDecode(response.body);
  print(
      "addToNegativeKeywordList STATUSCODE: " + response.statusCode.toString());
  if (response.statusCode == 401) {
    // signInSILENT(store);
    return KeywordResponse([
      KeywordError("UNAUTHENTICATED", "Please reopen Search Terms Manager.")
    ], response.statusCode, null);
  } else if (response.statusCode > 300) {
    addToErrorLogs(responseJson.toString());
    return KeywordResponse(
        getKeywordErrors(response), response.statusCode, null);
  }
  if (response.statusCode != 200 && response.statusCode != 202) {
    return KeywordResponse(
        getKeywordErrors(response), response.statusCode, null);
  }

  print("addToNegativeKeywordList: " + responseJson.toString());
  return null;
}

// Not used right now, but there should be
// a checkbox to 'add to campaign' which triggers this.
// https://developers.google.com/google-ads/api/reference/rpc/v7/CampaignSharedSet
// https://developers.google.com/google-ads/api/docs/samples/create-and-attach-shared-keyword-set
Future<dynamic> attachNegativeKeywordListToCampaign(
    Store<AppState> store,
    String customerId,
    String managerId,
    String sharedSetResourceName,
    String campaignResourceName) async {
  final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId +
          "/campaignSharedSets:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
        "login-customer-id": managerId, // ?
      },
      body: json.encode({
        "operations": [
          {
            "create": {
              "campaign": campaignResourceName,
              "sharedSet": sharedSetResourceName,
            }
          }
        ],
      }));
  final responseJson = jsonDecode(response.body);

  print("attachNegativeKeywordListToCampaign STATUSCODE: " +
      response.statusCode.toString());
  print("attachNegativeKeywordListToCampaign: " + responseJson.toString());
  return responseJson;
}

Future<List<Keyword>> getKeywords(Store<AppState> store, String customerId,
    String managerId, DateRange dateRange) async {
  try {
    print('KEYWORD Manager id: ' + managerId);
    if (managerId == null || managerId == "") {
      managerId = customerId;
    }
    List<Keyword> out = [];
    final response = await http.post(
        Uri.parse("https://googleads.googleapis.com/v10/customers/" +
            customerId +
            "/googleAds:search"),
        body: json.encode({
          "pageSize": PAGE_SIZE, //10000,
          "query":
              "SELECT ad_group_criterion.keyword.text, ad_group_criterion.keyword.match_type, ad_group_criterion.negative, ad_group_criterion.ad_group, ad_group_criterion.status FROM ad_group_criterion WHERE ad_group_criterion.type = 'KEYWORD' AND ad_group_criterion.status = 'ENABLED'"
        }),
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": managerId,
          "Content-Type": "application/json",
        });
    final responseJson = jsonDecode(response.body);
    if (responseJson["results"] == null) {
      return out;
    }
    print("KEYWORDS: " + responseJson.toString());
    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i]["adGroupCriterion"];
      Keyword k = Keyword(
        obj['keyword']['text'],
        obj['resourceName'],
        obj['adGroup'],
        obj['keyword']['text'],
        obj['negative'],
        obj['adGroup'],
        obj['keyword']['matchType'],
      );
      out.add(k);
      insertObjectIfNotExistUpdateIfExist(k.toMap(), 'KEYWORDS', k.text, true);
    }
    return out;
  } catch (err) {
    print("Issue retrieving keywords: " + err.toString());
    ANALYTICS_logErrorEvent(
        store, 'Error retrieving keywords: ' + err.toString());
    return [];
  }
}

void updateKeywords(Store<AppState> store, String customerId, String newText,
    Keyword k, DateRange dateRange) async {
  final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId +
          "/adGroupCriteria:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
      },
      body: json.encode({
        "operations": [
          {
            "updateMask": "keyword,match_type,text",
            "update": {
              "resourceName": k
                  .resourceName, //"customers/" + this.customerId.toString() + "/adGroupCriteria/" + adGroupId + "~" + adGroupCriteriaId,
              "keyword": {"match_type": "EXACT", "text": newText}
            }
          }
        ]
      }));
  if (store.state.currentManager.id != customerId) {
    // Interrupt process
    print("PROCESS INTERRUPTED");
    return;
  }
  final responseJson = jsonDecode(response.body);
  updateObject(k.toMap(), 'KEYWORDS', "id" /*k.resourceName*/);
  print("Updated: " + responseJson["resourceNames"].toString());
}

// https://developers.google.com/google-ads/api/docs/targeting/criteria
// https://github.com/googleads/google-ads-python/blob/310a488b6fdad9d5beea8fa4b166edce779a2511/google/ads/googleads/v8/resources/types/campaign_criterion.py#L33
Future<KeywordResponse> createKeywordCampaignLevel(
    Store<AppState> store,
    String customerId,
    String managerId,
    String campaignResourceName,
    String text,
    String matchType) async {
  print("CREATING CAMPAIGN LEVEL KEYWORD: " + campaignResourceName.toString());

  final response = await http.post(
      Uri.parse('https://googleads.googleapis.com/v10/customers/' +
          managerId +
          "/campaignCriteria:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
        "login-customer-id": customerId, //managerId,
      },
      body: json.encode({
        "operations": [
          {
            "create": {
              "status": "ENABLED",
              "campaign": campaignResourceName,
              "keyword": {"match_type": matchType, "text": text},
              "negative": true, // Has to always be negative for campaign level
            }
          }
        ]
      }));
  print("Create keyword campaign level");
  print(jsonDecode(response.body));

  final int statusCode = response.statusCode;
  if (statusCode != 200) {
    return KeywordResponse(
        getKeywordErrors(response), response.statusCode, null);
  }

  print("responseJson.toString(): ${jsonDecode(response.body).toString()}");

  return null;

  // return responseJson;
}

Future<KeywordResponse> createKeyword(
    Store<AppState> store,
    String customerId,
    String managerId,
    String text,
    String adGroupResourceName,
    bool isNegative,
    String matchType,
    String finalUrls,
    double maxCpc) async {
  // print('maxCpc: $maxCpc');
  // print("customerId: $customerId");
  // print("managerId: $managerId");
  // print('CREATING KEYWORD!!!: ' +
  //     text +
  //     " customerId: " +
  //     customerId +
  //     ' managerId: ' +
  //     managerId +
  //     ', finalURLS: ' +
  //     finalUrls +
  //     ', maxCpc: ' +
  //     maxCpc.toString());
  // print("store.state.currentCustomer.id: ${store.state.currentCustomer.id}");
  // print("store.state.currentManager.id: ${store.state.currentManager.id}");
  // print('adGroup: $adGroupResourceName, $isNegative, $matchType');

  final response = await http.post(
      Uri.parse('https://googleads.googleapis.com/v10/customers/' +
          managerId + //customerId +
          "/adGroupCriteria:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
        "login-customer-id": customerId, //managerId,
      },
      body: json.encode({
        "operations": [
          {
            "create": {
              "status": "ENABLED",
              "ad_group": adGroupResourceName,
              "keyword": {"match_type": matchType /*"BROAD"*/, "text": text},
              "negative": isNegative,
              "finalUrls": [finalUrls],
              if (maxCpc != null)
                "cpc_bid_micros": maxCpc * 1000000, // in micros.
            }
          }
        ]
      }));
  print(jsonDecode(response.body));
  // if (store.state.currentManager.id != customerId) {
  //   // Interrupt process
  //   print("PROCESS INTERRUPTED");
  //   return 0;
  // }
  // final responseJson = jsonDecode(response.body);
  final int statusCode = response.statusCode;

  if (statusCode != 200) {
    return KeywordResponse(
        getKeywordErrors(response), response.statusCode, null);
  }
  //TODO update keywords
  // insertObjectIfNotExistUpdateIfExist(k.toMap(), 'KEYWORDS', k.resourceName);

  // Keyword k = Keyword(this.resourceName, this.text, this.isNegative, this.adGroup,
  //     this.matchType

  print("CREATED KEYWORD: ${jsonDecode(response.body)}");
  // print("TODO SAVE THIS KEYWORD LOCALLY!!!");

  // return responseJson;
}

void deleteKeywords(String customerId, String adGroupId,
    String adGroupCriteriaId, Keyword k) async {
  final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId +
          "/adGroupCriteria:mutate"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "Content-Type": "application/json",
      },
      body: json.encode({
        "operations": [
          {
            "remove": "customers/" +
                customerId +
                "/adGroupCriteria/" +
                adGroupId +
                "~" +
                adGroupCriteriaId,
          }
        ]
      }));
  final responseJson = jsonDecode(response.body);
  deleteObject('id', k.resourceName, 'KEYWORDS');
  print("Deleted: " + responseJson["resourceNames"].toString());
}

Future<List<AdGroup>> getAdGroups(Store<AppState> store, String customerId,
    String managerId, DateRange dateRange,
    {String campaignId, String nextPageToken}) async {
  List<AdGroup> out = [];

  List<Map<String, dynamic>> outMap = [];
  List<Map<String, dynamic>> metrics = [];
  print("ADGROUP LOADING API!!!");
  print('ADGROUP Manager id: ' + managerId);
  print('ADGROUP Customer id: ' + customerId);
  print("ADGROUP CamapignId: $campaignId");
  if (managerId == null || managerId == "") {
    managerId = customerId;
  }
  try {
    StringBuffer buffer = StringBuffer("SELECT ");
    buffer.write(getMetricsQuery('ADGROUPS'));
    buffer.write(
        " ad_group.id, ad_group.resource_name, ad_group.name, campaign.id, campaign.name, customer.id, ad_group.status FROM ad_group ");
    // String query =
    //     "SELECT ${getMetricsQuery('ADGROUPS')} ad_group.id, ad_group.resource_name, ad_group.name, campaign.id, ad_group.status FROM ad_group "; //, segments.date
    // if (dateRange.getKeyName().isNotEmpty) {
    //   // query += "WHERE segments.date ${dateRange.getKeyName()}";
    //   buffer.write("WHERE segments.date ${dateRange.getKeyName()}");
    // }
    // 'All Time' is empty, so set it here.
    // else {
    //   // query +=
    //   //     "WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'";
    //   buffer.write(
    //       "WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'");
    // }
    // buffer.write(" AND ad_group.status != REMOVED");
    buffer.write(" WHERE ad_group.status IN (ENABLED, PAUSED)");
    if (campaignId != null && campaignId.length > 0) {
      // query = query + " AND campaign.id = $campaignId";
      buffer.write(" AND campaign.id = $campaignId");
    }
    // print("ADGROUP QUERY: ${buffer.toString()}");
    final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId +
          "/googleAds:searchStream"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "login-customer-id": managerId,
      },
      body: json.encode({
        // "pageSize": PAGE_SIZE, //10000,
        "query": buffer.toString(),
        // if (nextPageToken != null) 'pageToken': nextPageToken
      }),
    );
    var responseJson = jsonDecode(response.body);
    if (isDataParametersDifferent(store, customerId, managerId, null)) {
      // Interrupt process
      print("PROCESS INTERRUPTED");
      return [];
    }
    if (responseJson.length == 0) {
      return out;
    }
    responseJson = responseJson[0];
    // print("ADGROUPS API DATA: " + response.body.toString());
    if (responseJson["results"] == null) {
      return out;
    }

    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i];
      obj['metrics']['parentId'] = obj['adGroup']['id'];
      metrics.add(obj['metrics']);
      // await insertOrUpdateMetrics(
      //     obj['metrics'], 'ADGROUP', obj['adGroup']['id']);
      AdGroup a = AdGroup(
        obj['adGroup']['id'],
        obj['customer']['id'],
        obj['campaign']['id'],
        obj['campaign']['name'],
        obj['adGroup']['resourceName'],
        obj['adGroup']['name'],
        store,
        // string2DateTime(responseJson['results'][i]['segments']['date']),
      );
      // a.loadMetrics();
      out.add(a);
      outMap.add(a.toMap());
      // insertObjectIfNotExistUpdateIfExist(a.toMap(), 'ADGROUPS', a.id);
    }
  } catch (err) {
    print('Issue retrieving AdGroups: ' + err.toString());
    ANALYTICS_logErrorEvent(store, 'Error getAdGroups(): ' + err.toString());
  }
  print("API ADGROUPS: " + out.length.toString()); //out.toString());
  await insertOrUpdateMetrics('ADGROUPS', metrics, 'ADGROUP');
  await insertMultipleObjects(outMap, 'ADGROUPS');
  return []; //out;
}

Future<List<Campaign>> getCampaigns(Store<AppState> store, String customerId,
    String managerId, DateRange dateRange) async {
  List<Campaign> out = []; // Removing campaign query

  List<Map<String, dynamic>> outMap = [];
  List<Map<String, dynamic>> metrics = [];
  print("CAMPAIGN LOADING API!!!");
  if (managerId == null || managerId == "") {
    managerId = customerId;
  }
  try {
    StringBuffer buffer = StringBuffer("SELECT ");
    buffer.write(getMetricsQuery('CAMPAIGN'));
    buffer.write(
        " campaign.id, campaign.name, campaign.resource_name, campaign.status FROM campaign ");
    // String query =
    //     "SELECT ${getMetricsQuery('CAMPAIGN')} campaign.id, campaign.name, campaign.resource_name FROM campaign ";
    // if (dateRange.getKeyName().isNotEmpty) {
    //   // query += "WHERE segments.date ${dateRange.getKeyName()}";
    //   buffer.write("WHERE segments.date ${dateRange.getKeyName()}");
    // }
    // 'All Time' is empty, so set it here.
    // else {
    //   // query +=
    //   //     "WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'";
    //   buffer.write(
    //       "WHERE segments.date > '2000-01-01' AND segments.date < '${date2String(DateTime.now())}'");
    // }
    // buffer.write(" AND campaign.status != REMOVED");
    buffer.write(" WHERE campaign.status IN (ENABLED, PAUSED)");
    // buffer.write(" WHERE campaign.status IN (ENABLED)");
    buffer
        .write(" AND campaign.advertising_channel_type IN (SEARCH, SHOPPING)");
    // query = buffer.toString();
    // print(buffer.toString());

    final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId +
          "/googleAds:searchStream"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "login-customer-id": managerId,
      },
      body: json.encode({
        // "pageSize": PAGE_SIZE,
        "query": buffer.toString()
      }),
    );
    var responseJson = jsonDecode(response.body);
    print(responseJson);
    if (isDataParametersDifferent(store, customerId, managerId, null)) {
      // Interrupt process
      print("PROCESS INTERRUPTED");
      return [];
    }
    // For searchStream
    if (responseJson.length == 0) {
      return out;
    }
    responseJson = responseJson[0];
    // print("CAMPAIGNS RESULT: " + responseJson.toString());
    if (responseJson["results"] == null) {
      return out;
    }
    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i]['campaign'];
      var m = responseJson["results"][i]['metrics'];
      m['parentId'] = obj['id'];
      metrics.add(m);
      // await insertOrUpdateMetrics(
      //     responseJson["results"][i]['metrics'], 'CAMPAIGN', obj['id']);
      Campaign c = Campaign(
        obj['id'],
        customerId,
        obj['resourceName'],
        obj['name'],
        obj['status'],
        store,
        // string2DateTime(responseJson['results'][i]['segments']['date'])
      );
      // c.loadMetrics();
      out.add(c);
      outMap.add(c.toMap());
      // insertObjectIfNotExistUpdateIfExist(c.toMap(), 'CAMPAIGNS', c.id);
    }
  } catch (err) {
    print('Issue retrieving Campaigns: ' + err.toString());
    ANALYTICS_logErrorEvent(store, 'Error getCampaigns(): ' + err.toString());
  }
  await insertOrUpdateMetrics('CAMPAIGN', metrics, 'CAMPAIGN');
  await insertMultipleObjects(outMap, 'CAMPAIGNS');
  return []; //out;
}

/*Future<CustomerInfo> getCustomerInfo(int customerId) async {
  // print('RETRIEVING CUSTOMER PAGE DATA: ' + this.customerId.toString());
  try {
    final response = await http.post(
        "https://googleads.googleapis.com/v8/customers/" +
            customerId.toString() +
            "/googleAds:search",
        headers: {
          "Authorization": "Bearer " + accessToken,
          "developer-token": DEVELOPER_TOKEN,
          "login-customer-id": customerId.toString(),
        },
        body: {
          "query":
              "SELECT ad_group_criterion.keyword.text, ad_group_criterion.status FROM ad_group_criterion WHERE ad_group_criterion.type = 'KEYWORD' AND ad_group_criterion.status = 'ENABLED'"
        });
    if (response.statusCode != 200) {
      throw HttpException("Error retrieving account info: $response");
    }
    final responseJson = jsonDecode(response.body);
    print("CUSTOMER PAGE STATE: " + responseJson.toString());
    return new CustomerInfo(customerId);
  } catch (err) {
    print('Issue retrieving Account page info: ' + err.toString());
    return new CustomerInfo(customerId);
  }
  // } on HttpException {
  //   print('Issue retrieving Account page info');
  //   return new CustomerInfo(this.customerId, context);
  // }
}*/

Future<List<CustomerClient>> getCustomerClients(
    Store<AppState> store, customerId) async {
  List<CustomerClient> out = [];

  try {
    // print("Searching with customerId: $customerId");
    // store.dispatch(StartLoadingCustomerClientsAction());
    final response = await http.post(
      Uri.parse("https://googleads.googleapis.com/v10/customers/" +
          customerId.toString() +
          "/googleAds:search"),
      headers: {
        "Authorization": "Bearer " + accessToken,
        "developer-token": DEVELOPER_TOKEN,
        "login-customer-id": customerId.toString(),
      },
      body: json.encode({
        "query":
            "SELECT customer_client.id, customer_client.descriptive_name, customer_client.manager, customer_client.test_account, customer_client.client_customer, customer_client.time_zone, customer_client.currency_code FROM customer_client"
      }),
    );
    // print("API customerClient response: ${jsonDecode(response.body)}");
    //, customer.client_customer
    // 'https://googleads.googleapis.com/v8/' + responseJson["resourceNames"][i].toString(),
    if (store.state.currentManager != null &&
        store.state.currentManager.id != customerId) {
      // Interrupt process
      print("PROCESS INTERRUPTED");
      return [];
    }
    if (response.statusCode != 200) {
      throw HttpException("Error retrieving account info: $response");
    }
    final responseJson = jsonDecode(response.body);
    if (responseJson["results"] == null ||
        responseJson["results"].length == 0) {
      return out;
    }
    // print("CustomerClient responseJson: " + responseJson['results'].toString());
    // print("responseJson['results'].length: " + responseJson['results'].length.toString());
    for (var i = 0; i < responseJson["results"].length; i++) {
      var obj = responseJson["results"][i];
      // print('customerClient obj: ' + obj.toString());
      CustomerClient cc = CustomerClient(
          obj['customerClient']['id'].toString(),
          obj['customerClient']['resourceName'].toString(),
          obj['customerClient']['descriptiveName'],
          obj['customerClient']['manager'],
          // new RegExp(r"([0-9]+)$")
          new RegExp(r"([0-9]+)")
              .allMatches(obj['customerClient']['resourceName'].toString())
              .elementAt(0)
              .group(0),
          obj['customerClient']['timeZone'],
          obj['customerClient']['currencyCode'],
          null,
          null,
          null,
          null,
          null);
      // print("cc.name: " + cc.name);
      out.add(cc);
      insertObjectIfNotExistUpdateIfExist(
          cc.toMap(), 'CUSTOMER_CLIENTS', cc.id);

      if (!cc.isManager) {
        getManagerCustomerMetrics(
            store, cc, obj['customerClient']['clientCustomer'], customerId);
      }
      // print('out: ' + out.toString());
    }

    return out;
    // this._clientCustomers = out;//responseJson["results"];
    // } on HttpException {
  } catch (err) {
    print('Issue retrieving customerClient info: $err ');
    ANALYTICS_logErrorEvent(
        store, 'Error getCustomerClients(): ' + err.toString());
    return out;
  }
}

// Future<List<Campaign>> getCampaigns() async {
//   try {
//     final response = await http.post(
//       "https://googleads.googleapis.com/v8/customers/" + this.customerId.toString() + "/campaigns:search",
//       headers: {
//         "Authorization": "Bearer " + accessToken,
//         "developer-token": DEVELOPER_TOKEN,
//         "login-customer-id": this.customerId.toString(),
//       },
//       body: {
//         "pageSize": 10000,
//         "query": "SELECT ad_group_criterion.keyword.text, ad_group_criterion.status FROM ad_group_criterion WHERE ad_group_criterion.type = 'KEYWORD' AND ad_group_criterion.status = 'ENABLED'"
//       }
//     );
//     if(response.statusCode != 200){
//       throw HttpException("Error retrieving account info: ${response.statusCode}");
//     }
//     final responseJson = jsonDecode(response.body);
//     // final List<Campaign> out = [];
//     print(responseJson["resourceNames"].toString());
//     // for(var i=0;i<responseJson["resourceNames"].length;i++){
//     //   try {
//     //     final response =
//     //   }
//     // }
//     return responseJson["resourceNames"];
//   } on HttpException {
//     print('Issue retrieving Campaign info');
//   }
// }
