import 'dart:async';
// import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/purchase_complete_dialog.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:searchTermAnalyzerFlutter/models/product_introductory_details.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:in_app_purchase_android/billing_client_wrappers.dart';

void listenToPurchaseUpdated(
    Store<AppState> store, List<PurchaseDetails> purchaseDetailsList) {
  // print("purchaseDetailsList.length: ${purchaseDetailsList.length}");
  purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
    print("GOT PURCHASE_DETAILS: ${purchaseDetails.status}");
    print("purchaseDetails.productID: ${purchaseDetails.productID}");
    // print("purchaseDetails.status: ${purchaseDetails.status}");
    if (purchaseDetails.status == PurchaseStatus.pending) {
    } else {
      if (purchaseDetails.status == PurchaseStatus.error) {
        // On ChromeOS, cannot press window X to close, will nto trigger error.
        // Have to press back button to emulate moving back.
        // _handleError(purchaseDetails.error!);
        print("ERROR HANDLING PURCHASE: " + purchaseDetails.error.toString());
        store.dispatch(UpdateIsPurchasingAction(false));
        ANALYTICS_logEvent(store, "Error handling purchase", {
          "purchaseDetails": purchaseDetails.error.toString(),
          "productID": purchaseDetails.productID,
          'purchaseErrorStatus': purchaseDetails.status.toString(),
        });

        ANALYTICS_logErrorEvent(store, purchaseDetails.error.toString());

      } else if (purchaseDetails.status == PurchaseStatus.purchased ||
          purchaseDetails.status == PurchaseStatus.restored) {
        store.dispatch(UpdateIsPurchasingAction(true));
        bool valid = await verifyPurchase(store, purchaseDetails);

        if (valid) {
          bool _monthlyPurchase = false;
          /* If SKU is lifetime, and purchase is verified
            If monthly subscription was purchased.
            Downgrade monthly subscription
          */
          if (purchaseDetails.productID == SKU_LIFETIME_PURCHASE) {
            ANALYTICS_logEvent(store, "Purchased Lifetime Membership");
            // store.dispatch(DowngradeMonthlySubscriptionAction(true));
            // print("RESTORING PURCHASES!!!");
            // InAppPurchase.instance.restorePurchases();
            PastPurchase monthlyPurchase = store.state.pastPurchases.firstWhere(
                (element) =>
                    element.productId == SKU_MONTHLY_SUBSCRIPTION &&
                    element.status == Status.ACTIVE,
                orElse: () => null);
            print("monthlyPurchase: ${monthlyPurchase.toString()}");
            if (monthlyPurchase != null) {
              // Downgrade
              print("MONTHLY EXISTS, DOWNGRADING PURCHASE!!!");
              downgradePurchase(store, purchaseDetails, monthlyPurchase);
            }
            
            _monthlyPurchase = monthlyPurchase != null;

          } else if (purchaseDetails.productID == SKU_SINGLE_SAVE) {
            ANALYTICS_logEvent(store, "Purchased Single Save");
            // Reload products to have single save available in UI.
            String uid =
                readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.FIREBASE_UID);
            loadPastConsumables(store, uid);
          }
          else if (purchaseDetails.productID == SKU_MONTHLY_SUBSCRIPTION) {
            ANALYTICS_logEvent(store, "Purchased Monthly Membership");
          //   if (store.state.isWaitingForMonthlyDowngrade) {
          //     ProductDetails monthlyProduct =
          //         store.state.iapProducts.singleWhere((f) {
          //       return f.id == SKU_MONTHLY_SUBSCRIPTION;
          //     }, orElse: () {
          //       return null;
          //     });
          //     print("Monthly product: $monthlyProduct");
          //     downgradeSubscription(monthlyProduct, purchaseDetails);
          //   }
          }

          showDialog(
            context: GLOBAL_navigatorKey.currentContext,
            builder: (BuildContext context) {
              return PurchaseCompleteDialog(store, purchaseDetails.productID, _monthlyPurchase);
            }
          );

          // store.dispatch(AddIAPPurchaseAction(purchaseDetails));
          // _deliverProduct(purchaseDetails);
          print("PRODUCT IS VALID!!!: ${purchaseDetails.productID}");
          // if (purchaseDetails.productID == SKU_SINGLE_SAVE) {
          if (store.state.isWaitingForPurchaseToBeValidated) {
            store.dispatch(SavingKeywordsAction(true));
            // notifyListeners(); // Trigger dialog if it is open, that a purchase was made.
            // if (store.state.isSingleSavePaywallLoading) {
            List<ChangeAction> changeActions =
                new List<ChangeAction>.from(store.state.positiveKeywords)
                  ..addAll(store.state.negativeKeywords);
            Navigator.of(store.state.singleSavePaywallBuildContext).pop();
            await saveAll(store.state.changesPageBuildContext, store,
                store.state, changeActions);
            // }
            store
                .dispatch(UpdateIsWaitingForPurchaseToBeValidatedAction(false));
            store.dispatch(SavingKeywordsAction(false));
          }

        } else {
          print("PRODUCT IS INVALID!!!");
          // _handleInvalidPurchase(purchaseDetails);
          ANALYTICS_logEvent(store, "Handling invalid purchase", {
            "productID": purchaseDetails.productID,
            "purchaseStatus": purchaseDetails.status,
          });

          ANALYTICS_logErrorEvent(store, purchaseDetails.error.toString());
        }

        store.dispatch(UpdateIsPurchasingAction(false));
      }
      
      if (purchaseDetails.pendingCompletePurchase) {
        print("PENDING PURCHASE => ${purchaseDetails.productID}");

        await InAppPurchase.instance.completePurchase(purchaseDetails);

        // if (purchaseDetails.productID != SKU_SINGLE_SAVE) {
          // Consume all non-consumable products.
          // print("Consuming: ${purchaseDetails.productID}");
          // await InAppPurchase.instance.completePurchase(purchaseDetails);
        // } else 
        if (purchaseDetails.productID == SKU_SINGLE_SAVE) {
          print("SINGLE SAVE PRODUCT pending purchase");
          print(
              "isWaitingToConsumeSaveConsumable: ${store.state.isWaitingToConsumeSaveConsumable}");

          // await InAppPurchase.instance.completePurchase(purchaseDetails);

          String uid =
              readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.FIREBASE_UID);
          loadPastConsumables(store, uid);

          // Triggered after saveAll() succeeds and calls restorePurchases();
          // if (store.state.isWaitingToConsumeSaveConsumable) {
          //   print("CONSUMING SINGLE SAVE!!!");
          //   // Use has saved keywords successfully, now consume this when it arrives.
          //   // PurchaseDetails purchaseDetails = await getLatestConsumablePurchaseDetails();
          //   await InAppPurchase.instance.completePurchase(purchaseDetails);
          //   store.dispatch(UpdateWaitingToConsumeSaveConsumableAction(false));
          // }
        }
      }
    }
  });
}

// Loads subscriptions, due to ACTIVE statuses.
// https://pub.dev/packages/in_app_purchase/changelog
Future<void> loadPastPurchases(Store<AppState> store, String uid) async {
  print("LOADING PAST PURCHASES!!! $uid");
  var purchaseStream = store.state.firestore
      .collection('purchases')
      .where('userId', isEqualTo: uid)
      .where('status', isEqualTo: 'ACTIVE')
      .snapshots();
  purchaseStream.listen((snapshot) {
    var purchases = snapshot.docs.map((DocumentSnapshot document) {
      var data = document.data();
      return PastPurchase.fromJson(data);
    }).toList();

    // print("PAST PURCHASES UPDATED: ${purchases.length}");

    store.dispatch(UpdatePastPurchasesAction(store, purchases));
  });
}

Future<void> loadPastConsumables(Store<AppState> store, String uid) async {
  // print("LOADING PAST CONSUMABLES");
  var purchaseStream = store.state.firestore
      .collection('purchases')
      .where('userId', isEqualTo: uid)
      .where('status', isEqualTo: 'COMPLETED')
      .snapshots();
  purchaseStream.listen((snapshot) {
    var purchases = snapshot.docs.map((DocumentSnapshot document) {
      var data = document.data();
      // print("CONSUMABLE DATA: $data");
      return PastPurchase.fromJson(data);
    }).toList();

    print("PAST CONSUMABLES UPDATED: ${purchases.length}");
    store.dispatch(UpdatePastConsumablesAction(store, purchases));
  });
}

PastPurchase getLastUnusedConsumable(List<PastPurchase> pastConsumables) {
  PastPurchase unusedConsumable = pastConsumables.firstWhere(
      (element) =>
          element.productId == SKU_SINGLE_SAVE && element.isConsumed == false,
      orElse: () => null);
  return unusedConsumable;
}

Future<bool> consumeSingleSave(
    Store store, String iapSource, String orderId) async {
  var functions = await store.state.functions;
  final callable = functions.httpsCallable('consumeSingleSave');
  try {
    final results = await callable({'source': iapSource, 'orderId': orderId});
    return results.data as bool;
  } catch (err) {
    print("ERROR running consumeSingleSave function: $err");
    return false;
  }
}

// Checks that the product exists in Play store by making serverside API calls.
Future<bool> verifyPurchase(
    Store store, PurchaseDetails purchaseDetails) async {
  // TODO while the server is waiting for payment.
  // await Future.delayed(const Duration(seconds: 3));
  // print("VERIFIED PURCHASE: ");
  // return true;

  var functions = await store.state.functions;
  final callable = functions.httpsCallable('verifyPurchase');
  // print("purchaseDetails.verificationData.source: ${purchaseDetails.verificationData.source}");
  // print("purchaseDetails.verificationData.serverVerificationData: ${purchaseDetails.verificationData.serverVerificationData}");
  // print("purchaseDetails.productID: ${purchaseDetails.productID}");
  try {
    final results = await callable({
      'source': purchaseDetails.verificationData.source,
      'verificationData':
          purchaseDetails.verificationData.serverVerificationData,
      'productId': purchaseDetails.productID,
    });
    // print("results.data: ${results}");
    return results.data as bool;
  } catch (err) {
    print("ERROR running verifyPurchase function: $err");
    return false;
  }
}

/*
  Downgrade purchase by contacting serverside using the previous purchase token to cancel the subscription.
*/
Future<void> downgradePurchase(Store store, PurchaseDetails purchaseDetails,
    PastPurchase monthlyPurchase) async {
  var functions = await store.state.functions;
  final callable = functions.httpsCallable('downgradeMonthly');
  try {
    final results = await callable({
      'source': purchaseDetails.verificationData.source,
      'verificationData': monthlyPurchase.token,
      'productId': SKU_MONTHLY_SUBSCRIPTION,
    });
    print("downgrade results: ${results.data}");
    return true;
  } catch (err) {
    return false;
  }
}

Future<void> purchaseProduct(ProductDetails productDetails) async {
  final PurchaseParam purchaseParam =
      PurchaseParam(productDetails: productDetails);

  /*
    Consumable: Can be bought multiple times.
    Non-consumable: Can only be bought once
    Subscription: Is a separate category with time-fixed frequency of renewals.
  */
  // print("purchasing productDetails.id: ${productDetails.id}");
  switch (productDetails.id) {
    case SKU_SINGLE_SAVE:
      InAppPurchase.instance
          .buyConsumable(purchaseParam: purchaseParam /*, autoConsume: false*/);
      break;
    case SKU_LIFETIME_PURCHASE:
      InAppPurchase.instance.buyConsumable(purchaseParam: purchaseParam);
      break;
    case SKU_MONTHLY_SUBSCRIPTION:
      InAppPurchase.instance.buyNonConsumable(purchaseParam: purchaseParam);
      break;
    default:
      print("PRODUCT NOT HANDLED: ${productDetails.id}");
      break;
  }
}

// User downgrades through their phone, no need ot handle this.
// This is for when the LIFETIME MEMBERSHIP is purchased.
/*
  1. Check if there is a monthly subscription
  2. If it exists, downgrade it.
  3. Purchase lifetime_subscription.
*/
// https://github.com/flutter/plugins/tree/master/packages/in_app_purchase/in_app_purchase
// Future<void> downgradeSubscription(
//     ProductDetails productDetails, PurchaseDetails oldPurchaseDetails) async {
//   print("RESTORING PURCHASES!!!");
//   // InAppPurchase.instance.restorePurchases();
//   // TODO try and get old purchase parameters from this.

//   // final PurchaseDetails oldPurchaseDetails =
//   PurchaseParam purchaseParam = GooglePlayPurchaseParam(
//     productDetails: productDetails,
//     changeSubscriptionParam: ChangeSubscriptionParam(
//       oldPurchaseDetails: oldPurchaseDetails,
//       prorationMode: ProrationMode.immediateWithTimeProration,
//     ),
//   );
//   InAppPurchase.instance.buyNonConsumable(purchaseParam: purchaseParam);
// }

Future<bool> isInAppPurchaseAvailable(Store<AppState> store) async {
  final bool available = await InAppPurchase.instance.isAvailable();
  if (!available) {
    // The store cannot be reached or accessed.
    // print("STORE CANNOT BE REACHED OR ACCESSED");
    showQuickDialog("In-App Purchases cannot be reached or accessed");
    ANALYTICS_logEvent(store, "In-app purchases cannot load");
  } else {
    store.dispatch((x) => loadIapProductsAction(store));
  }
  // print("STORE IS AVAILABLE: $available");
  return available;
}

Future<List<ProductDetails>> loadProducts(Store<AppState> store) async {
  const Set<String> _kIds = <String>{
    SKU_SINGLE_SAVE,
    SKU_MONTHLY_SUBSCRIPTION,
    SKU_LIFETIME_PURCHASE
  };
  final ProductDetailsResponse response =
      await InAppPurchase.instance.queryProductDetails(_kIds);
  if (response.notFoundIDs.isNotEmpty) {
    // Handle the error.
    // print("PRODUCTS NOT FOUND: ${response.notFoundIDs}");

    // If empty, repeat until not empty.
    Future.delayed(const Duration(seconds: 1), () {
      print("REPEAT LOADING PRODUCTS");
      store.dispatch((x) => loadIapProductsAction(store));
    });
  } else {
    // print("PRODUCTS LOAD SUCCESS!!!");
  }
  // print("Products response: $response");
  List<ProductDetails> products = response.productDetails;
  // print("Products: ${products.toString()}");

  // for (ProductDetails productDetails in products) {

  // }

  // Sort products by incrementing rawPrice
  products.sort((a, b) => a.rawPrice.compareTo(b.rawPrice));
  return products;
}

ProductIntroductoryDetails getIntroductoryDetails(
    ProductDetails productDetails) {
  if (productDetails is GooglePlayProductDetails) {
    SkuDetailsWrapper skuDetails =
        (productDetails as GooglePlayProductDetails).skuDetails;
    // SkuDetailsWrapper skuDetails = productDetails.skuDetails;
    // print("productDetails.id: ${productDetails.id}");
    // print("skuDetails.introductoryPrice: ${skuDetails.introductoryPrice.toString()}");
    // print("skuDetails.introductoryPricePeriod: ${skuDetails.introductoryPricePeriod.toString()}");
    // print("skuDetails.introductoryPriceCycles: ${skuDetails.introductoryPriceCycles.toString()}");
    return ProductIntroductoryDetails(
        skuDetails.introductoryPrice, skuDetails.introductoryPriceCycles);
  }
}
