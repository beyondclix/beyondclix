import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_notification_channel/flutter_notification_channel.dart';
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

Future<void> firebaseMessagingBackgroundHandler(
    RemoteMessage remoteMessage) async {
  await Firebase.initializeApp();
}

String constructFCMPayload(String token) {
  return jsonEncode({
    'token': token,
    'data': {
      'via': 'Flutterfire cloud messaging',
    },
    'notification': {
      'title': 'Hello flutterfire',
      'body': 'This notification was created via FCM'
    },
  });
}