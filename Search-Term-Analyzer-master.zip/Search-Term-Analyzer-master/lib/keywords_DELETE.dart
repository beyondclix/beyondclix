// // Get keywords via API
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'dart:io';
// import 'constants.dart';
// import 'main.dart';
// import 'package:http/http.dart' as http;

// // class Keyword extends StatelessWidget {
// //   Keyword(this.text);
// //   final String text;

// //   @override
// //   Widget build(BuildContext context) {
// //     return Text(this.text);
// //   }
// // }

// // class Keywords extends StatelessWidget {
// //   Keywords(this.customerId, BuildContext context){
// //     // _loadJson(context);
// //   }
// //   final int customerId;
// //   Map<String, dynamic> getKeywordsJson;
// //   List<Keyword> _keywords;
  
//   // int getCount() {
//   //   return 0;//_keywords.length;
//   // }

//   // void _loadJson(BuildContext context) async {
//   //   String data = await DefaultAssetBundle.of(context).loadString("./assets/getKeywords.json");
//   //   this.getKeywordsJson = jsonDecode(data);
//   // }

//   Future<List<String>> getKeywords(String customerId) async {
//     final response = await http.post(
//       "https://googleads.googleapis.com/v6/customers/" + customerId + "/googleAds:search",
//       body: json.encode({
//         "pageSize": 10000,
//         "query": "SELECT ad_group_criterion.keyword.text, ad_group_criterion.status FROM ad_group_criterion WHERE ad_group_criterion.type = 'KEYWORD' AND ad_group_criterion.status = 'ENABLED'"
//       }),
//       headers: {
//         "Authorization": "Bearer " + accessToken,
//         "developer-token": DEVELOPER_TOKEN,
//         "Content-Type": "application/json",
//       }
//     );
//     final responseJson = jsonDecode(response.body);
//     print(responseJson.toString());
//     return responseJson["results"];
//   }

//   void updateKeywords(String newText, String resourceName) async {
//     final response = await http.post(
//       "https://googleads.googleapis.com/v6/customers/" + this.customerId.toString() + "/adGroupCriteria:mutate",
//       headers: {
//         "Authorization": "Bearer " + accessToken,
//         "developer-token": DEVELOPER_TOKEN,
//         "Content-Type": "application/json",
//       },
//       body: {
//         "operations": [{
//           "updateMask": "keyword,match_type,text",
//           "update": {
//               "resourceName": resourceName,//"customers/" + this.customerId.toString() + "/adGroupCriteria/" + adGroupId + "~" + adGroupCriteriaId,
//               "keyword": {
//                   "match_type": "EXACT",
//                   "text": newText
//               }
//           }
//         }]
//       }
//     );
//     final responseJson = jsonDecode(response.body);
//     print("Updated: " + responseJson["resourceNames"].toString());
//     // return responseJson["resourceNames"];
//   }

//   void deleteKeywords(String adGroupId, String adGroupCriteriaId) async {
//     final response = await http.post(
//       "https://googleads.googleapis.com/v6/customers/" + this.customerId.toString() + "/adGroupCriteria:mutate",
//       headers: {
//         "Authorization": "Bearer " + accessToken,
//         "developer-token": DEVELOPER_TOKEN,
//         "Content-Type": "application/json",
//       },
//       body: {
//         "operations": [
//             {
//               "remove": "customers/" + this.customerId.toString() + "/adGroupCriteria/" + adGroupId + "~" + adGroupCriteriaId,
//             }
//         ]
//       }
//     );
//     final responseJson = jsonDecode(response.body);
//     print("Deleted: " + responseJson["resourceNames"].toString());
//     // return responseJson["resourceNames"];
//   }

//   // @override
//   // Widget build(BuildContext context) {
//   //   return Scaffold(
//   //     appBar: AppBar(
//   //       title: Text("Keywords"),
//   //     ),
//   //     body: Center(
//   //       child: FutureBuilder(
//   //         future: getKeywords(),
//   //         builder: (context, snapshot) {
//   //           if(snapshot.hasData || snapshot.data != null){
//   //             this._keywords = snapshot.data;
//   //             return Column(
//   //               mainAxisAlignment: MainAxisAlignment.center,
//   //               mainAxisSize: MainAxisSize.min,
//   //               crossAxisAlignment: CrossAxisAlignment.center,
//   //               children: this._keywords,
//   //             );
//   //           }
//   //           return CircularProgressIndicator();
//   //         }
//   //       )
//   //     )
//   //   );
//   // }
// // }

// // for(var i=0;i<responseJson["resourceNames"].length;i++){
// //   try {
// //     final response = 
// //   }
// // }