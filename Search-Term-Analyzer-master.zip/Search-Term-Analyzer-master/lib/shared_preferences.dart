import 'package:shared_preferences/shared_preferences.dart';
import 'package:enum_to_string/enum_to_string.dart';

enum SHARED_PREFERENCE_KEYS {
  FIREBASE_UID,
  CURRENT_USER,
  CURRENT_USER_NAME,
  CURRENT_USER_PHOTO_URL,
  CURRENT_USER_EMAIL,
  CURRENT_DATE_RANGE,
  CURRENT_CUSTOMER_ID,
  CURRENT_CUSTOMER_CLIENT_ID, // Manager Id
  CURRENT_CAMPAIGN_ID,
  CURRENT_AD_GROUP_ID,
  MOST_RECENT_DATA_DATETIME,
  OLDEST_DATA_DATETIME,
  CURRENT_BOTTOM_NAVIGATION_TAB,
  CUSTOM_DATERANGE_START,
  CUSTOM_DATERANGE_END,
  NEXT_PAGE_TOKEN, // There is more data to be loaded.
  LAST_SEARCH_TERM, // If next_page_token expires, query based on the last search term.
  CURRENT_TIMEZONE,
  LOAD_COUNT,
}

SharedPreferences prefs;

Future<void> initializeSharedPreferences() async {
  prefs = await SharedPreferences.getInstance();
}

void setSharedPreferenceValue<T>(SHARED_PREFERENCE_KEYS key, T value) {
  String convertedKey = EnumToString.convertToString(key);
  if (T == int) {
    prefs.setInt(convertedKey, value as int);
  } else {
    prefs.setString(convertedKey, value as String);
  }
}

T readSharedPreferenceValue<T>(SHARED_PREFERENCE_KEYS key) {
  String convertedKey = EnumToString.convertToString(key);
  if (T == int) {
    return (prefs.getInt(convertedKey) ?? 0) as T;
  }
  return (prefs.getString(convertedKey) ?? "") as T;
}

void removeValue(SHARED_PREFERENCE_KEYS key) {
  String convertedKey = EnumToString.convertToString(key);
  prefs.remove(convertedKey);
}

void removeAllSharedPreferences() {
  removeValue(SHARED_PREFERENCE_KEYS.FIREBASE_UID);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_USER);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_NAME);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_PHOTO_URL);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_USER_EMAIL);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_DATE_RANGE);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_ID);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_CLIENT_ID);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_CAMPAIGN_ID);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_AD_GROUP_ID);
  removeValue(SHARED_PREFERENCE_KEYS.MOST_RECENT_DATA_DATETIME);
  removeValue(SHARED_PREFERENCE_KEYS.OLDEST_DATA_DATETIME);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_BOTTOM_NAVIGATION_TAB);
  removeValue(SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_START);
  removeValue(SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_END);
  removeValue(SHARED_PREFERENCE_KEYS.CURRENT_TIMEZONE);
}
