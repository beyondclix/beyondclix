// // Load all campaigns for this account

// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'api.dart';
// import 'constants.dart';
// import 'main.dart'; // For accessToken
// import 'dart:convert';
// import 'dart:io';
// import 'constants.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'models/campaign.dart';

// class Campaigns extends StatelessWidget {
//   Campaigns(this.customerId){
//     print('Initializing Campaigns constructor');
//   }
//   final int customerId;
//   // List<Campaign> campaigns;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Campaigns"),
//       ),
//       body: Center(
//         child: FutureBuilder(
//           future: getCampaigns(this.customerId.toString(), this.customerId.toString()),
//           builder: (context, snapshot) {
//             if(snapshot.hasData || snapshot.data != null){
//               List<Campaign> campaigns = snapshot.data;
//               return Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: campaigns,
//               );
//             }
//             return CircularProgressIndicator();
//           }
//         )
//       )
//     );
//   }
// }
