import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:searchTermAnalyzerFlutter/api.dart';
import 'package:searchTermAnalyzerFlutter/main.dart';
import 'package:searchTermAnalyzerFlutter/constants.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/single_save_paywall_dialog.dart';
import 'package:searchTermAnalyzerFlutter/local_data.dart';
import 'package:searchTermAnalyzerFlutter/models/change_action.dart';
import 'package:searchTermAnalyzerFlutter/models/date_range.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_group.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/column_group.dart';
import 'package:searchTermAnalyzerFlutter/models/keyword_response.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:searchTermAnalyzerFlutter/models/metric_value.dart';
import 'package:searchTermAnalyzerFlutter/models/campaign.dart';
import 'package:searchTermAnalyzerFlutter/models/db_object.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list.dart';
import 'package:searchTermAnalyzerFlutter/models/negative_keyword_list_to_save.dart';
import 'package:searchTermAnalyzerFlutter/models/payments_states.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/models.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:redux/redux.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:uuid/uuid.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

Color getColorFromIndex(int index) {
  int i = index % 4;
  if (i == 0) {
    return Colors.green;
  } else if (i == 1) {
    return Colors.blue;
  } else if (i == 2) {
    return Colors.yellow;
  } else if (i == 3) {
    return Colors.red;
  }
  return Colors.white;
}

// getDateKeyNameFromName(String name) {
//   for (var i = 0; i < DateRange.dateOptions.length; i++) {
//     if (DateRange.dateOptions[i].getName() == name) {
//       return DateRange.dateOptions[i].getKeyName();
//     }
//   }
//   print('!!!Date not found: ' + name);
// }

// Compares current toSaveData in state to savedData to see if discrepancies exist that need to be saved.
bool areTheseMapsTheSame(Map toSave, Map saved) {
  if (mapEquals(toSave, saved)) {
    return true;
  }
  return false;
}

int boolToInt(bool b) {
  return b ? 1 : 0;
}

bool intToBool(int n) {
  return n == 1;
}

// T checkIfInArrayAndGet<T>(List<DBObject> list, String item) {
//   list.where((c) => c.id == item).first;
// }

// This is wrong.
// DateTime convertToLocalDateTime(DateTime dateTime, String timeZone) {
//   if (timeZone != "") {
//     final location = tz.getLocation(timeZone);
//     // print("timeZone: $timeZone");
//     DateTime adjustedDate = tz.TZDateTime.from(dateTime, location);
//     // print("converting dateTime ${dateTime.toString()} by timezone: ${timeZone}, result is: $adjustedDate");
//     return adjustedDate;
//   } else {
//     return dateTime;
//   }
// }

// Gets the local dateTime, then strips the hour and minute and only compares by day.
int epochToLocalEpoch(int epochTime, String timeZone) {
  if (timeZone != "" && epochTime != null) {
    DateTime dateTime = epochTime2Date(epochTime);
    // print('epochTime: $epochTime');
    // print('timeZone: $timeZone');
    final location = tz.getLocation(timeZone);
    // var timeInUtc = DateTime.utc(dateTime.year, dateTime.month, dateTime.day);
    // print("dateTime: $dateTime, epochTime: $epochTime");

    // Pass in minute to be accurate up to minutes to get the latest account local time.
    var localTime = DateTime(dateTime.year, dateTime.month, dateTime.day,
        dateTime.hour, dateTime.minute);

    // var timeZone2 = location.timeZone(timeInUtc.millisecondsSinceEpoch);
    // print('timeZone2: $timeZone2');
    var accountTime = tz.TZDateTime.from(localTime, location);
    var strippedTime =
        DateTime(accountTime.year, accountTime.month, accountTime.day);
    // print("timeInUtc: $timeInUtc");
    // DateTime localDate = tz.TZDateTime(location, dateTime.year, dateTime.month, dateTime.day);
    // print("localTime: $localTime");
    // print("accountTime: $accountTime");
    // print("stripepdTime: $strippedTime");
    // print("localDate: $localDate");
    // print("date2EpochTime(accountTime): ${date2EpochTime(strippedTime)}");
    // print("original epoch: ${epochTime2Date(epochTime)} local epoch: ${epochTime2Date(localEpoch)}");
    // return localEpoch;

    // Add 10 to push it forward.
    // If this date is used in API queries, the time will be stripepd anyway.
    // But, if it is used in local queries, it will ignore the current day or previous day.
    return date2EpochTime(strippedTime); //localTime;
  }
  return epochTime;
}

String date2String(DateTime date) {
  DateFormat formatter = DateFormat('yyyy-MM-dd');
  return formatter.format(date);
}

DateTime string2DateTime(String s) {
  DateFormat formatter = DateFormat('yyyy-MM-dd');
  return formatter.parse(s);
}

// This value is independent of timezone.
int date2EpochTime(DateTime date) {
  if (date == null) {
    return null;
  }
  return date.millisecondsSinceEpoch;
}

DateTime epochTime2Date(int millisecondsSinceEpoch) {
  if (millisecondsSinceEpoch == null) {
    return null;
  }
  return DateTime.fromMillisecondsSinceEpoch(millisecondsSinceEpoch);
}

String epochTime2DateString(int millisecondsSinceEpoch) {
  if (millisecondsSinceEpoch == null) {
    return null;
  }
  return date2String(
      DateTime.fromMillisecondsSinceEpoch(millisecondsSinceEpoch));
}

// Check if a more recent date has been requested, if so, then load data for those days by itself and save to local database.
bool isMoreRecentDataRequired(
    DateRange, currentDateRange, DateRange dateRange) {
  // Convert dateRange query into after and until dates.
  // Compare those dates with the current localData after and until dates.
  // Locate the discrepancies.
  return true;
}

bool checkShowingInitialSequence(String initialCustomerId,
    String initialManagerId, DateRange initialDateRange) {
  // print("checkShowingInitialSequence: " + initialCustomerId.toString() + initialManagerId.toString() + initialDateRange.toString());
  // print("getKeyName(): " + initialDateRange.getKeyName());
  // print("getName(): " + initialDateRange.getName());
  return (initialCustomerId == null ||
      initialCustomerId == "" ||
      initialManagerId == null ||
      initialManagerId == "" ||
      initialDateRange.getName() == "");
}

// Constructs a metrics query from the array of metrics
String getMetricsQuery(String category) {
  var metrics = METRIC_TYPES[category].map((m) => m['name']);

  String out = "";
  for (String metric in metrics) {
    out += "metrics." + metric + ", ";
  }
  // print("metrics query: " + out.toString());
  return out;
}

List<List<Metric>> splitArray(List<Metric> metrics, [int groupSize = 3]) {
  List<List<Metric>> chunks = [];
  for (var i = 0; i < metrics.length; i += groupSize) {
    chunks.add(metrics.sublist(
        i, i + groupSize > metrics.length ? metrics.length : i + groupSize));
  }
  return chunks;
}

// TODO dart is rounding 5 down, and 6 up.
// https://groups.google.com/a/dartlang.org/g/misc/c/PKL-a0n040Y
String convertMetric(double value, String type, String currencyCode) {
// print('value: $value, $type');
  switch (type) {
    case "percentage":
      return (value * 100).toStringAsFixed(2) + '%';
    case "double":
      return value.toStringAsFixed(3);
    case "int":
      return value.round().toString();
    case "micros":
      return (value / 1000000).toStringAsFixed(3);
    case "currency":
    // return handleCurrency(value.toStringAsFixed(2), currencyCode);
    case "micros_currency":
      // return (value / 1000000).toStringAsFixed(3)
      return handleCurrency((value / 1000000).toStringAsFixed(3), currencyCode);
    default:
      return value.toStringAsFixed(3);
  }
}

// https://www.newbridgefx.com/currency-codes-symbols/
String handleCurrency(String value, currencyCode) {
  switch (currencyCode) {
    case "NZD":
    case "AUD":
    case "CAD":
    case "USD":
      return "\$" + value + " $currencyCode";
    case "CNY":
      return "¥" + value + " $currencyCode";
    case "INR":
      return "₹" + "$value $currencyCode"; //"₨." + value " $currencyCode";
    case "EUR":
      return "€" + value + " $currencyCode";
    default:
      return "$value $currencyCode";
  }
}

double revertMetric(double value, String metricType) {
  print("metricType: $metricType, $value, ${value / 100}");
  switch (metricType) {
    case 'percentage':
      return value / 100;
    case 'micros':
      return value * 1000000;
    case 'micros_currency':
    case 'currency':
      return value * 1000000;
    default:
      return value;
  }
}

String getMetricDisplayValue(Map<String, MetricValue> metricValues, String name,
    String valueType, String currencyCode) {
  // print("metricValues: $metricValues");
  if (metricValues == null) {
    return "NONE"; //"0";
  }
  if (metricValues.containsKey(snake2Camel(name))) {
    MetricValue mv = metricValues[snake2Camel(name)];
    // if (mv != null) {
    // print("mv.name: ${mv.name}, mv.value: ${mv.value}, valueType: $valueType, camelCase: ${snake2Camel(name)}, name: $name");
    return convertMetric(mv.value, valueType, currencyCode);
    // }
  } else {
    return "0";
  }
}

String convertToDisplayName(String name) {
  return capitalize(name.replaceAll('_', ' '));
}

String capitalize(String name) {
  return "${name[0].toUpperCase()}${name.substring(1)}";
}

String camel2Snake(String text) {
  RegExp exp = RegExp(r'(?<=[a-z])[A-Z]');
  String result =
      text.replaceAllMapped(exp, (Match m) => ('_' + m.group(0))).toLowerCase();
  return result;
}

String snake2Camel(String text) {
  // print('snake2camel: $text');
  List<String> texts = text.split('_');
  for (int i = 1; i < texts.length; i++) {
    texts[i] = capitalize(texts[i]);
  }
  // print("texts.join();: ${texts.join()}");
  return texts.join();
}

// Convert query into custom date range.
// e.g. 'Last 7 days' => '1 - 7 December 2020'.
// https://developers.google.com/google-ads/api/docs/query/date-ranges
DateRangeLocal getUpperLowerDates(DateRange dateRange, String timeZone) {
  String keyName = dateRange.getKeyName();
  String name = dateRange.getName();
  int lowerDateEpoch;
  int upperDateEpoch;

  // print("dateRange.getName(): ${dateRange.getName()}");
  // print("dateRange.getKeyName(): ${dateRange.getKeyName()}");
  if (dateRange.getName() == 'Custom') {
    lowerDateEpoch = dateRange.lowerEpochDate;
    upperDateEpoch = dateRange.upperEpochDate;

    // Return without converting custom date to local epoch.
    return DateRangeLocal(lowerDateEpoch, upperDateEpoch);

  } else if (dateRange.getName() == 'All Time') {
    lowerDateEpoch = date2EpochTime(DateTime.utc(2000, 01, 01));
    upperDateEpoch = date2EpochTime(DateTime.now());
  } else {
    switch (keyName) {
      case "DURING TODAY":
        {
          lowerDateEpoch = getPastDateHours(DateTime.now(), 24) +
              10; // Add 10 to be slightly larger and exclude this day exactly.
          upperDateEpoch = date2EpochTime(DateTime.now());
          break;
        }
      case "DURING YESTERDAY":
        {
          lowerDateEpoch = getPastDateHours(DateTime.now(), 48) +
              10; // Add 10 to be slightly larger to exclude this day exactly.
          upperDateEpoch = getPastDateDays(DateTime.now(), 1);
          break;
        }
      case "DURING LAST_7_DAYS":
        {
          lowerDateEpoch = getPastDateDays(DateTime.now(), 8); // 7
          upperDateEpoch = getPastDateDays(
              DateTime.now(), 1); //date2EpochTime(DateTime.now());
          break;
        }
      case "DURING LAST_BUSINESS_WEEK":
        {
          lowerDateEpoch = getLastLastMonday(DateTime.now());
          upperDateEpoch = getLastFriday(DateTime.now());
          break;
        }
      case "DURING THIS_MONTH":
        {
          lowerDateEpoch = getFirstDayOfMonth(DateTime.now());
          upperDateEpoch = date2EpochTime(DateTime.now());
          break;
        }
      case "DURING LAST_MONTH":
        {
          lowerDateEpoch = getFirstDayOfLastMonth(DateTime.now());
          upperDateEpoch = getLastDayOfLastMonth(DateTime.now());
          break;
        }
      case "DURING LAST_14_DAYS":
        {
          lowerDateEpoch = getPastDateDays(DateTime.now(), 15); // 14
          upperDateEpoch = getPastDateDays(
              DateTime.now(), 1); //date2EpochTime(DateTime.now());
          break;
        }
      case "DURING LAST_30_DAYS":
        {
          lowerDateEpoch = getPastDateDays(DateTime.now(), 31); // 30
          upperDateEpoch = getPastDateDays(
              DateTime.now(), 1); //date2EpochTime(DateTime.now());
          break;
        }
      case "DURING THIS_WEEK_SUN_TODAY":
        {
          lowerDateEpoch = getLastSunday(DateTime.now());
          upperDateEpoch = date2EpochTime(DateTime.now());
          break;
        }
      case "DURING THIS_WEEK_MON_TODAY":
        {
          lowerDateEpoch = getLastMonday(DateTime.now());
          upperDateEpoch = date2EpochTime(DateTime.now());
          break;
        }
      case "DURING LAST_WEEK_SUN_SAT":
        {
          lowerDateEpoch = getLastLastSunday(DateTime.now());
          upperDateEpoch = getLastSaturday(DateTime.now());
          break;
        }
      case "DURING LAST_WEEK_MON_SUN":
        {
          lowerDateEpoch = getLastLastMonday(DateTime.now());
          upperDateEpoch = getLastSunday(DateTime.now());
          break;
        }
    }
  }
  // print("lowerDateEpoch: ${epochTime2Date(lowerDateEpoch)}");
  // print("upperDateEpoch: ${epochTime2Date(upperDateEpoch)}");
  return DateRangeLocal(epochToLocalEpoch(lowerDateEpoch, timeZone),
      epochToLocalEpoch(upperDateEpoch, timeZone));

  // Query database for data from this date.
}

int getPastDateDays(DateTime dateTime, int numberOfDaysAgo) {
  return date2EpochTime(dateTime.subtract(new Duration(days: numberOfDaysAgo)));
}

int getPastDateHours(DateTime dateTime, int numberOfHoursAgo) {
  return date2EpochTime(
      dateTime.subtract(new Duration(hours: numberOfHoursAgo)));
}

int getLastMonday(DateTime dateTime) {
  int monday = 1;
  while (dateTime.weekday != monday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  return date2EpochTime(dateTime);
}

int getLastFriday(DateTime dateTime) {
  int friday = 5;
  while (dateTime.weekday != friday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  return date2EpochTime(dateTime);
}

int getLastSaturday(DateTime dateTime) {
  int saturday = 6;
  while (dateTime.weekday != saturday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  return date2EpochTime(dateTime);
}

int getLastSunday(DateTime dateTime) {
  int sunday = 7;
  while (dateTime.weekday != sunday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  return date2EpochTime(dateTime);
}

int getLastLastSunday(DateTime dateTime) {
  // Get last Saturday
  int saturday = 6;
  while (dateTime.weekday != saturday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  // Get last sunday from alst saturday
  int sunday = 7;
  while (dateTime.weekday != sunday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  return date2EpochTime(dateTime);
}

int getLastLastMonday(DateTime dateTime) {
  // Get last Sunday
  int sunday = 7;
  while (dateTime.weekday != sunday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  // print("last sunday: $dateTime");
  // Get last monday from last sunday
  int monday = 1;
  while (dateTime.weekday != monday) {
    dateTime = dateTime.subtract(new Duration(days: 1));
  }
  // print("last monday: $dateTime");
  return date2EpochTime(dateTime);
}

int getFirstDayOfMonth(DateTime dateTime) {
  return date2EpochTime(new DateTime(dateTime.year, dateTime.month, 1));
}

int getFirstDayOfLastMonth(DateTime dateTime) {
  int month = dateTime.month;
  int year = dateTime.year;
  if (month == 1) {
    month = 12;
    year -= 1;
  } else {
    month -= 1;
  }
  return date2EpochTime(new DateTime(year, month, 1));
}

int getLastDayOfLastMonth(DateTime dateTime) {
  // equivalent to day 0 of this month
  return date2EpochTime(new DateTime(dateTime.year, dateTime.month, 0));
}

// Filter local data in DB
// Future<List<SearchTerm>> filterSearchTermsDB<T>(
//     List<FilterValue> filterValues, List<SearchTerm> searchTerms,
//     {stringFilterType = "text"}) async {
//   String query = "";
//   for (FilterValue fv in filterValues) {
//     switch () {

//     }
//   }
// }

String addSearchTermFilters(String query, List<FilterValue> filterValues) {
  for (FilterValue fv in filterValues) {
    if (fv.name == "Campaign" || fv.name == "AdGroup") {
      continue;
    }
    if (fv.valueType == 'added_excluded' /* Added/excluded */) {
      if (!query.contains("WHERE")) {
        query += " WHERE ";
      } else {
        query += " AND ";
      }
      query += "SEARCHTERMS.${fv.stringFilterType} = '${fv.value}'";
      continue;
    }
    fv.name = snake2Camel(fv.name);
    // print("fv.name: ${fv.name}, f.value: ${fv.value}, fv.type: ${fv.type}, fv.valueType: ${fv.valueType}, fv.metricType: ${fv.metricType}, fv.stringFilterType: ${fv.stringFilterType}");

    // Modify filter values to query.
    // e.g. Percentage needs to be divided by 100 (reverted)
    double newValue;
    if (fv.valueType == 'num') {
      newValue = revertMetric(double.parse(fv.value), fv.metricType);
    }

    if (!query.contains("WHERE")) {
      query += " WHERE ";
    } else {
      query += " AND ";
    }
    switch (fv.type) {
      case ">":
        query += "SEARCHTERMS_METRICS.${fv.name} > ${newValue}";
        break;
      case ">=":
        query += "SEARCHTERMS_METRICS.${fv.name} >= ${newValue}";
        break;
      case "=":
        query += "SEARCHTERMS_METRICS.${fv.name} = ${newValue}";
        break;
      case "not equals":
        query += "SEARCHTERMS_METRICS.${fv.name} != ${newValue}";
        break;
      case "<":
        query += "SEARCHTERMS_METRICS.${fv.name} < ${newValue}";
        break;
      case "<=":
        query += "SEARCHTERMS_METRICS.${fv.name} <= ${newValue}";
        break;
      case "contains":
        query +=
            "LOWER(SEARCHTERMS.${fv.stringFilterType}) LIKE '%${fv.value.toLowerCase()}%'";
        break;
      case "does not contain":
        query +=
            "LOWER(SEARCHTERMS.${fv.stringFilterType}) NOT LIKE '%${fv.value.toLowerCase()}%'";
        break;
      case "contains (case sensitive)":
        query += "SEARCHTERMS.${fv.stringFilterType} LIKE '%${fv.value}%'";
        break;
      case "does not contain (case sensitive)":
        query += "SEARCHTERMS.${fv.stringFilterType} LIKE '%${fv.value}%'";
        break;
      case "equals":
        query += "SEARCHTERMS.${fv.stringFilterType} = '${fv.value}'";
        break;
      case "starts with":
        query += "SEARCHTERMS.${fv.stringFilterType} LIKE '${fv.value}%'";
        break;
      case "ends with":
        query += "SEARCHTERMS.${fv.stringFilterType} LIKE '%${fv.value}'";
        break;
    }
  }
  return query;
}

// Filter local data in memory.
List<SearchTerm> filterSearchTerms<T>(
    FilterValue filterValue, List<SearchTerm> searchTerms,
    {stringFilterType = "text"}) {
  switch (filterValue.type) {
    // Metric/numerical comparisons
    case ">":
      // print(filterValue.value);
      // print(double.parse(filterValue.value));
      // for(SearchTerm s in searchTerms) {
      //   print(s.metrics['clicks']);
      //   print(s.metrics[camel2Snake(filterValue.name)].value);
      // }
      return searchTerms
          .where((element) =>
              element.metrics[camel2Snake(filterValue.name)].value >
              double.parse(filterValue.value))
          .toList();

    case ">=":
      return searchTerms
          .where((element) =>
              element.metrics[camel2Snake(filterValue.name)].value >=
              double.parse(filterValue.value))
          .toList();
    case "=":
      // print(filterValue.value);
      // for(SearchTerm s in searchTerms) {
      //   // print(s.metrics['clicks'].value);
      //   print(s.metrics[camel2Snake(filterValue.name)].value);
      //   print(s.metrics[camel2Snake(filterValue.name)].value == double.parse(filterValue.value));
      // }
      return searchTerms
          .where((element) =>
              element.metrics[camel2Snake(filterValue.name)].value ==
              double.parse(filterValue.value))
          .toList();
    case "not equals":
      return searchTerms
          .where((element) =>
              element.metrics[camel2Snake(filterValue.name)].value !=
              double.parse(filterValue.value))
          .toList();
    case "<":
      return searchTerms
          .where((element) =>
              element.metrics[camel2Snake(filterValue.name)].value <
              double.parse(filterValue.value))
          .toList();
    case "<=":
      return searchTerms
          .where((element) =>
              element.metrics[camel2Snake(filterValue.name)].value <=
              double.parse(filterValue.value))
          .toList();
    // String comparisons
    case "contains":
      return searchTerms
          .where((s) => s
              .toMap()[stringFilterType]
              .toLowerCase()
              .contains(filterValue.value.toLowerCase()))
          .toList();
    case "does not contain":
      return searchTerms
          .where((s) => !s
              .toMap()[stringFilterType]
              .toLowerCase()
              .contains(filterValue.value.toLowerCase()))
          .toList();
    case "contains (case sensitive)":
      return searchTerms
          .where((s) => s.toMap()[stringFilterType].contains(filterValue.value))
          .toList();
    case "does not contain (case sensitive)":
      return searchTerms
          .where((s) => s.toMap()[stringFilterType].contains(filterValue.value))
          .toList();
    case "equals":
      return searchTerms
          .where((s) => s.toMap()[stringFilterType] == filterValue.value)
          .toList();
    case "starts with":
      return searchTerms
          .where((s) =>
              s.toMap()[stringFilterType].startsWith(filterValue.value, 0))
          .toList();
  }
  return null;
}

FilterValue _getMetric(List<Metric> metrics, String metricName) {
  Metric m =
      metrics.firstWhere((m) => m.name == metricName, orElse: () => null);

  return FilterValue(
    metricName,
    "",
    "",
    displayName: m.displayName,
    metricType: m.valueType,
  );
}

Metric _getMetricByName(List<Metric> metrics, String metricName) {
  // print("MetricName: metrics: ${metrics[0].toMap()}, $metricName");
  Metric m =
      metrics.firstWhere((m) => m.name == metricName, orElse: () => null);
  // print("Found metric: ${m.name}");
  return m;
}

List<ColumnGroup> createColumnGroups(Store<AppState> store) {
  List<ColumnGroup> columnGroups = [];
  List<Metric> metrics = List.from(store.state.searchTermMetrics);

  columnGroups.add(ColumnGroup("Performance", [
    _getMetricByName(metrics, "average_cost"),
    _getMetricByName(metrics, "average_cpc"),
    _getMetricByName(metrics, "average_cpe"),
    _getMetricByName(metrics, "average_cpm"),
    // _getMetricByName(metrics, "average_cpv"),
    _getMetricByName(metrics, "clicks"),
    _getMetricByName(metrics, "cost_micros"),
    _getMetricByName(metrics, "ctr"),
    _getMetricByName(metrics, "impressions"),
    _getMetricByName(metrics, "interaction_rate"),
    _getMetricByName(metrics, "interactions"),
    _getMetricByName(metrics, "engagement_rate"),
    _getMetricByName(metrics, "engagements"),
    _getMetricByName(metrics, "absolute_top_impression_percentage"),
    _getMetricByName(metrics, "top_impression_percentage"),
  ]));

  columnGroups.add(ColumnGroup("Conversions", [
    _getMetricByName(metrics, "conversions"),
    _getMetricByName(metrics, "all_conversions"),
    _getMetricByName(metrics, "conversions_from_interactions_rate"),
    _getMetricByName(metrics, "all_conversions_from_interactions_rate"),
    _getMetricByName(
        metrics, "all_conversions_from_interactions_value_per_interaction"),
    _getMetricByName(
        metrics, "conversions_from_interactions_value_per_interaction"),
    _getMetricByName(metrics, "all_conversions_value"),
    _getMetricByName(metrics, "all_conversions_value_per_cost"),
    _getMetricByName(metrics, "conversions_value"),
    _getMetricByName(metrics, "conversions_value_per_cost"),
    _getMetricByName(metrics, "cost_per_all_conversions"),
    _getMetricByName(metrics, "cost_per_conversion"),
    _getMetricByName(metrics, "value_per_all_conversions"),
    _getMetricByName(metrics, "value_per_conversion"),
    _getMetricByName(metrics, "view_through_conversions"),
  ]));

  return columnGroups;
}

List<FilterGroup> createFilterGroups(Store<AppState> store,
    [String filterType = 'FILTER' /* 'ORDER' or 'FILTER' */]) {
  List<Metric> metrics = List.from(store.state.searchTermMetrics);
  List<FilterGroup> _filterGroups = [];
  _filterGroups.add(FilterGroup("Performance", [
    _getMetric(metrics, "clicks"),
    _getMetric(metrics, "cost_micros"),
    _getMetric(metrics, "impressions"),
    _getMetric(metrics, "ctr"),
    _getMetric(metrics, "interactions"),
    _getMetric(metrics, "interaction_rate"),
    _getMetric(metrics, "engagements"),
    _getMetric(metrics, "engagement_rate"),
    _getMetric(metrics, "average_cpc"),
    _getMetric(metrics, "average_cost"),
    _getMetric(metrics, "average_cpe"),
    _getMetric(metrics, "average_cpm"),
    // _getMetric(metrics, "average_cpv", "Avg. CPV"),
    _getMetric(metrics, "absolute_top_impression_percentage"),
    _getMetric(metrics, "top_impression_percentage"),
  ]));
  _filterGroups.add(FilterGroup("Search Term", [
    FilterValue("Text", "", "", valueType: "string", stringFilterType: "text")
  ]));
  _filterGroups.add(FilterGroup("Conversions", [
    _getMetric(metrics, "conversions"),
    _getMetric(metrics, "cost_per_conversion"),
    _getMetric(metrics, "conversions_from_interactions_rate"),
    _getMetric(metrics, "conversions_value"),
    _getMetric(metrics, "conversions_value_per_cost"),
    // calculate conv. value per click?
    _getMetric(metrics, "value_per_conversion"),
    _getMetric(metrics, "all_conversions"),
    _getMetric(metrics, "cost_per_all_conversions"),
    _getMetric(metrics, "all_conversions_value"),
    _getMetric(metrics, "all_conversions_value_per_cost"),

    // "All conv. value / click"
    _getMetric(metrics, "value_per_all_conversions"),
    _getMetric(metrics, "view_through_conversions"),
  ]));
  _filterGroups.add(FilterGroup("Attributes", [
    FilterValue("Added/Excluded", "", "", 
      valueType: "added_excluded", 
      stringFilterType: "status"),
    FilterValue("Campaign name", "", "",
        valueType: "string", stringFilterType: "campaignName"),

    if (filterType != 'ORDER')
      FilterValue("Campaign", "", "",
          valueType:
              "campaign"), // callback to show the list of campaigns and query by them.
    // FilterValue("Max CPC.")
    // FilterValue("Status")
    FilterValue("AdGroup name", "", "",
        valueType: "string", stringFilterType: "adGroupName"),
    if (filterType != 'ORDER')
      FilterValue("AdGroup", "", "", valueType: "adGroup"),
  ]));
  return _filterGroups;
}

Future<void> saveAll(BuildContext context, Store<AppState> store,
    AppState state, List<ChangeAction> changeActions) async {
  List<SearchTermSaveAction> errorSaves = [];
  List<String> errorLogs = [];
  // Saved negative keyword lists to save.
  // Track this to prevent from saving duplicates.
  List<NegativeKeywordListToSave> savedNklts = [];

  void addToErrorLogs(String s) {
    errorLogs.add(s);
  }

  // List<NegativeKeywordList> negativeKeywordsLists =
  //     (await getLocalObjects('NEGATIVE_KEYWORD_LIST'))
  //         .map((map) => NegativeKeywordList.map2NegativeKeywordList(ap))
  //         .toList();
  print("saving changeActions: ${changeActions.length} ");

  for (var changeAction in changeActions) {
    if (changeAction.changeType == 'SearchTerm') {
      SearchTermSaveAction searchTermSaveAction = changeAction.changeObject;
      // print("searhcTermSaveAction: ${searchTermSaveAction.toMap()}");

      // Retrieve Manager Id from adGroup.
      // List<dynamic> a = await getLocalObjectsWithConstraint(
      //     'ADGROUPS', 'id', searchTermSaveAction.adGroupId);
      // AdGroup currentParentAdGroup = a.first;

      // Campaign parentCampaign = await getLocalObjectsWithConstraint(
      //     'CAMPAIGNS', 'id', parentAdGroup.campaignId) as Campaign;
      // CustomerClient parentCustomerClient =
      //     await getLocalObjectsWithConstraint(
      //             'CUSTOMER_CLIENTS', 'id', parentCampaign.customerClientId)
      //         as CustomerClient;
      if (searchTermSaveAction.isNegative == false) {
        final KeywordResponse keywordResponse = await createKeyword(
            // state.currentCustomer.id,
            store,
            searchTermSaveAction.customerId,
            searchTermSaveAction.managerId,
            //currentParentAdGroup.getCustomerId(), //parentCustomerClient.id,
            searchTermSaveAction.searchTermText,
            //"customers/4710197191/adGroups/92874977456", //TODO user to set this from a dropdown of available adgroups
            searchTermSaveAction.adGroupResourceId,
            searchTermSaveAction.isNegative,
            searchTermSaveAction.matchType,
            searchTermSaveAction.finalUrls,
            searchTermSaveAction.maxCpc);
        if (keywordResponse != null &&
            keywordResponse.keywordErrors.length > 0) {
          handleKeywordResponses(store, changeAction, searchTermSaveAction,
              keywordResponse.keywordErrors);
          errorSaves.add(searchTermSaveAction);
        }
      } else if (searchTermSaveAction.isNegative == true) {
        if (searchTermSaveAction.negativeKeywordSaveType == "Ad group") {
          final KeywordResponse keywordResponse = await createKeyword(
              // state.currentCustomer.id,
              store,
              searchTermSaveAction.customerId,
              searchTermSaveAction.managerId,
              //currentParentAdGroup.getCustomerId(), //parentCustomerClient.id,
              searchTermSaveAction.searchTermText,
              //"customers/4710197191/adGroups/92874977456", //TODO user to set this from a dropdown of available adgroups
              searchTermSaveAction.adGroupResourceId,
              searchTermSaveAction.isNegative,
              searchTermSaveAction.matchType,
              searchTermSaveAction.finalUrls,
              searchTermSaveAction.maxCpc);
          if (keywordResponse != null &&
              keywordResponse.keywordErrors.length > 0) {
            handleKeywordResponses(store, changeAction, searchTermSaveAction,
                keywordResponse.keywordErrors);
            errorSaves.add(searchTermSaveAction);
          }
        } else if (searchTermSaveAction.negativeKeywordSaveType == "Campaign") {
          final KeywordResponse keywordResponse =
              await createKeywordCampaignLevel(
                  store,
                  searchTermSaveAction.customerId,
                  searchTermSaveAction.managerId,
                  searchTermSaveAction.campaignResourceName,
                  searchTermSaveAction.searchTermText,
                  searchTermSaveAction.matchType);
          if (keywordResponse != null &&
              keywordResponse.keywordErrors.length > 0) {
            handleKeywordResponses(store, changeAction, searchTermSaveAction,
                keywordResponse.keywordErrors);
            errorSaves.add(searchTermSaveAction);
          }
        } else if (searchTermSaveAction.negativeKeywordSaveType ==
            "Negative keyword list") {
          // If resourceName does not exist, look through Db, it should have been saved and updated by now.
          if (searchTermSaveAction.negativeKeywordListResourceName == null ||
              searchTermSaveAction.negativeKeywordListResourceName.length ==
                  0) {
            // Save temporary negative Keyword lists if it exists.
            // print("Searching for: ${searchTermSaveAction.negativeKeywordListName}");
            List<NegativeKeywordListToSave> nkltss =
                await NegativeKeywordListToSave.fromMaps(
              searchTermSaveAction.customerId,
              searchTermSaveAction.managerId,
            );
            // for(NegativeKeywordListToSave nklt in nkltss) {
            //   print("${nklt.toMap()}");
            // }
            NegativeKeywordListToSave nklts =
                // store.state.negativeKeywordListsToSave
                nkltss.firstWhere(
                    (element) =>
                        element.name ==
                        searchTermSaveAction.negativeKeywordListName,
                    orElse: () => null);
            // print("FOUND negativeKeywordListToSave: " +
            // store.state.negativeKeywordListsToSave.length.toString());

            // Was not found, maybe it was edited. Create a new one.
            if (nklts == null) {
              // print("Creating new");
              nklts = NegativeKeywordListToSave(
                  searchTermSaveAction.negativeKeywordListName,
                  searchTermSaveAction.customerId,
                  searchTermSaveAction.managerId,
                  "",
                  0,
                  0);
            }
            NegativeKeywordList nkl = nklts.toNegativeKeywordList();

            String negativeKeywordListResourceName;

            NegativeKeywordListToSave existingNklts = savedNklts.firstWhere(
                (element) => element.name == nkl.name,
                orElse: () => null);
            // Only create negative keyword list if it hasn't already been created.
            if (existingNklts == null) {
              final KeywordResponse keywordResponse =
                  await createNegativeKeywordList(store, nkl.customerId,
                      nkl.managerId, nkl.name, addToErrorLogs);

              if (keywordResponse.keywordErrors.length > 0) {
                handleKeywordResponses(store, changeAction,
                    searchTermSaveAction, keywordResponse.keywordErrors);
                errorSaves.add(searchTermSaveAction);
              }
              // Save was successful
              // Add to tracking list to prevent saving duplicates.
              // Add resource name to use in subsequent calls.
              nklts.resourceName = keywordResponse.value;
              savedNklts.add(nklts);
              negativeKeywordListResourceName = keywordResponse.value;
            } else {
              // Use the saved resource name for next save.
              negativeKeywordListResourceName = existingNklts.resourceName;
            }

            if (negativeKeywordListResourceName == null) {
              // Could not add Negative Keyword List to Google Ads.
              // handleKeywordResponses(
              //     store, changeAction, searchTermSaveAction,
              //     keywordResponse.keywordErrors
              // [KeywordError(
              //     "", "Could not add Negative Keyword List to Google Ads")]
              // );
              errorSaves.add(searchTermSaveAction);
              return;
            }
            // Modify local state.
            await store.dispatch(
                AddResourceNameToNegativeKeywordListToSaveAction(
                    nkl.name, negativeKeywordListResourceName));

            // store.dispatch(RemoveNegativeKeywordListToSaveAction(nklts));
            // print("RETURNED negativeKeywordListResourceName: " +
            // negativeKeywordListResourceName.toString());
            nkl.resourceName = negativeKeywordListResourceName;
            await insertObjectIfNotExistUpdateIfExist(
                nkl.toMap(), 'NEGATIVE_KEYWORD_LIST', nkl.name, true);

            // print("searchTermSaveAction.negativeKeywordListName: " +
            // searchTermSaveAction.negativeKeywordListName);
            // print("store.state.negativeKeywordListsToSave: " +
            // store.state.negativeKeywordListsToSave.toString());
            for (NegativeKeywordListToSave _nk
                in store.state.negativeKeywordListsToSave) {
              // print("name: " + _nk.name);
            }
            searchTermSaveAction.negativeKeywordListResourceName = store
                .state.negativeKeywordListsToSave
                .firstWhere(
                    (element) =>
                        element.name ==
                        searchTermSaveAction.negativeKeywordListName,
                    orElse: () => null)
                .resourceName;
            // print("searchTermSaveAction.negativeKeywordListResourceName: " +
            // searchTermSaveAction.negativeKeywordListResourceName
            // .toString());
          }
          final KeywordResponse keywordResponse =
              await addToNegativeKeywordList(
                  store,
                  searchTermSaveAction.customerId,
                  searchTermSaveAction.managerId,
                  searchTermSaveAction.matchType,
                  searchTermSaveAction.searchTermText,
                  searchTermSaveAction.negativeKeywordListResourceName,
                  addToErrorLogs);
          if (keywordResponse != null &&
              keywordResponse.keywordErrors.length > 0) {
            handleKeywordResponses(store, changeAction, searchTermSaveAction,
                keywordResponse.keywordErrors);
            errorSaves.add(searchTermSaveAction);
          }

          // store.dispatch(AddNegativeKeywordListAction(nkl));

        }

        //   String negativeKeywordList = await createNegativeKeywordList(
        //     initialCustomerId,
        //     initialCustomerClientId,
        //     "BROAD",
        //     "NEW TEXT TO ADD",
        //     "API CREATED NEGATIVE KEYWORD LIST: " + DateTime.now().toString());
        // print("RETURNED negativeKeywordList: " + negativeKeywordList.toString());
        // await addToNegativeKeywordList(
        //     initialCustomerId,
        //     initialCustomerClientId,
        //     "BROAD",
        //     "NEW SEARCHTERM ADDED TO NEGATIVE KEYWORD LIST: " +
        //         DateTime.now().toString(),
        //     [],
        //     negativeKeywordList);
        // }
      }
    }
  }

  // store.dispatch(UpdateErrorSavesAction(errorSaves));
  // print("errorSaves.length: ${errorSaves.length}");

  // print("errorLogs: " + errorLogs.length.toString());
  if (errorSaves.isNotEmpty || errorLogs.isNotEmpty) {
    ANALYTICS_logEvent(store, 'Error saving search terms', {
      "number_of_errors": errorSaves.length.toString(),
    });
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text(
                  "Error creating keyword${errorSaves.length == 1 ? '' : 's'}"),
              content: Container(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                        "${errorSaves.length} error${errorSaves.length == 1 ? ' is' : 's are'} highlighted.")
                  ],
                  //         errorSaves.map((e) =>
                  //           Text(e.searchTermText))
                  //           .toList()
                  //           ..addAll(
                  //             errorLogs.map((e) => Text(e)).toList(),
                  // ),
                ),
              ),
              actions: [
                InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Container(
                        padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.all(Radius.circular(6)),
                        ),
                        child: Text('Ok', //'Let us know about this issue',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ))))
              ]);
        });
  } else {
    // Consume in-app-purchase only after keywords are saved without issue.
    // Only if currently not on any subscription.
    // This code was only reached by using a single_save.
    if (store.state.membershipType == null) {
      store.dispatch(UpdateWaitingToConsumeSaveConsumableAction(true));
      // print("RESTORING PURCHASES!!!");
      // InAppPurchase.instance.restorePurchases(); // Test this out and see what happens.
      PastPurchase unusedConsumable =
          getLastUnusedConsumable(store.state.pastConsumables);
      consumeSingleSave(store, stringFromStore(unusedConsumable.store),
          unusedConsumable.orderId);
    }

    ANALYTICS_logEvent(store, 'Success saving search terms');

    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Container(
              child: Text(
                "Success!",
                style: TextStyle(
                  fontSize: 25,
                ),
                textAlign: TextAlign.center,
              ), //"Saved successfully"),
            ),
            content: Container(
              padding: EdgeInsets.fromLTRB(25, 10, 25, 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "${changeActions.length.toString()} keyword${changeActions.length != 1 ? 's were' : ' was'} added to Google Ads",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16.5,
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.symmetric(vertical: 35, horizontal: 5),
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color.fromRGBO(75, 205, 75, 1),
                        // borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 60,
                      )),
                ],
              ),
            ),
            actions: [
              InkWell(
                  onTap: () {
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  },
                  child: Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(left: 35, right: 35, bottom: 35),
                    padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                    decoration: BoxDecoration(
                      // color: Colors.blue,
                      color: Color.fromRGBO(75, 205, 75, 1),
                      borderRadius: BorderRadius.all(Radius.circular(50)),
                    ),
                    child: Text(
                      'Continue', //'Keep on editing',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                      ),
                    ),
                  ))
            ],
          );
        }).then((_) {
      // After save success alert dialog is closed.
      Navigator.of(context).popUntil((route) => route.isFirst);
    });
    store.dispatch(ResetChangesAction(store.state.currentCustomer.id));
    store.dispatch(
        ResetNegativeKeywordListToSaveAction(store.state.currentManager.id));
  }
}

void handleKeywordResponses(
    Store<AppState> store,
    ChangeAction changeAction,
    SearchTermSaveAction searchTermSaveAction,
    List<KeywordError> keywordErrors) {
  searchTermSaveAction.setKeywordErrors(keywordErrors);
  changeAction.changeObject = searchTermSaveAction;
  store.dispatch(ModifyChangeAction(
    changeAction.changeId,
    changeAction,
    searchTermSaveAction.isNegative,
  ));
}

/*
    {
      error: 
      {
        code: 400, 
        message: Request contains an invalid argument., 
        status: INVALID_ARGUMENT, 
        details: [
          {
            @type: type.googleapis.com/google.ads.googleads.v8.errors.GoogleAdsFailure, 
            errors: [
              {
                errorCode: {
                  criterionError: KEYWORD_HAS_TOO_MANY_WORDS
                }, 
                message: Keyword text has too many words., 
                trigger: {
                  stringValue: 2016 unic uc40+ new arrival led projector home cinema theater vga hd
                }, 
                location: {
                  fieldPathElements: [
                    {fieldName: operations, index: 0}, 
                    {fieldName: create}, 
                    {fieldName: keyword}, 
                    {fieldName: text}
                  ]
                }
              }
            ], 
            requestId: i-FXv1vbiqgHOzyG58C7cw
          }
        ]
      }
    }
*/
List<KeywordError> getKeywordErrors(var response) {
  List<KeywordError> out = [];
  var errorObj = jsonDecode(response.body);
  print("getKeywordErrors: $errorObj");
  try {
    errorObj = errorObj['error']['details'][0];
    // print("errorObj: $errorObj");
    var errors = errorObj['errors'];
    // print("errors $errors");
    for (var error in errors) {
      // Check different error types until one is found.
      int index = 0;
      String errorName = processError(error, index);

      String errorDescription = error['message'];
      print("errorName: $errorName, errordescription: $errorDescription");
      out.add(KeywordError(errorName, errorDescription));
    }
    return out;
  } catch (err) {
    // Different type of error. Throw everything here.
    print("CAUGHT DIFFERENT ERROR: $err, $errorObj");
    return [KeywordError("Custom", "${errorObj}")];
  }
}

// Process custom error.
// Format is variable, so always wrap in try/catch.
String processError(var errorMap, int index) {
  String errorName;
  int MAX_ERRORS = 2;
  // print("processError index; $index");
  try {
    if (index == 0) {
      errorName = errorMap['errorCode']['criterionError'];
    } else if (index == 1) {
      // Too many keywords in negative keyword list (>5000)
      // RESOURCE_LIMIT
      errorName = errorMap['trigger']['stringValue'];
    } else if (index == 2) {
      // Too many negative keyword lists (>20)
      // RESOURCE LIMIT
      // errorName = error['trigger']['int64Value'].toString();
      errorName =
          errorMap['details']['resourceCountDetails']['limit'].toString();
    }
  } catch (err) {
    // Process the next error.
    return processError(errorMap, index + 1);
  }

  if (errorName == null && index <= MAX_ERRORS) {
    return processError(errorMap, index + 1);
  }

  return errorName;
}

int getCombinedChangesCount(Store<AppState> store) {
  return store.state.positiveKeywords.length +
      store.state.negativeKeywords.length;
}

int getKeywordErrorsCount(List<ChangeAction> changeActions) {
  int count = 0;
  for (ChangeAction keyword in changeActions) {
    if (keyword.changeType == "SearchTerm") {
      SearchTermSaveAction searchTermSaveAction =
          keyword.changeObject as SearchTermSaveAction;
      if (searchTermSaveAction.keywordErrors != null &&
          searchTermSaveAction.keywordErrors.length > 0) {
        count += searchTermSaveAction.keywordErrors.length;
      }
    }
  }
  return count;
}

String generateId() {
  var uuid = Uuid();
  var v1 = uuid.v1();
  return v1;
}

bool isDataParametersDifferent(Store<AppState> store, String managerId,
    String customerId, DateRange dateRange) {
  // print("store.state.currentManager: ${store.state.currentManager.id}");
  // print("store.state.currentCustomer: ${store.state.currentCustomer.id}");
  // print("store.state.currentCustomer.id: ${store.state.currentCustomer.id}");
  // print("store.state.currentManager.id: ${store.state.currentManager.id}");
  // print("managerId: $managerId");
  // print("customerId: $customerId");
  if (accessToken == null || accessToken.length == 0) {
    // User is not signed in, cancel all requests.
    return true;
  }
  if (store.state.currentManager == null ||
      store.state.currentCustomer == null) {
    return true;
  }
  if (store.state.currentManager.id != managerId ||
      store.state.currentCustomer.id != customerId) {
    return true;
  } else if (dateRange != null) {
    return DateRange.isDifferent(store.state.currentDateRange, dateRange);
  }
  return false;
}

void showQuickDialog(String title) {
  showDialog(
      context: GLOBAL_navigatorKey.currentContext,
      builder: (BuildContext context) {
        return AlertDialog(
            title: Text(title),
            content: Container(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [],
              ),
            ),
            actions: [
              InkWell(
                  onTap: () {
                    Navigator.of(context).pop();
                  },
                  child: Container(
                      padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.all(Radius.circular(6)),
                      ),
                      child: Text('Ok', //'Let us know about this issue',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ))))
            ]);
      });
}

// Write error log to DB to track errors.
Future<void> logError(Store<AppState> store, dynamic map) async {
  print("Logging Error");
  store.state.firestore
      .collection('errors')
      .add(map)
      .then((doc) => 
        print("Error written into DB"));
}