import 'dart:async';
// import 'package:provider/provider.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:searchTermAnalyzerFlutter/common_functions.dart';
// import 'package:flutter_appauth/flutter_appauth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/string_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/dialogues/options_filter_dialog.dart';
import 'package:searchTermAnalyzerFlutter/pages/adgroups_selection_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_selection_page.dart';
import 'package:searchTermAnalyzerFlutter/models/adgroup_to_load.dart';
import 'package:searchTermAnalyzerFlutter/models/latest_data_loaded_date.dart';
import 'package:searchTermAnalyzerFlutter/models/customer.dart';
import 'package:searchTermAnalyzerFlutter/models/filter_value.dart';
import 'package:searchTermAnalyzerFlutter/models/order_value.dart';
import 'package:searchTermAnalyzerFlutter/models/searchterm.dart';
import 'package:searchTermAnalyzerFlutter/pages/logo_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/initial_screen.dart';
import 'package:searchTermAnalyzerFlutter/pages/adgroups_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/order_filters_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/campaigns_overview_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/customers_list_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/purchaseable_products_page.dart';
import 'package:searchTermAnalyzerFlutter/pages/search_terms_page.dart';
import 'package:searchTermAnalyzerFlutter/provider/firebase_notifier.dart';
import 'package:searchTermAnalyzerFlutter/redux/actions.dart';
import 'package:searchTermAnalyzerFlutter/redux/reducers.dart';
import 'package:searchTermAnalyzerFlutter/shared_preferences.dart';
import 'package:searchTermAnalyzerFlutter/utils/firebase_messaging.dart';
import 'package:searchTermAnalyzerFlutter/utils/payments.dart';
import 'package:searchTermAnalyzerFlutter/widgets/changes_fab.dart';
import 'package:searchTermAnalyzerFlutter/widgets/initial_setup_flow.dart';
import 'package:searchTermAnalyzerFlutter/widgets/measure_size.dart';
// import 'package:searchTermAnalyzerFlutter/widgets/snack_bar_filter.dart';
import 'package:searchTermAnalyzerFlutter/widgets/customer_client_bar.dart';
import 'package:searchTermAnalyzerFlutter/widgets/date_range_bar.dart';
import 'package:searchTermAnalyzerFlutter/widgets/settings_drawer.dart';
import 'package:searchTermAnalyzerFlutter/widgets/purchasing_loader.dart';
import 'package:searchTermAnalyzerFlutter/widgets/welcome.dart';
import 'package:searchTermAnalyzerFlutter/models/metric.dart';
import 'package:timezone/timezone.dart';
import 'auth.dart';
import 'constants.dart';
import 'models/date_range.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:redux/redux.dart';
import 'package:flutter_redux/flutter_redux.dart';
import 'package:redux_thunk/redux_thunk.dart';
import 'package:after_layout/after_layout.dart';
import 'package:searchTermAnalyzerFlutter/api.dart';
import 'local_data.dart';
import 'redux/models.dart';
import 'package:searchTermAnalyzerFlutter/widgets/expandable_order_item.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_smartlook/flutter_smartlook.dart';
import 'package:searchTermAnalyzerFlutter/analytics.dart';
import 'package:google_api_availability/google_api_availability.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// Global variables.
String accessToken;
bool GLOBAL_isLoadingSearchTerms = false;
int GLOBAL_lastSearchTermsDisplayCall = DateTime.now().millisecondsSinceEpoch;

// Tracks the number of paginated entries to load.
int GLOBAL_paginatedLoadComplete = 0;

// Total number of paginated pages that are being loaded.
int GLOBAL_paginatedLoadTotal = 0;

// Tracks number of adGroups completed loading.
int GLOBAL_adGroupsToLoadFinished = 0;

// Number of total adGroups to load.
int GLOBAL_adGroupsToLoadTotal = 0;

bool GLOBAL_showingQuotaPopup = false;

// As long as SearchTerm.fromMaps() is being called, this is true.
bool GLOBAL_searchTermsLoading = false;

// As long as API is loading, this shows.
// As long as this is true, 'No search terms' never displays.
bool GLOBAL_searchTermsAPILoading = false;

// As long as DB is querying for data
bool GLOBAL_searchTermsDBLoading = false;

// After two seconds, this is trigged to true.
// This allows authentication to remove it only after two seconds.
bool isWelcomeScreenAllowedToHide = false;

bool GLOBAL_customerNotEnabled = false;

final GLOBAL_navigatorKey = GlobalKey<NavigatorState>();

AndroidNotificationChannel channel;

FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

void main() async {
  tz.initializeTimeZones();
  WidgetsFlutterBinding.ensureInitialized();
  await initializeSharedPreferences();
  // Initialize local data storage
  await initializeDB();
  DateRange initialDateRange = DateRange.fromName(
      readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_DATE_RANGE),
      readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_TIMEZONE));

  if (initialDateRange != null && initialDateRange.getName() == 'Custom') {
    // Load the selected start and end dates as well.
    String customDateRangeStart = readSharedPreferenceValue(
        SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_START);
    print('customDateRangeStart: ' + customDateRangeStart.toString());
    String customDateRangeEnd =
        readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CUSTOM_DATERANGE_END);

    if (customDateRangeStart.length > 1 && customDateRangeEnd.length > 1) {
      initialDateRange.setKeyName(
          "BETWEEN ${epochTime2DateString(int.parse(customDateRangeStart))} AND ${epochTime2DateString(int.parse(customDateRangeEnd))}");
      initialDateRange.setAdditionalName(
          "(${epochTime2DateString(int.parse(customDateRangeStart))} to ${epochTime2DateString(int.parse(customDateRangeEnd))})");
      initialDateRange.lowerEpochDate = int.parse(customDateRangeStart);
      initialDateRange.upperEpochDate = int.parse(customDateRangeEnd);
    }
  }
  String initialCustomerId =
      readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_ID);
  String initialCustomerClientId = readSharedPreferenceValue(
      SHARED_PREFERENCE_KEYS.CURRENT_CUSTOMER_CLIENT_ID);
  String initialCampaign =
      readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_CAMPAIGN_ID);
  String initialAdgroup =
      readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.CURRENT_AD_GROUP_ID);
  // String mostRecentDataDateTime = readSharedPreferenceValue(
  //     SHARED_PREFERENCE_KEYS.MOST_RECENT_DATA_DATETIME);
  // String oldestDataDateTime =
  //     readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.OLDEST_DATA_DATETIME);

  int appLoadCount =
      readSharedPreferenceValue<int>(SHARED_PREFERENCE_KEYS.LOAD_COUNT);

  print("appLoadCount: $appLoadCount");

  int mostRecentDataDateTime =
      await LatestDataLoadedDate.fromDB(initialCustomerClientId);

  // NOT IN USE
  String oldestDataDateTime = "";

  String nextPageToken =
      readSharedPreferenceValue(SHARED_PREFERENCE_KEYS.NEXT_PAGE_TOKEN);

  List<Metric> campaignMetrics = await Metric.fromDB("CAMPAIGN");
  List<Metric> adGroupMetrics = await Metric.fromDB("ADGROUPS");
  List<Metric> searchTermMetrics = await Metric.fromDB("SEARCHTERMS");
  // print("searchTermMetrics: $searchTermMetrics");

  OrderValue orderValue = await OrderValue.fromDB();
  // print("orderValue: ${orderValue.name}");

  print('initialCampaign: $initialCampaign');
  print('initialAdGroup: $initialAdgroup');
  List<FilterValue> filterValues = await FilterValue.fromDB();
  for (FilterValue fv in filterValues) {
    print('filterValue: ${fv.toMap()}');
  }

  await Firebase.initializeApp();

  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  channel = const AndroidNotificationChannel(
    'high_importance_channel',
    'High importance Notifications',
    description: 'Channel used for important notifications.',
    importance: Importance.high,
  );

  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  // Create an Android notification channel.
  // Enable heads-up notifications.
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  // Update the iOS foreground notificaton presentation options to allow heads up notifications.
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true, badge: true, sound: true);

  List<ProductDetails> iapProducts = [];

  // Map<String, dynamic> locations = tz.timeZoneDatabase.locations;
  // for (Location location in locations.values) {
  //   print("location: $location");
  // }

  // print("Initial campaignId: $initialCampaign");
  final Store<AppState> store = Store<AppState>(
      appReducers, // Defined in reducers file to handle each action.
      initialState: AppState.initialState(
          initialDateRange,
          initialCustomerId,
          initialCustomerClientId,
          initialCampaign,
          initialAdgroup,
          mostRecentDataDateTime,
          oldestDataDateTime,
          campaignMetrics,
          adGroupMetrics,
          searchTermMetrics,
          orderValue,
          filterValues,
          iapProducts,
          appLoadCount),
      middleware: [thunkMiddleware]);

  await initFlutterFire(store);

  setSharedPreferenceValue<int>(
      SHARED_PREFERENCE_KEYS.LOAD_COUNT, appLoadCount + 1);

  // Pass all uncaught errors from the framework to Crashlytics.
  FlutterError.onError = store.state.crashlytics.recordFlutterError;

  // Use a listener to notify from reducer.
  // Update search terms.

  // store.state.addListener(() {
  //   if (!GLOBAL_isLoadingSearchTerms) {
  //     print("LISTENER Updating visible search terms");
  //     GLOBAL_isLoadingSearchTerms = true;
  //     store.dispatch((x) =>
  //       updateVisibleSearchTermsAction(store));
  //   }
  // });

  // print("nextPageToken: $nextPageToken");
  // if (nextPageToken != "") {

  // TODO START OF DEBUG
  // resetAdGroupsToLoad(initialCustomerClientId);
  // truncateTable("SEARCHTERMS");
  // TODO END OF DEBUG

  // int searchTermCount = await getRowCount("SEARCHTERMS");

  // store.dispatch(IncrementLoadedAction('searchTerm', searchTermCount));
  // }

  // Only fetch if it has been intialzied before.
  print("initialCustomerId: $initialCustomerId");
  print("initialCustomerClientId: $initialCustomerClientId");
  if (initialCustomerId != null &&
      initialCustomerId.length > 0 &&
      initialCustomerClientId != null &&
      initialCustomerClientId.length > 0) {
    store.dispatch((x) => fetchInitialStateAction(store));

    // store.dispatch((x) => resumeLoadingSearchTermsAction(
    //       store,
    //       initialCustomerId,
    //       initialCustomerClientId,
    //       initialDateRange,
    //       initialCampaign,
    //       initialAdgroup,
    //     ));
  } else {
    // Accounts were loaded from API, but none was selected.
    // Load the customers from local DB.
    store.dispatch((x) => fetchLocalCustomersAction(store));
  }

  if (campaignMetrics.length == 0) {
    store.dispatch(UpdateDisplayMetricsAction("CAMPAIGN", [], store));
  }
  if (adGroupMetrics.length == 0) {
    store.dispatch(UpdateDisplayMetricsAction("ADGROUPS", [], store));
  }
  if (searchTermMetrics.length == 0) {
    store.dispatch(UpdateDisplayMetricsAction("SEARCHTERMS", [], store));
  }

  if (defaultTargetPlatform == TargetPlatform.android) {
    InAppPurchaseAndroidPlatformAddition.enablePendingPurchases();

    store.dispatch((x) => iapAvailabilityUpdateAction(store));
  }

  runApp(
    // ChangeNotifierProvider(
    // create: (context) => FirebaseNotifier(),
    // lazy: false,
    // child:
    MyApp(
      store: store,
      initialCustomerId: initialCustomerId,
      initialCustomerClientId: initialCustomerClientId,
      initialDateRange: initialDateRange,
      appLoadCount: appLoadCount,
    ),
    // ),
  );
}

Future initFlutterFire(Store<AppState> store) async {
  // Create the initialization Future outside of `build`:
  // await Firebase.initializeApp();

  GoogleSignInAuthentication googleAuth = await getGoogleAuth(store);
  // await signInWithGoogleAuth(store, googleAuth);
}

class MyApp extends StatefulWidget {
  final Store<AppState> store;
  final String initialCustomerId;
  final String initialCustomerClientId;
  final DateRange initialDateRange;
  final int appLoadCount;

  MyApp(
      {this.store,
      this.initialCustomerId,
      this.initialCustomerClientId,
      this.initialDateRange,
      this.appLoadCount});

  @override
  _MyAppState createState() => _MyAppState(
      store: this.store,
      initialCustomerId: this.initialCustomerId,
      initialCustomerClientId: this.initialCustomerClientId,
      initialDateRange: this.initialDateRange,
      appLoadCount: this.appLoadCount);
}

class _MyAppState extends State<MyApp> {
  _MyAppState(
      {Key key,
      this.store,
      this.initialCustomerId,
      this.initialCustomerClientId,
      this.initialDateRange,
      this.appLoadCount});
  //: super(key: key);

  String initialCustomerId;
  String initialCustomerClientId;
  DateRange initialDateRange;
  int appLoadCount;

  final Store<AppState> store;

  StreamSubscription<List<PurchaseDetails>> _subscription;

  GooglePlayServicesAvailability _playStoreAvailability =
      GooglePlayServicesAvailability.unknown;

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> checkPlayServices([bool showDialog = false]) async {
    GooglePlayServicesAvailability playStoreAvailability;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      playStoreAvailability = await GoogleApiAvailability.instance
          .checkGooglePlayServicesAvailability(showDialog);
    } on PlatformException {
      playStoreAvailability = GooglePlayServicesAvailability.unknown;
    }
    print("playStoreAvailability: $playStoreAvailability");

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) {
      return;
    }

    setState(() {
      _playStoreAvailability = playStoreAvailability;
    });
  }

  @override
  void initState() {
    super.initState();

    final Stream purchaseUpdated = InAppPurchase.instance.purchaseStream;
    _subscription = purchaseUpdated.listen((purchaseDetailsList) {
      print("purchaseDetailsList: , $purchaseDetailsList");
      listenToPurchaseUpdated(this.store, purchaseDetailsList);
    }, onDone: () {
      _subscription.cancel();
    }, onError: (error) {
      print("ERROR LISTENING TO PURCHASES: " + error.toString());
    });

    periodicallyCheckSignIn(this.store);

    SetupOptions options = (new SetupOptionsBuilder(SMARTLOOK_API_KEY)).build();
    Smartlook.setupAndStartRecording(options);

    // Check Google Play Services for Firebase Push Notifications.
    // https://github.com/Baseflow/flutter-google-api-availability/blob/main/example/lib/main.dart
    checkPlayServices(true);

    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification.android;
      print("RECEIVED MESSAGE: ${message.notification.title}");
      print("message.notification.title: ${message.notification.title}");
      print("notification.android.imageUrl: ${notification.android.imageUrl}");
      print("notification.hashCode: ${notification.hashCode}");

      ANALYTICS_logEvent(store, "Notification ${notification.title}");
      if (notification != null && android != null) {
        if (notification.title == 'Unsaved Search Terms') {
          // Only show if there are unsaved search terms.
          int unsavedSearchTerms =
              await getRowCount('SEARCH_TERM_SAVE_ACTIONS');
          if (unsavedSearchTerms > 0) {
            flutterLocalNotificationsPlugin.show(
                notification.hashCode,
                notification.title,
                notification.body,
                NotificationDetails(
                    android: AndroidNotificationDetails(
                  channel.id,
                  channel.name,
                  channelDescription: channel.description,
                  // icon: notification.android.imageUrl, // 'launcher_icon',//'launch_background',
                  icon: 'launcher_icon',
                )));
          }
        } else {
          flutterLocalNotificationsPlugin.show(
              notification.hashCode,
              notification.title,
              notification.body,
              NotificationDetails(
                  android: AndroidNotificationDetails(
                channel.id,
                channel.name,
                channelDescription: channel.description,
                // icon: notification.android.imageUrl, //'launcher_icon',//'launch_background',
                icon:
                    '@drawable/icon_transparent_trimmed', //'@drawable/launcher_icon',
              )));
        }
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print("Notification was pressed");
      ANALYTICS_logEvent(
          store, "Notification pressed ${message.notification.title}");
    });
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StoreProvider<AppState>(
      store: store,
      child: /*RefreshConfiguration(
         headerBuilder: () => WaterDropHeader(),        // Configure the default header indicator. If you have the same header indicator for each page, you need to set this
         footerBuilder:  () => ClassicFooter(),        // Configure default bottom indicator
         headerTriggerDistance: 80.0,        // header trigger refresh trigger distance
         springDescription:SpringDescription(stiffness: 170, damping: 16, mass: 1.9),         // custom spring back animate,the props meaning see the flutter api
         maxOverScrollExtent :100, //The maximum dragging range of the head. Set this property if a rush out of the view area occurs
         maxUnderScrollExtent:0, // Maximum dragging range at the bottom
         enableScrollWhenRefreshCompleted: true, //This property is incompatible with PageView and TabBarView. If you need TabBarView to slide left and right, you need to set it to true.
         enableLoadingWhenFailed : true, //In the case of load failure, users can still trigger more loads by gesture pull-up.
         hideFooterWhenNotFull: false, // Disable pull-up to load more functionality when Viewport is less than one screen
         enableBallisticLoad: true, // trigger load more by BallisticScrollActivity
        child: */
          SmartlookHelperWidget(
        child: MaterialApp(
          navigatorKey: GLOBAL_navigatorKey,
          title: 'Search Terms Manager',
          theme: ThemeData(
            primarySwatch: Colors.blue,
            // This makes the visual density adapt to the platform that you run
            // the app on. For desktop platforms, the controls will be smaller and
            // closer together (more dense) than on mobile platforms.
            visualDensity: VisualDensity.adaptivePlatformDensity,
            // textTheme: const TextTheme(
            //   headline1: TextStyle(fontSize: 72.0, fontWeight: FontWeight.bold),
            //   headline6: TextStyle(fontSize: 36.0, fontStyle: FontStyle.italic),
            //   bodyText2: TextStyle(fontSize: 14.0, fontFamily: 'Hind'),
            // ),
          ),
          // builder: (context, child) {
          //   // Scaffold under Navigator but above all routes.
          //   return Scaffold(
          home: Scaffold(
            // appBar: AppBar(title: Text('Insert Customer Account Here')),
            // bottomNavigationBar: BottomNavigationBar(
            //   elevation: 10,
            //   items: [
            //     customBottomNavigationItem("Campaigns", 6),
            //     customBottomNavigationItem("Adgroups", 10),
            //     customBottomNavigationItem("Search Terms", 25)
            //   ],
            //   selectedItemColor: Colors.amber[800],
            //   currentIndex: this._currentBottomNavigationIndex,
            //   onTap: _onBottomNavigationItemTapped,
            // ),
            // drawer: Drawer(child: Text("Drawer")),

            // Wrap in StoreConnector to force listening to state changes.
            body: StoreConnector<AppState, Store<AppState>>(
              converter: (store) => store,
              builder: (context, store) => checkShowingInitialSequence(
                      store.state.currentCustomer != null
                          ? store.state.currentCustomer.id
                          : "",
                      store.state.currentManager != null
                          ? store.state.currentManager.id
                          : "",
                      store.state.currentDateRange)
                  ? CustomersList(store, false)
                  : MyHomePage(
                      store: store,
                      initialCustomerId: initialCustomerId,
                      initialCustomerClientId: initialCustomerClientId,
                      initialDateRange: initialDateRange,
                      appLoadCount: appLoadCount),
              //},
            ),
            // ),
          ),
          builder: (context, child) => Stack(children: [
            child,
            PurchasingLoader(),
            WelcomeScreen(store, initialCustomerId, appLoadCount),
            // IgnorePointer(
            //   ignoring: !store.state.isShowingInitialScreen,
            // child:
            StoreConnector<AppState, Store<AppState>>(
                    converter: (store) => store,
                    builder: (context, _store) => 
                    _store.state.isShowingInitialScreen
                ? MaterialApp(
                    home: SafeArea(
                      top: true,
                      bottom: true,
                      child: InitialSetupFlow(_store),
                      // child: state.isShowingInitialScreen == 1
                      //   ? LogoPage(store)
                      //   : InitialScreen(store),
                    ),
                  )
                : SizedBox.shrink(),
            ),
            // Text("${store.state.isShowingInitialScreen}"),
            // ),
          ]),
          //}
        ),
      ),
    );
  }
  // home:
  // MyHomePage()));

  // void _onBottomNavigationItemTapped(int index) {
  //   print('Navigation bar item tapped: ' + index.toString());
  // switch (index) {
  //   case 0:
  //     Navigator.pushNamed(context, '/campaigns-overview');
  //     break;
  //   case 1:
  //   Navigator.pushNamed(context, '/adgroups-overview');
  //     break;
  //   case 2:
  //   Navigator.pushNamed(context, '/searchterms');
  //     break;
  // }
  // }

}

class MyHomePage extends StatefulWidget {
  MyHomePage(
      {Key key,
      this.store,
      this.initialCustomerId,
      this.initialCustomerClientId,
      this.initialDateRange,
      this.appLoadCount})
      : super(key: key) {
    // print('user credential: ' + this.userCredential.toString());
  }
  final Store<AppState> store;
  final String initialCustomerId;
  final String initialCustomerClientId;
  final DateRange initialDateRange;
  final int appLoadCount;

  @override
  _MyHomePageState createState() => _MyHomePageState(
      this.store,
      this.initialCustomerId,
      this.initialCustomerClientId,
      this.initialDateRange);
}

class _MyHomePageState extends State<MyHomePage>
    with AfterLayoutMixin<MyHomePage> {
  // PageController _pageController;
  Store<AppState> _store;
  // var currentIndex;

  _MyHomePageState(this._store, this.initialCustomerId,
      this.initialCustomerClientId, this.initialDateRange);

  String initialCustomerId;
  String initialCustomerClientId;
  DateRange initialDateRange;

  @override
  void initState() {
    super.initState();

    // _pageController = PageController(initialPage: initialPage);

    // currentIndex = this._store.state.currentPageIndex;
  }

  @override
  void dispose() {
    super.dispose();
  }

  BottomNavigationBarItem customBottomNavigationItem(
      bool isLoading, String text, int n, String filteringOn) {
    return BottomNavigationBarItem(
        // backgroundColor: Colors.black,
        icon: isLoading
            ? Center(
                child: SizedBox(
                child: CircularProgressIndicator(
                  color: Color.fromRGBO(55, 55, 55, 0.35),
                ),
                width: 20,
                height: 20,
              ))
            : Container(
                // color: Colors.white.withOpacity(0.5),
                child: Column(children: [
                Container(
                  padding: EdgeInsets.all(6),
                  margin: EdgeInsets.only(bottom: 0),
                  // decoration: BoxDecoration(
                  //   shape: BoxShape.circle,
                  //   border: Border.all(
                  //     color: Color.fromRGBO(0, 0, 0, 0.0), // 0.2 opacity
                  //     width: 1.0,
                  //   ),
                  // ),
                  child: filteringOn != null
                      ? Text(filteringOn,
                          softWrap: true,
                          style: TextStyle(
                            color: Color.fromRGBO(55, 55, 55, 0.35),
                            fontSize: 13,
                            fontWeight: FontWeight.w400,
                          ))
                      : Text(n.toString(),
                          style: TextStyle(
                            color: Color.fromRGBO(55, 55, 55, 0.35),
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          )),
                ),
                Text(text,
                    style: TextStyle(
                        color: Color.fromRGBO(55, 55, 55, 0.35),
                        fontWeight: FontWeight.w600))
              ])),
        activeIcon: isLoading
            ? Center(
                child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Color.fromRGBO(55, 55, 55, 0.35),
                ),
              ))
            : Container(
                // color: Colors.blue,
                child: Column(children: [
                Container(
                  padding: EdgeInsets.all(6),
                  margin: EdgeInsets.only(bottom: 0),
                  // decoration: BoxDecoration(
                  //   shape: BoxShape.circle,
                  //   border: Border.all(
                  //     color: Color.fromRGBO(0, 0, 0, 0.0), // 0.2 opacity
                  //     width: 1.0,
                  //   ),
                  // ),
                  child: filteringOn != null
                      ? Text(filteringOn,
                          softWrap: true,
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 13,
                            fontWeight: FontWeight.w400,
                          ))
                      : Text(n.toString(),
                          style: TextStyle(
                            color: Colors.blue,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          )),
                ),
                Text(text,
                    style: TextStyle(
                        color: Colors.blue, fontWeight: FontWeight.w600))
              ])),
        label: "");
  }

  void _onBottomNavigationItemTapped(int index) {
    // print('Bottom navigation index pressed: ' + index.toString());
    /*this._pageController*/
    this._store.state.bottomController.jumpToPage(index);

    // this.setState(() {
    //   currentIndex = index;
    // });

    setSharedPreferenceValue<int>(
        SHARED_PREFERENCE_KEYS.CURRENT_BOTTOM_NAVIGATION_TAB, index);
  }

  @override
  void afterFirstLayout(BuildContext context) {
    // print("checkShowingInitialSequence(this.initialCustomerId, this.initialManagerId, this.initialDateRange): ${checkShowingInitialSequence(this.initialCustomerId, this.initialManagerId, this.initialDateRange)}");
    // if (checkShowingInitialSequence(
    //     this.initialCustomerId, this.initialManagerId, this.initialDateRange)) {
    //   print("NAVIGATE TO INITIAL LOADING SCREEN");
    //   Navigator.push(context,
    //       new MaterialPageRoute(builder: (context) => CustomersList(false)));
    // }
  }

  Widget _pageView() {
    return StoreConnector<AppState, Store<AppState>>(
      converter: (store) => store,
      builder: (context, store) => MaterialApp(
        // initialRoute: '/campaigns-overview',
        // routes: <String, WidgetBuilder>{
        //   '/': (BuildContext context) =>
        //       AccountOverviewPage(),
        //   '/campaigns-overview':
        //       (BuildContext context) =>
        //           CampaignsOverviewPage(),
        //   '/adgroups-overview':
        //       (BuildContext context) =>
        //           AdGroupsOverviewPage(),
        //   '/searchterms': (BuildContext context) =>
        //       Container(
        //           child: Text(
        //               "SEARCH TERMS PAAGE FROM ROUTER"))
        // },

        home: PageView(
          physics: NeverScrollableScrollPhysics(),
          controller: store.state.bottomController, //this._pageController,
          children: [
            // CampaignsOverviewPage(state.campaigns),
            // AdGroupsOverviewPage(state.adGroups),
            SearchTermsPage(
              store,
              store.state,
              /*state.currentCustomer.id,
                state.currentManager.id*/
            ),
          ],
        ),
      ),
    );
  }

  Widget _orderFilter(BuildContext context) {
    return StoreConnector<AppState, Store<AppState>>(
        converter: (store) => store,
        builder: (context, store) {
          return AnimatedPositioned(
            top: 0, //store.state.searchTermOrderBy.value != 0 ? 0 : -100,
            left: 0,
            width: MediaQuery.of(context).size.width,
            height: 25.0,
            duration: const Duration(milliseconds: 250),
            curve: Curves.ease,
            child: AnimatedOpacity(
              opacity:
                  1.0, //store.state.searchTermOrderBy.name == null ? 0.0 : 1.0,
              duration: const Duration(milliseconds: 150),
              child: Container(
                padding: EdgeInsets.fromLTRB(5.5, 4.5, 15.5, 3.5),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 5,
                      blurRadius: 7,
                      offset: Offset(0, 3), // 3 // changes position of shadow
                    ),
                  ],
                ),
                child: GestureDetector(
                  onTap: () {
                    ANALYTICS_logEvent(store, 'Order Search Terms Selected');
                    Navigator.of(context).push(
                      new MaterialPageRoute(builder: (context) {
                        return OrderFiltersPage(store);
                      }),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      store.state.searchTermOrderBy.value != 0
                          ? Text(
                              store.state.searchTermOrderBy.groupName +
                                  ' > ' +
                                  (store.state.searchTermOrderBy.displayName !=
                                          null
                                      ? store
                                          .state.searchTermOrderBy.displayName
                                      : store.state.searchTermOrderBy.name),
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: Colors.blue,
                                fontWeight: FontWeight.w600,
                              ),
                            )
                          : Text(
                              "Select Ordering",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: Colors.blue,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                      SizedBox(width: 10),
                      Text(ORDER_SEQUENCE[store.state.searchTermOrderBy.value],
                          style: TextStyle(
                            color: Colors.black54,
                            fontWeight: FontWeight.w800,
                          )),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }

  Widget _searchTermFilters(BuildContext context) {
    return StoreConnector<AppState, Store<AppState>>(
        converter: (store) => store,
        builder: (context, store) {
          int numberOfFilters = store.state.filterValues != null
              ? store.state.filterValues.length
              : 0;
          return AnimatedPositioned(
            top: numberOfFilters <= 0 ? -100 : 25.0,
            // store.state.searchTermOrderBy.value != 0
            //     ? 25.0
            //     : 0,
            left: 0,
            width: MediaQuery.of(context).size.width,
            // height: 40.0,
            duration: const Duration(milliseconds: 250),
            curve: Curves.ease,
            child: MeasureSize(
              onChange: (size) {
                double newHeight = size.height +
                    25; // Order filters are always visible, so just attach this.
                // if (store.state.searchTermOrderBy.value != 0) {
                //   // Add additional offset to adjust for padding.
                //   newHeight += 25.0;
                // }
                store.dispatch(
                    UpdateSearchTermFiltersDisplayTopOffsetAction(newHeight));
              },
              child: AnimatedOpacity(
                opacity: numberOfFilters == 0 ? 0.0 : 1.0,
                duration: const Duration(milliseconds: 150),
                child: Container(
                  padding: EdgeInsets.all(2.5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 3.5,
                        offset: Offset(0, 3.5), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Wrap(
                    children: List.generate(
                        numberOfFilters,
                        (index) => _searchTermFilter(
                            store, store.state.filterValues[index])),
                  ),
                ),
              ),
            ),
          );
        });
  }

  Widget _searchTermFilter(Store<AppState> store, FilterValue filterValue) {
    String _displayText = filterValue.value;
    // if (filterValue.displayName != "") {
    //   _displayText = filterValue.displayName;
    // }
    if (filterValue.valueType == 'string') {
      _displayText = "'$_displayText'";
    } else if (filterValue.valueType == 'added_excluded') {
      _displayText = "${filterValue.value}";
    } else if (filterValue.valueType == 'campaign') {
      _displayText = "'${filterValue.displayName}'";
    } else if (filterValue.valueType == 'adGroup') {
      _displayText = "'${filterValue.displayName}'";
    }

    return GestureDetector(
      onTap: () {
        ANALYTICS_logEvent(store, 'Filter Search Terms Selected');
        showDialog(
            context: context,
            builder: (BuildContext context) {
              if (filterValue.valueType == "string") {
                return StringFilterDialog(
                    filterValue.name,
                    filterValue.type,
                    filterValue.value,
                    filterValue.displayName,
                    filterValue.metricType,
                    filterValue.stringFilterType,
                    id: filterValue.id);
              }
              else if (filterValue.valueType == "added_excluded") {
                return OptionsFilterDialog(
                  filterValue.name,
                  filterValue.type,
                  filterValue.value,
                  stringFilterType: filterValue.stringFilterType,
                  valueType: filterValue.valueType,
                  id: filterValue.id,
                );
              }
              // List of Campaign / AdGroups
              else if (filterValue.valueType == "campaign") {
                return CampaignsSelectionPage(false, store);
              } else if (filterValue.valueType == "adGroup") {
                return AdGroupsSelectionPage(store);
              } else {
                return MetricFilterDialog(filterValue.name, filterValue.type,
                    filterValue.value, filterValue.displayName,
                    metricType: filterValue.metricType, id: filterValue.id);
              }
            }).then(
          (newFilterValue) {
            // newFilterValue is empty for campaign and adgroups.
            if (newFilterValue != null) {
              // This updates the redux store, which is a bad design pattern.
              // this._filterValues.add(newFilterValue);
              store.dispatch(StartSearchTermsLoadingAction());
              store.dispatch(UpdateFilterAction(newFilterValue));
              // Don't update filters for campaigns or adgroups.
              // These are already updated because modifyCurrentAdGroup/modifyCurrentCampaign redux actions are called.
              if (newFilterValue.name != "Campaign" &&
                  newFilterValue.name != "AdGroup") {
                store.dispatch((x) => updateVisibleSearchTermsAction(store));
              }
            }
          },
        );
      },
      child: Container(
        padding: EdgeInsets.only(left: 10, top: 2.5, right: 2.5, bottom: 2.5),
        margin: EdgeInsets.only(top: 5, bottom: 2.5, left: 4, right: 4),
        decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.all(Radius.circular(20))),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              fit: FlexFit.loose,
              child: Text(
                filterValue.valueType == 'campaign' ||
                        filterValue.valueType == 'adGroup'
                    ? "${filterValue.name} ${filterValue.type} $_displayText"
                    : "${filterValue.displayName} ${filterValue.type} $_displayText",
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 5),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(20))),
              child: GestureDetector(
                onTap: () {
                  ANALYTICS_logEvent(store, 'Filter Deleted');

                  store.dispatch(StartSearchTermsLoadingAction());
                  store.dispatch(RemoveFilterAction(filterValue));

                  // If Campaign/Adgroup, reset currentCampaign/currentAdGroup
                  if (filterValue.name == "Campaign") {
                    store.dispatch(ModifyCurrentCampaignAction(
                      store,
                      store.state,
                      null,
                    ));
                    store.dispatch(
                        ModifyCurrentAdGroupAction(store, store.state, null));
                    store.dispatch((x) => updateVisibleSearchTermsAction(store,
                        noAPI: true, adGroupId: null, campaignId: null));
                  } else if (filterValue.name == "AdGroup") {
                    store.dispatch(
                        ModifyCurrentAdGroupAction(store, store.state, null));
                    store.dispatch((x) => updateVisibleSearchTermsAction(store,
                        noAPI: true, adGroupId: null));
                  }
                  // Don't modify campaign/adgroup because redux already handles it.
                  else {
                    store.dispatch((x) =>
                        updateVisibleSearchTermsAction(store, noAPI: true));
                  }
                },
                child: Icon(Icons.close, size: 20, color: Colors.black54),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _snackBarFilter(BuildContext context) {
    return StoreConnector<AppState, AppState>(
        converter: (store) => store.state,
        builder: (context, state) {
          String text = "";
          String type = "";
          int index;
          // int currentIndex = 2; //state.currentPageIndex;
          // if (currentIndex == 0) {
          //   if (state.currentCampaign != null) {
          //     text = state.currentCampaign.name;
          //     index = state.campaigns
          //         .indexWhere((w) => w.id == state.currentCampaign.id);
          //     type = 'CAMPAIGN';
          //   }
          // } else if (currentIndex == 1) {
          //   if (state.currentAdGroup != null) {
          //     text = state.currentAdGroup.name;
          //     index = state.adGroups
          //         .indexWhere((w) => w.id == state.currentAdGroup.id);
          //     type = 'ADGROUP';
          //   }
          // }
          return AnimatedPositioned(
            bottom: text.length == 0 ? -40 : 0,
            left: 0,
            width: MediaQuery.of(context).size.width,
            height: 40.0,
            duration: const Duration(milliseconds: 250),
            curve: Curves.ease,
            child: AnimatedOpacity(
              opacity: text.length == 0 ? 0.0 : 1.0,
              duration: const Duration(milliseconds: 150),
              child: GestureDetector(
                onTap: () {
                  if (type == 'CAMPAIGN') {
                    state.campaignsScrollController.jumpTo(index: index);
                  } else if (type == 'ADGROUP') {
                    state.adgroupsScrollController.jumpTo(index: index);
                  }
                },
                child: Container(
                  padding: EdgeInsets.only(left: 10, right: 10),
                  color: Colors.blue,
                  child: Row(
                    children: [
                      Text(text.length > 0 ? "Filtering on: " : "",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          )),
                      Flexible(
                        fit: FlexFit.loose,
                        child: Text(
                          text,
                          overflow: TextOverflow.ellipsis,
                          softWrap: false,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }

  Widget _loadingFilter(BuildContext context) {
    return StoreConnector<AppState, AppState>(
        converter: (store) => store.state,
        builder: (context, state) {
          String text = "";
          String type = "";
          int index;
          return AnimatedPositioned(
            bottom: state.showLoadingToast ? 0 : -50,
            left: 0,
            width: MediaQuery.of(context).size.width,
            height: 50.0,
            duration: const Duration(milliseconds: 250),
            curve: Curves.ease,
            child: AnimatedOpacity(
              opacity: state.showLoadingToast ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 150),
              child: GestureDetector(
                onTap: () {
                  // NO ACTION
                  // Could display the number of items here.
                },
                child: Container(
                  padding: EdgeInsets.only(left: 10, right: 10),
                  color: Colors.blue,
                  child: Row(
                    children: [
                      Text(
                          state.showLoadingToast ||
                                  GLOBAL_searchTermsAPILoading == true
                              ? "Loading in background..." //: ${state.searchTermsLoadedCount}"
                              : "",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                          )),
                      Flexible(
                        fit: FlexFit.loose,
                        child: Text(
                          text,
                          overflow: TextOverflow.ellipsis,
                          softWrap: false,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Container(
          child: StoreConnector<AppState, Store<AppState>>(
            converter: (store) => store,
            builder: (context, store) => GestureDetector(
              onTap: () {
                ANALYTICS_logEvent(store, 'Account selected from main screen');

                Navigator.push(
                    context,
                    new MaterialPageRoute(
                        builder: (context) => CustomersList(store)));
              },
              child: StoreConnector<AppState, Customer>(
                converter: (store) => store.state.currentCustomer,
                builder: (context, customer) => Row(children: [
                  Flexible(
                      fit: FlexFit.loose,
                      // padding: EdgeInsets.only(right: 13.0),
                      child: Text(
                        customer != null && customer.descriptiveName != ""
                            ? customer.descriptiveName
                            : "Select Account",
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                      )),
                  Icon(Icons.arrow_drop_down),
                ]),
              ),
            ),
          ),
        ),
        // actions: <Widget>[
        //   StoreConnector<AppState, Store<AppState>>(
        //     converter: (store) => (store),
        //     builder: (context, store) => Padding(
        //         padding: EdgeInsets.only(right: 20.0),
        //         child: GestureDetector(
        //           onTap: () {
        //             // store.dispatch(CreateBuildContextAction(context));
        //             signOut(store);
        //           },
        //           child: Icon(Icons.person),
        //         )),
        //   ),
        // ],
      ),
      endDrawer: SettingsDrawer(),
      /*bottomNavigationBar: StoreConnector<AppState, Store<AppState>>(
        converter: (store) => store,
        builder: (context, store) => BottomNavigationBar(
            elevation: 10,
            items: [
              customBottomNavigationItem(
                  store.state.isLoadingCampaigns,
                  "Campaigns",
                  store.state.campaigns.length,
                  store.state.currentCampaign?.name),
              customBottomNavigationItem(
                  store.state.isLoadingAdGroups,
                  "Adgroups",
                  store.state.adGroups.length,
                  store.state.currentAdGroup?.name),
              customBottomNavigationItem(store.state.isLoadingSearchTerms,
                  "Search Terms", store.state.searchTerms.length, null),
            ],
            type: BottomNavigationBarType.fixed,
            backgroundColor: Colors.white,
            // selectedItemColor: Colors.amber[800],
            currentIndex: store.state.currentPageIndex, //this.currentIndex,
            onTap: (index) {
              print('Index: $index');
              store.dispatch(UpdateCurrentPageIndexAction(index));
              _onBottomNavigationItemTapped(index);
            }),
      ),*/
      floatingActionButton: ChangesFAB(),
      body: Center(
        // Gesture Detector to listen for taps outside of the screen.
        child: StoreConnector<AppState, Store<AppState>>(
          converter: (store) => store,
          builder: (context, store) => GestureDetector(
            onTap: () {
              ANALYTICS_logEvent(store, 'Search Terms Changes Box Selected');

              // print('Tapped outside of screen');
              FocusScopeNode currentFocus = FocusScope.of(context);
              if (!currentFocus.hasPrimaryFocus) {
                currentFocus.unfocus();
              }
            },
            child: Column(
              children: [
                CustomerClientBar(),
                StoreConnector<AppState, int>(
                  converter: (store) => store.state.currentPageIndex,
                  builder: (context, currentPageIndex) =>
                      DateRangeBar(currentPageIndex),
                ),
                Expanded(
                  child: SafeArea(
                    bottom: true,
                    child: Stack(children: <Widget>[
                      _pageView(),
                      _snackBarFilter(context),
                      _loadingFilter(context),
                      _orderFilter(context),
                      _searchTermFilters(context),
                    ]),
                  ),
                )

                //Scaffold(body: AccountOverviewPage())))),
                // Expanded(
                //     child: SearchTermsPage(
                //         state.searchTerms,
                //         state.currentCustomer.id,
                //         state.currentManager.id)))
                // CustomersList(),
              ],
            ),
          ),
        ),
      ),
    );
    /*body: StoreConnector<AppState, _ViewModel>(
        converter: (Store<AppState> store) => _ViewModel.create(store),
        builder: (BuildContext context, _ViewModel viewModel) => 
          Center(
            // Gesture Detector to listen for taps outside of the screen.
            child: GestureDetector(
              onTap: () {
                print('Tapped outside of screen');
                FocusScopeNode currentFocus = FocusScope.of(context);
                if(!currentFocus.hasPrimaryFocus){
                  currentFocus.unfocus();
                }
              },
              child: Customers(),
            )
          )*/
    // body: Center(
    //   child: Column(
    //     mainAxisAlignment: MainAxisAlignment.center,
    //     children: <Widget>[
    // Text(
    //   'You have pushed the button this many times:',
    // ),
    // Text(
    //   '$_counter',
    //   style: Theme.of(context).textTheme.headline4,
    // ),
    // Accounts(),
    // ],
    // ),
    // ),
    // floatingActionButton: FloatingActionButton(
    //   onPressed: _incrementCounter,
    //   tooltip: 'Increment',
    //   child: Icon(Icons.add),
    // ),
  }
}

/*
class _ViewModel {
  final List<Item> items;
  final Function(String) onAddItem;
  final Function(Item) onRemoveItem;
  final Function() onRemoveItems;

  _ViewModel({
    this.items,
    this.onAddItem,
    this.onRemoveItem,
    this.onRemoveItems
  });

  factory _ViewModel.create(Store<AppState> store) {
    _onAddItem(String body){
      store.dispatch(AddItemAction(body));
    }
    _onRemoveItem(Item item){
      store.dispatch(RemoveItemAction(item));
    }
    _onRemoveItems() {
      store.dispatch(RemoveItemsAction());
    }

    return _ViewModel(
      items: store.state.items,
      onAddItem: _onAddItem,
      onRemoveItem: _onRemoveItem,
      onRemoveItems: _onRemoveItems,
    );  
  }
}
*/
