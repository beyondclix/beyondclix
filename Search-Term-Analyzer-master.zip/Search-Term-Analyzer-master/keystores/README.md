Upload-keystore
/junkagaya/keystores/search-terms-analzyer-upload-keystore.jks

keystore password = unl1m1t3d
key password = P@ssw0rd0

This is defined in /android/key.properties