package webbi.ads.searchtermanalyzer

import android.animation.ObjectAnimator
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.animation.AnticipateInterpolator
import androidx.core.view.WindowCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.android.SplashScreen

// https://developer.android.com/guide/topics/ui/splash-screen/migrate

class MainActivity : FlutterActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Aligns the Flutter view vertically with the window.
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false)

//    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      // Disable the Android splash screen fade out animation to avoid
      // a flicker before the similar frame is drawn in Flutter.
//        var splashScreen = Activity.getSplashScreen()
//  var splashScreen =
//      splashScreen.setOnExitAnimationListener { splashScreenView: SplashScreen -> //splashScreenView.remove() }
        // Create your custom animation.
//        val slideUp = ObjectAnimator.ofFloat(
//                splashScreenView,
//                View.TRANSLATION_Y,
//                0f,
//                -splashScreenView.height.toFloat()
//        )
//        slideUp.interpolator = AnticipateInterpolator()
//        slideUp.duration = 200L
//
//        // Call SplashScreenView.remove at the end of your custom animation.
//        slideUp.doOnEnd { splashScreenView.remove() }

        // Run your animation.
//        slideUp.start()
//        splashScreenView.remove()
//      }
//    }

    super.onCreate(savedInstanceState)
  }
}
