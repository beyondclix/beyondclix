export const ANDROID_PACKAGE_ID = "webbi.ads.searchtermanalyzer";
export const CLOUD_REGION = "australia-southeast1";
export const GOOGLE_PLAY_PUBSUB_BILLING_TOPIC = "play_billing";
