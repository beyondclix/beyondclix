export interface ProductData {
    productId: string;
    type: "SUBSCRIPTION" | "NON_SUBSCRIPTION";
  }

export const productDataMap: { [productId: string]: ProductData } = {
    "save": {
      productId: "save",
      type: "NON_SUBSCRIPTION",
    },
    "monthly_subscription": {
      productId: "monthly_subscription",
      type: "SUBSCRIPTION"
    },
    "lifetime_membership": {
      productId: "lifetime_membership",
      type: "NON_SUBSCRIPTION",
    },
};