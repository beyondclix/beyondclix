import {ProductData} from "./products";

export abstract class PurchaseHandler {
  async verifyPurchase(
      userId: string,
      productData: ProductData,
      token: string, // .verficationData
  ): Promise<boolean> {
    switch (productData.type) {
      case "SUBSCRIPTION":
        return this.handleSubscription(userId, productData, token);
      case "NON_SUBSCRIPTION":
        return this.handleNonSubscription(userId, productData, token);
      default:
        return false;
    }
  }

  abstract cancelSubscription(
    productId: string,
    token: string,
  ): Promise<boolean>;

  abstract consumeSingleSave(
    iapSource: string,
    orderId: string,
  ): Promise<boolean>;

  abstract handleNonSubscription(
      userId: string,
      productData: ProductData,
      token: string,
  ): Promise<boolean>;

  abstract handleSubscription(
      userId: string,
      productData: ProductData,
      token: string,
  ): Promise<boolean>;
}