// import {PurchaseHandler} from "./purchase-handler";
// import {IapRepository} from "./iap.repository";
// import {ProductData} from "./products";

// export class AppStorePurchaseHandler extends PurchaseHandler {
//     constructor(private iapRepository: IapRepository) {
//         super();
//     }

//     async handleNonSubscription(
//         userId: string | null,
//         productData: ProductData,
//         token: string,
//     ): Promise<boolean> {
//         return true;
//     }

//     async handleSubscription(
//         userId: string | null,
//         productData: ProductData,
//         token: string,
//     ): Promise<boolean> {
//         return true;
//     }
// }
