Follow this:

https://codelabs.developers.google.com/codelabs/flutter-in-app-purchases#9