## TODO:
- Send Google an email to remove the customer account level information, display it somewhere else if necessary.

- Transfer Firebase Functions billing account to Samar. (Screen call)
- https://services.google.com/fb/forms/toolchanges/

- DONE - Link Search Terms Manager Google Ads account to Firebase/Google analytics.
- DONE - Test and track events in Firebase
- MAYBE - Fix white screen of death.


1. Send an email with text
2. Get a link to a website with that text.
3. Tinder-style yes/no swipe.

### MUST DO:
- DONE - Add facebook_app_id to android/strings.xml, and ios/Info.plist
- DONE - To run Facebook Ads for App Installs, we need to install their SDK 
https://developers.facebook.com/docs/app-events/getting-started-app-events-android
- DONE - Promo codes functionality (Payments server & app update)
- DONE - Facebook Ads SDK integration (I have accepted and joined the business account)
- DONE - Test out-of-app purchases (Redeeming promo codes outside of app and make sure the app processes them.)
https://developer.android.com/google/play/billing/integrate#ooap
- DONE - Firebase push notifications.
- DONE - Run Google Play Services.
- DONE - First opening app on 'Today' shows load spinner forever and loading toast. Happens after the first time opening, only for TODAY.

- DONE - Faster loading of customers. (HUGE improvement, from linear time to constant time.)
- DONE - Display circularprogressIndicator when loading any customers at all.
- DONE - Display pull down to refresh of accounts at all times. (At bottom of list)
- DONE - Hide welcome screen signin button as soon as it is pressed. Make it show again only if authentication failed.
- DONE - This account is not linked to Google Ads, you need to use a Google Ads account.
- CANCELLED - Save/Send all errors to DB or email. (Firebase crashlytics) Attached crashlytics UNTESTED
- WORKS WITH MONTHLY Show an in-app popup that a purchase was successful. (showQuickPopup, monthly user/lifetime user)
https://play.google.com/redeem?code=promo_code
- TEST Uri schemes don't work with mailto:/tel: links in emulators. Check on real phone.
- DONE - Fallback https URL for mailto:
- DONE - a UI button that would have sent feedback email using a mailto URL might instead open a web-based feedback form using an https URL on failure, rather than disabling the button if canLaunchUrl returns false for mailto.
- DONE - Initial screen NEXT button not working, navigator context fails.
- DONE - load all customer accounts at once, quickly.
- DONE - Check if campaigns are showing when searching for accounts/client accounts.
- DONE - Add customers loading text earlier.
- DONE - Separate the welcome screen and the button.
- DONE - Display 'No Google Ad account associated with this email' and go back to sign in button.
- DONE I THINK - Next button out of screen
- DONE - After cancelling logging in, it shows the welcome screen and nothing else, the welcome screen doesn't fade away. (Because account didn't change)
- DONE - adding duplication to current index rather than end of list, 
- DONE - adding added/excluded display and filter, 
- DONE - fixing timezone bug for custom date, (Took two hours to find...)
- DONE - fixing editing of duplicated issues, 
- CANT REPRODUCE - fixing negative keyword search term display issue, 
- CANT REPRODUCE - fixing negative keyword list cancel issue
- DONE - 'My feedback' => 'Give Feedback'
- DONE - Move the secure sign in into vertical center.
- DONE - When don't sign in and click back, it is empty.
- DONE - I need the Added/Excluded columns to be added. 
- DONE - Lifetime purchase not working.
- DONE - FWD: Action Required: Resolve the issue with your app by May 08, 2022 (Search Terms Manager)
- DONE - We need to add a welcome message like this to the app for first 3 loads before the user can start using the app.
- DONE - We need to add "Secured by..." or some security information below the "Sign In to your Google Ads account" button to increase trust in the login.
- DONE - Metrics for customer load time
- DONE - The search terms attributes for "Added / Excluded / None" needs to be added to columns and to filters. 
- DONE - Duplicate operation should add the duplicate right after keyword, not to the end of the screen.  


- NOTE - If they redeem through play store, it will only redeem to the play store account, not the google account they want in the app.

- Make sure 'today' matches today, and what is blanked out actually works.
- DONE - Refresh drag down doesn't update the data.
- CAN'T TELL, LINK DOESN'T WORK - What's happening here? https://app.smartlook.com/org/5ab60330673eece5048b4621/project/b8648e01cd1a075fb68c1806/recordings?filter=e9c588c80e243456007b3d6102a84877f19c2734e8addd538cba3cc8c466613a&player=1&session=mSGUpRfo4JAiSWucMw22W&visitor=jyU7bnzOTkE28QGE7cB57
- 'No Accounts Loaded' grey rectangle covering most of the page instead of where the button is.
- Initial_screen => 'Today' loads forever.
- DONE - Add 'Give Feedback' to settings sidebar.
- SHOULD BE COVERED BY EXISTING CODEBASE - Android notification channels to be able to see them:
https://pub.dev/packages/flutter_notification_channel
FlutterLocalNotificationsPlugin()

Ask to test notifications, and only integrate this further if it fails.
- DONE - Added/Excluded should show text instead of numbers. None is displaying 0 instead of 'None'
- DONE - Added/Excluded filter view, then upload the keyword, and drag down to refresh, but it still keeps on showing. (Caching issue, drag down refresh just loading from cache)
- DONE - Need the duplicate keyword button to duplicate the keyword right after the current row, not at the end.
- Make sure that data for 'today', or any date matches what is in Google Ads UI.
- Sign in buttons not showing.
- Android 9, first screen buttons not showing at the bottom.
- Check screen recordings:
https://mail.google.com/mail/u/0/#inbox/FMfcgzGpFzwLkXLTWmJBpCNGQqgPJkMV
https://mail.google.com/mail/u/0/#inbox/FMfcgzGpFzxTcpcHtgLhgxrVPsXgNxNs
- Force external links to open in the phone's default browser? 
- Deal Hatke loading forever on real device until order change is triggered.
- Ask before saving the same keyword twice.
- Pressing purchase button doesn't work.
- Unable to delete duplicated keywords without a restart.
- Purchase popup still shows after purchasing.
- Problem with the listing of accounts
- I needed the duplicate keyword button to duplicate the keyword right after the current row, not at the end. This hasn't been done. 
- There is some problem with the listing of accounts.
- Show an error message if a user tries to login with an account that doesn't have a Google Ads account associated with it. I tried and I got an account list screen with "no accounts". Instead we need to check if there are no accounts and return a message and then return to login.
- Expired monthly subscription still shows that I have purchased.
- Testing of promo code input scenarios as per Google's suggestions (https://developer.android.com/google/play/billing/test#promo)
- Test out lifetime purchases via promo codes (Test from my other accounts)
When signed in as a licensed tester, 'redeem code' payments option doesn't show, so have to sign in as another account.
!!!! - Possible bug. Save to Google did not work when I selected Lifetime plan.
- Monthly subscription downgrade/redemption is not triggered.
- Able to purchase monthly, even though already in monthly.
- After a search term is selected as keyword, let user select same again as keyword or negative. There may be use cases where that is required. 
- Need to be able to add the keyword to other location (other campaign or ad group) 
- Need to be able to reorder the metrics columns
- Notification for 'You have unsaved search terms. Only if you have unsaved search terms, not if you don't have them.
- Debug build can't purchase with test accounts. 
Deploy a new version and test using promo codes on it.
- Add app-ads.txt to root of BeyondClix.com for Facebook verification.
- Deploy to Samsung Galaxy Store
https://developer.samsung.com/galaxy-store
- DONE - DealHatke taking more than 10 seconds to load. (It's jsut slow)
- https://app.smartlook.com/org/9b625c195a487e0d42e2a52e/project/0488d43b4df286c25a004ce1/recordings?filter=e9c588c80e243456007b3d6102a84877f19c2734e8addd538cba3cc8c466613a&playSession=P5qBoWCOCNBwHaglrSOKa&playVisitor=Kl9aIu_VwsX54ObZbuud_

- When no matching results for the entered keyword, display message for this. "No search results"
- Campaigns showing up in account search?
- Test splash screen
https://developer.android.com/guide/topics/resources/drawable-resource#LayerList
- Pull down to refresh for 'No Google Accounts To Display' text

### Notify
- Monthly is 90days free trial, 3 months instead of 6 months.

### iOS 

https://pub.dev/packages/url_launcher

Facebook SDK
https://pub.dev/packages/facebook_app_events

Firebase Cloud Messaging.
https://firebase.google.com/docs/cloud-messaging/flutter/client

Signing key base64:
BdbZgVJ5EFEgtcQe4plSRZ9qQEo=

Upload key base64:
kVxhAccgh3JbUp0bd8NGjaCPNus=

### Analytics:

Google Analytics:
https://analytics.google.com/analytics/web/?authuser=0&hl=en#/p263679341/reports/intelligenthome

Firebase Console:
https://console.firebase.google.com/u/0/project/searchtermsanalyzer-2baca/analytics/app/android:webbi.ads.searchtermanalyzer/events/~2Foverview%3Ft%3D1649723996978&fpn%3D800291765673&swu%3D1&sgu%3D1&sus%3Dupgraded&cs%3Dapp.m.events.overview&g%3D1

Smartlook:
https://app.smartlook.com/org/9b625c195a487e0d42e2a52e/project/0488d43b4df286c25a004ce1/recordings

Google Ads:
https://ads.google.com/aw/campaigns?ocid=854473166&euid=250317497&__u=7670139953&uscid=854473166&__c=4055347934&authuser=0&workspaceId=0

### HAVEN'T TESTED
- Save keywords in both Basic Browns and Deal Hatke at the same time.
- Displayed campaigns are incorrect after changing accounts. (Takes a while to reload but looks okay.)
- Test FinalURL 
- Test MaxCPC
- Test Negative Keyword To List saving across accounts.
- Save 20 keywords at once.
- Testing monthly integration
Renewals, cancellations, promo codes, etc.
https://developer.android.com/google/play/billing/test

- (If possible) Smarter loading system, only reloading data from the new dates.

### Later:
- Firebase in-app messaging dialogues.  
- 'Couldn't find any adgroups for your account'
- Search bar for adGroups.
- Search bar for campaigns.
- DONE - Wrap overflowing text.
- Signing out from client account screen shows no accounts listed, doesn't automatically go back to parent screen.
- Force a display call after every load (with new loading system, this is feasible)
- changing halfway through loading triggers PROCESS INTERRUPTED, which hides the 'loading in background message', but new loading starts on the next account.
- COULDN'T REPRODUCE, POSSIBLY SOLVED - After removing filters, loading spinner spins forever. (When no results)
- COULDN'T REPRODUCE, POSSIBLY SOLVED - Change ordering, and loading spinner spins forever.
- COULDN'T REPRODUCE, POSSIBLY SOLVED - campaignId / adGroupId still exist even though the filters have been cleared.
- 0.745 rounds to 0.74 instead of 0.75 when using .toStringAsFixed(2)
- Tree structure accounts.
(Requires looking at Samar's account data directly, investigating customer_client_link resource)
https://developers.google.com/google-ads/api/docs/account-management/get-account-hierarchy
customer_client.level
- DONE - Set DB version to 2 for deployment.
- Issue migrating between API calls. When swapping and an account is still loading, loading toast doesn't show.
- DONE - Update currentCustomer and currentManager separately without waiting for async getAllAdGroups() call. (Solved and stopped the blocking)
- Choosing customerClient briefly goes back to customer screen.
- CustomerClient account should list the number of unsaved search terms in it.
- Faster initial signin loading of accounts (remove 'await' calls.)
- Faster date queries, when changing dates only load in data from the different dates.
- Load from AdGroupToLoad by query date.
- Click on filter to edit it.
- New adgroups won't be loaded in after account is set. But they will still be loaded per adgroup query, so search terms should still reload fi that adgroup is selected.
- Add NegativeKeywordList to campaign checkbox.
api.dart => attachNegativeKeywordListToCampaign()
- Interrupt loading process for customers if user changes them in between.
When PROCESS INTERRUPTED for customer, cancel loading in background.
1. Go to loaded account
2. Go to not loaded account.
3. Navigate back to loaded account after loading bar shows.
- Delete & recreate tables if their columns have changed. (When table structure is changed for a new update.)
- Test saving keywords after changing accounts.
- Test that only searchterms that have been created for the account were saved.
- Changing accounts multiple times doesn't show the loading numbers.
- After selecting account, jumps back to customer_list_page.dart briefly before loading everything.
- WARNING: Play Store: "This App Bundle contains native code, and you've not uploaded debug symbols. We recommend that you upload a symbol file to make your crashes and ANRs easier to analyse and debug."
- Select multiple adgroups/campaigns/negative keyword lists
- If there is no negative keyword list, and no new one, disable pressing 'done'. 'A negative keyword list with this name already exists'
- "No [negative] Keywords created." - In changes_page.dart when one tab doesn't show.
- PARTIALLY - Only load new data when the queried date is more recent than the current one.
This only loads data for the new date and inserts it into the local DB.
- Deliver keystore with end product so that it can be rebuilt/redeployed. (Add keystore to repo)
- Make sure display works on real phone.
https://stackoverflow.com/questions/51607440/horizontally-scrollable-cards-with-snap-effect-in-flutter
https://flutter.dev/docs/cookbook/effects/photo-filter-carousel
- Add analytics to every button.
- Test Display on different phones.
- Done button, always visible.
- defaultTargetPlatform == TargetPlatform.iOS
    ? const CupertinoActivityIndicator()
    : const CircularProgressIndicator(
        strokeWidth: 2.0),

### BUGS:

https://groups.google.com/g/google-ads-for-mobile/c/AQfAWJmBaYQ

- List of accounts in Samar's MCC are not the same as in web view.
(Need to access account to check what the differences are.)

- Login to "samar.slamstrategy@gmail.com" and check the accounts that are displayed are the same. (Need two-factor authentication)

- Only upload the SearchTermSaveActions for the current account, not for the others.

- "The main MCC in this other google account has two sub-MCCs. When I click on the SLAM PPC Team Leader MCC, I should see two Sub-MCCs but instead I see all the ad accounts under it."
Q: What is this supposed to look like?

MCC = My Client Center

Sub - MCC's

Accounts that are no longer part of MCC.
Tree structure.

- samar@beyondclix.com accounts Customer client accounts displayed are different from what they should be.
1. Login to samar.slamstrategy@gmail.com to reproduce.


## DONE:
- DONE - Resuming loading doubles up API call. (On first load, and after changing accounts)
- DISCARDED - Basic browns can't paginate. (While loading)
- DONE - Real device, Rainbow reading paginating too frequently. (May be related to some open space at the top) (Solved by extending debounce)
- DONE - Real device only All Time is reloading each time. (Some of the metrics with apostrophes weren't working, so cancel reloading, and handle apostrophes.)
- DONE - Real device, empty space underneath orderBy display. (disable top of SafeArea in SearchTermsPage)
- DONE - Test changing accounts then check if search terms have been cached, cache is not rest, etc.
- DONE - Test possible metrics memory leak, with old entries not being deleted.
- DONE - Test possible searchterms memory leak, with old entries not being deleted.
- DONE - Campaigns/adgroups taking a long time to load. (WHen customer not enabled, no campaign shows.)
- DONE - RESUMING INITIAL runs without access Token. This should only trigger after auth success.
- DONE - Add analytics events for all onTap:() {} / Navigator.pop() / relevant actions.
- DONE - Screen navigations
- DONE - Fix map to replace all spaces with underscores.
- DONE - Settings text looks wrong.
- DONE - In App Purchases not accessible (Because first time using phone and google play store wasn't signed in)
- DONE - Campaigns from another account are showing if they have already loaded?
- DONE - Metrics not loading for Derringers, all 0.
- DONE - Rainbow Reading 'rainbow reading' metric for absolute top impressions is 100%, but in Ads UI it is 97.78%
- DISCARDED - All search term queries to use filters and ordering as well. (Might speed up results)
- DONE - Make first page just 50 results, then load 1000 at a time afterwards.
- DONE - Yesterday data doesn't show on first/second load/without reordering?
- DONE - Rainbow Reading (Last 30 days) sometimes doesn't load.
- DONE - Rainbow Reading (Last 30 days) -> Absolute Top Impressions Percentage < 100% + order by absolute top impressions DESCENDING
- DONE - [Campaign Name does not contain "Search"] and it did not work. 
- DONE - Adgroup name filter also not working.
- DONE - Tested Filter > Attributes > Campaign (campaign list not loading for a long time). It later loaded when I clicked on Adgroup instead. Started working after that. Maybe you need to add "Loading in background" message here also. Alternatively why not pre-load this when you are loading search terms. PRELOAD CAMPAIGNS in background.
- DONE - AdGroup selection page scrolls back to top each time when more are loaded.
- DONE - Check Avg. CPC. It is probably showing the data in millions (maybe we have to divide by 1 million to get the right figure?). 
- DONE - Check Impression Top and Abs. Impr. Top filters. The filter number and the %age in the data are not compatible. Filter for %age figures needs to be %age. Filter for currency needs to be currency. And so on.
- DONE - Test cost figures filtering and ordering.
- DONE - Editing filters doesn't revertMetric
- DONE - Remove customer metrics data.
- DONE - Currency metrics need the currency symbol next to the metric.
- DONE - Caching of queried metric data.
- DONE - Search term Match type is null.
- DONE - Caching to use last queried date on both upper and lower, if this is different (queried from a new date), then delete all local data with this queryId and update the caching entry.
- DONE - Blank ID should be constructed per query.
- DONE - Remove customer/customerClient level stats.
- NO WIFI network image. Please connect to the internet.
- DONE - Does the google ads app work offline? Use caching.
- DONE - Metrics is specific to date range.
They are calculated. But since there is so much data, they have to be pulled from the API every time.

Option 1:
Store metrics per every single day and pull them locally each time. (Calculate locally)
Option 2:
Pull from API every single query and use those values. (Reload each time)
- DONE - Handle loading local percentage-based data.
- DONE - Edit filters by clicking on them.
- DONE - Change "Near Exact" and "Near Phrase" to "Exact match (close variant)" and "Phrase match (close variant)".
- DONE - Use Metric display names for filters and ordering.
- DONE - Edit ORDER BY by clicking on them.
- DONE - Add something to make it obvious that the user needs to tap on the card. And add a small "Close" button to the Pro membership cards. CLICK ME / X
- DONE - View-through conversion not showing, probably needs safe area. (Wrap the whole area in safe-area)
- DONE - Fix timezones for custom. getUpperLowerDates needs to create epoch time relative to location.
- DONE - Q: Why did YESTERDAY load immediately after TODAY?
A: If the timezone is set to India, perhaps some data overlaps the two days, so partial data will be returned.
If this is the case, this can be solved by using local timezones (the same timezones as Google Ads API) for all time-related queries.
- DONE - Use local timezone to create all local epochDateTimes and for custom date ranges in API. Display/Load date data correctly as per timezone.
- DONE - Add unsaved accounts to each client account.
- DONE - Show number of unsaved under search screen as well.
- DONE - Added another way of loading and saving data.
- DONE - Campaign scrolling resets.
- DONE - Selecting a campaign -> NoSuchMethodError: The getter 'iterator' was called on
null.
- DONE - getAllAdGroups not loading all adGroups.
- DONE - Deal Hatke reloads.
Happens when interrupting loading of an account.
- DONE - YESTERDAY = 07 - 07, not 06 - 08.
- DONE - TODAY and YESTERDAY are showing the same data.
- DONE - IAP Products not loading - test on real phone.
Might not work because version code, or because running .apk directly outside of google play store.
ISSUE was when switching accounts, products were removed.
- MAYBE - Request Samar to test directly from the internal testing link, because running the API directly could stop billing from being available.
- DONE - 'Loading search terms' bar not showing at the bottom on Samar's phone
MAYBE FIXED by adding safe area, if this doesn't work, just display at top.
- DONE - Apply for Standard Access.
- DONE - TODAY doesn't work.
- DONE - 'Yesterday' and then spins forever
- DONE - Today, first load in and it says 'no search terms'
- DONE - Add campaign name to changes_page.dart
- DONE - Lifetime option in Single save paywall.
- DONE - Introductory offer under monthly single save paywall. (Inside the button)
- DONE - Columns Grouped in UI the same way orders and filters are.
- DONE - Latest date loaded for display.
- DONE - Last 7 days (5th March - other date)
- DONE - "Drag down to update search terms" and force loading from API.
- DONE - Memory size decreases when loading more search terms. It seems like there are many duplicates. (Solved by loading per adGroupId)
- DONE - No products are showing up.
Internet issue?
- DONE - Monthly renews / 5 min.
Because it is a test card linked to the payments email address (not the signed in email address)
- Q: Why does monthly renewal cancel by default? 
A: Test subscriptions cancel after renewing five times.
- DONE - dialog "Are you sure you want to delete this Search Term?"
- DONE - Paginated data doesn't show 'loading more'
- DONE - Halfway through loading API, shows 'No search terms' before showing the search terms again.
- DONE - updateVisibleSearchTerms is not called until all API requests are finished.
(Issue was it was calling the wrong customerId)
- DONE - Reloads samar.slamstrategy@gmail.com customers from API every time.
- DONE - Reload all customers, every time if pulled down.
- DONE - Load into new gmail account, then choose order by performance => 'clicks', and 'no such column' error
- DONE - Briefly shows 'no search terms' while loading new accounts.
- DONE - samarslam -> test loading on all accounts.
- AllPhoneLeads 
sort by performance clicks, endless spinning wheel.
- DONE - Sorting & Filters
- DONE - Test all the sorts and filters one by one.
- DONE - Paginated data from API is not being saved, or loaded in.
- MAYBE FIXED - Settings in drawer doesn't completely show the text. Force this to show.
https://codelabs.developers.google.com/codelabs/flutter-in-app-purchases#8

https://pub.dev/packages/in_app_purchase#upgrading-or-downgrading-an-existing-in-app-subscription


AppState resetChanges(AppState appState, ResetChangesAction action) {

- DONE - Additional pages loading, but no loading bar showing.
- DONE - 'No search terms' is displayed briefly before data is presented.
- DONE - Test save keywords after changing accounts and changing back.
- DONE - NegativeKeywordList exclusion with RainbowReading. (no customerClientId);
- DONE - Test saving keywords after changing manager/customer accounts.
- DONE - AdGroups are not displaying from the correct account.
- DONE - Have many keywords to save across many accounts.
- DONE - Number of changes to save are incorrect and picking up from wrong place.
- DONE - Negative keyword list error display fails, then doesn't display single_save unless reopened.
changes_page.dart => line 165 
SOLVED BY MOVING INTO build sequence to force rebuild when store updates.
- DONE - Quota for loading customers runs out, so never delte customer information, but store it in DB linked to email address. Then, never have to reload accounts.
- DONE - searchterms are duplicated.
Solved by creating a primary key unique to search term text + adGroup.
- DONE - Customers are saved in DB so don't need ot reload them each time.
- DONE - 'No search terms' when opening app.
- DONE - 'No search terms' when loading.
- DONE - Coming back to account after it has stopped once and it doesn't resume loading searchterms.- DONE - Number of inserted rows is different to number of loaded rows. (Always use rowCount)
Need to save all results under new primary key, and see what the difference is. Maybe they are different scope, campaign/adgroup/searchterm 
scopes?
SOLUTION: Change SEARCHTERMS primaryKey to a unique id.
- SEEMS TO BE FIXED - DealHatke is loading with 'No search terms' and long grey line on first load after API data.
- DONE - Filtering by campaign.
- DONE - Columns to display not updating.
- DONE - Handle CUSTOMER_NOT_ENABLED
- DONE - background loading without updating search terms.
- DONE - Not resuming loading.
- DONE - Basicbrowns is empty.
- DONE - Previous data is being shown without updating the list. (Testing out clearing all data beforehand)
- DONE - Remove empties when reloading an account. (by date only)
- DONE - Srikrish online all time is blank 'no search terms'.
- DONE - Fix Campaign/Adgroup orderBy & filters.
- DONE - saving to campaign level.
- DONE - Catch special string errors.
- DONE - Test monthly expires after the given date.
- DONE - 
1. AdGroup list needs to display the current campaign this is filtered on.
2. User can select the campaign to push the campaign list screen, and select one and update the new selection and pop. Then the available adgroups are updated.
3. Paginated list of campaigns and adgroups. When there are too many, app lags.
4. Adgroups loading from API every time.
5. campaign/adGroup filter displayName
- DONE - Insert Blank doesn't insert the campaign id.
- DONE - Update visible search terms query is being made 3 times
- DONE - If already ASC in order, update state.
- DONE - Resetting orderBy leaves empty space on main page.
- DONE - Remove duplicate campaign/adgroups filters.
- DONE - Test copyDown/copyUp/duplicate.
- DONE - Test editing keywords.
- DONE - Add keyword with new negative keyword list, then close it, and reopen, throws error.
- DONE - Edit new negative keyword list name.
SOlved by dynamically creating each time.
- DONE - Create more than X number of negative keyword lists and handle the error.
- DONE - Saving to new negative keyword list in a separate save again.
- DONE - negative keyword list to save after closing and reopening app.
- DONE - Only load the relevant shared_sets.
- DONE - Don't load removed shared_sets (negative keyword lists)
- DONE - negativeKeywordList to save needs to be removed per customerId, and created per customerId.
- DONE - Negative keyword List, currently only saving as 'Owner by manager account.'
- DONE - Save to a new negative keyword list across different keywords. (Save the first and continue the next)
- DONE - Filter by campaign & adGroup metrics.
- DONE - After user has been online for more than 30 minutes, make them sign in again.
(Solved with periodical checker)
- DONE - Handle errors for: addToNegativeKeywordList();
- DONE - DB versioning.
- DONE - remove match type UNKNOWN, UNSPECIFIED
- DONE - Test cancelling monthly subscription. Pub/sub event should be sent upon modification & DB status should be modified to EXPIRE.
- DONE - Duplicate searchterms is broken.
- DONE - Don't consume consumable if there were errors while saving, reload it immediately.
- NOT AN ISSUE - Listen to purchases after changing accounts, check that they update.
- DONE - Warning/Red error on searchterm when it's too long.
- DONE - Welcome/Login screen (inanimate)
https://docs.flutter.dev/development/ui/advanced/splash-screen
- DONE - Metrics are not showing on first load.
- DONE - Changing customers and clients doesn't resume loading on the new customer.

because of noAPI flag which is true when changing customer/customerClient.

SearchTerms are loading from API only after reopening the app.

SearchTerms in API are not loading after choosing a separate account in search.
Account/client account name are blank, but data is being loaded in.
- DONE - BasicBrowns API loads but doesn't increase number of rows, search terms are the same.
- DONE - Pull down to reload searchterms.
- DONE - After changing google account, Initial loading of Customer Clients broken, and loading restarts again 
- DONE - While loading data from API, customer/client accounts are not displayed, displayed as defaults. Happens only when 'No search terms' is displayed. (Had to remove 'await' clarifier from fetchInitialStateAction, which was waiting for all searchTerms to finish loading.)
- DONE - Only save/load search terms from current account.
- DONE - Prettier products 
- DONE - Prettier sliding drawer from side.
- DONE - Test Introductory Pricing with a new SKU. (Might only work first time)
- DONE - Update user based on what they have purchased.
- DONE - Purchasing loading bar.
- DONE - Cancel monthly subscription if lifetime purchase was acquired. (Either do this serverside (requires purchase token), or clientside (requires verificationData))

--------------------------------
buyConsumable has a named parameter autoConsume that is true by default. If you set this parameter to false, you'll have to call iapConnection.getPlatformAddition<InAppPurchaseAndroidPlatformAddition>().consumePurchase(purchaseDetails) after you consume the purchase on Android.
------------------------------------
- Youtube video of the whole app and process.
- DONE - Order 'Apply' changes button
- DONE - Saving/Loading SearchTermsToSave across different accounts.
- DONE - Pull down to refresh search terms.
- DONE - Only consume consumable if the search terms were saved without error. (Requires payment server)
- DONE - ERROR: KEYWORD_HAS_TOO_MANY_WORDS
- DONE - ERROR: Keyword too long.
- DONE - PurchaseProductsPage, add "Or, pay as you go for $1.99" etc.
- DONE - Change the text on the premium button if currently a member.
- DONE - Faster loading of all data.
- Analytics for each button.
- DONE - Introductory price
- DONE - Displaying customer accounts when multiple accounts have their own searchterms to save.
- DONE - Filter by campaign/adgroup (load campaignsOverviewPage.dart and show the list of campaigns, then return id) Filter by Campaign's Max CPC, etc. Need to load campaign and metric data, as already done, and filter by these.
- DONE - Test different payment responses.
- DONE - Metrics not loading on initial load. (Store not recognizing metrics changing)
- DONE - Interrupted load process needs to resume.
- DONE - Be able to process data while loading data in the background.
- DONE - Persistent filters across restarts (save to DB)
- DONE - Persistent orderBy across restarts (save to DB)
- DONE - submit button and payment, after error handling and fixing errors.
- undo change/next change.
- save filters option.
performance
attributes
conversions
- Test reloading after changing to a different account.
- Multiple searchTerms that are different
e.g. Multiple matchtypes per search_term. Partitioned by segments.keyword.info.match_type
- Selecting date: 'All Time' Warning: This will save a lot of data to your device, continue?
- DONE - order, up/down arrow icon. order by metric. 
order by search term, order by campaign, order by adgroup.
- DONE - Persist un-uploaded changes, only show changes specific to account as well.
- DONE - Pull down to refresh & reload accounts.
- DONE - Move Done button to the bottom of the dialog, in a seprate row of its own.
- Google Ads app for metrics. Select as default.
- TESTING - Make filters work by comparing to real data and seeing which search terms show.
- Test different dates and corroborate data with ads dashboard.
- DONE - Error trying to edit duplicates, it edits the original instead. (modifyIndex in reducer gets the wrong index, for some reason the id never changes, but is saved correctly in the DB)
Solved with reference error, by recreating new reference.
- DONE - Use a Drawer to show settings for how long to hold data for before deleting it and logout user.- Pull down to re-query/refresh this again. ( Or use a drawer with option to reload data)
- DONE- Search terms are not customer specific.
A new column needs to be added in SEARCHTERMS table and queried as an additional constraint.
- DONE - Trigger store.dispatch((x) => fetchLocalDataAction(store));
in the correct places. Currently, it's not triggered when customer or customerClient changes, but is triggered when date changes.
Needs to cancel the already loading action if this is the case.
- DONE - MCC Customer is going straight to dates.
- DONE - NOT LIKE SearchTerm.Text is broken.
- DONE - Hide CustomerClientBar when there is no customer client.
- DONE - Search terms spinner not stopping loading.
- DONE - Check what is displayed on "Rainbow Reading - BC". is the same as on web.
This has no client account. Need to handle loading and displaying all of the data.
- DONE - Refresh clients and all loading with a pull down to refresh.
- DONE - Scrollable Customer Clients.
- DONE - "Search Terms Analyzer" -> "Search Terms Manager"
- DONE - If no customer is selected, endless spinner on subsequent restarts.
- DONE - Load purchased products via firestore/firebase functions server.
- DONE - Link service account to Play store.
- DONE - Transfer firebase project to Samar.
https://stackoverflow.com/questions/24688716/transferring-an-app-to-another-firebase-account
- DONE - API Access for the play store app. Link to firebase project. (Setup > API Access)
https://stackoverflow.com/questions/65191149/what-permissions-do-i-need-to-access-api-access-in-google-play-console
- DONE - Make keyword dialog prettier 
- DONE - If no search term results on main page, and data is still loading, periodically query it for more information.
- DONE - Loading bar is always showing.
- DONE (For small amount of data) Load campaigns, adgroups, and searchterms at once.
- DONE - (For small amount of data) If no campaign is selected, show all of the adgroups and searchterms.
- DONE - If no adgroup is selected, show all of the searchterms under this campaign.
Maybe - Disabling campaign means adgroup is also disabled.
- DONE - Double scrollbar bug.
- DONE - Persistent metric fields.
- DONE - scroll to index instantly.
Use controller.jumpTo(n);
- DONE - Metrics not loading after restarting app.
- DONE - Data management:
If searchterms is 0, add a <No data> entry to stop from reloading and handle on client.
Otherwise, load everything for all time at the start, and process data/dates offline clientside to remove strain on API.
(How big is this data?)
DONE - Searching for currently visible information
DONE - Only use enabled and paused campaigns + adgroups.
- DONE - Only use 
Search, Search Network, Standard Shopping
Can't exclude all display campaigns, instead focus on include for the above.
- DONE - implemented :searchStream - Load paginated data via nextPageToken/pageToken.
- DONE - - Keywords to save are not showing up / being saved in local DB.
- DONE - final url
- DONE - Max CPC.
- DONE - Search in list.
Do we need to search for all information
Should search act as a filter for each category instead? YES
- DONE - loading by date
1. Convert date query into upper and lower dates.
2. Filter local data by date range.
1. Delete all data when date is changed?
2. Load data from newer dates when date has changed?
- DONE - Filter on everything.
- DONE - Filter the list based on metrics/name.
- DONE - How filter button looks.
- DONE - 'cannot call .length of undefined' (after loading everything for first time) store.state.filterValues is null.
- DONE- use LIMIT / OFFSET for endless list implementation of large amounts of data.
- DONE - Dialog for loading data, showing how many rows loaded.
- DONE - Move filters to db query rather than in-memory query, 
SELECT * FROM SEARCHTERMS
INNER JOIN METRICS 
WHERE METRICS.NAME = ___
AND METRICS.TYPE = ___
- DONE - Dialog for orderBy
- DONE - Search terms select which column/metric to ORDER BY.
- DONE - Loading bar not showing.
- DONE - Revive Campaigns & Adgroups data storing, to be able to use filters on them.
- DONE - Filter by campaign name & adgroup name.
- DONE - lazy load of local data.
- DONE - ordering of columns by the visible groupings, performance/conversions etc.
- DONE - Small loading bar for currently importing data, number of rows imported.
- DONE - Endless list jump to index is not working, or has a delay. (SOlved after tampering with keys and rerendering.)
- DONE - - syntax error in "SELECT * FROM SEARCHTERMS WHERE LOWER(SEARCHTERMS.) LIKE '%price%' ORDER BY SEARCHTERMS."text" LIMIT 10"
- DONE - Endless list smooth scrolling.
- DISCARDED - Only paginate if more results are to be loaded. (DO a COUNT check after first page is loaded)
- DONE - Interrupting loading sequence will load wrong accounts. Need to change the accessToken, and customers from :listAccessibleCustomers
- DONE - Load account-specific searchTermSaveActions.
- DONE - Data is still loading in background even after changing accounts. (Need to be able to cancel this)
- DONE - Always loading new adgroups. adGroupToLoads.length
- DONE - Display in-app purchaseable products.
https://www.istockphoto.com/vector/black-right-arrows-set-flat-icon-isolated-on-white-continue-icon-gm1262598396-369442260

https://www.istockphoto.com/vector/three-black-arrows-arrows-icons-arrow-arrows-for-design-arrow-in-a-row-gm1139637682-304669558
- DONE - One arrow for monthly, two arrows for lifetime.
- DONE - Google Green theme color for all purchases related content.
- DONE - Search Terms Manager Pro (App name for premium button)
- DONE - Change 'ok' to 'apply' when adding filter.
- DONE - AppBar: Premium Features => Unlimited Uploads
- DISCARDED - Downgrade monthly subscription (Handled through UI)
- DONE - Icons for purchaseable products.
- DONE - TODO google play's setup for in-app purchases. 
- DISCARDED - Bottom menu and visible menu sometimes not in sync. (Removed bottom tabBar)
- DISCARDED - Hide bottom menu while loading (optional)
- DONE - Load paginated data from API.
- DONE - If no search terms, make it 0, instead of displaying current data. (DB_Insert empty row to let know that it's just empty.)
- DONE - Infinite Scrolling with search - https://pub.dev/packages/infinite_scroll_pagination(Handled by ListView.builder()) (Using endless list, flutter Listview.builder inherently provides list virtualization)
- DONE - Move from :search => :searchStream (paginated vs not-paginated)
- DISCARDED - View More button on stats with dropdown that shows the rest of the stats.
- DONE - Use the Google profile image instead of a blank user.
- DISCARDED - Use themed buttons.
- DONE - Display the size of the local data in memory in settings drawer.
- DONE - Only query campaigns that have not been removed.
- DISCARDED - Terms & Conditions
- DISCARDED - Route transition animations
- DISCARDED - Add arrows to each display. If the item is clicked, stop filtering here and show results. If the arrow is clicked, filter one layer deeper.
- DISCARDED - API Developer token.
- DISCARDED - First thing, use their own API token.
- DISCARDED - Move Search into DB search rather than in-memory search.
- DISCARDED - loading at bottom spinner for first load.
- DONE - Load all data at once, or at least in background.
- DONE - Show a loading bar for the data, and how many rows have been imported.
Show it right above bottom navigation bar.
When pressed, it displays a dialog with the loaded rows updating.
- DONE - When loading accounts for first time, show the number of customer accounts currently loading.
- DONE - Use better search handling. )Fixed with filter system)
- DONE - Loading data from custom date range throws error.
- DISCARDED - Dashboard for initial load in explaining what to do. (obvious)
- DONE - Remove all current data (truncate tables) and load all new data.
- DISCARDED - Snap Effect when scrolling stats. 
- DONE - List the number of un-uploaded changes in the list of client_accounts. (Needs a new column in searchTermActionsToSave Table.)
- DONE - Changing accounts while loading data needs to be handled. Need to check the adGroupId is the same.
- DONE - Free tier = "Pay as you go"
- DONE - Pro tier = "Pro user"
- DONE - Save to google ads only when upload.
Won't show to PRO users.
- DONE - Loading of data after closing and reopening app.
- DONE - Paywall to save keywords.
- DONE - Loading after closing app and interrupting loading.

### Virtual credits system?
Do people use CC each time they upload search terms? Or is there a virtual credit system?
(Display this in the drawer in the settings on top right.)



QUESTIONS:
- Search only works for currently visible data.Should it search ofr everything? YES
- Deal Hatke, is there a special way these adgroups work? Are they duplicated? Is there a way to mititage loading everything here? (By querying a parent?)  NO SHORTCUT
- Option to see the search terms at the ad group level, campaign level, or account level.


### How Final URL / Max CPC works:
Final URL , max CPC (OPTIONAL)

Final URL is showing after adding keyword, under Final URL.
"$1 projector DealHatke"

- Load AdGroups from the start, as soon as date is selected.

Keyword limit 80 chars, make it shorter.

Loading with number of things coming in.

Campaign has to be manual CPC to show Max CPC.


- Final URL
    - ad_group_criterion.final_urls - (The list of possible final URLs after all cross-domain redirects for the ad.)
    - Add final_url to existing API calls.
    - Add final URL to local DB and code.
    - Load final_url and display it.
    - Save & update final_url.
- Max CPC (linked to bidding)
    - Inherits from adgroup if not set.
    - If set, sets to keyword specific value.
    https://support.google.com/searchads/answer/6109225?hl=en&ref_topic=6109232#zippy=%2Csteps-for-navigating-to-an-engine-account

http://googleads.github.io/googleads-java-lib/3.2.0/com/google/api/ads/adwords/lib/selectorfields/v201609/cm/AdGroupCriterionField.html
CpcBid:
Max CPC (cost per click) bid. At the ad group level, this represents the default bid applicable for:
keyword targeting on search network.
keywords & placements for content targeting.

At the ad group criteria level, this is the max cpc bid.

Most advertisers are using automated bid strategies. Low priority. Advanced feature.

Only thing to do on a daily basis is searchterms.

Many people won't have huge campaigns/adgroups.
----------------------------------------------
